import uuid
from datetime import date, datetime

from decimal import Decimal

from sqlalchemy import CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, Numeric, SmallInteger, String, Text, Uuid
from sqlalchemy.orm import Mapped, mapped_column

from omega_core.constantes import en_lista
from omega_core.models.base import Base, ahora

ESTADOS_RECETA = ("EMITIDA", "DESPACHADA", "ANULADA")


def _fk(tabla: str, **kw):
    return mapped_column(Uuid, ForeignKey(f"{tabla}.id", ondelete="RESTRICT"), **kw)


class ClaveFirma(Base):
    """Par Ed25519 del médico. La privada solo existe cifrada con su PIN (scrypt + AES-GCM)."""

    __tablename__ = "clave_firma"
    persona_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"), primary_key=True)
    clave_publica: Mapped[str] = mapped_column(String(64))
    privada_cifrada: Mapped[str] = mapped_column(Text)
    huella: Mapped[str] = mapped_column(String(16))
    creada_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)


class Receta(Base):
    """Receta digital firmada. Inmutable salvo `estado` (EMITIDA → DESPACHADA | ANULADA), controlado por trigger."""

    __tablename__ = "receta"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    folio: Mapped[str] = mapped_column(String(20), unique=True)
    paciente_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    medico_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    institucion_id: Mapped[uuid.UUID] = _fk("institucion")
    atencion_id: Mapped[uuid.UUID] = _fk("atencion")
    emitida_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    vigente_hasta: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    estado: Mapped[str] = mapped_column(String(12), default="EMITIDA")
    token_hash: Mapped[str] = mapped_column(String(64))  # el token en claro solo se entrega una vez al emitir
    payload: Mapped[str] = mapped_column(Text)  # JSON canónico firmado
    hash_payload: Mapped[str] = mapped_column(String(64))
    firma: Mapped[str] = mapped_column(String(100))
    clave_publica: Mapped[str] = mapped_column(String(64))
    huella_clave: Mapped[str] = mapped_column(String(16))
    __table_args__ = (
        CheckConstraint(en_lista("estado", ESTADOS_RECETA), name="estado_valido"),
        CheckConstraint("vigente_hasta > emitida_en", name="vigencia_valida"),
    )


class RecetaItem(Base):
    __tablename__ = "receta_item"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    receta_id: Mapped[uuid.UUID] = _fk("receta", index=True)
    orden: Mapped[int] = mapped_column(SmallInteger)
    medicamento: Mapped[str] = mapped_column(String(120))
    presentacion: Mapped[str | None] = mapped_column(String(120))
    dosis: Mapped[str] = mapped_column(String(120))
    via: Mapped[str | None] = mapped_column(String(40))
    frecuencia: Mapped[str] = mapped_column(String(120))
    duracion_dias: Mapped[int] = mapped_column(Integer)
    cantidad: Mapped[int] = mapped_column(Integer)
    indicaciones: Mapped[str | None] = mapped_column(String(500))
    __table_args__ = (
        CheckConstraint("duracion_dias BETWEEN 1 AND 365 AND cantidad BETWEEN 1 AND 1000", name="rangos_validos"),
        Index("uq_receta_item_orden", "receta_id", "orden", unique=True),
    )


class Despacho(Base):
    """UNIQUE(receta_id) + trigger BEFORE INSERT con bloqueo de fila = una receta, un solo despacho, aunque haya peticiones simultáneas."""

    __tablename__ = "despacho"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    receta_id: Mapped[uuid.UUID] = _fk("receta", unique=True)
    farmacia_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    despachado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    responsable: Mapped[str | None] = mapped_column(String(150))
    observaciones: Mapped[str | None] = mapped_column(String(500))
    hash_receta: Mapped[str] = mapped_column(String(64))


# ---------------------------------------------------------------- Inventario por farmacia (Etapa 3B)
TIPOS_MOVIMIENTO = ("ENTRADA", "DESPACHO", "MERMA", "CORRECCION")


class Lote(Base):
    """Lote de un medicamento en UNA farmacia. `cantidad_actual` solo cambia por movimientos (CHECK ≥ 0; trigger bloquea el resto de columnas)."""

    __tablename__ = "lote"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    farmacia_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    medicamento: Mapped[str] = mapped_column(String(120))  # normalizado (minúsculas, sin tildes)
    presentacion: Mapped[str | None] = mapped_column(String(120))
    numero_lote: Mapped[str] = mapped_column(String(40))
    fecha_vencimiento: Mapped[date] = mapped_column(Date)  # vigente HASTA este día inclusive
    cantidad_inicial: Mapped[int] = mapped_column(Integer)
    cantidad_actual: Mapped[int] = mapped_column(Integer)
    precio_unitario: Mapped[Decimal | None] = mapped_column(Numeric(10, 2))  # opcional (USD por unidad); NULL = la farmacia no lo publica
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    __table_args__ = (
        CheckConstraint("cantidad_actual >= 0", name="stock_no_negativo"),
        CheckConstraint("precio_unitario IS NULL OR precio_unitario > 0", name="precio_positivo"),
        CheckConstraint("cantidad_inicial > 0", name="inicial_positiva"),
        Index("uq_lote_farmacia_med_numero", "farmacia_id", "medicamento", "numero_lote", unique=True),
        Index("ix_lote_fefo", "farmacia_id", "medicamento", "fecha_vencimiento"),
    )


class MovimientoInventario(Base):
    """Libro de movimientos append-only: toda variación de stock deja una fila con delta y saldo resultante."""

    __tablename__ = "movimiento_inventario"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    farmacia_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    lote_id: Mapped[uuid.UUID] = _fk("lote", index=True)
    tipo: Mapped[str] = mapped_column(String(12))
    delta: Mapped[int] = mapped_column(Integer)
    saldo: Mapped[int] = mapped_column(Integer)
    motivo: Mapped[str | None] = mapped_column(String(300))
    despacho_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("despacho.id", ondelete="RESTRICT"))
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    __table_args__ = (
        CheckConstraint(en_lista("tipo", TIPOS_MOVIMIENTO), name="tipo_valido"),
        CheckConstraint("delta <> 0 AND saldo >= 0", name="delta_valido"),
        CheckConstraint("(tipo = 'DESPACHO') = (despacho_id IS NOT NULL)", name="despacho_coherente"),
    )


class UmbralStock(Base):
    """Umbral de stock bajo configurable por farmacia y medicamento."""

    __tablename__ = "umbral_stock"
    farmacia_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("institucion.id", ondelete="RESTRICT"), primary_key=True)
    medicamento: Mapped[str] = mapped_column(String(120), primary_key=True)
    umbral: Mapped[int] = mapped_column(Integer)
    actualizado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    __table_args__ = (CheckConstraint("umbral >= 0", name="umbral_valido"),)
