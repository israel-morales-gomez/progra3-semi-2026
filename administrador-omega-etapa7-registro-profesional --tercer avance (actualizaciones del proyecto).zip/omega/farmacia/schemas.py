import uuid
from datetime import date, datetime
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field

from omega_core.schemas import DUI


class In(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")


class EnrolarFirmaIn(In):
    pin: Annotated[str, Field(min_length=6, max_length=64, description="PIN de firma (≥6 caracteres). Cifra su clave privada; no se almacena ni se puede recuperar.")]


class FirmaOut(BaseModel):
    huella: str
    clave_publica: str
    creada_en: datetime


class MedicamentoIn(In):
    medicamento: Annotated[str, Field(min_length=2, max_length=120, description="Principio activo (ej. 'amoxicilina').")]
    presentacion: Annotated[str, Field(max_length=120)] | None = Field(None, description="Ej. 'tabletas 500 mg'.")
    dosis: Annotated[str, Field(min_length=1, max_length=120)] = Field(description="Ej. '500 mg'.")
    via: Annotated[str, Field(max_length=40)] | None = Field(None, description="Ej. 'oral'.")
    frecuencia: Annotated[str, Field(min_length=1, max_length=120)] = Field(description="Ej. 'cada 8 horas'.")
    duracion_dias: Annotated[int, Field(ge=1, le=365)]
    cantidad: Annotated[int, Field(ge=1, le=1000, description="Unidades a despachar.")]
    indicaciones: Annotated[str, Field(max_length=500)] | None = None


class EmitirRecetaIn(In):
    dui: DUI = Field(description="DUI del paciente. Debe tener una atención abierta en su institución.")
    pin: Annotated[str, Field(min_length=6, max_length=64)] = Field(description="PIN de firma del médico.")
    vigencia_dias: Annotated[int, Field(ge=1, le=90)] = Field(30, description="Días de vigencia de la receta.")
    medicamentos: Annotated[list[MedicamentoIn], Field(min_length=1, max_length=15)]


class RecetaEmitidaOut(BaseModel):
    id: uuid.UUID
    folio: str
    token: str = Field(description="Token de canje. SE MUESTRA UNA SOLA VEZ: entréguelo al paciente; la farmacia lo exige junto con el folio.")
    emitida_en: datetime
    vigente_hasta: datetime
    huella_firma: str
    hash_payload: str
    medicamentos: list[MedicamentoIn]


class CanjeIn(In):
    folio: Annotated[str, Field(min_length=5, max_length=20)]
    token: Annotated[str, Field(min_length=8, max_length=40)]


class DespacharIn(CanjeIn):
    responsable: Annotated[str, Field(max_length=150)] | None = Field(None, description="Químico farmacéutico que despacha.")
    observaciones: Annotated[str, Field(max_length=500)] | None = None


class AlergiaRelevanteOut(BaseModel):
    sustancia: str
    severidad: str
    reaccion: str | None
    medicamentos_afectados: list[str]


class FirmaEstadoOut(BaseModel):
    valida: bool
    huella: str


class RecetaFarmaciaOut(BaseModel):
    """Vista mínima para despachar. NO incluye diagnósticos, notas, antecedentes ni signos vitales."""

    folio: str
    estado: str
    emitida_en: datetime
    vigente_hasta: datetime
    vigente: bool
    paciente_iniciales: str
    paciente_dui_parcial: str = Field(description="Solo los últimos dígitos, para cotejar con el documento presentado.")
    medico: str
    medicamentos: list[MedicamentoIn]
    alergias_relevantes: list[AlergiaRelevanteOut] = Field(description="Solo las alergias que chocan con los medicamentos de ESTA receta.")
    firma: FirmaEstadoOut
    apto_para_despacho: bool
    motivos_bloqueo: list[str]
    stock_faltante: list[dict] = Field(default_factory=list, description="Medicamentos sin existencias vigentes suficientes en SU inventario.")


class LoteDescontadoOut(BaseModel):
    medicamento: str
    numero_lote: str
    fecha_vencimiento: date
    cantidad: int


class DespachoOut(BaseModel):
    id: uuid.UUID
    folio: str
    despachado_en: datetime
    medicamentos: list[MedicamentoIn]
    lotes_descontados: list[LoteDescontadoOut] = Field(description="Lotes de los que se descontó, en orden FEFO.")

