"""Módulo farmacia: receta digital firmada, despacho único anti doble canje y bloqueo por alergias."""
