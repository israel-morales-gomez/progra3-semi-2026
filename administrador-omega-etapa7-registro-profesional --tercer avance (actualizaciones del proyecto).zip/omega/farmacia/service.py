import hashlib
import json
import secrets
import uuid
from datetime import datetime

from fastapi import HTTPException
from sqlalchemy import exists, select
from sqlalchemy.orm import Session, aliased

from core_expediente.models import Alergia
from omega_core.models.base import ahora

from . import firma as fx
from .alergias import choca
from .models import Receta, RecetaItem
from .schemas import AlergiaRelevanteOut, MedicamentoIn


def nuevo_token() -> str:
    t = "".join(secrets.choice("ABCDEFGHJKMNPQRSTUVWXYZ23456789") for _ in range(16))
    return "-".join(t[i:i + 4] for i in range(0, 16, 4))


def hash_token(token: str) -> str:
    return hashlib.sha256(token.replace("-", "").replace(" ", "").upper().encode()).hexdigest()


def payload_canonico(folio: str, paciente_id, medico_id, institucion_id, emitida_en: datetime, vigente_hasta: datetime,
                     items: list[MedicamentoIn]) -> bytes:
    cuerpo = {"folio": folio, "paciente": str(paciente_id), "medico": str(medico_id), "institucion": str(institucion_id),
              "emitida_en": emitida_en.isoformat(), "vigente_hasta": vigente_hasta.isoformat(),
              "medicamentos": [i.model_dump() for i in items]}
    return json.dumps(cuerpo, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def items_de(db: Session, receta_id: uuid.UUID) -> list[RecetaItem]:
    return list(db.scalars(select(RecetaItem).where(RecetaItem.receta_id == receta_id).order_by(RecetaItem.orden)))


def a_med(i: RecetaItem) -> MedicamentoIn:
    return MedicamentoIn(medicamento=i.medicamento, presentacion=i.presentacion, dosis=i.dosis, via=i.via, frecuencia=i.frecuencia,
                         duracion_dias=i.duracion_dias, cantidad=i.cantidad, indicaciones=i.indicaciones)


def alergias_relevantes(db: Session, paciente_id: uuid.UUID, items: list[RecetaItem]) -> list[AlergiaRelevanteOut]:
    """Lee SOLO sustancia/severidad/reacción de las alergias vigentes y activas, y devuelve únicamente las que chocan con la receta."""
    otra = aliased(Alergia)
    filas = db.execute(select(Alergia.sustancia, Alergia.severidad, Alergia.reaccion).where(
        Alergia.paciente_id == paciente_id, Alergia.estado == "ACTIVA",
        ~exists().where(otra.reemplaza_id == Alergia.id))).all()
    out = []
    for f in filas:
        afectados = [i.medicamento for i in items if choca(i.medicamento, f.sustancia)]
        if afectados:
            out.append(AlergiaRelevanteOut(sustancia=f.sustancia, severidad=f.severidad, reaccion=f.reaccion, medicamentos_afectados=afectados))
    return out


def firma_valida(r: Receta) -> bool:
    return hashlib.sha256(r.payload.encode()).hexdigest() == r.hash_payload and fx.verificar(r.clave_publica, r.payload.encode(), r.firma)


def iniciales(nombres: str, apellidos: str) -> str:
    return "".join(p[0].upper() + "." for p in (nombres + " " + apellidos).split() if p)


def buscar_receta(db: Session, folio: str, token: str, bloquear: bool = False) -> Receta:
    """El mismo 404 si el folio no existe o el token no corresponde (no se puede sondear folios)."""
    q = select(Receta).where(Receta.folio == folio.strip().upper())
    r = db.scalar(q.with_for_update() if bloquear else q)
    if r is None or not secrets.compare_digest(r.token_hash, hash_token(token)):
        raise HTTPException(404, "Receta no encontrada o token incorrecto")
    return r


def motivos_bloqueo(r: Receta, firma_ok: bool, choques: list[AlergiaRelevanteOut]) -> list[str]:
    m = []
    if r.estado == "DESPACHADA":
        m.append("RECETA_YA_DESPACHADA")
    elif r.estado == "ANULADA":
        m.append("RECETA_ANULADA")
    if r.vigente_hasta <= ahora():
        m.append("RECETA_VENCIDA")
    if not firma_ok:
        m.append("FIRMA_INVALIDA")
    if choques:
        m.append("ALERGIA_CONFLICTO")
    return m


def nuevo_folio_rx() -> str:
    return f"RX-{secrets.token_hex(5).upper()}"
