"""Inventario por farmacia: lotes, FEFO (primero en vencer, primero en salir), existencias y alertas."""
import uuid
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from core_expediente.constantes import normalizar_texto
from omega_core.models.base import ahora

from .models import Lote, MovimientoInventario, RecetaItem, UmbralStock
from .schemas_inventario import ExistenciaOut, LoteOut

_SV = timezone(timedelta(hours=-6))  # El Salvador no tiene horario de verano


def hoy() -> date:
    return datetime.now(_SV).date()


def norm(medicamento: str) -> str:
    return normalizar_texto(medicamento)


def estado_lote(l: Lote, dias_alerta: int = 30) -> str:
    if l.cantidad_actual == 0:
        return "AGOTADO"
    if l.fecha_vencimiento < hoy():
        return "VENCIDO"
    return "POR_VENCER" if (l.fecha_vencimiento - hoy()).days <= dias_alerta else "VIGENTE"


def lote_out(l: Lote, dias_alerta: int = 30) -> LoteOut:
    return LoteOut(id=l.id, medicamento=l.medicamento, presentacion=l.presentacion, numero_lote=l.numero_lote, fecha_vencimiento=l.fecha_vencimiento,
                   cantidad_inicial=l.cantidad_inicial, cantidad_actual=l.cantidad_actual, precio_unitario=l.precio_unitario, estado=estado_lote(l, dias_alerta),
                   dias_para_vencer=(l.fecha_vencimiento - hoy()).days, creado_en=l.creado_en)


def lote_propio(db: Session, farmacia_id: uuid.UUID, lote_id: uuid.UUID, bloquear: bool = False) -> Lote:
    """Siempre filtra por farmacia: un lote ajeno responde igual que uno inexistente (404)."""
    q = select(Lote).where(Lote.id == lote_id, Lote.farmacia_id == farmacia_id)
    l = db.scalar(q.with_for_update() if bloquear else q)
    if l is None:
        raise HTTPException(404, "Lote no encontrado en su inventario")
    return l


def movimiento(db: Session, l: Lote, tipo: str, delta: int, motivo: str | None = None, despacho_id=None) -> MovimientoInventario:
    l.cantidad_actual += delta
    m = MovimientoInventario(farmacia_id=l.farmacia_id, lote_id=l.id, tipo=tipo, delta=delta, saldo=l.cantidad_actual, motivo=motivo, despacho_id=despacho_id)
    db.add(m)
    return m


def plan_fefo(db: Session, farmacia_id: uuid.UUID, items: list[RecetaItem], bloquear: bool = False):
    """Asigna cada medicamento a los lotes VIGENTES que vencen primero. Devuelve (asignaciones[(Lote, cantidad)], faltantes).
    Con `bloquear` toma SELECT … FOR UPDATE de los lotes en orden determinista (medicamento, vencimiento, id) para evitar interbloqueos."""
    requerido: dict[str, int] = defaultdict(int)
    for it in items:
        requerido[norm(it.medicamento)] += it.cantidad
    h, asignaciones, faltantes = hoy(), [], []
    for med in sorted(requerido):
        q = select(Lote).where(Lote.farmacia_id == farmacia_id, Lote.medicamento == med, Lote.cantidad_actual > 0).order_by(Lote.fecha_vencimiento, Lote.id)
        lotes = list(db.scalars(q.with_for_update() if bloquear else q))
        vigentes = [l for l in lotes if l.fecha_vencimiento >= h]
        vencido = sum(l.cantidad_actual for l in lotes if l.fecha_vencimiento < h)
        falta = requerido[med]
        for l in vigentes:
            if falta == 0:
                break
            toma = min(l.cantidad_actual, falta)
            asignaciones.append((l, toma))
            falta -= toma
        if falta > 0:
            faltantes.append({"medicamento": med, "requerido": requerido[med], "disponible": sum(l.cantidad_actual for l in vigentes), "vencido_no_utilizable": vencido})
    return asignaciones, faltantes


def motivos_stock(faltantes: list[dict]) -> list[str]:
    m = []
    if faltantes:
        m.append("STOCK_INSUFICIENTE")
        if any(f["vencido_no_utilizable"] for f in faltantes):
            m.append("LOTE_VENCIDO")
    return m


def existencias(db: Session, farmacia_id: uuid.UUID, dias_alerta: int = 30) -> list[ExistenciaOut]:
    h = hoy()
    filas = db.execute(select(
        Lote.medicamento,
        func.coalesce(func.sum(Lote.cantidad_actual).filter(Lote.fecha_vencimiento >= h), 0),
        func.coalesce(func.sum(Lote.cantidad_actual).filter(Lote.fecha_vencimiento < h), 0),
        func.count().filter(Lote.fecha_vencimiento >= h, Lote.cantidad_actual > 0),
        func.min(Lote.fecha_vencimiento).filter(Lote.fecha_vencimiento >= h, Lote.cantidad_actual > 0),
    ).where(Lote.farmacia_id == farmacia_id).group_by(Lote.medicamento)).all()
    umbrales = {u.medicamento: u.umbral for u in db.scalars(select(UmbralStock).where(UmbralStock.farmacia_id == farmacia_id))}
    out = {f[0]: ExistenciaOut(medicamento=f[0], stock_vigente=int(f[1]), stock_vencido=int(f[2]), lotes_vigentes=f[3], proximo_vencimiento=f[4],
                               umbral=umbrales.get(f[0]), stock_bajo=False) for f in filas}
    for med, u in umbrales.items():  # medicamento con umbral pero sin lotes: stock 0
        out.setdefault(med, ExistenciaOut(medicamento=med, stock_vigente=0, stock_vencido=0, lotes_vigentes=0, proximo_vencimiento=None, umbral=u, stock_bajo=False))
    for e in out.values():
        e.stock_bajo = e.umbral is not None and e.stock_vigente <= e.umbral
    return sorted(out.values(), key=lambda e: e.medicamento)
