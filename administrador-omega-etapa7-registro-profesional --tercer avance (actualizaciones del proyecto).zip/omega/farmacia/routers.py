import hashlib
import uuid
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from core_expediente.deps import Profesional, medico_activo
from core_expediente.models import Atencion
from core_expediente.service import dui_o_422, esta_congelado, identidad_minima
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Institucion, Persona
from omega_core.models.base import ahora
from omega_core.security.ratelimit import comprobar_bloqueo, ip_cliente, limitador, limitar_ip

from . import firma as fx
from . import inventario as inv
from . import service
from .deps import farmacia_actual
from .models import ClaveFirma, Despacho, Receta, RecetaItem
from .schemas import (
    CanjeIn, DespacharIn, DespachoOut, EmitirRecetaIn, EnrolarFirmaIn, FirmaEstadoOut, FirmaOut, LoteDescontadoOut, RecetaEmitidaOut,
    RecetaFarmaciaOut,
)

medico_router = APIRouter(tags=["farmacia · receta digital (médico)"])
farmacia_router = APIRouter(prefix="/farmacia", tags=["farmacia · canje y despacho (farmacia)"])
ERR_M = {401: {"description": "No autenticado / PIN incorrecto"}, 403: {"description": "Sin acceso al paciente o no es médico verificado"},
         409: {"description": "Estado no válido (sin firma enrolada, atención fuera de fase, …)"}, 423: {"description": "DUI congelado por fallecimiento"},
         429: {"description": "Demasiados intentos de PIN"}}
ERR_F = {404: {"description": "Receta no encontrada o token incorrecto (mismo mensaje en ambos casos)"},
         409: {"description": "Bloqueada: ya despachada, vencida, anulada, firma inválida o conflicto con alergias"},
         423: {"description": "Paciente fallecido"}, 429: {"description": "Demasiados intentos"}}


# ------------------------------------------------------------------ Médico
@medico_router.post("/farmacia/firma/enrolar", response_model=FirmaOut, status_code=201, responses=ERR_M, summary="Crear mi clave de firma de recetas",
                    description="Genera un par Ed25519. La clave privada se guarda cifrada con su PIN (scrypt + AES-GCM); el PIN no se almacena. Una sola vez por médico.")
def enrolar(datos: EnrolarFirmaIn, request: Request, med: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    if db.get(ClaveFirma, med.persona.id) is not None:
        raise HTTPException(409, "Ya tiene una clave de firma enrolada")
    pub, priv, huella = fx.generar_par(datos.pin)
    c = ClaveFirma(persona_id=med.persona.id, clave_publica=pub, privada_cifrada=priv, huella=huella)
    db.add(c)
    db.commit()
    auditar("FIRMA_ENROLADA", actor_tipo="persona", actor_id=med.persona.id, recurso="clave_firma", recurso_id=med.persona.id,
            ip=ip_cliente(request), detalle={"huella": huella})
    return FirmaOut(huella=huella, clave_publica=pub, creada_en=c.creada_en)


@medico_router.post("/recetas", response_model=RecetaEmitidaOut, status_code=201, responses=ERR_M, summary="Emitir una receta digital firmada",
                    description="Requiere médico verificado, **atención abierta (fase 3 o 4) del paciente en su institución** y su PIN de firma. "
                                "Se firma el contenido (Ed25519) y se genera un **token de canje** que se muestra una sola vez. "
                                "**No se puede emitir si el DUI está congelado por fallecimiento (423).** Queda en la bitácora.")
def emitir(datos: EmitirRecetaIn, request: Request, med: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    return emitir_receta(db, med, datos, ip_cliente(request))


def emitir_receta(db: Session, med: Profesional, datos: EmitirRecetaIn, ip: str, *, antes_commit=None, auditoria_extra: dict | None = None) -> RecetaEmitidaOut:
    """Emite y firma una receta a nombre de `med`. `antes_commit(db, receta)` corre en la MISMA transacción (lo usa la co-firma de borradores de estudiantes)."""
    yo = med.persona.id

    def denegar(codigo: int, msg: str, motivo: str, pid=None):
        auditar("RECETA_EMISION_DENEGADA", actor_tipo="persona", actor_id=yo, recurso="receta", resultado="FALLO", ip=ip,
                detalle={"motivo": motivo, "paciente_id": pid})
        raise HTTPException(codigo, msg)

    ident = identidad_minima(db, dui_o_422(datos.dui))
    if ident is None:
        denegar(403, "Sin acceso a este paciente", "PACIENTE_NO_ACCESIBLE")
    if esta_congelado(db, ident.id):
        denegar(423, "Expediente congelado: el paciente figura como fallecido. No se pueden emitir recetas.", "DUI_CONGELADO", ident.id)
    at = db.execute(select(Atencion.id, Atencion.fase).where(Atencion.paciente_id == ident.id, Atencion.institucion_id == med.institucion_id,
                                                             Atencion.estado == "ABIERTA")).first()
    if at is None:
        denegar(403, "Sin acceso a este paciente: requiere atención activa en su institución", "SIN_ATENCION_ACTIVA", ident.id)
    if at.fase not in (3, 4):
        denegar(409, "La receta se emite durante la ejecución o la trazabilidad de la atención (fase 3 o 4)", "FASE_INVALIDA", ident.id)
    clave = db.get(ClaveFirma, yo)
    if clave is None:
        raise HTTPException(409, "Primero enrole su clave de firma (POST /farmacia/firma/enrolar)")
    bloqueo = f"pin:{yo}"
    comprobar_bloqueo(bloqueo)

    folio, emitida, vence = service.nuevo_folio_rx(), ahora(), ahora() + timedelta(days=datos.vigencia_dias)
    payload = service.payload_canonico(folio, ident.id, yo, med.institucion_id, emitida, vence, datos.medicamentos)
    try:
        firma = fx.firmar(clave.privada_cifrada, datos.pin, payload)
    except fx.PinIncorrecto:
        limitador.fallo(bloqueo)
        auditar("FIRMA_PIN_INCORRECTO", actor_tipo="persona", actor_id=yo, recurso="clave_firma", recurso_id=yo, resultado="FALLO", ip=ip)
        raise HTTPException(401, "PIN de firma incorrecto")
    limitador.exito(bloqueo)

    token = service.nuevo_token()
    r = Receta(folio=folio, paciente_id=ident.id, medico_id=yo, institucion_id=med.institucion_id, atencion_id=at.id, emitida_en=emitida,
               vigente_hasta=vence, token_hash=service.hash_token(token), payload=payload.decode(), hash_payload=hashlib.sha256(payload).hexdigest(),
               firma=firma, clave_publica=clave.clave_publica, huella_clave=clave.huella)
    db.add(r)
    db.flush()
    for n, m in enumerate(datos.medicamentos, 1):
        db.add(RecetaItem(receta_id=r.id, orden=n, **m.model_dump()))
    if antes_commit is not None:
        antes_commit(db, r)
    db.commit()
    auditar("RECETA_EMITIDA", actor_tipo="persona", actor_id=yo, recurso="receta", recurso_id=r.id, ip=ip,
            detalle={"folio": folio, "paciente_id": ident.id, "medicamentos": len(datos.medicamentos), "vigente_hasta": vence,
                     "huella_firma": clave.huella, "hash_payload": r.hash_payload, **(auditoria_extra or {})})
    return RecetaEmitidaOut(id=r.id, folio=folio, token=token, emitida_en=emitida, vigente_hasta=vence, huella_firma=clave.huella,
                            hash_payload=r.hash_payload, medicamentos=datos.medicamentos)


# ------------------------------------------------------------------ Farmacia
def _abrir(db: Session, farm: Institucion, datos: CanjeIn, request: Request, bloquear: bool) -> Receta:
    """Autentica el canje (folio + token) con límite de intentos por IP, por folio y por farmacia."""
    limitar_ip(request, "receta_canje", 60)
    folio = datos.folio.strip().upper()
    for k in (f"receta:{folio}", f"farmacia:{farm.id}"):
        comprobar_bloqueo(k)
    try:
        return service.buscar_receta(db, folio, datos.token, bloquear=bloquear)
    except HTTPException:
        for k in (f"receta:{folio}", f"farmacia:{farm.id}"):
            limitador.fallo(k)
        auditar("RECETA_CANJE_FALLIDO", actor_tipo="institucion", actor_id=farm.id, recurso="receta", resultado="FALLO", ip=ip_cliente(request),
                detalle={"folio": folio})
        raise


def _vista(db: Session, r: Receta, farm: Institucion, bloquear: bool = False):
    items = service.items_de(db, r.id)
    choques = service.alergias_relevantes(db, r.paciente_id, items)
    ok = service.firma_valida(r)
    asignaciones, faltantes = inv.plan_fefo(db, farm.id, items, bloquear=bloquear)
    motivos = service.motivos_bloqueo(r, ok, choques) + inv.motivos_stock(faltantes)
    return items, choques, ok, motivos, asignaciones, faltantes


@farmacia_router.post("/recetas/consulta", response_model=RecetaFarmaciaOut, responses=ERR_F, summary="Consultar una receta para despacharla",
                      description="Se identifica con **folio + token** (POST para que el token no viaje en la URL). Devuelve **solo lo necesario para despachar**: "
                                  "medicamentos y dosis, iniciales y DUI parcial del paciente, validez de la firma y **únicamente las alergias que chocan con esta receta**. "
                                  "Nunca diagnósticos, notas SOAP, antecedentes ni signos vitales.")
def consultar(datos: CanjeIn, request: Request, farm: Institucion = Depends(farmacia_actual), db: Session = Depends(get_db)):
    r = _abrir(db, farm, datos, request, bloquear=False)
    items, choques, _, motivos, _, faltantes = _vista(db, r, farm)
    pac = db.execute(select(Persona.nombres, Persona.apellidos, Persona.dui).where(Persona.id == r.paciente_id)).one()
    med = db.execute(select(Persona.nombres, Persona.apellidos).where(Persona.id == r.medico_id)).one()
    auditar("RECETA_CONSULTADA", actor_tipo="institucion", actor_id=farm.id, recurso="receta", recurso_id=r.id, ip=ip_cliente(request),
            detalle={"folio": r.folio, "apto": not motivos, "motivos": motivos})
    return RecetaFarmaciaOut(
        folio=r.folio, estado=r.estado, emitida_en=r.emitida_en, vigente_hasta=r.vigente_hasta, vigente=r.estado == "EMITIDA" and r.vigente_hasta > ahora(),
        paciente_iniciales=service.iniciales(pac.nombres, pac.apellidos), paciente_dui_parcial="****" + pac.dui[-5:],
        medico=f"{med.nombres} {med.apellidos}", medicamentos=[service.a_med(i) for i in items], alergias_relevantes=choques,
        firma=FirmaEstadoOut(valida=service.firma_valida(r), huella=r.huella_clave), apto_para_despacho=not motivos, motivos_bloqueo=motivos,
        stock_faltante=[{k: f[k] for k in ('medicamento', 'requerido', 'disponible')} for f in faltantes])


@farmacia_router.post("/recetas/despachar", response_model=DespachoOut, status_code=201, responses=ERR_F, summary="Despachar una receta (una sola vez)",
                      description="**Anti doble canje a nivel de base de datos**: se bloquea la fila de la receta (`SELECT … FOR UPDATE`), `despacho.receta_id` es UNIQUE y un trigger de "
                                  "PostgreSQL rechaza el INSERT si la receta no está EMITIDA o venció. Con peticiones simultáneas, exactamente una tiene éxito y las demás reciben 409. "
                                  "**Se bloquea automáticamente** si algún medicamento choca con las alergias vigentes del paciente (sin anulación posible desde farmacia), "
                                  "si la firma no valida, si venció o si el paciente falleció. Cada intento queda en la bitácora.")
def despachar(datos: DespacharIn, request: Request, farm: Institucion = Depends(farmacia_actual), db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    r = _abrir(db, farm, datos, request, bloquear=True)  # la fila queda bloqueada hasta el commit/rollback
    if esta_congelado(db, r.paciente_id):
        db.rollback()
        auditar("RECETA_DESPACHO_BLOQUEADO", actor_tipo="institucion", actor_id=farm.id, recurso="receta", recurso_id=r.id, resultado="FALLO", ip=ip,
                detalle={"folio": r.folio, "motivos": ["PACIENTE_FALLECIDO"]})
        raise HTTPException(423, "El paciente figura como fallecido: no se puede despachar")
    items, choques, _, motivos, asignaciones, faltantes = _vista(db, r, farm, bloquear=True)  # además bloquea los lotes (FOR UPDATE)
    if motivos:
        folio, rid = r.folio, r.id
        db.rollback()
        auditar("RECETA_DESPACHO_BLOQUEADO", actor_tipo="institucion", actor_id=farm.id, recurso="receta", recurso_id=rid, resultado="FALLO", ip=ip,
                detalle={"folio": folio, "motivos": motivos, "alergias": [c.model_dump() for c in choques], "stock_faltante": faltantes})
        raise HTTPException(409, {"mensaje": "Despacho bloqueado", "motivos": motivos, "alergias_relevantes": [c.model_dump() for c in choques],
                                  "stock_faltante": faltantes})
    d = Despacho(receta_id=r.id, farmacia_id=farm.id, responsable=datos.responsable, observaciones=datos.observaciones, hash_receta=r.hash_payload)
    rid, folio = r.id, r.folio
    db.add(d)
    try:
        db.flush()  # el trigger despacho_guard valida y marca la receta DESPACHADA
        for lote, cantidad in asignaciones:  # FEFO: los lotes ya vienen ordenados por vencimiento
            inv.movimiento(db, lote, "DESPACHO", -cantidad, f"Despacho {folio}", despacho_id=d.id)
        db.commit()
    except IntegrityError:
        db.rollback()
        auditar("RECETA_DESPACHO_BLOQUEADO", actor_tipo="institucion", actor_id=farm.id, recurso="receta", recurso_id=rid, resultado="FALLO", ip=ip,
                detalle={"folio": folio, "motivos": ["RECETA_YA_DESPACHADA"]})
        raise HTTPException(409, {"mensaje": "Despacho bloqueado", "motivos": ["RECETA_YA_DESPACHADA"], "alergias_relevantes": [], "stock_faltante": []})
    descontados = [LoteDescontadoOut(medicamento=l.medicamento, numero_lote=l.numero_lote, fecha_vencimiento=l.fecha_vencimiento, cantidad=c) for l, c in asignaciones]
    auditar("RECETA_DESPACHADA", actor_tipo="institucion", actor_id=farm.id, recurso="receta", recurso_id=rid, ip=ip,
            detalle={"folio": folio, "despacho_id": d.id, "medicamentos": len(items)})
    auditar("INVENTARIO_DESCUENTO_DESPACHO", actor_tipo="institucion", actor_id=farm.id, recurso="inventario", recurso_id=d.id, ip=ip,
            detalle={"folio": folio, "lotes": [x.model_dump() for x in descontados]})
    return DespachoOut(id=d.id, folio=folio, despachado_en=d.despachado_en, medicamentos=[service.a_med(i) for i in items], lotes_descontados=descontados)


from .router_inventario import router as inventario_router  # noqa: E402

routers = [medico_router, farmacia_router, inventario_router]
