"""Choque medicamento-alergia. Diccionario de clases terapéuticas (ampliable); texto normalizado sin tildes."""
import re

from core_expediente.constantes import normalizar_texto

CLASES: dict[str, set[str]] = {
    "penicilinas": {"penicilina", "amoxicilina", "ampicilina", "dicloxacilina", "oxacilina", "piperacilina", "cloxacilina", "benzatinica", "clavulanico"},
    "cefalosporinas": {"cefalexina", "cefazolina", "ceftriaxona", "cefuroxima", "cefixima", "cefotaxima", "ceftazidima", "cefadroxilo", "cefepime"},
    "sulfonamidas": {"sulfametoxazol", "sulfadiazina", "cotrimoxazol", "sulfasalazina", "sulfacetamida"},
    "aines": {"ibuprofeno", "naproxeno", "diclofenaco", "ketorolaco", "aspirina", "acido acetilsalicilico", "indometacina", "meloxicam",
              "piroxicam", "ketoprofeno", "celecoxib", "etoricoxib", "nimesulida"},
    "macrolidos": {"azitromicina", "claritromicina", "eritromicina"},
    "quinolonas": {"ciprofloxacino", "levofloxacino", "norfloxacino", "moxifloxacino", "ofloxacino"},
    "opioides": {"morfina", "codeina", "tramadol", "fentanilo", "oxicodona", "metadona", "meperidina"},
    "tetraciclinas": {"doxiciclina", "tetraciclina", "minociclina"},
}
CLASES["betalactamicos"] = CLASES["penicilinas"] | CLASES["cefalosporinas"]
ALIAS = {
    "penicilina": "penicilinas", "penicilinas": "penicilinas", "cefalosporina": "cefalosporinas", "sulfa": "sulfonamidas", "sulfas": "sulfonamidas",
    "sulfamidas": "sulfonamidas", "sulfonamida": "sulfonamidas", "aine": "aines", "antiinflamatorios no esteroideos": "aines",
    "antiinflamatorios": "aines", "macrolido": "macrolidos", "quinolona": "quinolonas", "opioide": "opioides", "tetraciclina": "tetraciclinas",
    "betalactamico": "betalactamicos", "betalactamicos": "betalactamicos", "cefalosporinas": "cefalosporinas",
}


def _contiene(texto: str, termino: str) -> bool:
    return re.search(rf"(?<![a-z0-9]){re.escape(termino)}(?![a-z0-9])", texto) is not None


def choca(medicamento: str, sustancia_alergia: str) -> bool:
    """True si el medicamento es la sustancia alergénica, la contiene, o pertenece a la clase a la que el paciente es alérgico."""
    med, alg = normalizar_texto(medicamento), normalizar_texto(sustancia_alergia)
    if not med or not alg:
        return False
    if _contiene(med, alg) or _contiene(alg, med):
        return True
    clase = ALIAS.get(alg) or (alg if alg in CLASES else None)
    return clase is not None and any(_contiene(med, m) for m in CLASES[clase])
