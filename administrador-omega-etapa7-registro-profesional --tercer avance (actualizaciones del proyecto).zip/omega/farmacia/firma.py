"""Firma digital del médico: Ed25519. La clave privada se guarda cifrada (scrypt + AES-GCM) con un PIN que solo conoce el médico."""
import base64
import hashlib
import os

from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

_AAD = b"omega-firma-receta-v1"
_RAW = dict(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)


class PinIncorrecto(Exception):
    pass


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode()


def _clave(pin: str, salt: bytes) -> bytes:
    return Scrypt(salt=salt, length=32, n=2**15, r=8, p=1).derive(pin.encode())


def generar_par(pin: str) -> tuple[str, str, str]:
    """-> (clave_publica_b64, privada_cifrada_b64, huella)."""
    priv = Ed25519PrivateKey.generate()
    raw = priv.private_bytes(encoding=serialization.Encoding.Raw, format=serialization.PrivateFormat.Raw,
                             encryption_algorithm=serialization.NoEncryption())
    salt, nonce = os.urandom(16), os.urandom(12)
    cifrada = salt + nonce + AESGCM(_clave(pin, salt)).encrypt(nonce, raw, _AAD)
    pub = priv.public_key().public_bytes(**_RAW)
    return _b64(pub), _b64(cifrada), huella(_b64(pub))


def huella(clave_publica_b64: str) -> str:
    return hashlib.sha256(base64.b64decode(clave_publica_b64)).hexdigest()[:16].upper()


def firmar(privada_cifrada_b64: str, pin: str, mensaje: bytes) -> str:
    datos = base64.b64decode(privada_cifrada_b64)
    salt, nonce, ct = datos[:16], datos[16:28], datos[28:]
    try:
        raw = AESGCM(_clave(pin, salt)).decrypt(nonce, ct, _AAD)
    except InvalidTag:
        raise PinIncorrecto()
    return _b64(Ed25519PrivateKey.from_private_bytes(raw).sign(mensaje))


def verificar(clave_publica_b64: str, mensaje: bytes, firma_b64: str) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(clave_publica_b64)).verify(base64.b64decode(firma_b64), mensaje)
        return True
    except (InvalidSignature, ValueError):
        return False
