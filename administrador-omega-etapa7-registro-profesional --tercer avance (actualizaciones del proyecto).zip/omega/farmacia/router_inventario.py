import uuid
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Institucion
from omega_core.models.base import ahora
from omega_core.security.ratelimit import ip_cliente

from . import inventario as inv
from .deps import farmacia_actual
from .models import Lote, MovimientoInventario, UmbralStock
from .schemas_inventario import AjusteIn, AlertasOut, ExistenciaOut, LoteIn, LoteOut, MovimientoOut, UmbralIn

router = APIRouter(prefix="/farmacia/inventario", tags=["farmacia · inventario (solo la propia farmacia)"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Solo farmacias activas"}, 404: {"description": "Lote no encontrado en su inventario (también si es de otra farmacia)"}}


def _aud(accion: str, farm: Institucion, request: Request, recurso_id, detalle: dict, resultado: str = "OK"):
    auditar(accion, actor_tipo="institucion", actor_id=farm.id, recurso="inventario", recurso_id=recurso_id, ip=ip_cliente(request), detalle=detalle, resultado=resultado)


@router.post("/lotes", response_model=LoteOut, status_code=201, responses={**ERR, 409: {"description": "Ya existe ese número de lote para ese medicamento (use un ajuste ENTRADA)"}},
             summary="Registrar un lote (entrada de mercadería)",
             description="Crea el lote en **su** inventario con fecha de vencimiento. No se aceptan lotes ya vencidos. Genera un movimiento ENTRADA y queda en la bitácora.")
def crear_lote(datos: LoteIn, request: Request, farm: Institucion = Depends(farmacia_actual), db: Session = Depends(get_db)):
    if datos.fecha_vencimiento < inv.hoy():
        raise HTTPException(422, "No se pueden ingresar lotes vencidos")
    l = Lote(farmacia_id=farm.id, medicamento=inv.norm(datos.medicamento), presentacion=datos.presentacion, numero_lote=datos.numero_lote,
             fecha_vencimiento=datos.fecha_vencimiento, cantidad_inicial=datos.cantidad, cantidad_actual=0, precio_unitario=datos.precio_unitario)
    db.add(l)
    try:
        db.flush()
        inv.movimiento(db, l, "ENTRADA", datos.cantidad, "Ingreso inicial del lote")
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Ya existe un lote con ese número para ese medicamento")
    _aud("INVENTARIO_LOTE_REGISTRADO", farm, request, l.id, {"medicamento": l.medicamento, "lote": l.numero_lote, "vence": l.fecha_vencimiento, "cantidad": datos.cantidad})
    return inv.lote_out(l)


@router.get("/lotes", response_model=list[LoteOut], responses=ERR, summary="Mis lotes (orden FEFO)",
            description="Solo lotes de su farmacia, ordenados por vencimiento. Filtros por medicamento y estado.")
def listar(medicamento: str | None = None, estado: Literal["VIGENTE", "POR_VENCER", "VENCIDO", "AGOTADO"] | None = None, dias_alerta: int = Query(30, ge=1, le=365),
           limite: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0), farm: Institucion = Depends(farmacia_actual), db: Session = Depends(get_db)):
    q = select(Lote).where(Lote.farmacia_id == farm.id).order_by(Lote.fecha_vencimiento, Lote.id)
    if medicamento:
        q = q.where(Lote.medicamento == inv.norm(medicamento))
    out = [inv.lote_out(l, dias_alerta) for l in db.scalars(q)]
    if estado:
        out = [o for o in out if o.estado == estado]
    return out[offset:offset + limite]


@router.get("/lotes/{lote_id}", response_model=LoteOut, responses=ERR, summary="Detalle de un lote propio")
def detalle(lote_id: uuid.UUID, farm: Institucion = Depends(farmacia_actual), db: Session = Depends(get_db)):
    return inv.lote_out(inv.lote_propio(db, farm.id, lote_id))


@router.get("/lotes/{lote_id}/movimientos", response_model=list[MovimientoOut], responses=ERR, summary="Libro de movimientos de un lote propio")
def movimientos(lote_id: uuid.UUID, farm: Institucion = Depends(farmacia_actual), db: Session = Depends(get_db)):
    inv.lote_propio(db, farm.id, lote_id)
    filas = db.scalars(select(MovimientoInventario).where(MovimientoInventario.lote_id == lote_id, MovimientoInventario.farmacia_id == farm.id)
                       .order_by(MovimientoInventario.creado_en, MovimientoInventario.id))
    return [MovimientoOut(id=m.id, tipo=m.tipo, delta=m.delta, saldo=m.saldo, motivo=m.motivo, despacho_id=m.despacho_id, creado_en=m.creado_en) for m in filas]


@router.post("/lotes/{lote_id}/ajustes", response_model=LoteOut, responses={**ERR, 409: {"description": "El ajuste dejaría el stock en negativo"}},
             summary="Ajustar el stock de un lote propio",
             description="ENTRADA (+), MERMA (−, p. ej. daño o vencimiento) o CORRECCION (fija el saldo contado). Exige motivo. Bloquea la fila del lote, deja un movimiento inmutable y queda en la bitácora.")
def ajustar(lote_id: uuid.UUID, datos: AjusteIn, request: Request, farm: Institucion = Depends(farmacia_actual), db: Session = Depends(get_db)):
    l = inv.lote_propio(db, farm.id, lote_id, bloquear=True)
    antes = l.cantidad_actual
    if datos.tipo == "CORRECCION":
        delta = datos.cantidad - antes
        if delta == 0:
            raise HTTPException(422, "El saldo contado coincide con el actual: no hay nada que corregir")
    else:
        if datos.cantidad < 1:
            raise HTTPException(422, "La cantidad debe ser al menos 1")
        delta = datos.cantidad if datos.tipo == "ENTRADA" else -datos.cantidad
    if antes + delta < 0:
        db.rollback()
        raise HTTPException(409, f"El ajuste dejaría el stock en negativo (actual: {antes})")
    inv.movimiento(db, l, datos.tipo, delta, datos.motivo)
    db.commit()
    _aud("INVENTARIO_AJUSTE", farm, request, l.id, {"medicamento": l.medicamento, "lote": l.numero_lote, "tipo": datos.tipo, "delta": delta,
                                                    "antes": antes, "despues": l.cantidad_actual, "motivo": datos.motivo})
    return inv.lote_out(l)


@router.put("/umbrales/{medicamento}", response_model=ExistenciaOut, responses=ERR, summary="Configurar el umbral de stock bajo de un medicamento",
            description="Umbral propio de su farmacia. La alerta se activa cuando el stock **vigente** (sin lotes vencidos) es ≤ umbral.")
def fijar_umbral(medicamento: str, datos: UmbralIn, request: Request, farm: Institucion = Depends(farmacia_actual), db: Session = Depends(get_db)):
    med = inv.norm(medicamento)
    if len(med) < 2:
        raise HTTPException(422, "Medicamento inválido")
    u = db.get(UmbralStock, (farm.id, med))
    antes = u.umbral if u else None
    if u is None:
        db.add(UmbralStock(farmacia_id=farm.id, medicamento=med, umbral=datos.umbral))
    else:
        u.umbral, u.actualizado_en = datos.umbral, ahora()
    db.commit()
    _aud("INVENTARIO_UMBRAL_CONFIGURADO", farm, request, med, {"medicamento": med, "antes": antes, "despues": datos.umbral})
    return next(e for e in inv.existencias(db, farm.id) if e.medicamento == med)


@router.get("/existencias", response_model=list[ExistenciaOut], responses=ERR, summary="Existencias por medicamento",
            description="Stock vigente y vencido, lotes vigentes, próximo vencimiento y estado de alerta por umbral.")
def listar_existencias(farm: Institucion = Depends(farmacia_actual), db: Session = Depends(get_db)):
    return inv.existencias(db, farm.id)


@router.get("/alertas", response_model=AlertasOut, responses=ERR, summary="Alertas: stock bajo y lotes por vencer",
            description="**stock_bajo**: medicamentos con umbral configurado cuyo stock vigente ≤ umbral. **lotes_por_vencer**: lotes con stock que vencen en `dias` o menos. "
                        "**lotes_vencidos_con_stock**: lotes ya vencidos que aún tienen unidades (no se despachan; registre la MERMA).")
def alertas(dias: int = Query(30, ge=1, le=365), farm: Institucion = Depends(farmacia_actual), db: Session = Depends(get_db)):
    lotes = [inv.lote_out(l, dias) for l in db.scalars(select(Lote).where(Lote.farmacia_id == farm.id, Lote.cantidad_actual > 0).order_by(Lote.fecha_vencimiento, Lote.id))]
    return AlertasOut(generado_en=ahora(), dias_alerta_vencimiento=dias, stock_bajo=[e for e in inv.existencias(db, farm.id, dias) if e.stock_bajo],
                      lotes_por_vencer=[l for l in lotes if l.estado == "POR_VENCER"], lotes_vencidos_con_stock=[l for l in lotes if l.estado == "VENCIDO"])
