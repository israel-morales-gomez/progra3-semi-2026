import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .schemas import In


class LoteIn(In):
    medicamento: Annotated[str, Field(min_length=2, max_length=120, description="Principio activo; debe coincidir con el de las recetas (ej. 'amoxicilina').")]
    presentacion: Annotated[str, Field(max_length=120)] | None = None
    numero_lote: Annotated[str, Field(min_length=1, max_length=40)]
    fecha_vencimiento: date = Field(description="Último día de vigencia (inclusive). Debe ser hoy o posterior.")
    cantidad: Annotated[int, Field(ge=1, le=1_000_000)]
    precio_unitario: Decimal | None = Field(None, gt=0, le=100_000, decimal_places=2, description="Precio por unidad en USD (opcional). Si no lo informa, el medicamento no entra en la comparación de precios.")


class AjusteIn(In):
    tipo: Literal["ENTRADA", "MERMA", "CORRECCION"] = Field(description="ENTRADA suma, MERMA resta (vencimiento, daño, pérdida), CORRECCION fija el saldo contado.")
    cantidad: Annotated[int, Field(ge=0, le=1_000_000)] = Field(description="Unidades (ENTRADA/MERMA ≥ 1) o saldo real contado (CORRECCION ≥ 0).")
    motivo: Annotated[str, Field(min_length=5, max_length=300)]


class UmbralIn(In):
    umbral: Annotated[int, Field(ge=0, le=1_000_000)] = Field(description="Alerta cuando el stock vigente es ≤ este valor (0 = alerta al agotarse).")


class LoteOut(BaseModel):
    id: uuid.UUID
    medicamento: str
    presentacion: str | None
    numero_lote: str
    fecha_vencimiento: date
    cantidad_inicial: int
    cantidad_actual: int
    precio_unitario: Decimal | None = None
    estado: Literal["VIGENTE", "POR_VENCER", "VENCIDO", "AGOTADO"]
    dias_para_vencer: int
    creado_en: datetime


class MovimientoOut(BaseModel):
    id: uuid.UUID
    tipo: str
    delta: int
    saldo: int
    motivo: str | None
    despacho_id: uuid.UUID | None
    creado_en: datetime


class ExistenciaOut(BaseModel):
    medicamento: str
    stock_vigente: int
    stock_vencido: int
    lotes_vigentes: int
    proximo_vencimiento: date | None
    umbral: int | None
    stock_bajo: bool


class AlertasOut(BaseModel):
    generado_en: datetime
    dias_alerta_vencimiento: int
    stock_bajo: list[ExistenciaOut]
    lotes_por_vencer: list[LoteOut]
    lotes_vencidos_con_stock: list[LoteOut]

