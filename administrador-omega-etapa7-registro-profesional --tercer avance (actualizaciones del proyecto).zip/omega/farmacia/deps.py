from fastapi import Depends, HTTPException

from omega_core.deps import institucion_actual
from omega_core.models import Institucion


def farmacia_actual(inst: Institucion = Depends(institucion_actual)) -> Institucion:
    if inst.tipo != "FARMACIA":
        raise HTTPException(403, "Solo farmacias autorizadas")
    return inst
