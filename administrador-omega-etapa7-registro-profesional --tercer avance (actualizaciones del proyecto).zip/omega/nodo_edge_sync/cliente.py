"""Cliente de ejemplo para un nodo (hospital, clínica, laboratorio o farmacia). Solo usa la biblioteca estándar de Python.

* Los eventos se guardan primero en una cola local (archivo SQLite) y de ahí se envían en lotes a `POST /sync/lotes`.
* Si no hay conexión, quedan PENDIENTES; al volver la red, `sincronizar()` los reenvía. Si el proceso se cae entre el envío y la
  anotación del resultado, el reenvío es seguro: el servidor reconoce la clave y responde DUPLICADO (idempotencia).
* Un evento rechazado por el servidor como ERROR se marca FALLIDO (no se reintenta solo, porque volvería a fallar); los demás estados lo cierran.

Uso:  python -m nodo_edge_sync.cliente --url http://127.0.0.1:8000 --token <TOKEN> --cola cola_nodo.sqlite \
          --evento NODO_ESTADO '{"clave":"horario","valor":"7-15"}'      (encola)  /  --enviar  (sincroniza)
"""
import argparse
import json
import sqlite3
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone

TAM_LOTE = 100


class SinConexion(Exception):
    """No se pudo llegar al servidor: los eventos siguen pendientes."""


class NodoNoAutorizado(Exception):
    """El servidor rechazó el token (401): hay que obtener otro; los eventos siguen pendientes."""


def transporte_http(url: str, token: str, timeout: float = 15.0):
    def enviar(lote: dict) -> tuple[int, dict]:
        req = urllib.request.Request(url.rstrip("/") + "/sync/lotes", data=json.dumps(lote).encode(), method="POST",
                                     headers={"Content-Type": "application/json", "X-Nodo-Token": token})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, (json.loads(e.read() or b"{}"))
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
            raise SinConexion(str(e)) from e
    return enviar


class ColaNodo:
    def __init__(self, ruta: str, transporte):
        """`transporte(lote) -> (status_http, json)`; puede lanzar SinConexion. Ver `transporte_http`."""
        self.db = sqlite3.connect(ruta)
        self.transporte = transporte
        self.db.execute("""CREATE TABLE IF NOT EXISTS cola (
            n INTEGER PRIMARY KEY AUTOINCREMENT, clave TEXT NOT NULL UNIQUE, tipo TEXT NOT NULL, ts TEXT NOT NULL, payload TEXT NOT NULL,
            estado TEXT NOT NULL DEFAULT 'PENDIENTE', intentos INTEGER NOT NULL DEFAULT 0, respuesta TEXT)""")
        self.db.commit()

    def encolar(self, tipo: str, payload: dict, ts: datetime | None = None, clave: str | None = None) -> str:
        """Guarda el evento localmente (sin red). La clave única se genera aquí y no cambia nunca, por muchos reenvíos que haya."""
        clave = clave or f"{uuid.uuid4()}"
        ts = ts or datetime.now(timezone.utc)
        self.db.execute("INSERT INTO cola (clave, tipo, ts, payload) VALUES (?,?,?,?)", (clave, tipo, ts.isoformat(), json.dumps(payload)))
        self.db.commit()
        return clave

    def pendientes(self) -> int:
        return self.db.execute("SELECT count(*) FROM cola WHERE estado = 'PENDIENTE'").fetchone()[0]

    def estados(self) -> dict[str, int]:
        return dict(self.db.execute("SELECT estado, count(*) FROM cola GROUP BY estado").fetchall())

    def sincronizar(self, tam_lote: int = TAM_LOTE) -> dict:
        """Envía los pendientes en lotes, en orden. Se detiene sin perder nada si falla la red (SinConexion) o el token (NodoNoAutorizado)."""
        total = {"enviados": 0, "lotes": 0, "aplicados": 0, "duplicados": 0, "conflictos": 0, "fallidos": 0}
        while True:
            filas = self.db.execute("SELECT n, clave, tipo, ts, payload FROM cola WHERE estado = 'PENDIENTE' ORDER BY n LIMIT ?", (tam_lote,)).fetchall()
            if not filas:
                return total
            lote = {"lote_id": str(uuid.uuid4()), "eventos": [{"clave": c, "tipo": t, "ts": ts, "payload": json.loads(p)} for _, c, t, ts, p in filas]}
            self.db.executemany("UPDATE cola SET intentos = intentos + 1 WHERE n = ?", [(f[0],) for f in filas])
            self.db.commit()
            status, cuerpo = self.transporte(lote)  # puede lanzar SinConexion: nada se marca, todo sigue pendiente
            if status == 401:
                raise NodoNoAutorizado(cuerpo.get("detail", "token rechazado"))
            if status >= 500 or status == 429:
                raise SinConexion(f"servidor no disponible (HTTP {status})")
            if status != 200:  # 4xx de formato: no se reintenta a ciegas
                raise RuntimeError(f"El servidor rechazó el lote (HTTP {status}): {cuerpo}")
            por_clave = {r["clave"]: r for r in cuerpo["resultados"] if r.get("clave")}
            for _, clave, *_ in filas:
                r = por_clave.get(clave)
                if r is None:
                    continue  # sin respuesta para este evento: sigue pendiente
                estado = "FALLIDO" if r["estado"] == "ERROR" else r["estado"]
                self.db.execute("UPDATE cola SET estado = ?, respuesta = ? WHERE clave = ?", (estado, json.dumps(r), clave))
                total[{"APLICADO": "aplicados", "DUPLICADO": "duplicados", "CONFLICTO": "conflictos", "FALLIDO": "fallidos"}[estado]] += 1
            self.db.commit()
            total["enviados"] += len(filas)
            total["lotes"] += 1
            if all(por_clave.get(f[1]) is None for f in filas):
                return total  # evita un bucle infinito si el servidor no responde por evento


def main() -> None:
    ap = argparse.ArgumentParser(description="Cliente de ejemplo de un nodo de Administrador Omega")
    ap.add_argument("--url", default="http://127.0.0.1:8000")
    ap.add_argument("--token", required=True)
    ap.add_argument("--cola", default="cola_nodo.sqlite")
    ap.add_argument("--evento", nargs=2, metavar=("TIPO", "PAYLOAD_JSON"), help="Encola un evento (no necesita red)")
    ap.add_argument("--enviar", action="store_true", help="Envía los pendientes")
    a = ap.parse_args()
    cola = ColaNodo(a.cola, transporte_http(a.url, a.token))
    if a.evento:
        print("Encolado:", cola.encolar(a.evento[0], json.loads(a.evento[1])))
    if a.enviar:
        try:
            print(cola.sincronizar())
        except SinConexion as e:
            print("Sin conexión; quedan pendientes:", cola.pendientes(), "-", e)
        except NodoNoAutorizado as e:
            print("Token rechazado:", e)
    print("Cola:", cola.estados())


if __name__ == "__main__":
    main()
