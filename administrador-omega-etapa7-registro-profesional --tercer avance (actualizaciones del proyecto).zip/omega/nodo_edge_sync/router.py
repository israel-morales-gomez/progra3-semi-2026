import hashlib
import secrets
import uuid

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.deps import institucion_actual
from omega_core.models import Institucion
from omega_core.models.base import ahora
from omega_core.security.ratelimit import ip_cliente, limitar_ip

from . import service
from .handlers import TODOS
from .models import NodoEdge, SyncConflicto, SyncEstadoNodo
from .schemas import ConflictoOut, EstadoNodoOut, LoteIn, LoteOut, NodoCreadoOut, NodoIn, NodoOut

router = APIRouter(prefix="/sync", tags=["nodos edge · sincronización offline (institución)"])
nodo_router = APIRouter(prefix="/sync", tags=["nodos edge · recepción de lotes (nodo)"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Solo hospitales, clínicas, laboratorios y farmacias activos"}, 404: {"description": "No encontrado en su institución"}}
MAX_NODOS_ACTIVOS = 10


def institucion_con_nodos(inst: Institucion = Depends(institucion_actual)) -> Institucion:
    if inst.tipo not in TODOS:
        raise HTTPException(403, "Solo hospitales, clínicas, laboratorios y farmacias pueden tener nodos")
    return inst


def _out(n: NodoEdge) -> NodoOut:
    return NodoOut(id=n.id, nombre=n.nombre, prefijo=n.prefijo, creado_en=n.creado_en, revocado_en=n.revocado_en, ultimo_envio=n.ultimo_envio)


# ------------------------------------------------------------------ Gestión de nodos (la hace la institución)
@router.post("/nodos", response_model=NodoCreadoOut, status_code=201, responses=ERR, summary="Registrar un nodo de mi institución y obtener su token",
             description="Con la cuenta institucional. El nodo queda ligado a **esta** institución para siempre: solo podrá enviar eventos de ella. El token se muestra una sola vez (se guarda su hash) y se revoca con `DELETE`.")
def crear_nodo(datos: NodoIn, request: Request, inst: Institucion = Depends(institucion_con_nodos), db: Session = Depends(get_db)):
    activos = db.scalars(select(NodoEdge.id).where(NodoEdge.institucion_id == inst.id, NodoEdge.revocado_en.is_(None))).all()
    if len(activos) >= MAX_NODOS_ACTIVOS:
        raise HTTPException(409, f"Ya tiene {MAX_NODOS_ACTIVOS} nodos activos: revoque alguno")
    token = "nodo_" + secrets.token_urlsafe(32)
    n = NodoEdge(institucion_id=inst.id, nombre=datos.nombre, prefijo=token[:9], token_hash=hashlib.sha256(token.encode()).hexdigest())
    db.add(n)
    db.commit()
    auditar("SYNC_NODO_CREADO", actor_tipo="institucion", actor_id=inst.id, recurso="nodo_edge", recurso_id=n.id, ip=ip_cliente(request), detalle={"nombre": n.nombre, "prefijo": n.prefijo, "tipo_institucion": inst.tipo})
    return NodoCreadoOut(**_out(n).model_dump(), token=token)


@router.get("/nodos", response_model=list[NodoOut], responses=ERR, summary="Mis nodos (sin el token)")
def listar_nodos(inst: Institucion = Depends(institucion_con_nodos), db: Session = Depends(get_db)):
    return [_out(n) for n in db.scalars(select(NodoEdge).where(NodoEdge.institucion_id == inst.id).order_by(NodoEdge.creado_en.desc()).limit(100))]


@router.delete("/nodos/{nodo_id}", response_model=NodoOut, responses=ERR, summary="Revocar un nodo",
               description="El token deja de valer de inmediato. Lo ya sincronizado se conserva.")
def revocar_nodo(nodo_id: uuid.UUID, request: Request, inst: Institucion = Depends(institucion_con_nodos), db: Session = Depends(get_db)):
    n = db.scalar(select(NodoEdge).where(NodoEdge.id == nodo_id, NodoEdge.institucion_id == inst.id))
    if n is None:
        raise HTTPException(404, "Nodo no encontrado")
    if n.revocado_en is None:
        n.revocado_en = ahora()
        db.commit()
        auditar("SYNC_NODO_REVOCADO", actor_tipo="institucion", actor_id=inst.id, recurso="nodo_edge", recurso_id=n.id, ip=ip_cliente(request), detalle={"prefijo": n.prefijo})
    return _out(n)


@router.get("/conflictos", response_model=list[ConflictoOut], responses=ERR, summary="Conflictos registrados de mi institución",
            description="Cada conflicto guarda el valor del evento, el valor del servidor, sus marcas de tiempo y quién ganó. Solo los de mi institución.")
def conflictos(limite: int = Query(100, ge=1, le=500), entidad: str | None = Query(None, description="Filtra por entidad, p. ej. `estado:horario` o `cama:<id>`."), inst: Institucion = Depends(institucion_con_nodos), db: Session = Depends(get_db)):
    q = select(SyncConflicto).where(SyncConflicto.institucion_id == inst.id)
    if entidad:
        q = q.where(SyncConflicto.entidad == entidad)
    return [ConflictoOut(id=c.id, tipo=c.tipo, entidad=c.entidad, resolucion=c.resolucion, motivo=c.motivo, ts_evento=c.ts_evento, ts_servidor=c.ts_servidor,
                         valor_evento=c.valor_evento, valor_servidor=c.valor_servidor, nodo_id=c.nodo_id, creado_en=c.creado_en)
            for c in db.scalars(q.order_by(SyncConflicto.creado_en.desc()).limit(limite))]


@router.get("/estado", response_model=list[EstadoNodoOut], responses=ERR, summary="Estado sincronizado de mi institución (clave/valor, gana el más reciente)")
def estado(clave: str | None = Query(None, description="Devuelve solo esta clave."), inst: Institucion = Depends(institucion_con_nodos), db: Session = Depends(get_db)):
    q = select(SyncEstadoNodo).where(SyncEstadoNodo.institucion_id == inst.id)
    if clave:
        q = q.where(SyncEstadoNodo.clave == clave)
    return [EstadoNodoOut(clave=e.clave, valor=e.valor, ts_evento=e.ts_evento, nodo_id=e.nodo_id)
            for e in db.scalars(q.order_by(SyncEstadoNodo.clave).limit(500))]


# ------------------------------------------------------------------ Recepción de lotes (la usa el nodo, no una persona)
def nodo_actual(request: Request, x_nodo_token: str | None = Header(None, alias="X-Nodo-Token", description="Token del nodo (se obtiene en `POST /sync/nodos`)."),
                db: Session = Depends(get_db)) -> NodoEdge:
    limitar_ip(request, "sync", 300)
    n = db.scalar(select(NodoEdge).where(NodoEdge.token_hash == hashlib.sha256(x_nodo_token.encode()).hexdigest())) if x_nodo_token else None
    inst = db.get(Institucion, n.institucion_id) if n else None
    if n is None or n.revocado_en is not None or inst is None or inst.estado != "ACTIVA" or inst.tipo not in TODOS:
        auditar("SYNC_NODO_RECHAZADO", actor_tipo="anonimo", actor_id=None, recurso="nodo_edge", recurso_id=n.id if n else None, resultado="FALLO", ip=ip_cliente(request),
                detalle={"motivo": ("REVOCADO_O_INSTITUCION_INACTIVA" if n else "TOKEN_DESCONOCIDO")})
        raise HTTPException(401, "Token de nodo inválido, revocado o institución inactiva")
    return n


@nodo_router.post("/lotes", response_model=LoteOut, responses={401: {"description": "Token de nodo inválido, revocado o institución inactiva"}, 422: {"description": "Cuerpo del lote mal formado"}},
                  summary="Recibir un lote de eventos de un nodo (al reconectar)",
                  description=("Cada evento trae una **clave única**: si ya fue procesada se **ignora sin error** (`DUPLICADO`; la restricción única está en la base de datos), de modo que reenviar el mismo lote es seguro. "
                               "Los conflictos se resuelven por marca de tiempo (**gana el evento más reciente**) y quedan registrados (`GET /sync/conflictos`). "
                               "La respuesta dice, evento por evento, si fue `APLICADO`, `DUPLICADO`, `CONFLICTO` o `ERROR` (un evento con error no frena a los demás ni consume su clave). "
                               "El nodo solo puede enviar eventos de **su propia institución** y de los tipos que su tipo de institución permite: `NODO_ESTADO` (todos) y `CAMA_LIMPIEZA_TERMINADA` (hospital/clínica). Cabecera `X-Nodo-Token`."))
def recibir_lote(lote: LoteIn, request: Request, nodo: NodoEdge = Depends(nodo_actual), db: Session = Depends(get_db)):
    return service.procesar_lote(db, nodo, lote, ip_cliente(request))
