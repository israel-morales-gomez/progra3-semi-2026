"""Manejadores de eventos. Cada uno decide con la regla 'gana el evento más reciente' y devuelve cómo quedó. Para añadir un tipo: una clase de payload,
una función `aplicar` y una fila en HANDLERS (con los tipos de nodo autorizados). Los eventos NUNCA llevan institución: siempre es la del nodo."""
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Annotated

from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from core_expediente.models import Cama
from omega_core.models.base import ahora

from .models import NodoEdge, SyncConflicto, SyncEstadoNodo, SyncEvento


class _P(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class NodoEstadoP(_P):
    clave: Annotated[str, Field(min_length=2, max_length=60, pattern=r"^[A-Za-z0-9._\-]+$")]
    valor: Any = Field(description="Cualquier JSON pequeño (texto, número, booleano, lista u objeto).")


class CamaLimpiezaP(_P):
    cama_id: uuid.UUID


@dataclass
class Resultado:
    estado: str  # APLICADO | CONFLICTO | ERROR
    detalle: str | None = None
    conflicto_id: uuid.UUID | None = None
    extra: dict = field(default_factory=dict)


def _conflicto(db: Session, nodo: NodoEdge, ev: SyncEvento, entidad: str, ts_servidor: datetime, valor_evento: dict, valor_servidor: dict, resolucion: str, motivo: str) -> uuid.UUID:
    c = SyncConflicto(evento_id=ev.id, institucion_id=nodo.institucion_id, nodo_id=nodo.id, tipo=ev.tipo, entidad=entidad, ts_evento=ev.ts_evento, ts_servidor=ts_servidor,
                      valor_evento=valor_evento, valor_servidor=valor_servidor, resolucion=resolucion, motivo=motivo)
    db.add(c)
    db.flush()
    return c.id


def aplicar_nodo_estado(db: Session, nodo: NodoEdge, ev: SyncEvento, p: NodoEstadoP) -> Resultado:
    nuevo = {"valor": p.valor}
    fila = db.scalar(select(SyncEstadoNodo).where(SyncEstadoNodo.institucion_id == nodo.institucion_id, SyncEstadoNodo.clave == p.clave).with_for_update())
    if fila is None:
        db.add(SyncEstadoNodo(institucion_id=nodo.institucion_id, clave=p.clave, valor=nuevo, ts_evento=ev.ts_evento, evento_id=ev.id, nodo_id=nodo.id))
        db.flush()
        return Resultado("APLICADO", "Estado creado")
    ent = f"estado:{p.clave}"
    if ev.ts_evento > fila.ts_evento:
        cid = None
        if fila.valor != nuevo:  # el evento gana y pisa un valor distinto: queda el rastro de lo que se sobrescribió
            cid = _conflicto(db, nodo, ev, ent, fila.ts_evento, nuevo, fila.valor, "EVENTO_GANA", "El evento es más reciente que el valor almacenado")
        fila.valor, fila.ts_evento, fila.evento_id, fila.nodo_id, fila.actualizado_en = nuevo, ev.ts_evento, ev.id, nodo.id, ahora()
        db.flush()
        return Resultado("APLICADO", "Sobrescribió un valor anterior" if cid else "Sin cambios de valor", cid)
    if ev.ts_evento == fila.ts_evento and fila.valor == nuevo:
        return Resultado("APLICADO", "Sin cambios (mismo valor y misma marca de tiempo)")
    motivo = "Empate de marca de tiempo con valor distinto: se conserva el almacenado" if ev.ts_evento == fila.ts_evento else "El valor almacenado es más reciente que el evento"
    cid = _conflicto(db, nodo, ev, ent, fila.ts_evento, nuevo, fila.valor, "SERVIDOR_GANA", motivo)
    return Resultado("CONFLICTO", motivo, cid)


def aplicar_limpieza(db: Session, nodo: NodoEdge, ev: SyncEvento, p: CamaLimpiezaP) -> Resultado:
    c = db.scalar(select(Cama).where(Cama.id == p.cama_id).with_for_update())
    if c is None or c.institucion_id != nodo.institucion_id:
        return Resultado("ERROR", "Cama no encontrada en su institución")  # igual respuesta para camas ajenas
    ent = f"cama:{c.id}"
    actual = {"estado": c.estado, "estado_desde": c.estado_desde.isoformat()}
    pedido = {"estado": "LIBRE", "cama_id": str(c.id)}
    if ev.ts_evento < c.estado_desde:
        cid = _conflicto(db, nodo, ev, ent, c.estado_desde, pedido, actual, "SERVIDOR_GANA", "La cama cambió de estado después de este evento: gana el cambio más reciente")
        return Resultado("CONFLICTO", "La cama cambió después del evento", cid)
    if c.estado == "LIMPIEZA":
        c.estado, c.estado_desde = "LIBRE", ev.ts_evento
        db.flush()
        return Resultado("APLICADO", "Cama liberada tras la limpieza", extra={"cama_id": str(c.id), "servicio": c.servicio, "codigo": c.codigo})
    if c.estado == "LIBRE":
        return Resultado("APLICADO", "Sin cambios: la cama ya estaba libre")
    cid = _conflicto(db, nodo, ev, ent, c.estado_desde, pedido, actual, "SERVIDOR_GANA", "La cama está ocupada: una limpieza terminada no aplica")
    return Resultado("CONFLICTO", "La cama está ocupada: la limpieza no aplica", cid)


TODOS = ("HOSPITAL", "CLINICA", "LABORATORIO", "FARMACIA")
HANDLERS = {
    "NODO_ESTADO": (NodoEstadoP, aplicar_nodo_estado, TODOS),
    "CAMA_LIMPIEZA_TERMINADA": (CamaLimpiezaP, aplicar_limpieza, ("HOSPITAL", "CLINICA")),
}
