from .router import nodo_router, router

routers = [router, nodo_router]
