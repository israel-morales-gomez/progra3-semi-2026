import uuid
from datetime import datetime

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Index, String, UniqueConstraint, Uuid
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from omega_core.models.base import Base, ahora


def _fk(tabla: str, **kw):
    return mapped_column(Uuid, ForeignKey(f"{tabla}.id", ondelete="RESTRICT"), **kw)


class NodoEdge(Base):
    """Nodo (equipo) de una institución con su credencial de envío. Solo se guarda el hash del token; se revoca, no se borra."""

    __tablename__ = "nodo_edge"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    institucion_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    nombre: Mapped[str] = mapped_column(String(80))
    prefijo: Mapped[str] = mapped_column(String(12))
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    revocado_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ultimo_envio: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class SyncEvento(Base):
    """Evento YA PROCESADO. La restricción única (institución, clave) es la que garantiza la idempotencia: la misma clave nunca se procesa dos veces.
    Inmutable: es el registro de qué llegó, cuándo y con qué resultado."""

    __tablename__ = "sync_evento"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    institucion_id: Mapped[uuid.UUID] = _fk("institucion")
    nodo_id: Mapped[uuid.UUID] = _fk("nodo_edge")
    clave: Mapped[str] = mapped_column(String(80))
    tipo: Mapped[str] = mapped_column(String(40))
    ts_evento: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    recibido_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    lote_id: Mapped[uuid.UUID | None] = mapped_column(Uuid)
    payload: Mapped[dict] = mapped_column(JSONB)
    hash_payload: Mapped[str] = mapped_column(String(64))
    resultado: Mapped[str] = mapped_column(String(10))  # PENDIENTE (solo dentro de la transacción) → APLICADO | CONFLICTO
    detalle: Mapped[str | None] = mapped_column(String(300))
    __table_args__ = (
        UniqueConstraint("institucion_id", "clave", name="uq_sync_evento_institucion_clave"),
        CheckConstraint("resultado IN ('PENDIENTE', 'APLICADO', 'CONFLICTO')", name="resultado_valido"),
        Index("ix_sync_evento_institucion_recibido", "institucion_id", "recibido_en"),
    )


class SyncConflicto(Base):
    """Cada vez que la regla 'gana el evento más reciente' descarta un lado, queda registrado con ambos valores. Inmutable."""

    __tablename__ = "sync_conflicto"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    evento_id: Mapped[uuid.UUID] = _fk("sync_evento", index=True)
    institucion_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    nodo_id: Mapped[uuid.UUID] = _fk("nodo_edge")
    tipo: Mapped[str] = mapped_column(String(40))
    entidad: Mapped[str] = mapped_column(String(120))
    ts_evento: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    ts_servidor: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    valor_evento: Mapped[dict] = mapped_column(JSONB)
    valor_servidor: Mapped[dict] = mapped_column(JSONB)
    resolucion: Mapped[str] = mapped_column(String(15))  # SERVIDOR_GANA (el evento perdió) | EVENTO_GANA (el evento sobrescribió)
    motivo: Mapped[str] = mapped_column(String(200))
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    __table_args__ = (CheckConstraint("resolucion IN ('SERVIDOR_GANA', 'EVENTO_GANA')", name="resolucion_valida"),)


class SyncEstadoNodo(Base):
    """Estado clave/valor por institución sincronizado con 'gana el más reciente' (p. ej. horario especial, servicio suspendido, sin stock)."""

    __tablename__ = "sync_estado_nodo"
    institucion_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("institucion.id", ondelete="RESTRICT"), primary_key=True)
    clave: Mapped[str] = mapped_column(String(60), primary_key=True)
    valor: Mapped[dict] = mapped_column(JSONB)
    ts_evento: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    evento_id: Mapped[uuid.UUID] = _fk("sync_evento")
    nodo_id: Mapped[uuid.UUID] = _fk("nodo_edge")
    actualizado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
