import hashlib
import json
import uuid
from datetime import timedelta

from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.models import Institucion
from omega_core.models.base import ahora

from .handlers import HANDLERS, Resultado
from .models import NodoEdge, SyncEvento
from .schemas import EventoIn, LoteIn, LoteOut, ResultadoEventoOut

FUTURO_MAX = timedelta(minutes=5)   # un reloj adelantado no puede "ganar" todos los conflictos
ANTIGUEDAD_MAX = timedelta(days=30)  # un nodo desconectado más de 30 días debe re-sincronizarse con soporte


def hash_payload(tipo: str, ts, payload: dict) -> str:
    base = json.dumps({"tipo": tipo, "ts": ts.astimezone(ahora().tzinfo).isoformat(), "payload": payload}, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
    return hashlib.sha256(base.encode()).hexdigest()


def _error(i: int, clave, msg: str) -> ResultadoEventoOut:
    return ResultadoEventoOut(indice=i, clave=clave if isinstance(clave, str) else None, estado="ERROR", detalle=msg)


def procesar_evento(db: Session, nodo: NodoEdge, tipo_nodo: str, i: int, crudo: dict) -> tuple[ResultadoEventoOut, dict | None]:
    """Un evento = un SAVEPOINT. Devuelve su resultado y, si cambió algo, los datos para la bitácora."""
    try:
        ev = EventoIn.model_validate(crudo)
    except ValidationError as e:
        err = e.errors()[0]
        return _error(i, crudo.get("clave") if isinstance(crudo, dict) else None, f"Evento inválido ({'.'.join(str(x) for x in err['loc'])}: {err['msg']})"), None
    ahora_ = ahora()
    if ev.ts > ahora_ + FUTURO_MAX:
        return _error(i, ev.clave, "ts en el futuro (reloj del nodo adelantado)"), None
    if ev.ts < ahora_ - ANTIGUEDAD_MAX:
        return _error(i, ev.clave, "ts con más de 30 días de antigüedad"), None
    h = HANDLERS.get(ev.tipo)
    if h is None:
        return _error(i, ev.clave, f"Tipo de evento desconocido: {ev.tipo}"), None
    modelo, aplicar, permitidos = h
    if tipo_nodo not in permitidos:
        return _error(i, ev.clave, f"Un nodo de tipo {tipo_nodo} no está autorizado a enviar eventos {ev.tipo}"), None
    try:
        p = modelo.model_validate(ev.payload)
    except ValidationError as e:
        err = e.errors()[0]
        return _error(i, ev.clave, f"payload inválido ({'.'.join(str(x) for x in err['loc'])}: {err['msg']})"), None
    hp = hash_payload(ev.tipo, ev.ts, ev.payload)
    fila = SyncEvento(institucion_id=nodo.institucion_id, nodo_id=nodo.id, clave=ev.clave, tipo=ev.tipo, ts_evento=ev.ts, payload=ev.payload, hash_payload=hp, resultado="PENDIENTE")
    try:
        with db.begin_nested():
            db.add(fila)
            db.flush()  # reclama la clave: la restricción única de la BD decide quién la procesa (primero la clave, luego los bloqueos de datos)
            r: Resultado = aplicar(db, nodo, fila, p)
            if r.estado == "ERROR":
                raise _Descartar(r)
            fila.resultado, fila.detalle = r.estado, (r.detalle or "")[:300]
            db.flush()
    except _Descartar as d:  # el savepoint se deshizo: la clave queda libre para reenviar el evento corregido
        return _error(i, ev.clave, d.r.detalle or "Error al aplicar"), None
    except IntegrityError as e:
        if "uq_sync_evento_institucion_clave" not in str(e.orig):
            raise
        previo = db.scalar(select(SyncEvento).where(SyncEvento.institucion_id == nodo.institucion_id, SyncEvento.clave == ev.clave))
        coincide = previo.hash_payload == hp
        return (ResultadoEventoOut(indice=i, clave=ev.clave, estado="DUPLICADO", detalle="Clave ya procesada: ignorada" + ("" if coincide else " (¡con contenido distinto!)"),
                                   resultado_original=previo.resultado, payload_coincide=coincide),
                None if coincide else {"clave_reutilizada": True, "clave": ev.clave, "tipo": ev.tipo})
    out = ResultadoEventoOut(indice=i, clave=ev.clave, estado=r.estado, detalle=r.detalle, conflicto_id=r.conflicto_id)
    return out, {"evento_id": fila.id, "clave": ev.clave, "tipo": ev.tipo, "estado": r.estado, "detalle": r.detalle, "conflicto_id": r.conflicto_id, "extra": r.extra, "ts": ev.ts}


class _Descartar(Exception):
    def __init__(self, r: Resultado):
        self.r = r


def procesar_lote(db: Session, nodo: NodoEdge, lote: LoteIn, ip: str) -> LoteOut:
    inst = db.get(Institucion, nodo.institucion_id)
    resultados: dict[int, ResultadoEventoOut] = {}
    cambios: list[dict] = []
    # orden total (ts, clave): dos lotes que se crucen toman los bloqueos en el mismo orden y no se interbloquean
    def llave(par):
        c = par[1]
        return (str(c.get("ts")), str(c.get("clave"))) if isinstance(c, dict) else ("", "")
    for i, crudo in sorted(enumerate(lote.eventos), key=llave):
        if not isinstance(crudo, dict):
            resultados[i] = _error(i, None, "El evento debe ser un objeto")
            continue
        r, cambio = procesar_evento(db, nodo, inst.tipo, i, crudo)
        resultados[i] = r
        if cambio:
            cambios.append(cambio)
    nodo.ultimo_envio = ahora()
    db.commit()
    ordenados = [resultados[i] for i in sorted(resultados)]
    cuenta = lambda e: sum(1 for r in ordenados if r.estado == e)  # noqa: E731
    # ---- bitácora: un registro por evento que cambió algo o dio conflicto + el resumen del lote
    for c in cambios:
        if c.get("clave_reutilizada"):
            auditar("SYNC_CLAVE_REUTILIZADA", actor_tipo="nodo", actor_id=nodo.id, recurso="sync_evento", ip=ip,
                    detalle={"institucion_id": nodo.institucion_id, "clave": c["clave"], "tipo": c["tipo"], "lote_id": lote.lote_id})
            continue
        auditar("SYNC_EVENTO_APLICADO" if c["estado"] == "APLICADO" else "SYNC_EVENTO_CONFLICTO", actor_tipo="nodo", actor_id=nodo.id, recurso="sync_evento", recurso_id=c["evento_id"], ip=ip,
                detalle={"institucion_id": nodo.institucion_id, "clave": c["clave"], "tipo": c["tipo"], "detalle": c["detalle"], "conflicto_id": c["conflicto_id"], "lote_id": lote.lote_id})
        if c["tipo"] == "CAMA_LIMPIEZA_TERMINADA" and c["estado"] == "APLICADO" and c["extra"]:
            auditar("CAMA_LIMPIEZA_TERMINADA", actor_tipo="nodo", actor_id=nodo.id, recurso="cama", recurso_id=c["extra"]["cama_id"], ip=ip,
                    detalle={"institucion_id": nodo.institucion_id, "servicio": c["extra"]["servicio"], "codigo": c["extra"]["codigo"], "via": "SYNC_NODO", "evento_id": c["evento_id"]})
    errores = [{"indice": r.indice, "clave": r.clave, "detalle": r.detalle} for r in ordenados if r.estado == "ERROR"][:20]
    auditar("SYNC_LOTE_RECIBIDO", actor_tipo="nodo", actor_id=nodo.id, recurso="sync_lote", recurso_id=lote.lote_id, ip=ip,
            detalle={"institucion_id": nodo.institucion_id, "nodo_id": nodo.id, "recibidos": len(ordenados), "aplicados": cuenta("APLICADO"), "duplicados": cuenta("DUPLICADO"),
                     "conflictos": cuenta("CONFLICTO"), "errores": cuenta("ERROR"), "errores_detalle": errores})
    return LoteOut(lote_id=lote.lote_id, recibidos=len(ordenados), aplicados=cuenta("APLICADO"), duplicados=cuenta("DUPLICADO"), conflictos=cuenta("CONFLICTO"), errores=cuenta("ERROR"), resultados=ordenados)
