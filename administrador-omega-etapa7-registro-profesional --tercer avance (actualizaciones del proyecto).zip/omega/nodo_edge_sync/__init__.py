"""Módulo nodo_edge_sync: nodos offline-first (hospital, clínica, laboratorio, farmacia) que envían eventos por lotes al reconectar. Versión simple."""
