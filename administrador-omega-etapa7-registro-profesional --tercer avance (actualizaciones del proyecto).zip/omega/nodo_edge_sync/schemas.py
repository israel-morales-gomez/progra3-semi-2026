import uuid
from datetime import datetime
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

Estado = Literal["APLICADO", "DUPLICADO", "CONFLICTO", "ERROR"]
MAX_EVENTOS = 200


class _In(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class NodoIn(_In):
    nombre: Annotated[str, Field(min_length=3, max_length=80, description="Etiqueta del equipo, p. ej. 'Servidor de la sala de emergencias'.")]


class NodoOut(BaseModel):
    id: uuid.UUID
    nombre: str
    prefijo: str
    creado_en: datetime
    revocado_en: datetime | None = None
    ultimo_envio: datetime | None = None


class NodoCreadoOut(NodoOut):
    token: str = Field(description="SE MUESTRA UNA SOLA VEZ. Se envía en la cabecera `X-Nodo-Token` a `POST /sync/lotes`.")


class EventoIn(_In):
    clave: Annotated[str, Field(min_length=8, max_length=80, pattern=r"^[A-Za-z0-9._:\-]+$", description="Clave ÚNICA del evento (la genera el nodo, p. ej. un UUID). Si ya fue procesada, se ignora sin error.")]
    tipo: Annotated[str, Field(min_length=3, max_length=40)]
    ts: datetime = Field(description="Cuándo ocurrió el evento en el nodo (con zona horaria). Con ella se resuelven los conflictos: gana el más reciente.")
    payload: dict[str, Any] = Field(default_factory=dict)

    @field_validator("ts")
    @classmethod
    def _con_zona(cls, v: datetime) -> datetime:
        if v.tzinfo is None:
            raise ValueError("ts debe incluir zona horaria")
        return v


class LoteIn(_In):
    lote_id: uuid.UUID | None = Field(None, description="Id del lote (opcional, solo para rastreo). La idempotencia depende de la clave de cada evento, no del lote.")
    eventos: Annotated[list[dict[str, Any]], Field(min_length=1, max_length=MAX_EVENTOS, description=(
        f"Hasta {MAX_EVENTOS} eventos `{{clave, tipo, ts, payload}}`. Cada uno se valida por separado: uno malo no frena a los demás."))]

    model_config = ConfigDict(extra="forbid", json_schema_extra={"example": {"lote_id": "6f1c0f0e-5b4e-4f2a-9a55-0c2f5d6c7a10", "eventos": [
        {"clave": "nodo1-000001", "tipo": "NODO_ESTADO", "ts": "2026-10-10T09:15:00-06:00", "payload": {"clave": "horario_especial", "valor": "7:00-15:00"}},
        {"clave": "nodo1-000002", "tipo": "CAMA_LIMPIEZA_TERMINADA", "ts": "2026-10-10T09:20:00-06:00", "payload": {"cama_id": "00000000-0000-0000-0000-000000000000"}}]}})


class ResultadoEventoOut(BaseModel):
    indice: int = Field(description="Posición del evento en el lote enviado.")
    clave: str | None
    estado: Estado
    detalle: str | None = None
    conflicto_id: uuid.UUID | None = Field(None, description="Si se registró un conflicto (el evento perdió o sobrescribió un valor distinto).")
    resultado_original: Literal["APLICADO", "CONFLICTO"] | None = Field(None, description="Solo en DUPLICADO: cómo se procesó la primera vez.")
    payload_coincide: bool | None = Field(None, description="Solo en DUPLICADO: false si la clave se reutilizó con un contenido distinto (se ignora igual y queda en la bitácora).")


class LoteOut(BaseModel):
    lote_id: uuid.UUID | None
    recibidos: int
    aplicados: int
    duplicados: int
    conflictos: int
    errores: int
    resultados: list[ResultadoEventoOut]


class ConflictoOut(BaseModel):
    id: uuid.UUID
    tipo: str
    entidad: str
    resolucion: Literal["SERVIDOR_GANA", "EVENTO_GANA"]
    motivo: str
    ts_evento: datetime
    ts_servidor: datetime
    valor_evento: dict
    valor_servidor: dict
    nodo_id: uuid.UUID
    creado_en: datetime


class EstadoNodoOut(BaseModel):
    clave: str
    valor: dict
    ts_evento: datetime
    nodo_id: uuid.UUID
