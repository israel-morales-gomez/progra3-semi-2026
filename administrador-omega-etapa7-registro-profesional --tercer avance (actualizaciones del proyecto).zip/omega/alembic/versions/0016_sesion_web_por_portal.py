"""sesion web por portal

Las sesiones pasan a pertenecer a UN portal (siete portales separados, Etapa 7). Las sesiones abiertas son efímeras: se descartan.

Revision ID: 0016
Revises: 0015
"""
from alembic import op
import sqlalchemy as sa

revision = "0016"
down_revision = "0015"
branch_labels = None
depends_on = None

PORTALES = "'ciudadano', 'profesional', 'institucion', 'farmacia', 'laboratorio', 'universidad', 'omega'"


def upgrade() -> None:
    op.execute("DELETE FROM sesion_web")  # sesiones del frontend de un solo portal: ya no valen
    op.add_column("sesion_web", sa.Column("portal", sa.String(length=20), nullable=False))
    op.create_check_constraint(op.f("ck_sesion_web_portal_valido"), "sesion_web", f"portal IN ({PORTALES})")
    op.drop_index("ix_sesion_web_sujeto", table_name="sesion_web")
    op.create_index("ix_sesion_web_sujeto", "sesion_web", ["portal", "sujeto_tipo", "sujeto_id"], unique=False)


def downgrade() -> None:
    op.execute("DELETE FROM sesion_web")
    op.drop_index("ix_sesion_web_sujeto", table_name="sesion_web")
    op.create_index("ix_sesion_web_sujeto", "sesion_web", ["sujeto_tipo", "sujeto_id"], unique=False)
    op.drop_constraint(op.f("ck_sesion_web_portal_valido"), "sesion_web", type_="check")
    op.drop_column("sesion_web", "portal")
