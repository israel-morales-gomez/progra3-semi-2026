"""autocompra declarada por el paciente

Tabla propia para los medicamentos que el ciudadano declara haber comprado sin receta (portal /ciudadano, historial farmacológico).
El origen queda fijo por CHECK: nunca se confunde con una receta oficial.

Revision ID: 0018
Revises: 0017
"""
from alembic import op
import sqlalchemy as sa

revision = "0018"
down_revision = "0017"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "autocompra",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("paciente_id", sa.Uuid(), nullable=False),
        sa.Column("medicamento", sa.String(length=200), nullable=False),
        sa.Column("dosis", sa.String(length=120), nullable=False),
        sa.Column("fecha_compra", sa.Date(), nullable=False),
        sa.Column("farmacia", sa.String(length=200), nullable=True),
        sa.Column("origen", sa.String(length=30), server_default="DECLARADA_POR_PACIENTE", nullable=False),
        sa.Column("creado_en", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("origen = 'DECLARADA_POR_PACIENTE'", name=op.f("ck_autocompra_origen_declarado")),
        sa.ForeignKeyConstraint(["paciente_id"], ["persona.id"], name=op.f("fk_autocompra_paciente_id_persona"), ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_autocompra")),
    )
    op.create_index(op.f("ix_autocompra_paciente_id"), "autocompra", ["paciente_id"], unique=False)
    op.create_index("ix_autocompra_paciente_fecha", "autocompra", ["paciente_id", "fecha_compra"], unique=False)


def downgrade() -> None:
    op.drop_index("ix_autocompra_paciente_fecha", table_name="autocompra")
    op.drop_index(op.f("ix_autocompra_paciente_id"), table_name="autocompra")
    op.drop_table("autocompra")
