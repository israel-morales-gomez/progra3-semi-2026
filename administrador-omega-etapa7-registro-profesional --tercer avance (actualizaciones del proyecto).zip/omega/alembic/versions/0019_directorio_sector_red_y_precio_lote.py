"""directorio: sector y red de seguros de las instituciones; precio opcional por lote

- institucion.sector / institucion.red_seguros: los gestiona Omega; filtran el directorio y la cascada de citas del ciudadano.
- lote.precio_unitario: opcional. El trigger lote_guard no lo vigila (solo bloquea las columnas de identidad del lote).

Revision ID: 0019
Revises: 0018
"""
from alembic import op
import sqlalchemy as sa

revision = "0019"
down_revision = "0018"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("institucion", sa.Column("sector", sa.String(length=10), nullable=True))
    op.add_column("institucion", sa.Column("red_seguros", sa.String(length=15), nullable=True))
    op.create_check_constraint(op.f("ck_institucion_sector_valido"), "institucion", "sector IS NULL OR sector IN ('PUBLICO', 'PRIVADO')")
    op.create_check_constraint(op.f("ck_institucion_red_seguros_valida"), "institucion",
                               "red_seguros IS NULL OR red_seguros IN ('PUBLICA', 'POLIZA_PRIVADA', 'AMBAS')")
    op.add_column("lote", sa.Column("precio_unitario", sa.Numeric(precision=10, scale=2), nullable=True))
    op.create_check_constraint(op.f("ck_lote_precio_positivo"), "lote", "precio_unitario IS NULL OR precio_unitario > 0")


def downgrade() -> None:
    op.drop_constraint(op.f("ck_lote_precio_positivo"), "lote", type_="check")
    op.drop_column("lote", "precio_unitario")
    op.drop_constraint(op.f("ck_institucion_red_seguros_valida"), "institucion", type_="check")
    op.drop_constraint(op.f("ck_institucion_sector_valido"), "institucion", type_="check")
    op.drop_column("institucion", "red_seguros")
    op.drop_column("institucion", "sector")
