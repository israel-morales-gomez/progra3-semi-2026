"""perfil_profesional.rol_clave: ámbito laboral (1 de 65) que decide la plantilla del portal profesional

Opcional: si falta, el portal lo infiere de `especialidad`. La validez de la clave la comprueba el esquema (omega_core.roles_profesionales),
no la base de datos, porque la lista de ámbitos crece por versiones del documento (v1.1 agregó 8).

Revision ID: 0020
Revises: 0019
"""
from alembic import op
import sqlalchemy as sa

revision = "0020"
down_revision = "0019"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("perfil_profesional", sa.Column("rol_clave", sa.String(length=60), nullable=True))


def downgrade() -> None:
    op.drop_column("perfil_profesional", "rol_clave")
