"""sesion web: desbloqueo de nivel 4 ligado a la sesión

El portal /ciudadano guarda aquí el id (no el token) del desbloqueo 2FA de nivel 4 abierto en esa sesión.
Al cerrar la sesión se revoca y se limpia; una sesión nueva siempre empieza bloqueada.

Revision ID: 0017
Revises: 0016
"""
from alembic import op
import sqlalchemy as sa

revision = "0017"
down_revision = "0016"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("sesion_web", sa.Column("n4_desbloqueo_id", sa.Uuid(), nullable=True))


def downgrade() -> None:
    op.drop_column("sesion_web", "n4_desbloqueo_id")
