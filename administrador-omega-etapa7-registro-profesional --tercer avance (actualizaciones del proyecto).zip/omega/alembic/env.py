from logging.config import fileConfig

from alembic import context
from sqlalchemy import create_engine, pool

from omega_core.config import settings
from omega_core.models import Base

import core_expediente.models  # noqa: F401
import portal_civil.models  # noqa: F401
import academico_cofirma.models  # noqa: F401
import nodo_edge_sync.models  # noqa: F401
import estadistica_epidemiologia.models  # noqa: F401
import laboratorio.models  # noqa: F401
import farmacia.models  # noqa: F401  (registra las tablas del módulo)
import web.comun.models  # noqa: F401  (sesiones web por portal)

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name, disable_existing_loggers=False)
target_metadata = Base.metadata


def run_migrations_offline() -> None:
    context.configure(url=settings.database_url, target_metadata=target_metadata, literal_binds=True, compare_type=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    engine = create_engine(settings.database_url, poolclass=pool.NullPool)
    with engine.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata, compare_type=True)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
