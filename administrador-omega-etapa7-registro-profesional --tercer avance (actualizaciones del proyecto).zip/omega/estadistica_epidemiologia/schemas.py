from datetime import date
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

UMBRAL = 5  # una celda con menos casos que esto NUNCA sale de la base de datos


class _In(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class MunicipioIn(_In):
    departamento: str = Field(min_length=3, max_length=60, examples=["Morazán"])
    nombre: str = Field(min_length=3, max_length=80, examples=["Perquín"])
    zona: Literal["RURAL", "URBANA"]


class MunicipioOut(BaseModel):
    departamento: str
    nombre: str
    zona: Literal["RURAL", "URBANA"]


class SaludPublicaIn(_In):
    activo: bool = Field(description="true concede el rol SALUD_PUBLICA; false lo retira.")
    motivo: str = Field(min_length=10, max_length=300)


class SaludPublicaOut(BaseModel):
    persona_id: str
    rol: str
    activo: bool


class Celda(BaseModel):
    """Una celda agregada. NUNCA lleva identificadores: solo categorías y el número de casos (siempre ≥ 5)."""

    causa: str | None = Field(None, description="Código CIE-10 de 3 caracteres (o SIN_CODIGO).")
    rango_edad: str | None = Field(None, description="0-4, 5-14, 15-29, 30-44, 45-59, 60-74, 75+ o SIN_DATO.")
    sexo: str | None = Field(None, description="F, M o SIN_DATO.")
    zona: str | None = Field(None, description="RURAL, URBANA o SIN_DATO (municipio fuera del catálogo).")
    casos: int = Field(ge=UMBRAL)


class Agregado(BaseModel):
    consulta: str
    origen: Literal["REAL", "EJEMPLO", "TODOS"]
    umbral_supresion: int = Field(description="Las celdas con menos casos que este umbral se suprimen: no aparecen.")
    celdas: list[Celda]
    celdas_suprimidas: int = Field(description="Cuántas celdas se ocultaron por tener pocos casos (sin revelar cuáles ni cuántos casos).")
    nota: str


# ------------------------------------------------------------------ Parte D: indicadores, brotes y medicamentos
class PoblacionIn(_In):
    departamento: str = Field(min_length=3, max_length=60, examples=["San Salvador"])
    anio: int = Field(ge=1900, le=2200)
    poblacion: int = Field(gt=0, le=100_000_000, description="Habitantes del departamento ese año (denominador de las tasas).")


class PoblacionOut(BaseModel):
    departamento: str
    anio: int
    poblacion: int


class CeldaIndicador(BaseModel):
    causa: str = Field(description="Código CIE-10 de 3 caracteres.")
    departamento: str = Field(description="Región (departamento del paciente); SIN_DATO si no consta.")
    casos: int = Field(ge=UMBRAL)
    poblacion: int | None = Field(None, description="Población usada como denominador (último año ≤ el del fin del periodo). null si Omega no la ha cargado.")
    tasa_por_100000: float | None = Field(None, description="casos / población × 100 000. null si no hay población.")


class IndicadorOut(BaseModel):
    indicador: Literal["incidencia", "prevalencia", "mortalidad"]
    origen: Literal["REAL", "EJEMPLO", "TODOS"]
    desde: date | None
    hasta: date
    umbral_supresion: int
    celdas: list[CeldaIndicador]
    celdas_suprimidas: int
    nota: str


class CeldaBrote(BaseModel):
    causa: str
    departamento: str
    municipio: str
    casos_ventana: int = Field(ge=UMBRAL, description="Casos en la ventana reciente.")
    promedio_base: float | None = Field(None, description="Promedio de casos por ventana en los periodos previos. null si la base tiene menos de 5 casos (no se revela).")
    razon: float | None = Field(None, description="casos_ventana / promedio_base (null si no hay base suficiente).")
    base_insuficiente: bool
    alerta: bool = Field(description="true si casos_ventana ≥ factor × max(promedio_base, 1).")


class BrotesOut(BaseModel):
    origen: Literal["REAL", "EJEMPLO", "TODOS"]
    hasta: date
    ventana_dias: int
    periodos_base: int
    factor: float
    umbral_supresion: int
    celdas: list[CeldaBrote]
    celdas_suprimidas: int
    nota: str


class CeldaMedicamento(BaseModel):
    periodo: str = Field(description="YYYY-MM (periodo=mes) o YYYY (periodo=anio).")
    departamento: str
    medicamento: str | None = Field(None, description="Nombre normalizado (minúsculas, sin tildes). No aparece en el consumo total de antibióticos.")
    prescripciones: int = Field(ge=UMBRAL, description="Renglones de receta (no recetas ni personas).")
    unidades: int = Field(description="Suma de la cantidad prescrita.")
    prescripciones_totales: int | None = Field(None, description="Solo antibióticos: todas las prescripciones del mismo periodo y región.")
    proporcion_antibioticos: float | None = Field(None, description="Solo antibióticos: prescripciones / prescripciones_totales.")


class MedicamentosOut(BaseModel):
    consulta: str
    origen: Literal["REAL", "EJEMPLO", "TODOS"]
    periodo: Literal["mes", "anio"]
    desde: date
    hasta: date
    umbral_supresion: int
    celdas: list[CeldaMedicamento]
    celdas_suprimidas: int
    nota: str


# ------------------------------------------------------------------ Parte E: vacunación y recursos
RangoEdad = Literal["0-4", "5-14", "15-29", "30-44", "45-59", "60-74", "75+"]


class PoblacionObjetivoIn(_In):
    departamento: str = Field(min_length=3, max_length=60, examples=["San Salvador"])
    anio: int = Field(ge=1900, le=2200)
    vacuna: str = Field(min_length=2, max_length=120, examples=["Influenza"])
    rango_edad: RangoEdad
    poblacion: int = Field(gt=0, le=100_000_000, description="Personas del grupo objetivo de esa vacuna, departamento, año y rango de edad.")


class PoblacionObjetivoOut(BaseModel):
    departamento: str
    anio: int
    vacuna: str
    rango_edad: str
    poblacion: int


class CeldaCobertura(BaseModel):
    vacuna: str
    departamento: str
    rango_edad: str
    personas_vacunadas: int = Field(ge=UMBRAL, description="Personas distintas con la primera dosis en el periodo (y al menos `min_dosis` dosis).")
    poblacion_objetivo: int | None = Field(None, description="Denominador cargado por Omega; null si no existe para esa vacuna, región y edad.")
    cobertura_pct: float | None = Field(None, description="personas_vacunadas / poblacion_objetivo × 100. Puede superar 100 si el denominador está desactualizado.")


class CoberturaOut(BaseModel):
    origen: Literal["REAL", "EJEMPLO", "TODOS"]
    desde: date
    hasta: date
    min_dosis: int
    umbral_supresion: int
    celdas: list[CeldaCobertura]
    celdas_suprimidas: int
    nota: str


class CeldaInsumo(BaseModel):
    departamento: str
    medicamento: str
    farmacias: int = Field(description="Farmacias de la región con lotes de este medicamento.")
    existencias_vigentes: int = Field(description="Unidades en lotes no vencidos.")
    umbral_total: int = Field(description="Suma de los umbrales de stock bajo configurados por las farmacias de la región.")
    consumo_30d: int = Field(description="Unidades despachadas en los últimos 30 días.")
    cobertura_dias: float | None = Field(None, description="existencias / consumo diario. null si no hubo consumo.")
    por_vencer_90d: int = Field(description="Unidades vigentes que vencen en 90 días o menos.")
    estado: Literal["FALTA", "SOBRA", "ADECUADO"]
    motivo: str


class InsumosOut(BaseModel):
    dias_minimos: int
    dias_exceso: int
    celdas: list[CeldaInsumo]
    nota: str


class FilaConsultas(BaseModel):
    periodo: str
    institucion: str | None = Field(None, description="Nombre legal de la institución (solo con nivel=institucion).")
    tipo_institucion: str | None = None
    departamento: str
    consultas: int = Field(ge=UMBRAL, description="Atenciones abiertas en el periodo.")
    hospitalizaciones_nuevas: int | None = Field(None, description="Atenciones de tipo HOSPITALIZACION abiertas en el periodo. null si hubo 1 a 4 (suprimido).")


class ConsultasOut(BaseModel):
    nivel: Literal["institucion", "region"]
    periodo: Literal["mes", "anio"]
    desde: date
    hasta: date
    umbral_supresion: int
    filas: list[FilaConsultas]
    filas_suprimidas: int
    nota: str


class FilaCamas(BaseModel):
    institucion: str | None = Field(None, description="Nombre legal (solo con nivel=institucion).")
    tipo_institucion: str | None = None
    departamento: str
    camas_totales: int = Field(description="Camas activas.")
    camas_ocupadas: int | None = Field(None, description="Camas ocupadas ahora. null si hay 1 a 4 (suprimido).")
    porcentaje_ocupacion: float | None = Field(None, description="camas_ocupadas / camas_totales × 100 (null si se suprimió la ocupación).")


class CamasOut(BaseModel):
    nivel: Literal["institucion", "region"]
    umbral_supresion: int
    filas: list[FilaCamas]
    nota: str
