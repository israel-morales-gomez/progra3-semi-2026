"""Consultas agregadas sobre la vista `v_epi_evento` (sin identificadores). La supresión de celdas pequeñas se aplica en SQL: el dato no sale de la base."""
from sqlalchemy import text
from sqlalchemy.orm import Session

from .schemas import UMBRAL, Agregado, Celda

NOTA = ("Datos agregados y anonimizados. Se cuentan diagnósticos DEFINITIVOS no confidenciales (nivel < 4) y defunciones vigentes; los diagnósticos de nivel 4 no se incluyen jamás. "
        f"Celdas con menos de {UMBRAL} casos suprimidas. No se publican totales para que lo suprimido no pueda deducirse por resta.")


def _donde(tipo: str, origen: str, anio_desde, anio_hasta, zona, solo_graves: bool) -> tuple[str, dict]:
    c, p = ["tipo = :tipo"], {"tipo": tipo, "umbral": UMBRAL}
    if origen != "TODOS":
        c.append("origen = :origen")
        p["origen"] = origen
    if anio_desde:
        c.append("anio >= :ad")
        p["ad"] = anio_desde
    if anio_hasta:
        c.append("anio <= :ah")
        p["ah"] = anio_hasta
    if zona:
        c.append("zona = :zona")
        p["zona"] = zona
    if solo_graves:
        c.append("grave")
    return " AND ".join(c), p


def agregar(db: Session, consulta: str, tipo: str, dims: list[str], origen: str, anio_desde=None, anio_hasta=None, zona=None, solo_graves=False, limite: int = 500) -> Agregado:
    donde, p = _donde(tipo, origen, anio_desde, anio_hasta, zona, solo_graves)
    cols = ", ".join(dims)
    base = f"SELECT {cols}, count(*) AS n FROM v_epi_evento WHERE {donde} GROUP BY {cols}"
    filas = db.execute(text(f"SELECT {cols}, n FROM ({base}) g WHERE n >= :umbral ORDER BY n DESC, {cols} LIMIT :lim"), p | {"lim": limite}).all()
    suprimidas = db.execute(text(f"SELECT count(*) FROM ({base}) g WHERE n < :umbral"), p).scalar_one()
    celdas = [Celda(**dict(zip(dims, f[:-1])), casos=f[-1]) for f in filas]
    return Agregado(consulta=consulta, origen=origen, umbral_supresion=UMBRAL, celdas=celdas, celdas_suprimidas=suprimidas, nota=NOTA)
