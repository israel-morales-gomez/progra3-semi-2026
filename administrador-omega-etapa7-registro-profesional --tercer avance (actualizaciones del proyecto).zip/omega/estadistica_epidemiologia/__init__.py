"""Módulo estadistica_epidemiologia: estadísticas agregadas y anonimizadas para salud pública (solo Omega y rol SALUD_PUBLICA)."""
