from . import router_indicadores, router_recursos
from .router import omega_router, router

routers = [router, omega_router, router_indicadores.router, router_indicadores.omega_router, router_recursos.router, router_recursos.omega_router]
