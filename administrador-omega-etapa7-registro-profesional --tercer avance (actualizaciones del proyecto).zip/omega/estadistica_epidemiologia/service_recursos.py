"""Vacunación (cobertura) y recursos. Mismas reglas que las partes C y D: solo agregados, sin identificadores de personas, supresión de 1 a 4 casos aplicada en SQL/servicio."""
import unicodedata
from datetime import date

from sqlalchemy import text
from sqlalchemy.orm import Session

from .schemas import UMBRAL, CeldaCobertura, CeldaInsumo, FilaCamas, FilaConsultas

NOTA_COB = ("Cobertura = personas distintas vacunadas (primera dosis dentro del periodo) / población objetivo cargada por Omega para esa vacuna, departamento, año (el último ≤ el del fin del periodo) y rango de edad. "
            "La edad es la de la primera dosis. Celdas con menos de 5 personas suprimidas; sin población objetivo, la cobertura es null (no se inventan cifras). Una persona cuenta una vez por vacuna.")
NOTA_INS = ("Inventario de las farmacias activas agregado por departamento y medicamento (no se muestran farmacias individuales). FALTA: sin existencias vigentes con demanda o umbral, existencias ≤ umbral, "
            "o cobertura menor a `dias_minimos`. SOBRA: cobertura mayor a `dias_exceso`, o más unidades por vencer en 90 días que el triple del consumo mensual. Sin datos de pacientes.")
NOTA_CON = ("Consultas = atenciones abiertas en el periodo; hospitalizaciones nuevas = las de tipo HOSPITALIZACION. Región = departamento de la institución. "
            "Filas con menos de 5 consultas suprimidas; hospitalizaciones de 1 a 4 se ocultan (null). No hay datos de pacientes.")
NOTA_CAM = "Ocupación actual de las camas activas por institución o región (módulo de camas). Una ocupación de 1 a 4 camas se oculta (null) para no identificar pacientes; los totales de camas no son datos personales."


def normalizar(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s.strip().lower()) if unicodedata.category(c) != "Mn")


def cobertura(db: Session, origen: str, desde: date, hasta: date, vacuna: str | None, departamento: str | None, min_dosis: int, limite: int) -> tuple[list[CeldaCobertura], int]:
    p: dict = {"umbral": UMBRAL, "desde": desde, "hasta": hasta, "md": min_dosis, "anio": hasta.year, "lim": limite}
    c = ""
    if origen != "TODOS":
        c += " AND origen = :origen"
        p["origen"] = origen
    if vacuna:
        c += " AND vacuna = :vac"
        p["vac"] = normalizar(vacuna)
    if departamento:
        c += " AND lower(departamento) = lower(:dep)"
        p["dep"] = departamento
    base = f"SELECT vacuna, departamento, rango_edad, count(*) AS n FROM v_epi_vacuna WHERE fecha BETWEEN :desde AND :hasta AND dosis_total >= :md{c} GROUP BY 1, 2, 3"
    filas = db.execute(text(f"""SELECT g.vacuna, g.departamento, g.rango_edad, g.n, o.poblacion FROM ({base}) g
        LEFT JOIN LATERAL (SELECT x.poblacion FROM poblacion_objetivo x WHERE lower(x.departamento) = lower(g.departamento) AND x.vacuna = g.vacuna AND x.rango_edad = g.rango_edad AND x.anio <= :anio
                           ORDER BY x.anio DESC LIMIT 1) o ON true
        WHERE g.n >= :umbral ORDER BY g.vacuna, g.departamento, g.rango_edad LIMIT :lim"""), p).all()
    sup = db.execute(text(f"SELECT count(*) FROM ({base}) g WHERE n < :umbral"), p).scalar_one()
    return [CeldaCobertura(vacuna=f[0], departamento=f[1], rango_edad=f[2], personas_vacunadas=f[3], poblacion_objetivo=f[4], cobertura_pct=round(f[3] * 100 / f[4], 2) if f[4] else None) for f in filas], sup


_INSUMOS = """
WITH f AS (SELECT id, COALESCE(initcap(NULLIF(trim(departamento), '')), 'SIN_DATO') AS dep FROM institucion WHERE tipo = 'FARMACIA' AND estado = 'ACTIVA'),
stock AS (SELECT f.dep, l.medicamento AS med, count(DISTINCT l.farmacia_id) AS farmacias,
                 coalesce(sum(l.cantidad_actual) FILTER (WHERE l.fecha_vencimiento >= current_date), 0) AS existencias,
                 coalesce(sum(l.cantidad_actual) FILTER (WHERE l.fecha_vencimiento BETWEEN current_date AND current_date + 90), 0) AS por_vencer
          FROM lote l JOIN f ON f.id = l.farmacia_id GROUP BY 1, 2),
umb AS (SELECT f.dep, u.medicamento AS med, sum(u.umbral) AS umbral FROM umbral_stock u JOIN f ON f.id = u.farmacia_id GROUP BY 1, 2),
cons AS (SELECT f.dep, l.medicamento AS med, -sum(m.delta) AS consumo FROM movimiento_inventario m JOIN lote l ON l.id = m.lote_id JOIN f ON f.id = m.farmacia_id
         WHERE m.tipo = 'DESPACHO' AND m.creado_en >= now() - interval '30 days' GROUP BY 1, 2),
meds AS (SELECT dep, med FROM stock UNION SELECT dep, med FROM umb)
SELECT meds.dep, meds.med, coalesce(stock.farmacias, 0), coalesce(stock.existencias, 0), coalesce(stock.por_vencer, 0), coalesce(umb.umbral, 0), coalesce(cons.consumo, 0)
FROM meds LEFT JOIN stock USING (dep, med) LEFT JOIN umb USING (dep, med) LEFT JOIN cons USING (dep, med)
WHERE (CAST(:dep AS text) IS NULL OR lower(meds.dep) = lower(CAST(:dep AS text))) AND (CAST(:med AS text) IS NULL OR meds.med = CAST(:med AS text))
ORDER BY meds.dep, meds.med
"""


def insumos(db: Session, departamento: str | None, medicamento: str | None, dias_minimos: int, dias_exceso: int, estado: str | None) -> list[CeldaInsumo]:
    out = []
    for dep, med, farm, exist, por_venc, umbral, consumo in db.execute(text(_INSUMOS), {"dep": departamento, "med": normalizar(medicamento) if medicamento else None}).all():
        cob = round(exist * 30 / consumo, 1) if consumo > 0 else None
        motivos, st = [], "ADECUADO"
        if exist == 0 and (umbral > 0 or consumo > 0):
            st, motivos = "FALTA", ["sin existencias vigentes"]
        elif umbral > 0 and exist <= umbral:
            st, motivos = "FALTA", ["existencias ≤ umbral de stock bajo"]
        elif cob is not None and cob < dias_minimos:
            st, motivos = "FALTA", [f"cobertura de {cob} días (< {dias_minimos})"]
        elif cob is not None and cob > dias_exceso:
            st, motivos = "SOBRA", [f"cobertura de {cob} días (> {dias_exceso})"]
        elif por_venc > 0 and por_venc > consumo * 3:
            st, motivos = "SOBRA", ["unidades por vencer en 90 días superan el triple del consumo mensual"]
        if estado is None and st == "ADECUADO" or (estado not in (None, "TODOS") and st != estado):
            continue
        out.append(CeldaInsumo(departamento=dep, medicamento=med, farmacias=farm, existencias_vigentes=exist, umbral_total=umbral, consumo_30d=consumo, cobertura_dias=cob,
                               por_vencer_90d=por_venc, estado=st, motivo="; ".join(motivos) or "dentro de lo esperado"))
    out.sort(key=lambda c: ({"FALTA": 0, "SOBRA": 1, "ADECUADO": 2}[c.estado], c.departamento, c.medicamento))
    return out


def consultas(db: Session, nivel: str, periodo: str, desde: date, hasta: date, departamento: str | None, tipo: str | None, limite: int) -> tuple[list[FilaConsultas], int]:
    col = "to_char(a.abierta_en, 'YYYY-MM')" if periodo == "mes" else "to_char(a.abierta_en, 'YYYY')"
    dep = "COALESCE(initcap(NULLIF(trim(i.departamento), '')), 'SIN_DATO')"
    p: dict = {"desde": desde, "hasta": hasta, "dep": departamento, "tipo": tipo, "lim": limite}
    ins = "i.nombre_legal, i.tipo" if nivel == "institucion" else "NULL::text, NULL::text"
    grupo = f"{col}, {dep}" + (", i.nombre_legal, i.tipo" if nivel == "institucion" else "")
    base = f"""SELECT {col} AS periodo, {ins}, {dep} AS dep, count(*) AS consultas, count(*) FILTER (WHERE a.tipo_atencion = 'HOSPITALIZACION') AS hosp
               FROM atencion a JOIN institucion i ON i.id = a.institucion_id
               WHERE a.abierta_en::date BETWEEN :desde AND :hasta AND (CAST(:dep AS text) IS NULL OR lower({dep}) = lower(CAST(:dep AS text))) AND (CAST(:tipo AS text) IS NULL OR i.tipo = CAST(:tipo AS text))
               GROUP BY {grupo}"""
    filas = db.execute(text(f"SELECT * FROM ({base}) g WHERE consultas >= {UMBRAL} ORDER BY periodo DESC, consultas DESC, dep LIMIT :lim"), p).all()
    sup = db.execute(text(f"SELECT count(*) FROM ({base}) g WHERE consultas < {UMBRAL}"), p).scalar_one()
    return [FilaConsultas(periodo=f[0], institucion=f[1], tipo_institucion=f[2], departamento=f[3], consultas=f[4], hospitalizaciones_nuevas=None if 0 < f[5] < UMBRAL else f[5]) for f in filas], sup


def camas(db: Session, nivel: str, departamento: str | None, tipo: str | None) -> list[FilaCamas]:
    dep = "COALESCE(initcap(NULLIF(trim(i.departamento), '')), 'SIN_DATO')"
    sel, grupo = ("i.nombre_legal, i.tipo, ", ", i.nombre_legal, i.tipo") if nivel == "institucion" else ("NULL::text, NULL::text, ", "")
    sql = f"""SELECT {sel}{dep} AS dep, count(*) FILTER (WHERE c.activa) AS totales, count(*) FILTER (WHERE c.activa AND c.estado = 'OCUPADA') AS ocupadas
              FROM cama c JOIN institucion i ON i.id = c.institucion_id
              WHERE (CAST(:dep AS text) IS NULL OR lower({dep}) = lower(CAST(:dep AS text))) AND (CAST(:tipo AS text) IS NULL OR i.tipo = CAST(:tipo AS text))
              GROUP BY {dep}{grupo} HAVING count(*) FILTER (WHERE c.activa) > 0 ORDER BY dep{', i.nombre_legal' if nivel == 'institucion' else ''}"""
    out = []
    for nombre, tp, d, tot, ocu in db.execute(text(sql), {"dep": departamento, "tipo": tipo}).all():
        oculto = 0 < ocu < UMBRAL
        out.append(FilaCamas(institucion=nombre, tipo_institucion=tp, departamento=d, camas_totales=tot, camas_ocupadas=None if oculto else ocu,
                             porcentaje_ocupacion=None if oculto else round(ocu * 100 / tot, 1)))
    return out
