from datetime import date
from typing import Literal

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.deps import require_permiso
from omega_core.models import Persona
from omega_core.security.ratelimit import ip_cliente

from . import service_recursos as sr
from .deps import Acceso, acceso_estadistica
from .models import PoblacionObjetivo
from .router_indicadores import _ORIGEN, _audit, _DEP, _DESDE, _HASTA, ERR, Origen, _periodo
from .schemas import (UMBRAL, CamasOut, CoberturaOut, ConsultasOut, InsumosOut, PoblacionObjetivoIn, PoblacionObjetivoOut)

router = APIRouter(prefix="/estadisticas", tags=["estadística epidemiológica"])
_NIVEL = Query("institucion", description="`institucion` (una fila por institución) o `region` (agregado por departamento).")
_TIPO = Query(None, pattern="^(HOSPITAL|CLINICA|LABORATORIO|FARMACIA)$", description="Filtra por tipo de institución.")


@router.get("/vacunacion/cobertura", response_model=CoberturaOut, responses=ERR, summary="Vacunación por región y edad, con cobertura",
            description=("Personas distintas vacunadas (primera dosis entre `desde` y `hasta`) por vacuna, departamento y rango de edad, y su **cobertura**: porcentaje de la población objetivo cargada por Omega "
                         "(`PUT /estadisticas/poblacion-objetivo`). `min_dosis` pide al menos N dosis (esquemas completos). Sin identificadores; celdas con menos de 5 personas suprimidas."))
def cobertura(origen: Origen = _ORIGEN, desde: date | None = _DESDE, hasta: date | None = _HASTA, vacuna: str | None = Query(None, max_length=120, description="Nombre de la vacuna, p. ej. `Influenza`."),
              departamento: str | None = _DEP, min_dosis: int = Query(1, ge=1, le=10), limite: int = Query(200, ge=1, le=1000),
              a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    d, h = _periodo(db, desde, hasta)
    celdas, sup = sr.cobertura(db, origen, d, h, vacuna, departamento, min_dosis, limite)
    _audit(a, "vacunacion_cobertura", len(celdas), sup, origen=origen, desde=str(d), hasta=str(h), vacuna=vacuna, departamento=departamento, min_dosis=min_dosis)
    return CoberturaOut(origen=origen, desde=d, hasta=h, min_dosis=min_dosis, umbral_supresion=UMBRAL, celdas=celdas, celdas_suprimidas=sup, nota=sr.NOTA_COB)


@router.get("/poblacion-objetivo", response_model=list[PoblacionObjetivoOut], responses=ERR, summary="Población objetivo de vacunación cargada (denominador de la cobertura)")
def poblacion_objetivo(a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    filas = db.scalars(select(PoblacionObjetivo).order_by(PoblacionObjetivo.vacuna, PoblacionObjetivo.departamento, PoblacionObjetivo.anio, PoblacionObjetivo.rango_edad)).all()
    _audit(a, "poblacion_objetivo", len(filas), 0)
    return [PoblacionObjetivoOut(departamento=f.departamento, anio=f.anio, vacuna=f.vacuna, rango_edad=f.rango_edad, poblacion=f.poblacion) for f in filas]


@router.get("/recursos/insumos", response_model=InsumosOut, responses=ERR, summary="Insumos que faltan o sobran (inventario de farmacia)",
            description=("Agrega el inventario de las farmacias activas por departamento y medicamento: existencias vigentes, umbrales de stock bajo, consumo de 30 días, cobertura en días y unidades por vencer. "
                         "Por defecto solo FALTA y SOBRA; `estado=TODOS` incluye los adecuados. No muestra farmacias individuales ni datos de pacientes."))
def recursos_insumos(departamento: str | None = _DEP, medicamento: str | None = Query(None, max_length=120), estado: Literal["FALTA", "SOBRA", "ADECUADO", "TODOS"] | None = Query(None),
                     dias_minimos: int = Query(15, ge=1, le=365, description="Cobertura por debajo de la cual falta."), dias_exceso: int = Query(180, ge=30, le=3650, description="Cobertura por encima de la cual sobra."),
                     a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    celdas = sr.insumos(db, departamento, medicamento, dias_minimos, dias_exceso, estado)
    _audit(a, "recursos_insumos", len(celdas), 0, departamento=departamento, medicamento=medicamento, estado=estado)
    return InsumosOut(dias_minimos=dias_minimos, dias_exceso=dias_exceso, celdas=celdas, nota=sr.NOTA_INS)


@router.get("/recursos/consultas", response_model=ConsultasOut, responses=ERR, summary="Consultas totales y hospitalizaciones nuevas por institución y región",
            description="Atenciones abiertas en el periodo (consultas totales) y las de tipo HOSPITALIZACION (nuevas hospitalizaciones), por mes o año, por institución o por región. Filas con menos de 5 consultas suprimidas; hospitalizaciones de 1 a 4 ocultas.")
def recursos_consultas(nivel: Literal["institucion", "region"] = _NIVEL, periodo: Literal["mes", "anio"] = Query("mes"), desde: date | None = _DESDE, hasta: date | None = _HASTA,
                       departamento: str | None = _DEP, tipo: str | None = _TIPO, limite: int = Query(200, ge=1, le=1000), a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    d, h = _periodo(db, desde, hasta)
    filas, sup = sr.consultas(db, nivel, periodo, d, h, departamento, tipo, limite)
    _audit(a, "recursos_consultas", len(filas), sup, nivel=nivel, periodo=periodo, desde=str(d), hasta=str(h), departamento=departamento, tipo=tipo)
    return ConsultasOut(nivel=nivel, periodo=periodo, desde=d, hasta=h, umbral_supresion=UMBRAL, filas=filas, filas_suprimidas=sup, nota=sr.NOTA_CON)


@router.get("/recursos/camas", response_model=CamasOut, responses=ERR, summary="Ocupación de camas por institución y región",
            description="Camas activas, camas ocupadas ahora y porcentaje de ocupación, por institución o por región. Una ocupación de 1 a 4 camas se oculta (null).")
def recursos_camas(nivel: Literal["institucion", "region"] = _NIVEL, departamento: str | None = _DEP, tipo: str | None = _TIPO,
                   a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    filas = sr.camas(db, nivel, departamento, tipo)
    _audit(a, "recursos_camas", len(filas), sum(1 for f in filas if f.camas_ocupadas is None), nivel=nivel, departamento=departamento, tipo=tipo)
    return CamasOut(nivel=nivel, umbral_supresion=UMBRAL, filas=filas, nota=sr.NOTA_CAM)


omega_router = APIRouter(tags=["administrador omega"])


@omega_router.put("/estadisticas/poblacion-objetivo", response_model=PoblacionObjetivoOut, responses={403: {"description": "Solo el Administrador Omega"}},
                  summary="Cargar la población objetivo de una vacuna (solo Omega)", description="Upsert por (departamento, año, vacuna, rango de edad). Queda en la bitácora.")
def guardar_objetivo(datos: PoblacionObjetivoIn, request: Request, omega: Persona = Depends(require_permiso("omega:administrar")), db: Session = Depends(get_db)):
    vac = sr.normalizar(datos.vacuna)
    f = db.get(PoblacionObjetivo, (datos.departamento, datos.anio, vac, datos.rango_edad))
    anterior = f.poblacion if f else None
    if f is None:
        f = PoblacionObjetivo(departamento=datos.departamento, anio=datos.anio, vacuna=vac, rango_edad=datos.rango_edad, poblacion=datos.poblacion)
        db.add(f)
    f.poblacion = datos.poblacion
    db.commit()
    auditar("ESTADISTICA_OBJETIVO_VACUNA_GUARDADO", actor_tipo="omega", actor_id=omega.id, recurso="poblacion_objetivo", ip=ip_cliente(request),
            detalle={"departamento": datos.departamento, "anio": datos.anio, "vacuna": vac, "rango_edad": datos.rango_edad, "poblacion": datos.poblacion, "anterior": anterior})
    return PoblacionObjetivoOut(departamento=f.departamento, anio=f.anio, vacuna=f.vacuna, rango_edad=f.rango_edad, poblacion=f.poblacion)
