"""Datos de ejemplo (FICTICIOS) para probar las estadísticas. Repetible y separado de los datos reales: solo escribe/borra en la tabla `epi_ejemplo`.

    python -m estadistica_epidemiologia.datos_ejemplo --generar [--semilla 42] [--cantidad 4000]   (borra el ejemplo anterior y lo regenera igual)
    python -m estadistica_epidemiologia.datos_ejemplo --borrar
    python -m estadistica_epidemiologia.datos_ejemplo --contar

Los casos no tienen DUI, nombre ni id de persona. En las consultas se piden con `?origen=EJEMPLO` (por defecto solo se consultan datos REAL).
"""
import argparse
import random
import sys
from datetime import date, timedelta

from sqlalchemy import delete, func, insert, select
from sqlalchemy.orm import Session

from omega_core.config import settings
from omega_core.database import SessionLocal

from .models import EpiEjemplo, EpiEjemploReceta, EpiEjemploVacuna, MunicipioCatalogo

MUERTES = [("I21", 12), ("I63", 9), ("J18", 8), ("C50", 5), ("C34", 5), ("E11", 7), ("K72", 3), ("N18", 6), ("A41", 4), ("X95", 3), ("V89", 3)]
DIAGNOSTICOS = [("J06", 30), ("A09", 18), ("I10", 16), ("E11", 12), ("J45", 9), ("N39", 8), ("B34", 7), ("J18", 5), ("I21", 2), ("I63", 2), ("N18", 3), ("C50", 2), ("A41", 1)]
MEDICAMENTOS = [("Paracetamol 500 mg", 30, 0), ("Ibuprofeno 400 mg", 14, 0), ("Amoxicilina 500 mg", 16, 1), ("Azitromicina 500 mg", 7, 1), ("Ciprofloxacino 500 mg", 5, 1),
                ("Metformina 850 mg", 10, 0), ("Losartán 50 mg", 9, 0), ("Omeprazol 20 mg", 9, 0)]
VACUNAS = [("Influenza", 5), ("Sarampión, rubéola y paperas (SRP)", 6), ("Pentavalente", 6), ("Hepatitis B", 4), ("Neumococo", 3)]
RAROS = [("FALLECIDO", "A15", "F", 33, "Perquín", "Morazán", 2), ("DIAGNOSTICO", "K72", "M", 81, "Arambala", "Morazán", 3)]  # celdas pequeñas a propósito: deben quedar suprimidas


def borrar(db: Session) -> int:
    n = db.execute(delete(EpiEjemplo)).rowcount + db.execute(delete(EpiEjemploReceta)).rowcount + db.execute(delete(EpiEjemploVacuna)).rowcount
    db.commit()
    return n


def generar(db: Session, semilla: int = 42, cantidad: int = 4000, hoy: date | None = None) -> int:
    """Borra el ejemplo anterior y lo vuelve a generar: la misma semilla produce siempre los mismos casos (si `hoy` es el mismo)."""
    rnd, hoy = random.Random(semilla), hoy or date.today()
    borrar(db)
    munis = db.execute(select(MunicipioCatalogo.departamento, MunicipioCatalogo.nombre, MunicipioCatalogo.zona)).all()
    if not munis:
        raise RuntimeError("El catálogo de municipios está vacío: ejecute `alembic upgrade head`.")
    pesos_m = [3 if z == "URBANA" else 2 for _, _, z in munis]
    filas = []
    for _ in range(cantidad):
        muerte = rnd.random() < 0.15
        codigo = rnd.choices(*zip(*(MUERTES if muerte else DIAGNOSTICOS)))[0]
        dep, mun, _z = rnd.choices(munis, pesos_m)[0]
        edad = min(100, int(rnd.triangular(0, 100, 62 if muerte else 38)))
        filas.append({"tipo": "FALLECIDO" if muerte else "DIAGNOSTICO", "fecha": hoy - timedelta(days=rnd.randint(0, 700)), "edad": edad,
                      "sexo": rnd.choice("FM"), "departamento": dep, "municipio": mun, "codigo_cie10": codigo,
                      "estatus": "ACTIVA" if muerte else rnd.choices(["ACTIVA", "EN_REMISION", "CURADA"], [5, 2, 3])[0]})
    for tipo, codigo, sexo, edad, mun, dep, n in RAROS:
        filas += [{"tipo": tipo, "fecha": hoy - timedelta(days=30 + i), "edad": edad, "sexo": sexo, "departamento": dep, "municipio": mun, "codigo_cie10": codigo} for i in range(n)]
    filas += [{"tipo": "DIAGNOSTICO", "fecha": hoy - timedelta(days=i % 4), "edad": 20 + i, "sexo": "FM"[i % 2], "departamento": "Morazán", "municipio": "Perquín",
               "codigo_cie10": "A09", "estatus": "ACTIVA"} for i in range(12)]  # brote de ejemplo: 12 casos recientes en Perquín
    db.execute(insert(EpiEjemplo), filas)
    recetas = []
    for _ in range(cantidad):
        dep, mun, _z = rnd.choices(munis, pesos_m)[0]
        recetas.append({"fecha": hoy - timedelta(days=rnd.randint(0, 700)), "departamento": dep, "municipio": mun, "cantidad": rnd.randint(5, 30),
                        "medicamento": rnd.choices([m[0] for m in MEDICAMENTOS], [m[1] for m in MEDICAMENTOS])[0]})
    recetas += [{"fecha": hoy - timedelta(days=40 + i), "departamento": "Morazán", "municipio": "Arambala", "cantidad": 10, "medicamento": "Vancomicina 1 g"} for i in range(3)]  # celda rara: suprimida
    db.execute(insert(EpiEjemploReceta), recetas)
    vacunados = []
    for _ in range(cantidad):
        dep, mun, _z = rnd.choices(munis, pesos_m)[0]
        vacunados.append({"fecha": hoy - timedelta(days=rnd.randint(0, 400)), "edad": min(90, int(rnd.triangular(0, 90, 6))), "sexo": rnd.choice("FM"), "departamento": dep, "municipio": mun,
                          "vacuna": rnd.choices([v[0] for v in VACUNAS], [v[1] for v in VACUNAS])[0], "dosis_total": rnd.choices([1, 2, 3], [5, 3, 2])[0]})
    vacunados += [{"fecha": hoy - timedelta(days=20 + i), "edad": 70, "sexo": "F", "departamento": "Morazán", "municipio": "Arambala", "vacuna": "Neumococo", "dosis_total": 1} for i in range(2)]  # celda rara: suprimida
    db.execute(insert(EpiEjemploVacuna), vacunados)
    db.commit()
    return len(filas) + len(recetas) + len(vacunados)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--generar", action="store_true")
    g.add_argument("--borrar", action="store_true")
    g.add_argument("--contar", action="store_true")
    ap.add_argument("--semilla", type=int, default=42)
    ap.add_argument("--cantidad", type=int, default=4000)
    a = ap.parse_args()
    if settings.produccion and not a.contar:
        sys.exit("Los datos de ejemplo no se generan ni se borran con ENTORNO=produccion.")
    with SessionLocal() as db:
        if a.generar:
            print(f"Generados {generar(db, a.semilla, a.cantidad)} registros ficticios (tablas epi_ejemplo y epi_ejemplo_receta).")
        elif a.borrar:
            print(f"Borrados {borrar(db)} casos de ejemplo. Los datos reales no se tocaron.")
        else:
            print("Casos de ejemplo:", db.scalar(select(func.count()).select_from(EpiEjemplo)), "| prescripciones de ejemplo:", db.scalar(select(func.count()).select_from(EpiEjemploReceta)))


if __name__ == "__main__":
    main()
