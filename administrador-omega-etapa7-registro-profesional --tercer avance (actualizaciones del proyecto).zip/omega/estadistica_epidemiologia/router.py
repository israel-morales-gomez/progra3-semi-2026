import uuid
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.deps import require_omega, require_permiso
from omega_core.models import Persona, Rol
from omega_core.security.ratelimit import ip_cliente

from . import service
from .deps import ROL_SALUD_PUBLICA, Acceso, acceso_estadistica
from .models import MunicipioCatalogo
from .schemas import Agregado, MunicipioIn, MunicipioOut, SaludPublicaIn, SaludPublicaOut

router = APIRouter(prefix="/estadisticas", tags=["estadística epidemiológica"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Solo el Administrador Omega y el rol SALUD_PUBLICA (el intento queda auditado)"}}
Origen = Literal["REAL", "EJEMPLO", "TODOS"]
_ORIGEN = Query("REAL", description="`REAL` (por defecto), `EJEMPLO` (casos ficticios de prueba) o `TODOS`.")
_AD = Query(None, ge=1900, le=2200, description="Año inicial (incluido).")
_AH = Query(None, ge=1900, le=2200, description="Año final (incluido).")
_ZONA = Query(None, pattern="^(RURAL|URBANA)$", description="Filtra por zona.")


def _responder(db: Session, a: Acceso, consulta: str, tipo: str, dims: list[str], origen: str, ad, ah, zona=None, graves=False, limite=500) -> Agregado:
    r = service.agregar(db, consulta, tipo, dims, origen, ad, ah, zona, graves, limite)
    auditar("ESTADISTICA_CONSULTADA", actor_tipo=a.actor_tipo, actor_id=a.actor_id, recurso="estadisticas", ip=a.ip,
            detalle={"consulta": consulta, "origen": origen, "anio_desde": ad, "anio_hasta": ah, "zona": zona, "celdas": len(r.celdas), "suprimidas": r.celdas_suprimidas})
    return r


@router.get("/fallecidos", response_model=Agregado, responses=ERR, summary="Fallecidos por causa, rango de edad y género",
            description="Defunciones vigentes agrupadas por causa (CIE-10, 3 caracteres), rango de edad y sexo. **Agregado y anonimizado**: sin DUI, nombres ni identificadores; las celdas con menos de 5 casos se suprimen.")
def fallecidos(origen: Origen = _ORIGEN, anio_desde: int | None = _AD, anio_hasta: int | None = _AH, zona: str | None = _ZONA,
               a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    return _responder(db, a, "fallecidos_por_causa_edad_genero", "FALLECIDO", ["causa", "rango_edad", "sexo"], origen, anio_desde, anio_hasta, zona)


@router.get("/enfermedades-comunes", response_model=Agregado, responses=ERR, summary="Enfermedades más comunes por rango de edad y zona rural/urbana",
            description="Diagnósticos definitivos no confidenciales por código CIE-10 (3 caracteres), rango de edad y zona (según el catálogo de municipios), de mayor a menor. Celdas con menos de 5 casos suprimidas.")
def enfermedades_comunes(origen: Origen = _ORIGEN, anio_desde: int | None = _AD, anio_hasta: int | None = _AH, zona: str | None = _ZONA,
                         limite: int = Query(50, ge=1, le=200, description="Máximo de celdas devueltas."),
                         a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    return _responder(db, a, "enfermedades_comunes_por_edad_zona", "DIAGNOSTICO", ["causa", "rango_edad", "zona"], origen, anio_desde, anio_hasta, zona, False, limite)


@router.get("/enfermedades-graves", response_model=Agregado, responses=ERR, summary="Enfermedades graves por género y rango de edad",
            description="Solo diagnósticos cuyo código CIE-10 está en el catálogo de enfermedades graves, por código, sexo y rango de edad. Celdas con menos de 5 casos suprimidas.")
def enfermedades_graves(origen: Origen = _ORIGEN, anio_desde: int | None = _AD, anio_hasta: int | None = _AH, zona: str | None = _ZONA,
                        a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    return _responder(db, a, "enfermedades_graves_por_genero_edad", "DIAGNOSTICO", ["causa", "sexo", "rango_edad"], origen, anio_desde, anio_hasta, zona, True)


@router.get("/municipios", response_model=list[MunicipioOut], responses=ERR, summary="Catálogo de municipios con su zona (rural/urbana)",
            description="Catálogo con el que se agrupa por zona. Un municipio fuera del catálogo se cuenta como zona `SIN_DATO`.")
def municipios(a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    filas = db.scalars(select(MunicipioCatalogo).order_by(MunicipioCatalogo.departamento, MunicipioCatalogo.nombre)).all()
    auditar("ESTADISTICA_CONSULTADA", actor_tipo=a.actor_tipo, actor_id=a.actor_id, recurso="estadisticas", ip=a.ip, detalle={"consulta": "catalogo_municipios", "filas": len(filas)})
    return [MunicipioOut(departamento=m.departamento, nombre=m.nombre, zona=m.zona) for m in filas]


# ------------------------------------------------------------------ Solo Omega: mantener el catálogo y conceder el rol
omega_router = APIRouter(tags=["administrador omega"])


@omega_router.put("/estadisticas/municipios", response_model=MunicipioOut, summary="Crear o actualizar un municipio del catálogo (solo Omega)",
                  responses={403: {"description": "Solo el Administrador Omega"}}, description="Upsert por (departamento, nombre). Queda en la bitácora.")
def guardar_municipio(datos: MunicipioIn, request: Request, omega: Persona = Depends(require_permiso("omega:administrar")), db: Session = Depends(get_db)):
    m = db.scalar(select(MunicipioCatalogo).where(MunicipioCatalogo.departamento == datos.departamento, MunicipioCatalogo.nombre == datos.nombre))
    anterior = m.zona if m else None
    if m is None:
        m = MunicipioCatalogo(departamento=datos.departamento, nombre=datos.nombre, zona=datos.zona)
        db.add(m)
    m.zona = datos.zona
    db.commit()
    auditar("ESTADISTICA_MUNICIPIO_GUARDADO", actor_tipo="omega", actor_id=omega.id, recurso="municipio_catalogo", ip=ip_cliente(request),
            detalle={"departamento": datos.departamento, "nombre": datos.nombre, "zona": datos.zona, "zona_anterior": anterior})
    return MunicipioOut(departamento=m.departamento, nombre=m.nombre, zona=m.zona)


@omega_router.put("/omega/personas/{persona_id}/salud-publica", response_model=SaludPublicaOut, summary="Conceder o retirar el rol de salud pública (solo Omega)",
                  responses={403: {"description": "Solo el Administrador Omega"}, 404: {"description": "Persona no encontrada"}},
                  description="El rol SALUD_PUBLICA solo permite consultar `/estadisticas/*` (agregados anonimizados); no abre ningún dato clínico ni de identidad.")
def rol_salud_publica(persona_id: uuid.UUID, datos: SaludPublicaIn, request: Request, omega: Persona = Depends(require_permiso("omega:administrar")), db: Session = Depends(get_db)):
    p = db.get(Persona, persona_id)
    if p is None or p.es_omega:
        raise HTTPException(404, "Persona no encontrada")
    rol = db.scalars(select(Rol).where(Rol.nombre == ROL_SALUD_PUBLICA)).one()
    if datos.activo and rol not in p.roles:
        p.roles.append(rol)
    if not datos.activo and rol in p.roles:
        p.roles.remove(rol)
    db.commit()
    auditar("ESTADISTICA_ROL_SALUD_PUBLICA", actor_tipo="omega", actor_id=omega.id, recurso="persona", recurso_id=p.id, ip=ip_cliente(request),
            detalle={"activo": datos.activo, "motivo": datos.motivo})
    return SaludPublicaOut(persona_id=str(p.id), rol=ROL_SALUD_PUBLICA, activo=datos.activo)
