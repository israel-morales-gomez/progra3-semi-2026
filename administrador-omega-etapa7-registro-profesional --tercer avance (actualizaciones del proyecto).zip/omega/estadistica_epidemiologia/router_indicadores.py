from datetime import date, timedelta
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import select, text
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.deps import require_permiso
from omega_core.models import Persona
from omega_core.security.ratelimit import ip_cliente

from . import service_indicadores as si
from .deps import Acceso, acceso_estadistica
from .models import PoblacionRegion
from .schemas import UMBRAL, BrotesOut, IndicadorOut, MedicamentosOut, PoblacionIn, PoblacionOut

router = APIRouter(prefix="/estadisticas", tags=["estadística epidemiológica"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Solo el Administrador Omega y el rol SALUD_PUBLICA (el intento queda auditado)"},
       422: {"description": "Parámetros inválidos (p. ej. periodo invertido o demasiado largo)"}}
Origen = Literal["REAL", "EJEMPLO", "TODOS"]
_ORIGEN = Query("REAL", description="`REAL` (por defecto), `EJEMPLO` (casos ficticios) o `TODOS`.")
_DESDE = Query(None, description="Inicio del periodo (incluido). Por defecto, 365 días antes de `hasta`.")
_HASTA = Query(None, description="Fin del periodo (incluido). Por defecto, hoy.")
_CAUSA = Query(None, pattern=r"^[A-Za-z][0-9A-Za-z]{2}$", description="Enfermedad: código CIE-10 de 3 caracteres, p. ej. `J06`.")
_DEP = Query(None, max_length=60, description="Región: nombre del departamento.")
MAX_DIAS = 3660


def _hoy(db: Session) -> date:
    return db.execute(text("SELECT current_date")).scalar_one()  # misma zona horaria que usan las vistas (fecha::date)


def _periodo(db: Session, desde: date | None, hasta: date | None) -> tuple[date, date]:
    hasta = hasta or _hoy(db)
    desde = desde or hasta - timedelta(days=365)
    if desde > hasta:
        raise HTTPException(422, "`desde` no puede ser posterior a `hasta`")
    if (hasta - desde).days > MAX_DIAS:
        raise HTTPException(422, "El periodo no puede superar 10 años")
    return desde, hasta


def _audit(a: Acceso, consulta: str, celdas: int, suprimidas: int, **filtros):
    auditar("ESTADISTICA_CONSULTADA", actor_tipo=a.actor_tipo, actor_id=a.actor_id, recurso="estadisticas", ip=a.ip,
            detalle={"consulta": consulta, "celdas": celdas, "suprimidas": suprimidas} | {k: v for k, v in filtros.items() if v is not None})


def _indicador(nombre, origen, desde, hasta, causa, dep, limite, a, db) -> IndicadorOut:
    d, h = _periodo(db, desde, hasta)
    celdas, sup = si.indicador(db, nombre, origen, d, h, causa, dep, limite)
    _audit(a, f"indicador_{nombre}", len(celdas), sup, origen=origen, desde=str(d), hasta=str(h), causa=causa, departamento=dep)
    return IndicadorOut(indicador=nombre, origen=origen, desde=None if nombre == "prevalencia" else d, hasta=h, umbral_supresion=UMBRAL, celdas=celdas, celdas_suprimidas=sup, nota=si.NOTA_IND)


@router.get("/indicadores/incidencia", response_model=IndicadorOut, responses=ERR, summary="Incidencia por enfermedad y región",
            description="Diagnósticos nuevos del periodo (`desde`–`hasta`) por enfermedad (CIE-10, 3 caracteres) y departamento, con la tasa por 100 000 habitantes si hay población cargada. Mismas reglas de acceso y anonimización que el resto: celdas con menos de 5 casos suprimidas.")
def incidencia(origen: Origen = _ORIGEN, desde: date | None = _DESDE, hasta: date | None = _HASTA, causa: str | None = _CAUSA, departamento: str | None = _DEP,
               limite: int = Query(100, ge=1, le=500), a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    return _indicador("incidencia", origen, desde, hasta, causa, departamento, limite, a, db)


@router.get("/indicadores/prevalencia", response_model=IndicadorOut, responses=ERR, summary="Prevalencia por enfermedad y región",
            description="Casos con diagnóstico ACTIVA o EN_REMISION registrados hasta `hasta` (corte), por enfermedad y departamento, y su tasa por 100 000 habitantes. `desde` se ignora. Celdas con menos de 5 casos suprimidas.")
def prevalencia(origen: Origen = _ORIGEN, hasta: date | None = _HASTA, causa: str | None = _CAUSA, departamento: str | None = _DEP,
                limite: int = Query(100, ge=1, le=500), a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    return _indicador("prevalencia", origen, None, hasta, causa, departamento, limite, a, db)


@router.get("/indicadores/mortalidad", response_model=IndicadorOut, responses=ERR, summary="Tasa de mortalidad por enfermedad (causa) y región",
            description="Defunciones vigentes del periodo por causa (CIE-10, 3 caracteres) y departamento de residencia, y su tasa por 100 000 habitantes. Celdas con menos de 5 casos suprimidas.")
def mortalidad(origen: Origen = _ORIGEN, desde: date | None = _DESDE, hasta: date | None = _HASTA, causa: str | None = _CAUSA, departamento: str | None = _DEP,
               limite: int = Query(100, ge=1, le=500), a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    return _indicador("mortalidad", origen, desde, hasta, causa, departamento, limite, a, db)


@router.get("/brotes", response_model=BrotesOut, responses=ERR, summary="Detección simple de brotes por municipio",
            description=("Para cada enfermedad y municipio compara los casos de la ventana reciente (`ventana_dias` hasta `hasta`) con el promedio de los `periodos_base` periodos previos de igual duración. "
                         "`alerta` = casos ≥ `factor` × max(promedio, 1). Solo municipios con 5 o más casos en la ventana; si la base suma menos de 5, su promedio no se revela."))
def detectar_brotes(origen: Origen = _ORIGEN, hasta: date | None = _HASTA, ventana_dias: int = Query(7, ge=1, le=60), periodos_base: int = Query(8, ge=2, le=52),
                    factor: float = Query(2.0, ge=1.0, le=20.0, description="Cuántas veces el promedio reciente debe superarse para alertar."),
                    causa: str | None = _CAUSA, departamento: str | None = _DEP, a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    h = hasta or _hoy(db)
    celdas, sup = si.brotes(db, origen, h, ventana_dias, periodos_base, factor, causa, departamento)
    _audit(a, "deteccion_brotes", len(celdas), sup, origen=origen, hasta=str(h), ventana_dias=ventana_dias, periodos_base=periodos_base, factor=factor, causa=causa, departamento=departamento)
    return BrotesOut(origen=origen, hasta=h, ventana_dias=ventana_dias, periodos_base=periodos_base, factor=factor, umbral_supresion=UMBRAL, celdas=celdas, celdas_suprimidas=sup, nota=si.NOTA_BROTE)


def _med(consulta, origen, desde, hasta, periodo, dep, limite, a, db) -> MedicamentosOut:
    d, h = _periodo(db, desde, hasta)
    celdas, sup = si.medicamentos(db, consulta, origen, d, h, periodo, dep, limite)
    _audit(a, f"medicamentos_{consulta}", len(celdas), sup, origen=origen, desde=str(d), hasta=str(h), periodo=periodo, departamento=dep)
    return MedicamentosOut(consulta=consulta, origen=origen, periodo=periodo, desde=d, hasta=h, umbral_supresion=UMBRAL, celdas=celdas, celdas_suprimidas=sup, nota=si.NOTA_MED)


_PERIODO = Query("mes", description="Agrupación temporal: `mes` (YYYY-MM) o `anio`.")


@router.get("/medicamentos/mas-prescritos", response_model=MedicamentosOut, responses=ERR, summary="Medicamentos más prescritos por periodo y región",
            description="Renglones de receta (no recetas, pacientes ni médicos) por medicamento, periodo y departamento, de mayor a menor. Celdas con menos de 5 prescripciones suprimidas.")
def mas_prescritos(origen: Origen = _ORIGEN, desde: date | None = _DESDE, hasta: date | None = _HASTA, periodo: Literal["mes", "anio"] = _PERIODO, departamento: str | None = _DEP,
                   limite: int = Query(50, ge=1, le=500), a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    return _med("mas_prescritos", origen, desde, hasta, periodo, departamento, limite, a, db)


@router.get("/medicamentos/antibioticos", response_model=MedicamentosOut, responses=ERR, summary="Consumo de antibióticos por periodo y región",
            description="Prescripciones y unidades de antibióticos por periodo y departamento, con su proporción sobre todas las prescripciones de la misma celda. Celdas con menos de 5 prescripciones de antibióticos suprimidas.")
def antibioticos(origen: Origen = _ORIGEN, desde: date | None = _DESDE, hasta: date | None = _HASTA, periodo: Literal["mes", "anio"] = _PERIODO, departamento: str | None = _DEP,
                 limite: int = Query(200, ge=1, le=1000), a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    return _med("antibioticos", origen, desde, hasta, periodo, departamento, limite, a, db)


@router.get("/poblacion", response_model=list[PoblacionOut], responses=ERR, summary="Población por departamento y año (denominador de las tasas)")
def poblacion(a: Acceso = Depends(acceso_estadistica), db: Session = Depends(get_db)):
    filas = db.scalars(select(PoblacionRegion).order_by(PoblacionRegion.departamento, PoblacionRegion.anio)).all()
    _audit(a, "poblacion_region", len(filas), 0)
    return [PoblacionOut(departamento=f.departamento, anio=f.anio, poblacion=f.poblacion) for f in filas]


omega_router = APIRouter(tags=["administrador omega"])


@omega_router.put("/estadisticas/poblacion", response_model=PoblacionOut, responses={403: {"description": "Solo el Administrador Omega"}}, summary="Cargar o actualizar la población de un departamento (solo Omega)",
                  description="Upsert por (departamento, año). Omega carga aquí las cifras oficiales; el sistema no trae cifras inventadas. Queda en la bitácora.")
def guardar_poblacion(datos: PoblacionIn, request: Request, omega: Persona = Depends(require_permiso("omega:administrar")), db: Session = Depends(get_db)):
    f = db.get(PoblacionRegion, (datos.departamento, datos.anio))
    anterior = f.poblacion if f else None
    if f is None:
        f = PoblacionRegion(departamento=datos.departamento, anio=datos.anio, poblacion=datos.poblacion)
        db.add(f)
    f.poblacion = datos.poblacion
    db.commit()
    auditar("ESTADISTICA_POBLACION_GUARDADA", actor_tipo="omega", actor_id=omega.id, recurso="poblacion_region", ip=ip_cliente(request),
            detalle={"departamento": datos.departamento, "anio": datos.anio, "poblacion": datos.poblacion, "anterior": anterior})
    return PoblacionOut(departamento=f.departamento, anio=f.anio, poblacion=f.poblacion)
