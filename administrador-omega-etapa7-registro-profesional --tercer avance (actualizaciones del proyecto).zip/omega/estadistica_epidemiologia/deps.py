"""Acceso exclusivo: Administrador Omega (token omega, IP autorizada) o persona con el rol SALUD_PUBLICA. Cualquier otro intento se rechaza y se audita."""
import uuid
from dataclasses import dataclass

from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.deps import _bearer, ip_permitida_omega
from omega_core.models import Persona
from omega_core.security.ratelimit import ip_cliente, limitar_ip
from omega_core.security.tokens import decodificar

ROL_SALUD_PUBLICA = "SALUD_PUBLICA"


@dataclass
class Acceso:
    actor_tipo: str  # omega | salud_publica
    actor_id: uuid.UUID
    ip: str


def acceso_estadistica(request: Request, cred: HTTPAuthorizationCredentials | None = Depends(_bearer), db: Session = Depends(get_db)) -> Acceso:
    limitar_ip(request, "estadistica", 120)
    ip = ip_cliente(request)

    def negar(codigo: int, mensaje: str, motivo: str, actor_tipo: str = "anonimo", actor_id=None):
        auditar("ESTADISTICA_ACCESO_DENEGADO", actor_tipo=actor_tipo, actor_id=actor_id, recurso="estadisticas", resultado="FALLO", ip=ip,
                detalle={"motivo": motivo, "ruta": request.url.path})
        raise HTTPException(codigo, mensaje, headers={"WWW-Authenticate": "Bearer"} if codigo == 401 else None)

    if cred is None:
        negar(401, "No autenticado", "SIN_TOKEN")
    p = decodificar(cred.credentials, "access")
    persona = db.get(Persona, uuid.UUID(p["sub"])) if p["typ"] in ("omega", "persona") else None
    if p["typ"] == "omega":
        if persona is None or not persona.activo or not persona.es_omega:
            negar(401, "No autenticado", "OMEGA_INVALIDO")
        if not ip_permitida_omega(ip):
            negar(403, "Acceso no permitido desde esta red", "IP_NO_AUTORIZADA", "omega", persona.id)
        return Acceso("omega", persona.id, ip)
    if p["typ"] == "persona":
        if persona is None or not persona.activo:
            negar(401, "No autenticado", "PERSONA_INVALIDA")
        if ROL_SALUD_PUBLICA not in persona.nombres_roles:
            negar(403, "Acceso restringido a Salud Pública y al Administrador Omega", "ROL_NO_AUTORIZADO", "persona", persona.id)
        return Acceso("salud_publica", persona.id, ip)
    negar(403, "Acceso restringido a Salud Pública y al Administrador Omega", "TIPO_CREDENCIAL_NO_PERMITIDO", p["typ"], p.get("sub"))
