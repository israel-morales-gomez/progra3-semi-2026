"""Indicadores, brotes y medicamentos. Mismas reglas que service.py: solo agregados, supresión (< 5) aplicada en SQL, sin totales que permitan restar."""
from datetime import date, timedelta

from sqlalchemy import text
from sqlalchemy.orm import Session

from .schemas import UMBRAL, CeldaBrote, CeldaIndicador, CeldaMedicamento

NOTA_IND = ("Agregados anonimizados; celdas con menos de 5 casos suprimidas. Casos = diagnósticos DEFINITIVOS no confidenciales (nivel < 4) y defunciones vigentes; región = departamento de residencia. "
            "Incidencia: diagnósticos nuevos en el periodo. Prevalencia: diagnósticos ACTIVA o EN_REMISION registrados hasta el fin del periodo (el estatus es el actual). "
            "Mortalidad: defunciones en el periodo por causa. Tasas por 100 000 habitantes con la población cargada por Omega.")
NOTA_BROTE = ("Compara los casos de la ventana reciente con el promedio de los periodos previos de igual duración, por enfermedad y municipio. Señal de alerta temprana, no un diagnóstico epidemiológico. "
              "Solo se muestran municipios con al menos 5 casos en la ventana; si la base previa suma menos de 5 casos no se revela su promedio.")
NOTA_MED = ("Agregados anonimizados: se cuentan renglones de receta (no personas ni médicos); celdas con menos de 5 prescripciones suprimidas. Región = departamento de residencia del paciente. "
            "Las recetas anuladas no cuentan. Antibiótico = el nombre empieza por un principio activo del catálogo `antibiotico_catalogo`.")


def _orig(origen: str, p: dict) -> str:
    if origen == "TODOS":
        return ""
    p["origen"] = origen
    return " AND origen = :origen"


def indicador(db: Session, nombre: str, origen: str, desde: date, hasta: date, causa: str | None, departamento: str | None, limite: int) -> tuple[list[CeldaIndicador], int]:
    p: dict = {"umbral": UMBRAL, "hasta": hasta, "anio": hasta.year, "lim": limite}
    c = _orig(origen, p)
    if nombre == "incidencia":
        c += " AND tipo = 'DIAGNOSTICO' AND fecha BETWEEN :desde AND :hasta"
        p["desde"] = desde
    elif nombre == "prevalencia":
        c += " AND tipo = 'DIAGNOSTICO' AND estatus IN ('ACTIVA', 'EN_REMISION') AND fecha <= :hasta"
    else:
        c += " AND tipo = 'FALLECIDO' AND fecha BETWEEN :desde AND :hasta"
        p["desde"] = desde
    if causa:
        c += " AND causa = :causa"
        p["causa"] = causa.upper()
    if departamento:
        c += " AND lower(departamento) = lower(:dep)"
        p["dep"] = departamento
    base = f"SELECT causa, departamento, count(*) AS n FROM v_epi_evento WHERE true{c} GROUP BY causa, departamento"
    filas = db.execute(text(f"""SELECT g.causa, g.departamento, g.n, pob.poblacion FROM ({base}) g
        LEFT JOIN LATERAL (SELECT r.poblacion FROM poblacion_region r WHERE lower(r.departamento) = lower(g.departamento) AND r.anio <= :anio ORDER BY r.anio DESC LIMIT 1) pob ON true
        WHERE g.n >= :umbral ORDER BY g.n DESC, g.causa, g.departamento LIMIT :lim"""), p).all()
    sup = db.execute(text(f"SELECT count(*) FROM ({base}) g WHERE n < :umbral"), p).scalar_one()
    return [CeldaIndicador(causa=f[0], departamento=f[1], casos=f[2], poblacion=f[3], tasa_por_100000=round(f[2] * 100000 / f[3], 2) if f[3] else None) for f in filas], sup


def brotes(db: Session, origen: str, hasta: date, ventana: int, periodos_base: int, factor: float, causa: str | None, departamento: str | None) -> tuple[list[CeldaBrote], int]:
    ini_v = hasta - timedelta(days=ventana - 1)
    ini_b = ini_v - timedelta(days=ventana * periodos_base)
    p: dict = {"umbral": UMBRAL, "ini_v": ini_v, "hasta": hasta, "ini_b": ini_b}
    c = _orig(origen, p)
    if causa:
        c += " AND causa = :causa"
        p["causa"] = causa.upper()
    if departamento:
        c += " AND lower(departamento) = lower(:dep)"
        p["dep"] = departamento
    base = f"""SELECT causa, departamento, municipio,
                      count(*) FILTER (WHERE fecha BETWEEN :ini_v AND :hasta) AS actual,
                      count(*) FILTER (WHERE fecha >= :ini_b AND fecha < :ini_v) AS previo
               FROM v_epi_evento WHERE tipo = 'DIAGNOSTICO' AND fecha >= :ini_b AND fecha <= :hasta{c} GROUP BY causa, departamento, municipio"""
    filas = db.execute(text(f"SELECT causa, departamento, municipio, actual, previo FROM ({base}) g WHERE actual >= :umbral ORDER BY actual DESC, causa, municipio"), p).all()
    sup = db.execute(text(f"SELECT count(*) FROM ({base}) g WHERE actual > 0 AND actual < :umbral"), p).scalar_one()
    out = []
    for causa_, dep, mun, actual, previo in filas:
        suficiente = previo >= UMBRAL
        prom = round(previo / periodos_base, 2) if suficiente else None
        # sin base suficiente (< 5 casos previos) el promedio real es < 0.63: se compara con 1
        ref = max(previo / periodos_base, 1.0)
        out.append(CeldaBrote(causa=causa_, departamento=dep, municipio=mun, casos_ventana=actual, promedio_base=prom, razon=round(actual / prom, 2) if prom else None,
                              base_insuficiente=not suficiente, alerta=actual >= factor * ref))
    out.sort(key=lambda b: (not b.alerta, -(b.razon or 1e9), -b.casos_ventana))
    return out, sup


def medicamentos(db: Session, consulta: str, origen: str, desde: date, hasta: date, periodo: str, departamento: str | None, limite: int) -> tuple[list[CeldaMedicamento], int]:
    col = "mes" if periodo == "mes" else "anio::text"
    p: dict = {"umbral": UMBRAL, "desde": desde, "hasta": hasta, "lim": limite}
    c = _orig(origen, p)
    if departamento:
        c += " AND lower(departamento) = lower(:dep)"
        p["dep"] = departamento
    donde = f"fecha BETWEEN :desde AND :hasta{c}"
    if consulta == "mas_prescritos":
        base = f"SELECT {col} AS periodo, departamento, medicamento, count(*) AS n, sum(cantidad)::bigint AS u FROM v_epi_receta WHERE {donde} GROUP BY 1, 2, 3"
        filas = db.execute(text(f"SELECT periodo, departamento, medicamento, n, u, NULL::bigint, NULL::bigint FROM ({base}) g WHERE n >= :umbral ORDER BY n DESC, periodo, departamento, medicamento LIMIT :lim"), p).all()
        sup = db.execute(text(f"SELECT count(*) FROM ({base}) g WHERE n < :umbral"), p).scalar_one()
    else:
        base = (f"SELECT {col} AS periodo, departamento, count(*) FILTER (WHERE es_antibiotico) AS n, coalesce(sum(cantidad) FILTER (WHERE es_antibiotico), 0)::bigint AS u, count(*) AS total "
                f"FROM v_epi_receta WHERE {donde} GROUP BY 1, 2")
        filas = db.execute(text(f"SELECT periodo, departamento, NULL::text, n, u, total, n FROM ({base}) g WHERE n >= :umbral ORDER BY periodo, n DESC, departamento LIMIT :lim"), p).all()
        sup = db.execute(text(f"SELECT count(*) FROM ({base}) g WHERE n > 0 AND n < :umbral"), p).scalar_one()
    out = [CeldaMedicamento(periodo=f[0], departamento=f[1], medicamento=f[2], prescripciones=f[3], unidades=f[4], prescripciones_totales=f[5],
                            proporcion_antibioticos=round(f[3] / f[5], 4) if f[5] else None) for f in filas]
    return out, sup
