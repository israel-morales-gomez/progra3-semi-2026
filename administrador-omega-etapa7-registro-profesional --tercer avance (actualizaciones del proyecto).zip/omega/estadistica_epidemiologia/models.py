from datetime import date

from sqlalchemy import CheckConstraint, Date, Integer, PrimaryKeyConstraint, SmallInteger, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from omega_core.models.base import Base


class MunicipioCatalogo(Base):
    """Catálogo de municipios con su zona (RURAL | URBANA). Con él se agrupan los casos por zona."""

    __tablename__ = "municipio_catalogo"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    departamento: Mapped[str] = mapped_column(String(60))
    nombre: Mapped[str] = mapped_column(String(80))
    zona: Mapped[str] = mapped_column(String(7))
    __table_args__ = (UniqueConstraint("departamento", "nombre", name="uq_municipio_departamento_nombre"), CheckConstraint("zona IN ('RURAL', 'URBANA')", name="zona_valida"))


class Cie10Grave(Base):
    """Prefijos CIE-10 que se consideran enfermedad grave para las estadísticas (ampliable)."""

    __tablename__ = "cie10_grave"
    prefijo: Mapped[str] = mapped_column(String(8), primary_key=True)
    descripcion: Mapped[str] = mapped_column(String(120))


class EpiEjemplo(Base):
    """Casos FICTICIOS para pruebas. Sin ningún identificador (ni DUI, ni nombre, ni id de persona). Se borran sin tocar los datos reales."""

    __tablename__ = "epi_ejemplo"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tipo: Mapped[str] = mapped_column(String(12))
    fecha: Mapped[date] = mapped_column(Date)
    edad: Mapped[int] = mapped_column(SmallInteger)
    sexo: Mapped[str] = mapped_column(String(1))
    departamento: Mapped[str] = mapped_column(String(60))
    municipio: Mapped[str] = mapped_column(String(80))
    codigo_cie10: Mapped[str] = mapped_column(String(8))
    estatus: Mapped[str] = mapped_column(String(12), default="ACTIVA", server_default="ACTIVA")
    __table_args__ = (CheckConstraint("estatus IN ('ACTIVA', 'EN_REMISION', 'CURADA')", name="estatus_valido"), CheckConstraint("tipo IN ('FALLECIDO', 'DIAGNOSTICO')", name="tipo_valido"), CheckConstraint("sexo IN ('F', 'M')", name="sexo_valido"),
                      CheckConstraint("edad BETWEEN 0 AND 120", name="edad_valida"))


class PoblacionRegion(Base):
    """Población por departamento y año: denominador de las tasas. La mantiene Omega (no se inventan cifras)."""

    __tablename__ = "poblacion_region"
    departamento: Mapped[str] = mapped_column(String(60))
    anio: Mapped[int] = mapped_column(SmallInteger)
    poblacion: Mapped[int] = mapped_column(Integer)
    __table_args__ = (PrimaryKeyConstraint("departamento", "anio", name="pk_poblacion_region"), CheckConstraint("poblacion > 0", name="poblacion_positiva"))


class AntibioticoCatalogo(Base):
    """Principios activos considerados antibióticos (nombre normalizado: minúsculas, sin tildes). Un medicamento cuyo nombre empieza así cuenta como antibiótico."""

    __tablename__ = "antibiotico_catalogo"
    nombre: Mapped[str] = mapped_column(String(60), primary_key=True)


class EpiEjemploReceta(Base):
    """Prescripciones FICTICIAS para pruebas (sin paciente ni médico). Se borran sin tocar las recetas reales."""

    __tablename__ = "epi_ejemplo_receta"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    fecha: Mapped[date] = mapped_column(Date)
    departamento: Mapped[str] = mapped_column(String(60))
    municipio: Mapped[str] = mapped_column(String(80))
    medicamento: Mapped[str] = mapped_column(String(120))
    cantidad: Mapped[int] = mapped_column(Integer)


class PoblacionObjetivo(Base):
    """Población objetivo de cada vacuna por departamento, año y rango de edad: denominador de la cobertura. La carga Omega con cifras oficiales."""

    __tablename__ = "poblacion_objetivo"
    departamento: Mapped[str] = mapped_column(String(60))
    anio: Mapped[int] = mapped_column(SmallInteger)
    vacuna: Mapped[str] = mapped_column(String(120))  # normalizada: minúsculas, sin tildes
    rango_edad: Mapped[str] = mapped_column(String(8))
    poblacion: Mapped[int] = mapped_column(Integer)
    __table_args__ = (PrimaryKeyConstraint("departamento", "anio", "vacuna", "rango_edad", name="pk_poblacion_objetivo"), CheckConstraint("poblacion > 0", name="poblacion_positiva"),
                      CheckConstraint("rango_edad IN ('0-4', '5-14', '15-29', '30-44', '45-59', '60-74', '75+')", name="rango_valido"))


class EpiEjemploVacuna(Base):
    """Vacunados FICTICIOS (una fila = una persona y una vacuna), sin identificadores. Se borran sin tocar los registros reales."""

    __tablename__ = "epi_ejemplo_vacuna"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    fecha: Mapped[date] = mapped_column(Date)  # primera dosis
    edad: Mapped[int] = mapped_column(SmallInteger)  # al aplicar la primera dosis
    sexo: Mapped[str] = mapped_column(String(1))
    departamento: Mapped[str] = mapped_column(String(60))
    municipio: Mapped[str] = mapped_column(String(80))
    vacuna: Mapped[str] = mapped_column(String(120))
    dosis_total: Mapped[int] = mapped_column(SmallInteger, default=1)
