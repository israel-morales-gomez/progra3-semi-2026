import uuid
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, Field

Sector = Literal["PUBLICO", "PRIVADO"]
RedSeguros = Literal["PUBLICA", "POLIZA_PRIVADA"]  # filtro: «AMBAS» en el centro cuenta para las dos redes
Disponibilidad = Literal["BAJA", "MEDIA", "ALTA"]

AVISO_FARMACIAS = ("Disponibilidad aproximada según el inventario que declara cada farmacia: confirme por teléfono antes de ir. "
                   "No es una indicación médica y no sustituye a su médico o farmacéutico.")


class CentroDirectorioOut(BaseModel):
    institucion_id: uuid.UUID
    nombre: str
    tipo: Literal["HOSPITAL", "CLINICA"]
    sector: Sector | None = Field(None, description="`null` = Omega aún no lo clasificó.")
    red_seguros: Literal["PUBLICA", "POLIZA_PRIVADA", "AMBAS"] | None = None
    departamento: str | None
    municipio: str | None
    direccion: str
    telefono: str
    horario: str | None
    especialidades: list
    atiende_domicilio: bool
    tiene_laboratorio: bool
    latitud: float | None = None
    longitud: float | None = None


class DirectorioOut(BaseModel):
    devueltos: int
    items: list[CentroDirectorioOut]


class FarmaciaDisponibleOut(BaseModel):
    farmacia_id: uuid.UUID
    farmacia: str
    departamento: str | None
    municipio: str | None
    direccion: str
    telefono: str
    horario: str | None
    atiende_domicilio: bool
    medicamento: str
    disponibilidad: Disponibilidad = Field(description="Aproximada (nunca la cantidad exacta): BAJA, MEDIA o ALTA.")
    precio_unitario: Decimal | None = Field(None, description="USD por unidad; `null` si la farmacia no publica precio.")


class ComparacionPreciosOut(BaseModel):
    medicamento: str
    farmacias_con_precio: int
    mas_barata_id: uuid.UUID
    mas_barata: str
    precio_minimo: Decimal
    precio_maximo: Decimal


class BusquedaMedicamentoOut(BaseModel):
    medicamento_buscado: str
    total: int
    aviso: str = AVISO_FARMACIAS
    resultados: list[FarmaciaDisponibleOut]
    comparacion_precios: list[ComparacionPreciosOut] = Field(default_factory=list, description="Vacía salvo que haya al menos dos farmacias con precio para el mismo medicamento.")
