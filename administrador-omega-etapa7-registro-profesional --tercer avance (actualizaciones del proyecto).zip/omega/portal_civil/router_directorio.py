from typing import Literal

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from omega_core.database import get_db
from omega_core.deps import persona_actual
from omega_core.models import Persona

from . import service_directorio as servicio
from .schemas_directorio import BusquedaMedicamentoOut, DirectorioOut, RedSeguros, Sector

router = APIRouter(tags=["directorio y farmacias · ciudadano"])
ERR = {401: {"description": "No autenticado"}}


@router.get("/directorio/instituciones", response_model=DirectorioOut, responses=ERR, summary="Directorio de clínicas y hospitales",
            description="Solo centros **activos**. Filtros: `sector` (público o privado), `red_seguros` (pública o póliza privada; un centro de red `AMBAS` aparece en los dos filtros), "
                        "`tipo`, `departamento`, `municipio` y `q` (parte del nombre). El mismo `sector` y `red_seguros` filtran la selección en cascada de `/citas/...`. "
                        "No expone datos del responsable ni de acceso.")
def listar(tipo: Literal["HOSPITAL", "CLINICA"] | None = None, sector: Sector | None = None, red_seguros: RedSeguros | None = None,
           departamento: str | None = Query(None, max_length=80), municipio: str | None = Query(None, max_length=80), q: str | None = Query(None, min_length=2, max_length=80),
           limite: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0), persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    items = servicio.directorio(db, tipo=tipo, sector=sector, red_seguros=red_seguros, departamento=departamento, municipio=municipio, q=q, limite=limite, offset=offset)
    return DirectorioOut(devueltos=len(items), items=items)


@router.get("/farmacias/buscar", response_model=BusquedaMedicamentoOut, responses=ERR, summary="¿Dónde hay este medicamento?",
            description="Busca el medicamento en el inventario vigente de las farmacias activas, filtrando por `departamento` y `municipio`. Muestra la farmacia y una **disponibilidad aproximada** "
                        "(BAJA, MEDIA o ALTA, nunca la cantidad exacta). El precio es opcional: `comparacion_precios` solo se llena cuando al menos dos farmacias lo publican. "
                        "Nunca incluye datos de pacientes ni de recetas.")
def buscar(medicamento: str = Query(..., min_length=3, max_length=60), departamento: str | None = Query(None, max_length=80), municipio: str | None = Query(None, max_length=80),
           orden: Literal["disponibilidad", "precio"] = "disponibilidad", limite: int = Query(50, ge=1, le=100),
           persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    return servicio.buscar_medicamento(db, medicamento, departamento, municipio, orden, limite)
