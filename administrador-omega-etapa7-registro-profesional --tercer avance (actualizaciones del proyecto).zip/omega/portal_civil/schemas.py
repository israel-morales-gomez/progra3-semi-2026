import uuid
from datetime import date, datetime
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field, model_validator

from core_expediente.schemas import Versionado
from omega_core.constantes import TipoSangre
from omega_core.schemas import DUI, Telefono


class In(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")


# ------------------------------------------------------------------ Perfil
class PerfilSecundarioOut(BaseModel):
    registrado: bool
    activo: bool = False
    verificado: bool = False
    detalle: str | None = Field(None, description="Estudiante: carrera · universidad. Profesional: tipo · junta.")


class PerfilCiudadanoOut(BaseModel):
    dui: str
    nombres: str
    apellidos: str
    fecha_nacimiento: date | None
    correo: str
    telefono: str
    departamento: str | None
    municipio: str | None
    direccion: str | None
    tipo_sangre: str | None
    contacto_emergencia_nombre: str | None
    contacto_emergencia_telefono: str | None
    estudiante: PerfilSecundarioOut
    profesional: PerfilSecundarioOut


class PerfilCiudadanoIn(In):
    """Solo datos de contacto, dirección y datos civiles. DUI, nombres y fecha de nacimiento NO son editables aquí (vienen del padrón)."""

    correo: EmailStr | None = None
    telefono: Telefono | None = None
    departamento: Annotated[str, Field(min_length=2, max_length=60)] | None = None
    municipio: Annotated[str, Field(min_length=2, max_length=80)] | None = None
    direccion: Annotated[str, Field(min_length=3, max_length=500)] | None = None
    tipo_sangre: TipoSangre | None = None
    contacto_emergencia_nombre: Annotated[str, Field(min_length=2, max_length=150)] | None = None
    contacto_emergencia_telefono: Telefono | None = None

    @model_validator(mode="after")
    def _algo(self):
        if not self.model_fields_set:
            raise ValueError("Indique al menos un campo a actualizar")
        return self


class EstadoPerfilIn(In):
    activo: bool
    motivo: Annotated[str, Field(max_length=300)] | None = None


# ------------------------------------------------------------------ Lectura de mi expediente
class RecetaMedicamentoOut(BaseModel):
    medicamento: str
    presentacion: str | None
    dosis: str
    via: str | None
    frecuencia: str
    duracion_dias: int
    cantidad: int
    indicaciones: str | None


class RecetaPacienteOut(BaseModel):
    """Lo que el ciudadano ve de su receta: nunca el token de canje, la firma ni el payload."""

    folio: str
    emitida_en: datetime
    vigente_hasta: datetime
    estado: str
    vigente: bool
    medico: str
    establecimiento_emisor: str
    despachada_en: datetime | None
    farmacia: str | None
    medicamentos: list[RecetaMedicamentoOut]


class RecetasOut(BaseModel):
    devueltos: int
    items: list[RecetaPacienteOut]


# ------------------------------------------------------------------ Nivel 4 con 2FA
class DesafioOut(BaseModel):
    desafio_id: uuid.UUID
    expira_en_minutos: int
    mensaje: str = "Se envió un código de verificación a su teléfono registrado."


class DesbloquearIn(In):
    desafio_id: uuid.UUID
    codigo: Annotated[str, Field(min_length=6, max_length=6, pattern=r"^\d{6}$")]


class DesbloqueoOut(BaseModel):
    token_desbloqueo: str = Field(description="Envíelo en la cabecera `X-Desbloqueo-N4` de las lecturas del portal. Se muestra una sola vez.")
    expira_en: datetime


# ------------------------------------------------------------------ Vacunas
class VacunaIn(Versionado):
    dui: DUI = Field(description="DUI del paciente. El profesional necesita atención activa en su institución o consentimiento del paciente.")
    vacuna: Annotated[str, Field(min_length=2, max_length=120, description="Ej. 'Influenza', 'SR (sarampión-rubéola)', 'COVID-19'.")]
    codigo: Annotated[str, Field(max_length=20)] | None = None
    dosis_numero: Annotated[int, Field(ge=1, le=10)] = 1
    lote: Annotated[str, Field(max_length=40)] | None = None
    fabricante: Annotated[str, Field(max_length=80)] | None = None
    fecha_aplicacion: date
    via_aplicacion: Annotated[str, Field(max_length=40)] | None = Field(None, description="Ej. 'intramuscular deltoides'.")
    proxima_dosis: date | None = None
    observaciones: Annotated[str, Field(max_length=500)] | None = None

    @model_validator(mode="after")
    def _fechas(self):
        if self.proxima_dosis is not None and self.proxima_dosis <= self.fecha_aplicacion:
            raise ValueError("proxima_dosis debe ser posterior a fecha_aplicacion")
        return self


class VacunaCreadaOut(BaseModel):
    id: uuid.UUID
    vacuna: str
    dosis_numero: int
    fecha_aplicacion: date
    reemplaza_id: uuid.UUID | None
    hash_contenido: str
    creado_en: datetime


# ------------------------------------------------------------------ Quién consultó mi expediente
class AccesoExpedienteOut(BaseModel):
    """Solo lo necesario: cuándo, quién, por qué vía y qué sección. Sin IP, sin justificaciones clínicas, sin hashes ni detalle interno de la bitácora."""

    fecha: datetime
    accedio: str = Field(description="Nombre del profesional o de la institución.")
    tipo: Literal["PROFESIONAL", "FARMACIA", "LABORATORIO", "OTRO"]
    rol: str | None = Field(None, description="Profesional: tipo y especialidad.")
    establecimiento: str | None = None
    via: str | None = Field(None, description="ATENCION_ACTIVA o CONSENTIMIENTO (profesionales).")
    que_consulto: str = Field(description="Sección del expediente, receta o pendientes de laboratorio.")
    abrio_nivel4: bool = False


class AccesosOut(BaseModel):
    devueltos: int
    items: list[AccesoExpedienteOut]
