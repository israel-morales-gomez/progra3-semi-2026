"""Directorio de clínicas y hospitales y búsqueda de medicamentos en farmacias. Solo lee instituciones y lotes: no toca datos de pacientes."""
from collections import defaultdict
from urllib.parse import urlencode

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from core_expediente.deps import TIPOS_CLINICOS
from farmacia import inventario as inv
from farmacia.models import Lote
from omega_core.models import Institucion, Persona

from . import chatbot
from .schemas_directorio import AVISO_FARMACIAS, BusquedaMedicamentoOut, CentroDirectorioOut, ComparacionPreciosOut, FarmaciaDisponibleOut

UMBRAL_MEDIA, UMBRAL_ALTA = 10, 50  # unidades vigentes en la farmacia: ≤10 BAJA, ≤50 MEDIA, más ALTA
_RANGO = {"BAJA": 0, "MEDIA": 1, "ALTA": 2}


def sin_tildes(col):
    return func.lower(func.translate(col, "áéíóúÁÉÍÓÚñÑ", "aeiouaeiounn"))


def condicion_red(red_seguros: str):
    """Un centro con red AMBAS atiende tanto a la red pública como a pólizas privadas."""
    return Institucion.red_seguros.in_((red_seguros, "AMBAS"))


def disponibilidad(stock: int) -> str:
    return "BAJA" if stock <= UMBRAL_MEDIA else "MEDIA" if stock <= UMBRAL_ALTA else "ALTA"


# ------------------------------------------------------------------ directorio
def directorio(db: Session, *, tipo=None, sector=None, red_seguros=None, departamento=None, municipio=None, q=None, limite=50, offset=0) -> list[CentroDirectorioOut]:
    st = select(Institucion).where(Institucion.estado == "ACTIVA", Institucion.tipo.in_(TIPOS_CLINICOS))
    if tipo:
        st = st.where(Institucion.tipo == tipo)
    if sector:
        st = st.where(Institucion.sector == sector)
    if red_seguros:
        st = st.where(condicion_red(red_seguros))
    if departamento:
        st = st.where(sin_tildes(Institucion.departamento) == inv.norm(departamento))
    if municipio:
        st = st.where(sin_tildes(Institucion.municipio) == inv.norm(municipio))
    if q:
        st = st.where(sin_tildes(Institucion.nombre_legal).contains(inv.norm(q), autoescape=True))
    st = st.order_by(Institucion.nombre_legal, Institucion.id).limit(limite).offset(offset)
    return [CentroDirectorioOut(institucion_id=i.id, nombre=i.nombre_legal, tipo=i.tipo, sector=i.sector, red_seguros=i.red_seguros, departamento=i.departamento,
                                municipio=i.municipio, direccion=i.direccion, telefono=i.telefono, horario=i.horario, especialidades=i.especialidades or [],
                                atiende_domicilio=bool(i.atiende_domicilio), tiene_laboratorio=bool(i.tiene_laboratorio), latitud=i.latitud, longitud=i.longitud)
            for i in db.scalars(st)]


# ------------------------------------------------------------------ farmacias
def buscar_medicamento(db: Session, medicamento: str, departamento: str | None = None, municipio: str | None = None, orden: str = "disponibilidad",
                       limite: int = 50) -> BusquedaMedicamentoOut:
    med = inv.norm(medicamento)
    if len(med) < 3:  # tras normalizar puede quedar vacío (p. ej. solo símbolos): sin esto el LIKE devolvería todo el inventario
        raise HTTPException(422, "Indique el nombre del medicamento (mínimo 3 letras)")
    stock = func.sum(Lote.cantidad_actual)
    st = (select(Institucion.id, Institucion.nombre_legal, Institucion.departamento, Institucion.municipio, Institucion.direccion, Institucion.telefono,
                 Institucion.horario, Institucion.atiende_domicilio, Lote.medicamento, stock.label("stock"), func.min(Lote.precio_unitario).label("precio"))
          .join(Institucion, Institucion.id == Lote.farmacia_id)
          .where(Institucion.tipo == "FARMACIA", Institucion.estado == "ACTIVA", Lote.cantidad_actual > 0, Lote.fecha_vencimiento >= inv.hoy(),
                 Lote.medicamento.contains(med, autoescape=True))
          .group_by(Institucion.id, Institucion.nombre_legal, Institucion.departamento, Institucion.municipio, Institucion.direccion, Institucion.telefono,
                    Institucion.horario, Institucion.atiende_domicilio, Lote.medicamento))
    if departamento:
        st = st.where(sin_tildes(Institucion.departamento) == inv.norm(departamento))
    if municipio:
        st = st.where(sin_tildes(Institucion.municipio) == inv.norm(municipio))
    filas = [FarmaciaDisponibleOut(farmacia_id=r.id, farmacia=r.nombre_legal, departamento=r.departamento, municipio=r.municipio, direccion=r.direccion,
                                   telefono=r.telefono, horario=r.horario, atiende_domicilio=bool(r.atiende_domicilio), medicamento=r.medicamento,
                                   disponibilidad=disponibilidad(int(r.stock)), precio_unitario=r.precio) for r in db.execute(st.limit(500))]
    if orden == "precio":  # las que no publican precio van al final
        filas.sort(key=lambda f: (f.precio_unitario is None, f.precio_unitario or 0, f.farmacia))
    else:
        filas.sort(key=lambda f: (-_RANGO[f.disponibilidad], f.farmacia))
    return BusquedaMedicamentoOut(medicamento_buscado=med, total=len(filas), resultados=filas[:limite], comparacion_precios=_comparar(filas))


def _comparar(filas: list[FarmaciaDisponibleOut]) -> list[ComparacionPreciosOut]:
    """Solo compara cuando hay al menos dos farmacias con precio para el mismo medicamento."""
    por_med = defaultdict(list)
    for f in filas:
        if f.precio_unitario is not None:
            por_med[f.medicamento].append(f)
    out = []
    for med, lista in sorted(por_med.items()):
        if len(lista) >= 2:
            barata = min(lista, key=lambda f: (f.precio_unitario, f.farmacia))
            out.append(ComparacionPreciosOut(medicamento=med, farmacias_con_precio=len(lista), mas_barata_id=barata.farmacia_id, mas_barata=barata.farmacia,
                                             precio_minimo=barata.precio_unitario, precio_maximo=max(f.precio_unitario for f in lista)))
    return out


# ------------------------------------------------------------------ chatbot
def respuesta_chatbot(db: Session, persona: Persona, medicamento: str) -> tuple[str, list[dict], int]:
    """«¿Dónde hay X?»: usa la misma búsqueda, primero en el municipio de la persona, luego su departamento y por último todo el país."""
    alcances = [("en su municipio", persona.departamento, persona.municipio), ("en su departamento", persona.departamento, None), ("en el país", None, None)]
    vistos, res, donde = set(), None, "en el país"
    for etiqueta, dep, mun in alcances:
        if (dep, mun) in vistos or (etiqueta != "en el país" and not dep):
            continue
        vistos.add((dep, mun))
        res = buscar_medicamento(db, medicamento, dep, mun, limite=5)
        if res.total:
            donde = etiqueta
            break
    consulta = {"medicamento": medicamento, **({"departamento": dep} if dep else {}), **({"municipio": mun} if mun else {})}
    ruta = {"etiqueta": "Ver todas las farmacias", "metodo": "GET", "ruta": "/farmacias/buscar?" + urlencode(consulta)}
    if res is None or not res.total:
        return (f"No encontré farmacias con «{medicamento}» disponible por ahora. Pruebe con el nombre del principio activo o consulte directamente a las farmacias. "
                f"{AVISO_FARMACIAS}", [ruta, chatbot.CITAS], 0)
    lineas = [f"- {f.farmacia}" + (f" ({f.municipio})" if f.municipio else "") + f": disponibilidad {f.disponibilidad.lower()}"
              + (f", desde ${f.precio_unitario}" if f.precio_unitario is not None else "") for f in res.resultados]
    extra = ""
    if res.comparacion_precios:
        c = res.comparacion_precios[0]
        extra = f"\nEntre las que publican precio, la más económica es {c.mas_barata} (${c.precio_minimo}; la más cara, ${c.precio_maximo})."
    texto = (f"Encontré {res.total} farmacia(s) con «{medicamento}» {donde}:\n" + "\n".join(lineas) + extra + f"\n{AVISO_FARMACIAS} "
             "Yo no agendo citas: si necesita una consulta o una receta, reserve su cita con un profesional en el módulo de citas.")
    return texto, [ruta, chatbot.CITAS], res.total
