import uuid
from datetime import date, datetime

from pydantic import BaseModel, Field, field_validator

from .schemas import In



class AutocompraIn(In):
    medicamento: str = Field(min_length=2, max_length=200, description="Nombre del medicamento tal como figura en el empaque.")
    dosis: str = Field(min_length=1, max_length=120, description="Dosis o presentación, p. ej. «500 mg» o «1 tableta cada 8 h».")
    fecha_compra: date = Field(description="Fecha de la compra (no puede ser futura).")
    farmacia: str | None = Field(None, max_length=200, description="Farmacia donde la compró (opcional).")

    @field_validator("farmacia")
    @classmethod
    def _vacia_es_nula(cls, v: str | None) -> str | None:
        return v or None


class AutocompraOut(BaseModel):
    id: uuid.UUID
    medicamento: str
    dosis: str
    fecha_compra: date
    farmacia: str | None
    origen: str = Field(description="Siempre `DECLARADA_POR_PACIENTE`: no es una receta ni un dato verificado por un profesional.")
    etiqueta: str = "Declarada por el paciente"
    oficial: bool = Field(False, description="Siempre false: nunca se presenta como receta oficial.")
    creado_en: datetime


class AutocomprasOut(BaseModel):
    devueltos: int
    items: list[AutocompraOut]
