from .router_autocompras import router as autocompras_router
from .router_chatbot import router as chatbot_router
from .router_citas import router_agenda, router_ciudadano
from .router_directorio import router as directorio_router
from .router_expediente import router as expediente_router
from .router_perfil import router as perfil_router
from .router_vacunas import router as vacunas_router

routers = [perfil_router, expediente_router, vacunas_router, autocompras_router, directorio_router, router_ciudadano, router_agenda, chatbot_router]
