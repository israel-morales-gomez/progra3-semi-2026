from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from omega_core.database import get_db
from omega_core.deps import persona_actual
from omega_core.models import Persona
from omega_core.security.ratelimit import ip_cliente

from . import service_autocompras as servicio
from .schemas_autocompras import AutocompraIn, AutocompraOut, AutocomprasOut

router = APIRouter(prefix="/portal/autocompras", tags=["portal civil · mis autocompras (declaradas por el paciente)"])
ERR = {401: {"description": "No autenticado"}, 423: {"description": "Expediente congelado"}}


@router.post("", response_model=AutocompraOut, status_code=201, responses=ERR, summary="Declarar un medicamento que compré por mi cuenta",
             description="Registra una **autocompra**: medicamento, dosis, fecha y farmacia (opcional). Se marca siempre como **declarada por el paciente**, "
                         "no es una receta ni un dato verificado, y nunca se mezcla con las recetas oficiales. No se puede editar. Queda en la bitácora.")
def declarar(datos: AutocompraIn, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    return servicio.a_salida(servicio.registrar(db, persona, datos, ip_cliente(request)))


@router.get("", response_model=AutocomprasOut, responses=ERR, summary="Mis autocompras declaradas",
            description="Solo las **propias**, de la más reciente a la más antigua. Cada una lleva la etiqueta «Declarada por el paciente».")
def mis_autocompras(limite: int = Query(100, ge=1, le=200), persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    items = [servicio.a_salida(a) for a in servicio.listar(db, persona, limite)]
    return AutocomprasOut(devueltos=len(items), items=items)
