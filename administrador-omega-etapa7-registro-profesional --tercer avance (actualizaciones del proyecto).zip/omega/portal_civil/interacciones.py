"""Interacciones entre medicamentos prescritos y autocomprados. Catálogo editable (ampliable) al estilo de `farmacia/alergias.py`:
grupos terapéuticos + reglas entre dos grupos. Texto normalizado sin tildes. Es una ayuda informativa: nunca indica suspender un tratamiento,
siempre remite al médico o al farmacéutico. Para ampliarlo basta añadir un grupo a GRUPOS o una regla a REGLAS."""
import re
from dataclasses import dataclass

from core_expediente.constantes import normalizar_texto

GRUPOS: dict[str, set[str]] = {
    "anticoagulantes": {"warfarina", "acenocumarol", "rivaroxaban", "apixaban", "dabigatran", "heparina", "enoxaparina"},
    "aines": {"ibuprofeno", "naproxeno", "diclofenaco", "ketorolaco", "aspirina", "acido acetilsalicilico", "indometacina", "meloxicam",
              "piroxicam", "ketoprofeno", "celecoxib", "etoricoxib", "nimesulida"},
    "antihipertensivos_sra": {"enalapril", "captopril", "lisinopril", "ramipril", "losartan", "valsartan", "irbesartan", "candesartan", "telmisartan"},
    "nitratos": {"nitroglicerina", "isosorbide", "dinitrato de isosorbide", "mononitrato de isosorbide"},
    "inhibidores_pde5": {"sildenafil", "tadalafil", "vardenafil"},
    "opioides": {"morfina", "codeina", "tramadol", "fentanilo", "oxicodona", "metadona", "meperidina"},
    "benzodiacepinas": {"diazepam", "alprazolam", "clonazepam", "lorazepam", "midazolam", "bromazepam"},
    "isrs": {"fluoxetina", "sertralina", "paroxetina", "citalopram", "escitalopram", "fluvoxamina"},
    "quinolonas": {"ciprofloxacino", "levofloxacino", "norfloxacino", "moxifloxacino", "ofloxacino"},
    "antiacidos_minerales": {"hidroxido de aluminio", "hidroxido de magnesio", "carbonato de calcio", "sales de hierro", "sulfato ferroso", "sulfato de zinc"},
    "litio": {"litio", "carbonato de litio"},
    "metotrexato": {"metotrexato"},
}


@dataclass(frozen=True)
class Regla:
    a: str
    b: str
    severidad: str  # GRAVE | MODERADA
    titulo: str
    mensaje: str


REGLAS: tuple[Regla, ...] = (
    Regla("anticoagulantes", "aines", "GRAVE", "Riesgo de sangrado", "Combinar un anticoagulante con un antiinflamatorio o aspirina aumenta el riesgo de hemorragia."),
    Regla("nitratos", "inhibidores_pde5", "GRAVE", "Caída fuerte de la presión", "Un nitrato junto con sildenafil, tadalafil o similares puede bajar la presión arterial de forma peligrosa."),
    Regla("opioides", "benzodiacepinas", "GRAVE", "Depresión respiratoria y sedación", "Un opioide junto con un benzodiacepínico puede causar somnolencia extrema y dificultad para respirar."),
    Regla("opioides", "isrs", "GRAVE", "Síndrome serotoninérgico", "Algunos opioides, como el tramadol, junto con antidepresivos ISRS pueden provocar un cuadro serotoninérgico."),
    Regla("litio", "aines", "GRAVE", "Aumento del litio en sangre", "Los antiinflamatorios pueden subir los niveles de litio hasta un rango tóxico."),
    Regla("metotrexato", "aines", "GRAVE", "Toxicidad del metotrexato", "Los antiinflamatorios pueden aumentar la toxicidad del metotrexato."),
    Regla("aines", "antihipertensivos_sra", "MODERADA", "Menor efecto y riesgo renal", "Un antiinflamatorio puede reducir el efecto de su medicina para la presión y afectar el riñón."),
    Regla("isrs", "aines", "MODERADA", "Mayor riesgo de sangrado", "Un antidepresivo ISRS junto con un antiinflamatorio o aspirina aumenta el riesgo de sangrado digestivo."),
    Regla("quinolonas", "antiacidos_minerales", "MODERADA", "Menor absorción del antibiótico", "Los antiácidos, el calcio, el hierro y el zinc reducen la absorción de algunos antibióticos si se toman juntos."),
)

SEVERIDADES = {"GRAVE": "Grave", "MODERADA": "Moderada"}
ORDEN = {"GRAVE": 0, "MODERADA": 1}
CONSEJO = "Consulte a su médico o farmacéutico antes de tomarlos juntos. No suspenda ningún tratamiento por su cuenta."


@dataclass(frozen=True)
class Alerta:
    severidad: str
    titulo: str
    mensaje: str
    prescrito: str
    autocompra: str
    consejo: str = CONSEJO


def _contiene(texto: str, termino: str) -> bool:
    return re.search(rf"(?<![a-z0-9]){re.escape(termino)}(?![a-z0-9])", texto) is not None


def _grupos_de(medicamento: str) -> set[str]:
    med = normalizar_texto(medicamento)
    return {g for g, miembros in GRUPOS.items() if any(_contiene(med, m) for m in miembros)} if med else set()


def _misma_sustancia(a: str, b: str) -> bool:
    na, nb = normalizar_texto(a), normalizar_texto(b)
    return bool(na and nb and (_contiene(na, nb) or _contiene(nb, na)))


def detectar(prescritos: list[str], autocomprados: list[str]) -> list[Alerta]:
    """Cruza cada medicamento prescrito con cada autocomprado. Detecta (1) reglas entre grupos y (2) duplicidad: la misma sustancia en ambos canales.
    Sin repetidos; de la más grave a la menos grave."""
    vistos: set[tuple] = set()
    salida: list[Alerta] = []
    for p in dict.fromkeys(prescritos):
        gp = _grupos_de(p)
        for a in dict.fromkeys(autocomprados):
            if _misma_sustancia(p, a):
                clave = (p, a, "duplicidad")
                if clave not in vistos:
                    vistos.add(clave)
                    salida.append(Alerta("MODERADA", "Medicamento repetido", "Ya tiene este medicamento recetado y también lo declaró como autocompra: podría estar duplicando la dosis.", p, a))
                continue
            ga = _grupos_de(a)
            for r in REGLAS:
                if (r.a in gp and r.b in ga) or (r.b in gp and r.a in ga):
                    clave = (p, a, r.titulo)
                    if clave not in vistos:
                        vistos.add(clave)
                        salida.append(Alerta(r.severidad, r.titulo, r.mensaje, p, a))
    return sorted(salida, key=lambda x: (ORDEN[x.severidad], x.prescrito, x.autocompra))
