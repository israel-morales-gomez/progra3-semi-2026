"""Inyecta la sección `vacunas` en el expediente sin que core_expediente dependa de este módulo."""
from core_expediente import service as expediente

from .models import Vacuna

expediente.MODELOS["vacunas"] = Vacuna
expediente.PLANOS["vacunas"] = ("vacuna", "codigo", "dosis_numero", "lote", "fabricante", "fecha_aplicacion", "via_aplicacion", "proxima_dosis",
                                "observaciones", "establecimiento")
if "vacunas" not in expediente.SECCIONES_RESUMEN:
    expediente.SECCIONES_RESUMEN.append("vacunas")
