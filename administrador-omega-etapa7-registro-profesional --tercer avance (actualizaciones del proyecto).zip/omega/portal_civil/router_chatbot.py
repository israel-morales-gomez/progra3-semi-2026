from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.deps import persona_actual
from omega_core.models import Persona
from omega_core.security.ratelimit import ip_cliente

from . import chatbot, service_directorio
from .schemas_citas import MensajeIn, MensajeOut

router = APIRouter(tags=["chatbot consultivo"])


@router.post("/chatbot/mensaje", response_model=MensajeOut, responses={401: {"description": "No autenticado"}}, summary="Preguntar al asistente informativo",
             description="Chatbot **consultivo por reglas** (preguntas frecuentes, orientación general y cómo agendar). **No agenda citas, no da diagnósticos ni indica medicamentos**: "
                         "redirige al módulo manual de citas (`/citas/...`). Para «¿dónde hay X?» responde con farmacias y disponibilidad aproximada (misma búsqueda que `/farmacias/buscar`). Tiene una interfaz opcional (`ProveedorLLM`) para conectar un LLM en el futuro; hoy no está conectada. "
                         "En la bitácora se guarda la *intención* detectada y el largo del mensaje, **nunca su texto** (puede contener datos de salud).")
def mensaje(body: MensajeIn, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)) -> MensajeOut:
    r = chatbot.responder(body.mensaje)
    resultados = None
    if r.consulta:  # «¿dónde hay X?»: respuesta armada con la búsqueda real de farmacias; sigue sin agendar nada
        r.respuesta, r.acciones, resultados = service_directorio.respuesta_chatbot(db, persona, r.consulta)
    auditar("CHATBOT_CONSULTA", actor_tipo="persona", actor_id=persona.id, recurso="chatbot", ip=ip_cliente(request),
            detalle={"intencion": r.intencion, "largo": len(body.mensaje), "llm": chatbot.proveedor_llm is not None, **({"resultados": resultados} if resultados is not None else {})})
    return MensajeOut(intencion=r.intencion, respuesta=r.respuesta, acciones=r.acciones)
