import uuid
from datetime import date, datetime, time, timedelta, timezone

from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import exists, func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from core_expediente.deps import TIPOS_CLINICOS, Profesional, medico_activo
from core_expediente.service import asegurar_no_congelado
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.deps import persona_actual
from omega_core.models import Institucion, Persona, PerfilProfesional
from omega_core.security.ratelimit import ip_cliente

from .models import AgendaDisponibilidad, Cita
from .service_directorio import condicion_red
from .schemas_citas import (AgendaCitaOut, AgendaCitasOut, AgendaIn, AgendaOut, CancelarIn, CentroOut, CitaIn, CitaOut, CitasOut, DoctorOut, EspecialidadOut,
                            FechasOut, HorasOut, ReprogramarIn)

SV = timezone(timedelta(hours=-6))  # El Salvador no usa horario de verano
ANTICIPACION_MIN = 60  # no se reserva con menos de 1 h de anticipación
HORIZONTE_DIAS = 60
MAX_VIGENTES = 5  # citas PROGRAMADAS simultáneas por ciudadano

router_ciudadano = APIRouter(tags=["citas · ciudadano (selección en cascada)"])
router_agenda = APIRouter(tags=["citas · agenda del profesional"])
ERR = {401: {"description": "No autenticado"}, 404: {"description": "No existe o no es suyo"}, 409: {"description": "Horario ya reservado / estado no permite la operación"},
       422: {"description": "Horario inexistente, pasado o fuera de la agenda"}, 423: {"description": "DUI congelado por fallecimiento"}}


# ------------------------------------------------------------------ utilidades
def _medicos_q(especialidad: str | None = None, institucion_id: uuid.UUID | None = None, medico_id: uuid.UUID | None = None, sector: str | None = None,
               red_seguros: str | None = None):
    """Médicos reservables: DOCTOR verificado y activo, en un hospital/clínica ACTIVA, con al menos un bloque de agenda vigente en ese centro."""
    q = (select(PerfilProfesional.persona_id.label("medico_id"), PerfilProfesional.especialidad, PerfilProfesional.institucion_id, Institucion.nombre_legal.label("centro"),
                Institucion.departamento, Institucion.municipio, Institucion.sector, Institucion.red_seguros, Persona.nombres, Persona.apellidos)
         .join(Persona, Persona.id == PerfilProfesional.persona_id).join(Institucion, Institucion.id == PerfilProfesional.institucion_id)
         .where(PerfilProfesional.tipo == "DOCTOR", PerfilProfesional.verificado.is_(True), PerfilProfesional.activo.is_(True), PerfilProfesional.especialidad.is_not(None),
                Institucion.estado == "ACTIVA", Institucion.tipo.in_(TIPOS_CLINICOS),
                exists().where(AgendaDisponibilidad.medico_id == PerfilProfesional.persona_id, AgendaDisponibilidad.institucion_id == PerfilProfesional.institucion_id,
                               AgendaDisponibilidad.activo.is_(True), or_(AgendaDisponibilidad.vigente_hasta.is_(None), AgendaDisponibilidad.vigente_hasta >= datetime.now(SV).date()))))
    if especialidad:
        q = q.where(func.lower(PerfilProfesional.especialidad) == especialidad.strip().lower())
    if institucion_id:
        q = q.where(PerfilProfesional.institucion_id == institucion_id)
    if medico_id:
        q = q.where(PerfilProfesional.persona_id == medico_id)
    if sector:
        q = q.where(Institucion.sector == sector)
    if red_seguros:
        q = q.where(condicion_red(red_seguros))
    return q


def _medico_reservable(db: Session, medico_id: uuid.UUID):
    m = db.execute(_medicos_q(medico_id=medico_id)).first()
    if m is None:
        raise HTTPException(404, "Ese doctor no está disponible para citas")
    return m


def _slots(db: Session, medico_id: uuid.UUID, institucion_id: uuid.UUID, dia: date) -> tuple[list[tuple[datetime, datetime]], int | None]:
    """Todos los horarios que la agenda define para ese día (libres u ocupados), en UTC-6."""
    bloques = db.scalars(select(AgendaDisponibilidad).where(
        AgendaDisponibilidad.medico_id == medico_id, AgendaDisponibilidad.institucion_id == institucion_id, AgendaDisponibilidad.activo.is_(True),
        AgendaDisponibilidad.dia_semana == dia.weekday(), AgendaDisponibilidad.vigente_desde <= dia,
        or_(AgendaDisponibilidad.vigente_hasta.is_(None), AgendaDisponibilidad.vigente_hasta >= dia)).order_by(AgendaDisponibilidad.hora_inicio)).all()
    out, dur = [], None
    for b in bloques:
        dur = b.duracion_min
        t, fin = datetime.combine(dia, b.hora_inicio, SV), datetime.combine(dia, b.hora_fin, SV)
        while t + timedelta(minutes=b.duracion_min) <= fin:
            out.append((t, t + timedelta(minutes=b.duracion_min)))
            t += timedelta(minutes=b.duracion_min)
    return out, dur


def _ocupados(db: Session, medico_id: uuid.UUID, dia: date) -> set[datetime]:
    ini = datetime.combine(dia, time.min, SV)
    return set(db.scalars(select(Cita.inicio).where(Cita.medico_id == medico_id, Cita.estado == "PROGRAMADA", Cita.inicio >= ini, Cita.inicio < ini + timedelta(days=1))).all())


def _libres(db: Session, medico_id: uuid.UUID, institucion_id: uuid.UUID, dia: date) -> tuple[list[datetime], int | None]:
    slots, dur = _slots(db, medico_id, institucion_id, dia)
    ocup, minimo = _ocupados(db, medico_id, dia), datetime.now(SV) + timedelta(minutes=ANTICIPACION_MIN)
    return [i for i, _ in slots if i not in ocup and i >= minimo], dur


def _validar_horario(db: Session, m, dia: date, hora: time) -> tuple[datetime, datetime]:
    hoy = datetime.now(SV).date()
    if dia > hoy + timedelta(days=HORIZONTE_DIAS):
        raise HTTPException(422, f"Solo se agenda con hasta {HORIZONTE_DIAS} días de anticipación")
    slots, _ = _slots(db, m.medico_id, m.institucion_id, dia)
    par = next(((i, f) for i, f in slots if i.timetz().replace(tzinfo=None) == hora), None)
    if par is None:
        raise HTTPException(422, "Ese horario no existe en la agenda del doctor (consulte /citas/horas)")
    if par[0] < datetime.now(SV) + timedelta(minutes=ANTICIPACION_MIN):
        raise HTTPException(422, f"Ese horario ya pasó o requiere al menos {ANTICIPACION_MIN} minutos de anticipación")
    return par


def _out(c, medico: str, centro: str) -> CitaOut:
    i, f = c.inicio.astimezone(SV), c.fin.astimezone(SV)
    return CitaOut(id=c.id, estado=c.estado, fecha=i.date(), hora=i.time().replace(tzinfo=None), fin=f.time().replace(tzinfo=None), medico_id=c.medico_id, medico=medico,
                   especialidad=c.especialidad, institucion_id=c.institucion_id, centro=centro, motivo=c.motivo, reprogramada_de_id=c.reprogramada_de_id)


def _nombre_centro(db: Session, c: Cita) -> tuple[str, str]:
    n = db.execute(select(Persona.nombres, Persona.apellidos).where(Persona.id == c.medico_id)).first()
    return f"{n.nombres} {n.apellidos}", db.scalar(select(Institucion.nombre_legal).where(Institucion.id == c.institucion_id))


def _reservar(db: Session, paciente_id: uuid.UUID, m, inicio: datetime, fin: datetime, motivo: str | None, de: uuid.UUID | None = None) -> Cita:
    c = Cita(paciente_id=paciente_id, medico_id=m.medico_id, institucion_id=m.institucion_id, especialidad=m.especialidad, inicio=inicio, fin=fin, motivo=motivo, reprogramada_de_id=de)
    db.add(c)
    try:
        db.flush()
    except IntegrityError as e:
        db.rollback()
        # los índices únicos parciales de la BD son quienes deciden la carrera entre dos reservas simultáneas
        if "uq_cita_paciente_inicio" in str(e.orig):
            raise HTTPException(409, "Usted ya tiene otra cita a esa misma hora")
        raise HTTPException(409, "Ese horario acaba de ser reservado por otra persona")
    return c


# ------------------------------------------------------------------ Cascada
@router_ciudadano.get("/citas/especialidades", response_model=list[EspecialidadOut], responses=ERR, summary="Paso 1 · Especialidades con doctores disponibles",
                     description="Filtros opcionales `sector` (PUBLICO/PRIVADO) y `red_seguros` (PUBLICA/POLIZA_PRIVADA), los mismos del directorio.")
def especialidades(sector: Literal["PUBLICO", "PRIVADO"] | None = None, red_seguros: Literal["PUBLICA", "POLIZA_PRIVADA"] | None = None,
                   persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    sub = _medicos_q(sector=sector, red_seguros=red_seguros).subquery()
    return [EspecialidadOut(especialidad=e, medicos=n) for e, n in db.execute(select(sub.c.especialidad, func.count()).group_by(sub.c.especialidad).order_by(sub.c.especialidad))]


@router_ciudadano.get("/citas/centros", response_model=list[CentroOut], responses=ERR, summary="Paso 2 · Centros que atienden esa especialidad",
                     description="Filtros opcionales `sector` (PUBLICO/PRIVADO) y `red_seguros` (PUBLICA/POLIZA_PRIVADA), los mismos del directorio.")
def centros(especialidad: str = Query(..., min_length=2, max_length=120), sector: Literal["PUBLICO", "PRIVADO"] | None = None,
            red_seguros: Literal["PUBLICA", "POLIZA_PRIVADA"] | None = None, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    sub = _medicos_q(especialidad, sector=sector, red_seguros=red_seguros).subquery()
    f = db.execute(select(sub.c.institucion_id, sub.c.centro, sub.c.departamento, sub.c.municipio, sub.c.sector, sub.c.red_seguros, func.count().label("n"))
                   .group_by(sub.c.institucion_id, sub.c.centro, sub.c.departamento, sub.c.municipio, sub.c.sector, sub.c.red_seguros).order_by(sub.c.centro)).all()
    return [CentroOut(institucion_id=r.institucion_id, nombre=r.centro, departamento=r.departamento, municipio=r.municipio, sector=r.sector, red_seguros=r.red_seguros, medicos=r.n) for r in f]


@router_ciudadano.get("/citas/doctores", response_model=list[DoctorOut], responses=ERR, summary="Paso 3 · Doctores de esa especialidad en ese centro")
def doctores(especialidad: str = Query(..., min_length=2, max_length=120), institucion_id: uuid.UUID = Query(...), sector: Literal["PUBLICO", "PRIVADO"] | None = None,
             red_seguros: Literal["PUBLICA", "POLIZA_PRIVADA"] | None = None, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    return [DoctorOut(medico_id=r.medico_id, nombre=f"{r.nombres} {r.apellidos}", especialidad=r.especialidad, institucion_id=r.institucion_id, centro=r.centro)
            for r in db.execute(_medicos_q(especialidad, institucion_id, sector=sector, red_seguros=red_seguros).order_by(Persona.apellidos, Persona.nombres))]


@router_ciudadano.get("/citas/fechas", response_model=FechasOut, responses=ERR, summary="Paso 4 · Fechas con horarios libres",
                      description=f"Próximos {HORIZONTE_DIAS} días (hora de El Salvador) con al menos un horario libre.")
def fechas(medico_id: uuid.UUID = Query(...), persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    m = _medico_reservable(db, medico_id)
    hoy = datetime.now(SV).date()
    return FechasOut(medico_id=medico_id, fechas=[d for d in (hoy + timedelta(days=k) for k in range(HORIZONTE_DIAS + 1)) if _libres(db, medico_id, m.institucion_id, d)[0]])


@router_ciudadano.get("/citas/horas", response_model=HorasOut, responses=ERR, summary="Paso 5 · Horas libres de una fecha")
def horas(medico_id: uuid.UUID = Query(...), fecha: date = Query(...), persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    m = _medico_reservable(db, medico_id)
    libres, dur = _libres(db, medico_id, m.institucion_id, fecha)
    return HorasOut(medico_id=medico_id, fecha=fecha, horas=[i.time().replace(tzinfo=None) for i in libres], duracion_min=dur)


# ------------------------------------------------------------------ Reservar / ver / cancelar / reprogramar
@router_ciudadano.post("/citas", response_model=CitaOut, status_code=201, responses=ERR, summary="Reservar una cita (para uno mismo)",
                       description="Valida que el doctor esté verificado y activo, que el horario exista en su agenda, sea futuro y esté libre, y que el DUI **no esté congelado** (423). "
                                   "La doble reserva la impide la **base de datos** (índice único parcial por doctor+hora y por paciente+hora): si dos personas reservan a la vez, una recibe 409.")
def reservar(body: CitaIn, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    try:
        asegurar_no_congelado(db, persona.id)
    except HTTPException:
        auditar("CITA_DENEGADA", actor_tipo="persona", actor_id=persona.id, recurso="cita", resultado="FALLO", ip=ip, detalle={"motivo": "DUI_CONGELADO"})
        raise
    m = _medico_reservable(db, body.medico_id)
    if m.medico_id == persona.id:
        raise HTTPException(422, "No puede reservar una cita con usted mismo")
    if db.scalar(select(func.count()).select_from(Cita).where(Cita.paciente_id == persona.id, Cita.estado == "PROGRAMADA", Cita.inicio > datetime.now(SV))) >= MAX_VIGENTES:
        raise HTTPException(409, f"Ya tiene {MAX_VIGENTES} citas vigentes: cancele o asista a alguna antes de reservar otra")
    ini, fin = _validar_horario(db, m, body.fecha, body.hora)
    try:
        c = _reservar(db, persona.id, m, ini, fin, body.motivo)
    except HTTPException as e:
        auditar("CITA_DENEGADA", actor_tipo="persona", actor_id=persona.id, recurso="cita", resultado="FALLO", ip=ip, detalle={"motivo": "HORARIO_OCUPADO", "medico_id": m.medico_id, "inicio": ini})
        raise e
    db.commit()
    auditar("CITA_RESERVADA", actor_tipo="persona", actor_id=persona.id, recurso="cita", recurso_id=c.id, ip=ip,
            detalle={"medico_id": m.medico_id, "institucion_id": m.institucion_id, "especialidad": m.especialidad, "inicio": ini})
    return _out(c, f"{m.nombres} {m.apellidos}", m.centro)


@router_ciudadano.get("/citas", response_model=CitasOut, responses=ERR, summary="Mis citas",
                      description="Solo las del ciudadano autenticado. `estado` filtra (PROGRAMADA, CANCELADA, REPROGRAMADA).")
def mis_citas(estado: str | None = Query(None, pattern="^(PROGRAMADA|CANCELADA|REPROGRAMADA)$"), persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    q = select(Cita).where(Cita.paciente_id == persona.id)
    if estado:
        q = q.where(Cita.estado == estado)
    cs = db.scalars(q.order_by(Cita.inicio.desc()).limit(200)).all()
    return CitasOut(total=len(cs), items=[_out(c, *_nombre_centro(db, c)) for c in cs])


def _propia(db: Session, cita_id: uuid.UUID, persona: Persona) -> Cita:
    c = db.scalar(select(Cita).where(Cita.id == cita_id, Cita.paciente_id == persona.id).with_for_update())
    if c is None:
        raise HTTPException(404, "Cita no encontrada")  # igual respuesta para citas ajenas: no se revela su existencia
    if c.estado != "PROGRAMADA":
        raise HTTPException(409, f"La cita ya está {c.estado.lower()}")
    if c.inicio <= datetime.now(SV):
        raise HTTPException(409, "La cita ya pasó")
    return c


@router_ciudadano.post("/citas/{cita_id}/cancelar", response_model=CitaOut, responses=ERR, summary="Cancelar mi cita", description="Libera el horario de inmediato. No se borra: queda CANCELADA y auditada.")
def cancelar(cita_id: uuid.UUID, request: Request, body: CancelarIn | None = None, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    c = _propia(db, cita_id, persona)
    c.estado, c.cerrada_en, c.motivo_cierre = "CANCELADA", datetime.now(timezone.utc), body.motivo if body else None
    db.commit()
    auditar("CITA_CANCELADA", actor_tipo="persona", actor_id=persona.id, recurso="cita", recurso_id=c.id, ip=ip_cliente(request), detalle={"medico_id": c.medico_id, "inicio": c.inicio})
    return _out(c, *_nombre_centro(db, c))


@router_ciudadano.post("/citas/{cita_id}/reprogramar", response_model=CitaOut, responses=ERR, summary="Reprogramar mi cita con el mismo doctor",
                       description="Crea la cita nueva y marca la anterior como REPROGRAMADA en **una sola transacción**: si el nuevo horario está ocupado, la cita original se conserva intacta. "
                                   "Devuelve la cita nueva (`reprogramada_de_id` apunta a la anterior). Para cambiar de doctor, cancele y reserve de nuevo.")
def reprogramar(cita_id: uuid.UUID, body: ReprogramarIn, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    asegurar_no_congelado(db, persona.id)
    ant = _propia(db, cita_id, persona)
    m = _medico_reservable(db, ant.medico_id)
    ini, fin = _validar_horario(db, m, body.fecha, body.hora)
    if ini == ant.inicio:
        raise HTTPException(422, "Elija un horario distinto al actual")
    ant.estado, ant.cerrada_en, ant.motivo_cierre = "REPROGRAMADA", datetime.now(timezone.utc), body.motivo
    db.flush()  # libera el horario viejo dentro de la transacción
    nueva = _reservar(db, persona.id, m, ini, fin, ant.motivo, de=ant.id)  # si falla, hace rollback y la original sigue PROGRAMADA
    db.commit()
    auditar("CITA_REPROGRAMADA", actor_tipo="persona", actor_id=persona.id, recurso="cita", recurso_id=nueva.id, ip=ip_cliente(request),
            detalle={"anterior_id": ant.id, "inicio_anterior": ant.inicio, "inicio_nuevo": ini, "medico_id": m.medico_id})
    return _out(nueva, f"{m.nombres} {m.apellidos}", m.centro)


# ------------------------------------------------------------------ Agenda del profesional
@router_agenda.post("/agenda", response_model=AgendaOut, status_code=201, responses={**ERR, 403: {"description": "No es médico verificado y activo"}}, summary="Definir un bloque de disponibilidad",
                    description="El médico publica bloques semanales (día, rango horario, duración de cada cita) en **su** centro. No se permiten bloques traslapados. Las citas se generan solas a partir de los bloques.")
def crear_bloque(body: AgendaIn, request: Request, prof: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    pf = prof.persona.profesional
    if not pf.especialidad:
        raise HTTPException(422, "Su perfil no tiene especialidad: pídale a Omega que la registre antes de publicar agenda")
    desde = body.vigente_desde or datetime.now(SV).date()
    choque = db.scalar(select(AgendaDisponibilidad.id).where(
        AgendaDisponibilidad.medico_id == prof.persona.id, AgendaDisponibilidad.activo.is_(True), AgendaDisponibilidad.dia_semana == body.dia_semana,
        AgendaDisponibilidad.hora_inicio < body.hora_fin, AgendaDisponibilidad.hora_fin > body.hora_inicio,
        or_(AgendaDisponibilidad.vigente_hasta.is_(None), AgendaDisponibilidad.vigente_hasta >= desde),
        or_(body.vigente_hasta is None, AgendaDisponibilidad.vigente_desde <= (body.vigente_hasta or date.max))).limit(1))
    if choque:
        raise HTTPException(409, "Ese bloque se traslapa con otro bloque activo de su agenda")
    b = AgendaDisponibilidad(medico_id=prof.persona.id, institucion_id=prof.institucion_id, dia_semana=body.dia_semana, hora_inicio=body.hora_inicio, hora_fin=body.hora_fin,
                             duracion_min=body.duracion_min, vigente_desde=desde, vigente_hasta=body.vigente_hasta)
    db.add(b)
    db.commit()
    auditar("AGENDA_BLOQUE_CREADO", actor_tipo="persona", actor_id=prof.persona.id, recurso="agenda", recurso_id=b.id, ip=ip_cliente(request),
            detalle={"dia_semana": b.dia_semana, "inicio": str(b.hora_inicio), "fin": str(b.hora_fin), "duracion_min": b.duracion_min, "desde": b.vigente_desde, "hasta": b.vigente_hasta})
    return b


@router_agenda.get("/agenda", response_model=list[AgendaOut], responses=ERR, summary="Mi agenda de disponibilidad", description="Bloques del médico autenticado (`solo_activos` por defecto).")
def mi_agenda(solo_activos: bool = True, prof: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    q = select(AgendaDisponibilidad).where(AgendaDisponibilidad.medico_id == prof.persona.id)
    if solo_activos:
        q = q.where(AgendaDisponibilidad.activo.is_(True))
    return db.scalars(q.order_by(AgendaDisponibilidad.dia_semana, AgendaDisponibilidad.hora_inicio)).all()


@router_agenda.delete("/agenda/{bloque_id}", response_model=AgendaOut, responses=ERR, summary="Retirar un bloque de disponibilidad",
                      description="Lo desactiva (no se borra): deja de ofrecer horarios nuevos. Las citas ya reservadas se conservan; el médico las ve en `/agenda/citas`.")
def retirar_bloque(bloque_id: uuid.UUID, request: Request, prof: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    b = db.scalar(select(AgendaDisponibilidad).where(AgendaDisponibilidad.id == bloque_id, AgendaDisponibilidad.medico_id == prof.persona.id))
    if b is None:
        raise HTTPException(404, "Bloque no encontrado")
    if b.activo:
        b.activo, b.desactivado_en = False, datetime.now(timezone.utc)
        db.commit()
        auditar("AGENDA_BLOQUE_RETIRADO", actor_tipo="persona", actor_id=prof.persona.id, recurso="agenda", recurso_id=b.id, ip=ip_cliente(request), detalle={"dia_semana": b.dia_semana})
    return b


@router_agenda.get("/agenda/citas", response_model=AgendaCitasOut, responses=ERR, summary="Citas reservadas conmigo",
                   description="Lista de citas del médico autenticado con el **nombre** del paciente (nada clínico ni de contacto). Filtros por fecha.")
def citas_del_medico(desde: date | None = None, hasta: date | None = None, prof: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    desde = desde or datetime.now(SV).date()
    q = select(Cita, Persona.nombres, Persona.apellidos).join(Persona, Persona.id == Cita.paciente_id).where(
        Cita.medico_id == prof.persona.id, Cita.estado == "PROGRAMADA", Cita.inicio >= datetime.combine(desde, time.min, SV))
    if hasta:
        q = q.where(Cita.inicio < datetime.combine(hasta + timedelta(days=1), time.min, SV))
    f = db.execute(q.order_by(Cita.inicio).limit(500)).all()
    return AgendaCitasOut(total=len(f), items=[AgendaCitaOut(id=c.id, fecha=c.inicio.astimezone(SV).date(), hora=c.inicio.astimezone(SV).time().replace(tzinfo=None), estado=c.estado,
                                                              paciente=f"{n} {a}", motivo=c.motivo) for c, n, a in f])
