import uuid
from datetime import date, datetime, time
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, model_validator


class _In(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class EspecialidadOut(BaseModel):
    especialidad: str
    medicos: int


class CentroOut(BaseModel):
    institucion_id: uuid.UUID
    nombre: str
    departamento: str | None = None
    municipio: str | None = None
    sector: str | None = None
    red_seguros: str | None = None
    medicos: int


class DoctorOut(BaseModel):
    medico_id: uuid.UUID
    nombre: str
    especialidad: str
    institucion_id: uuid.UUID
    centro: str


class FechasOut(BaseModel):
    medico_id: uuid.UUID
    fechas: list[date] = Field(description="Fechas con al menos un horario libre (hora de El Salvador).")


class HorasOut(BaseModel):
    medico_id: uuid.UUID
    fecha: date
    horas: list[time] = Field(description="Horas de inicio libres, hora de El Salvador (UTC-6).")
    duracion_min: int | None = None


class CitaIn(_In):
    medico_id: uuid.UUID
    fecha: date
    hora: time = Field(description="Hora de inicio exacta de un horario libre (devuelto por /citas/horas).")
    motivo: Annotated[str, Field(min_length=3, max_length=300)] | None = None

    @model_validator(mode="after")
    def _hora_limpia(self):
        if self.hora.second or self.hora.microsecond:
            raise ValueError("La hora debe venir como HH:MM")
        return self


class ReprogramarIn(_In):
    fecha: date
    hora: time
    motivo: Annotated[str, Field(min_length=3, max_length=300)] | None = None


class CancelarIn(_In):
    motivo: Annotated[str, Field(min_length=3, max_length=300)] | None = None


class CitaOut(BaseModel):
    id: uuid.UUID
    estado: str
    fecha: date
    hora: time
    fin: time
    medico_id: uuid.UUID
    medico: str
    especialidad: str
    institucion_id: uuid.UUID
    centro: str
    motivo: str | None = None
    reprogramada_de_id: uuid.UUID | None = None


class CitasOut(BaseModel):
    total: int
    items: list[CitaOut]


class AgendaIn(_In):
    dia_semana: int = Field(ge=0, le=6, description="0 = lunes … 6 = domingo")
    hora_inicio: time
    hora_fin: time
    duracion_min: int = Field(30, ge=10, le=120)
    vigente_desde: date | None = Field(None, description="Por defecto, hoy.")
    vigente_hasta: date | None = None

    @model_validator(mode="after")
    def _coherente(self):
        if self.hora_fin <= self.hora_inicio:
            raise ValueError("hora_fin debe ser posterior a hora_inicio")
        if (self.hora_fin.hour * 60 + self.hora_fin.minute) - (self.hora_inicio.hour * 60 + self.hora_inicio.minute) < self.duracion_min:
            raise ValueError("El bloque es más corto que una cita")
        if self.vigente_desde and self.vigente_hasta and self.vigente_hasta < self.vigente_desde:
            raise ValueError("vigente_hasta anterior a vigente_desde")
        return self


class AgendaOut(BaseModel):
    id: uuid.UUID
    dia_semana: int
    hora_inicio: time
    hora_fin: time
    duracion_min: int
    vigente_desde: date
    vigente_hasta: date | None
    activo: bool


class AgendaCitaOut(BaseModel):
    id: uuid.UUID
    fecha: date
    hora: time
    estado: str
    paciente: str = Field(description="Solo nombre: sin datos clínicos ni de contacto.")
    motivo: str | None = None


class AgendaCitasOut(BaseModel):
    total: int
    items: list[AgendaCitaOut]


class MensajeIn(_In):
    mensaje: Annotated[str, Field(min_length=1, max_length=500)]


class AccionOut(BaseModel):
    etiqueta: str
    metodo: str
    ruta: str


class MensajeOut(BaseModel):
    intencion: str
    respuesta: str
    acciones: list[AccionOut] = []
    aviso: str = "Soy un asistente informativo: no agendo citas, no doy diagnósticos ni indico medicamentos."
