from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.deps import persona_actual
from omega_core.models import Persona
from omega_core.security.ratelimit import ip_cliente
from omega_core.servicios.personas import upsert_civil
from omega_core.schemas import PerfilCivilIn

from .schemas import EstadoPerfilIn, PerfilCiudadanoIn, PerfilCiudadanoOut, PerfilSecundarioOut

router = APIRouter(prefix="/portal/perfil", tags=["portal civil · mi perfil"])
ERR = {401: {"description": "No autenticado"}, 404: {"description": "No tiene ese perfil registrado"}, 409: {"description": "Correo ya registrado por otra persona"}}
_CIVIL = ("tipo_sangre", "contacto_emergencia_nombre", "contacto_emergencia_telefono")
_PERSONA = ("correo", "telefono", "departamento", "municipio", "direccion")


def _out(p: Persona) -> PerfilCiudadanoOut:
    c, e, pr = p.civil, p.estudiante, p.profesional
    return PerfilCiudadanoOut(
        dui=p.dui, nombres=p.nombres, apellidos=p.apellidos, fecha_nacimiento=p.fecha_nacimiento, correo=p.correo, telefono=p.telefono,
        departamento=p.departamento, municipio=p.municipio, direccion=p.direccion,
        tipo_sangre=c.tipo_sangre if c else None, contacto_emergencia_nombre=c.contacto_emergencia_nombre if c else None,
        contacto_emergencia_telefono=c.contacto_emergencia_telefono if c else None,
        estudiante=PerfilSecundarioOut(registrado=e is not None, activo=bool(e and e.activo), verificado=bool(e and e.verificado),
                                       detalle=f"{e.carrera} · {e.universidad_nombre}" if e else None),
        profesional=PerfilSecundarioOut(registrado=pr is not None, activo=bool(pr and pr.activo), verificado=bool(pr and pr.verificado),
                                        detalle=f"{pr.junta} {pr.numero_junta} · {pr.tipo}" if pr else None))


@router.get("", response_model=PerfilCiudadanoOut, responses=ERR, summary="Mi perfil de ciudadano",
            description="Datos personales (del padrón, solo lectura), contacto, dirección, datos civiles y el estado de mis perfiles de estudiante y profesional.")
def ver(persona: Persona = Depends(persona_actual)):
    return _out(persona)


@router.patch("", response_model=PerfilCiudadanoOut, responses=ERR, summary="Actualizar mis datos de contacto, dirección y datos civiles",
              description="Edita solo lo enviado. **No** permite cambiar DUI, nombres ni fecha de nacimiento (padrón). Queda en la bitácora (se registran los campos modificados, no sus valores).")
def actualizar(datos: PerfilCiudadanoIn, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    cambios = datos.model_dump(exclude_unset=True)
    if any(v is None for k, v in cambios.items() if k in ("correo", "telefono")):
        raise HTTPException(422, "correo y telefono no pueden quedar vacíos")
    for k in _PERSONA:
        if k in cambios and cambios[k] is not None:
            setattr(persona, k, str(cambios[k]).lower() if k == "correo" else cambios[k])
    civil = {k: cambios[k] for k in _CIVIL if k in cambios}
    if civil:
        actual = persona.civil
        base = {k: getattr(actual, k, None) if actual else None for k in _CIVIL}
        upsert_civil(db, persona, PerfilCivilIn(**{**base, **civil}))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Ese correo ya está registrado por otra persona")
    auditar("PORTAL_PERFIL_ACTUALIZADO", actor_tipo="persona", actor_id=persona.id, recurso="persona", recurso_id=persona.id, ip=ip_cliente(request),
            detalle={"campos": sorted(cambios)})
    return _out(persona)


@router.put("/{perfil}/estado", response_model=PerfilCiudadanoOut, responses=ERR, summary="Activar o desactivar mi perfil de estudiante o de profesional",
            description="Un perfil **desactivado** deja de operar de inmediato (un profesional desactivado no puede leer ni escribir en expedientes, emitir recetas ni órdenes) "
                        "pero **conserva** sus datos y su verificación: al reactivarlo no hay que volver a verificarlo. Solo el titular puede hacerlo sobre su propia cuenta. Queda auditado.")
def cambiar_estado(perfil: Literal["estudiante", "profesional"], datos: EstadoPerfilIn, request: Request, persona: Persona = Depends(persona_actual),
                   db: Session = Depends(get_db)):
    p = getattr(persona, perfil)
    if p is None:
        raise HTTPException(404, f"No tiene perfil de {perfil} registrado")
    antes, p.activo = p.activo, datos.activo
    db.commit()
    auditar("PORTAL_PERFIL_ESTADO", actor_tipo="persona", actor_id=persona.id, recurso=f"perfil_{perfil}", recurso_id=persona.id, ip=ip_cliente(request),
            detalle={"antes": antes, "despues": datos.activo, "motivo": datos.motivo, "verificado": p.verificado})
    return _out(persona)
