import hashlib
import secrets
import uuid
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo
from typing import Literal

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from sqlalchemy import and_, exists, or_, select
from sqlalchemy.orm import Session, aliased

from core_expediente import service as expediente
from core_expediente.constantes import NIVEL_ULTRA
from core_expediente.models import Atencion, Defuncion, Diagnostico  # noqa: F401
from core_expediente.schemas import SeccionOut
from farmacia.models import Despacho, Receta, RecetaItem
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.deps import persona_actual
from omega_core.models import Auditoria, Institucion, Persona
from omega_core.models.base import ahora
from omega_core.security.campos import descifrar_json
from omega_core.security import twofa
from omega_core.config import settings
from omega_core.security.ratelimit import comprobar_bloqueo, ip_cliente, limitador
from omega_core.models import Desafio2FA

from . import registro  # noqa: F401  (inyecta `vacunas`)
from .models import DesbloqueoN4
from .router_citas import mis_citas
from .schemas import (
    AccesoExpedienteOut, AccesosOut, DesafioOut, DesbloquearIn, DesbloqueoOut, RecetaMedicamentoOut, RecetaPacienteOut, RecetasOut,
)

router = APIRouter(prefix="/portal", tags=["portal civil · mi expediente (solo lectura)"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Desbloqueo de nivel 4 inválido, vencido o ajeno"}, 429: {"description": "Demasiados intentos"}}
DESBLOQUEO_MIN = 10
SeccionPortal = Literal["diagnosticos", "resultados", "vacunas"]
_JUST = "DESBLOQUEO_2FA_PACIENTE"  # marca interna: el paciente abrió su propio nivel 4 con segundo factor


def _hash(t: str) -> str:
    return hashlib.sha256(t.encode()).hexdigest()


def _desbloqueo_valido(db: Session, persona: Persona, token: str | None) -> bool:
    """True si el token corresponde a un desbloqueo 2FA vigente DE ESTA persona. Un token inválido/ajeno/vencido responde 403 (no se degrada en silencio)."""
    if token is None:
        return False
    d = db.scalar(select(DesbloqueoN4).where(DesbloqueoN4.token_hash == _hash(token.strip())))
    if d is None or d.persona_id != persona.id or d.revocado_en is not None or d.expira_en <= ahora():
        raise HTTPException(403, "Desbloqueo de nivel 4 inválido o vencido: verifique de nuevo su código 2FA")
    return True


# ------------------------------------------------------------------ Nivel 4 con 2FA
@router.post("/nivel4/desafio", response_model=DesafioOut, responses=ERR, summary="Pedir código 2FA para ver mis datos de nivel 4",
             description="Envía un código de 6 dígitos al teléfono registrado (**simulado**: sale en el log del servidor). Máximo 5 solicitudes cada 10 minutos.")
def pedir_desafio(request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    espera = limitador.golpe(f"n4desafio:{persona.id}", 5, 600)
    if espera:
        raise HTTPException(429, "Demasiadas solicitudes de código. Intente más tarde.", headers={"Retry-After": str(espera)})
    did = twofa.crear_desafio(db, "persona_n4", persona.id, persona.telefono, f"portal-nivel4 {persona.dui}")
    db.commit()
    auditar("PORTAL_NIVEL4_DESAFIO", actor_tipo="persona", actor_id=persona.id, recurso="nivel4", ip=ip_cliente(request))
    return DesafioOut(desafio_id=did, expira_en_minutos=settings.twofa_minutos)


@router.post("/nivel4/desbloquear", response_model=DesbloqueoOut, responses=ERR, summary="Desbloquear mis datos de nivel 4 con el código 2FA",
             description=f"Verifica el código y devuelve un `token_desbloqueo` válido **{DESBLOQUEO_MIN} minutos** para la cabecera `X-Desbloqueo-N4`. Solo desbloquea **mis** datos. "
                         "Sin este paso, los registros de nivel 4 (VIH, salud mental, genética) salen como `restringido`. 5 intentos fallidos bloquean el código.")
def desbloquear(datos: DesbloquearIn, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    token, d = abrir_desbloqueo(datos, request, persona, db)
    return DesbloqueoOut(token_desbloqueo=token, expira_en=d.expira_en)


def abrir_desbloqueo(datos: DesbloquearIn, request: Request, persona: Persona, db: Session) -> tuple[str, DesbloqueoN4]:
    """Verifica el código 2FA (desafío, 5 intentos, bloqueo por cuenta y bitácora) y crea el desbloqueo. Lo usan la API y el portal web."""
    ip, clave = ip_cliente(request), f"n4:{persona.id}"
    comprobar_bloqueo(clave)
    d0 = db.get(Desafio2FA, datos.desafio_id)
    desafio = twofa.validar_desafio(db, datos.desafio_id, datos.codigo) if d0 is not None and d0.sujeto_tipo == "persona_n4" and d0.sujeto_id == persona.id else None
    if desafio is None:
        limitador.fallo(clave)
        auditar("PORTAL_NIVEL4_DESBLOQUEO", actor_tipo="persona", actor_id=persona.id, recurso="nivel4", resultado="FALLO", ip=ip)
        raise HTTPException(401, "Código inválido o vencido")
    limitador.exito(clave)
    token = secrets.token_urlsafe(32)
    d = DesbloqueoN4(persona_id=persona.id, token_hash=_hash(token), expira_en=ahora() + timedelta(minutes=DESBLOQUEO_MIN))
    db.add(d)
    db.commit()
    auditar("PORTAL_NIVEL4_DESBLOQUEO", actor_tipo="persona", actor_id=persona.id, recurso="nivel4", recurso_id=d.id, ip=ip, detalle={"expira_en": d.expira_en})
    return token, d


def desbloqueo_vigente(db: Session, persona: Persona, desbloqueo_id: uuid.UUID | None) -> DesbloqueoN4 | None:
    """El desbloqueo con ese id si es de ESTA persona, no está revocado y no venció; None en cualquier otro caso (sin error: lo usa la sesión web)."""
    d = db.get(DesbloqueoN4, desbloqueo_id) if desbloqueo_id else None
    return d if d is not None and d.persona_id == persona.id and d.revocado_en is None and d.expira_en > ahora() else None


def revocar_desbloqueo(db: Session, desbloqueo_id: uuid.UUID | None) -> None:
    """Revoca un desbloqueo concreto (cierre de sesión web). El caller hace commit."""
    d = db.get(DesbloqueoN4, desbloqueo_id) if desbloqueo_id else None
    if d is not None and d.revocado_en is None:
        d.revocado_en = ahora()


@router.post("/nivel4/bloquear", status_code=204, responses=ERR, summary="Volver a bloquear mis datos de nivel 4 (revoca mis desbloqueos)")
def bloquear(request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    ahora_ = ahora()
    n = 0
    for d in db.scalars(select(DesbloqueoN4).where(DesbloqueoN4.persona_id == persona.id, DesbloqueoN4.revocado_en.is_(None), DesbloqueoN4.expira_en > ahora_)):
        d.revocado_en, n = ahora_, n + 1
    db.commit()
    auditar("PORTAL_NIVEL4_BLOQUEO", actor_tipo="persona", actor_id=persona.id, recurso="nivel4", ip=ip_cliente(request), detalle={"revocados": n})


# ------------------------------------------------------------------ Lectura de mi expediente (solo lectura)
def _acceso_propio(abre4: bool) -> expediente.Acceso:
    return expediente.Acceso(via="PROPIO", puede_nivel4=abre4)


@router.get("/mi-expediente/recetas", response_model=RecetasOut, responses=ERR, summary="Mis recetas",
            description="Mis recetas (vigentes, despachadas, vencidas), con medicamentos, médico y farmacia que despachó. Nunca incluye el token de canje ni la firma. Solo mis recetas.")
def mis_recetas(request: Request, limite: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0), persona: Persona = Depends(persona_actual),
                db: Session = Depends(get_db)):
    recetas = list(db.scalars(select(Receta).where(Receta.paciente_id == persona.id).order_by(Receta.emitida_en.desc()).limit(limite).offset(offset)))
    ids = [r.id for r in recetas]
    items: dict = {}
    if ids:
        for it in db.scalars(select(RecetaItem).where(RecetaItem.receta_id.in_(ids)).order_by(RecetaItem.receta_id, RecetaItem.orden)):
            items.setdefault(it.receta_id, []).append(RecetaMedicamentoOut(medicamento=it.medicamento, presentacion=it.presentacion, dosis=it.dosis, via=it.via,
                                                                          frecuencia=it.frecuencia, duracion_dias=it.duracion_dias, cantidad=it.cantidad, indicaciones=it.indicaciones))
    medicos = {m.id: f"{m.nombres} {m.apellidos}" for m in db.execute(select(Persona.id, Persona.nombres, Persona.apellidos).where(Persona.id.in_({r.medico_id for r in recetas})))} if recetas else {}
    desp = {d.receta_id: d for d in db.scalars(select(Despacho).where(Despacho.receta_id.in_(ids)))} if ids else {}
    inst_ids = {r.institucion_id for r in recetas} | {d.farmacia_id for d in desp.values()}
    insts = {i.id: i.nombre_legal for i in db.execute(select(Institucion.id, Institucion.nombre_legal).where(Institucion.id.in_(inst_ids)))} if inst_ids else {}
    h = ahora()
    out = [RecetaPacienteOut(folio=r.folio, emitida_en=r.emitida_en, vigente_hasta=r.vigente_hasta, estado=r.estado, vigente=r.estado == "EMITIDA" and r.vigente_hasta > h,
                             medico=medicos.get(r.medico_id, ""), establecimiento_emisor=insts.get(r.institucion_id, ""),
                             despachada_en=desp[r.id].despachado_en if r.id in desp else None, farmacia=insts.get(desp[r.id].farmacia_id) if r.id in desp else None,
                             medicamentos=items.get(r.id, [])) for r in recetas]
    auditar("PORTAL_LECTURA_PROPIA", actor_tipo="persona", actor_id=persona.id, recurso="expediente", recurso_id=persona.id, ip=ip_cliente(request),
            detalle={"seccion": "recetas", "devueltos": len(out), "restringidos": 0, "nivel4_abierto": False})
    return RecetasOut(devueltos=len(out), items=out)


@router.get("/mi-expediente/{seccion}", response_model=SeccionOut, responses=ERR, summary="Leer una sección de MI expediente (solo lectura)",
            description="Secciones: `diagnosticos`, `resultados` (laboratorio e imagenología) y `vacunas`; las recetas están en `/portal/mi-expediente/recetas`. **Solo se lee el expediente del titular del token**: "
                        "no hay forma de indicar otro DUI. Los datos de **nivel 4** salen como `restringido` salvo que envíe la cabecera `X-Desbloqueo-N4` obtenida con su código 2FA "
                        "(`/portal/nivel4/desafio` → `/portal/nivel4/desbloquear`). `historial=true` incluye versiones corregidas. Cada lectura queda en la bitácora.")
def mi_seccion(seccion: SeccionPortal, request: Request, historial: bool = False, limite: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
               x_desbloqueo_n4: str | None = Header(None, description="Token de desbloqueo de nivel 4 (opcional)."),
               persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    return leer_propia(seccion, request, historial, limite, offset, _desbloqueo_valido(db, persona, x_desbloqueo_n4), persona, db)


def leer_propia(seccion: str, request: Request, historial: bool, limite: int, offset: int, abre4: bool, persona: Persona, db: Session) -> SeccionOut:
    """Lee una sección de MI expediente. `abre4` ya viene decidido por quien llama (cabecera con token en la API; desbloqueo ligado a la sesión en el portal web)."""
    out, abiertos = expediente.leer_seccion(db, seccion, persona.id, _acceso_propio(abre4), _JUST if abre4 else None, historial, limite, offset)
    auditar("PORTAL_LECTURA_PROPIA", actor_tipo="persona", actor_id=persona.id, recurso="expediente", recurso_id=persona.id, ip=ip_cliente(request),
            detalle={"seccion": seccion, "devueltos": out.devueltos, "restringidos": out.restringidos, "nivel4_abierto": abiertos > 0, "historial": historial})
    return out


# ------------------------------------------------------------------ Resumen de estado activo e historial de atenciones (solo lectura; los usa el portal web)
TIPOS_ATENCION = {"AMBULATORIA": "Ambulatoria", "URGENCIAS": "Urgencias", "HOSPITALIZACION": "Hospitalización", "TELEMEDICINA": "Telemedicina"}
CIERRES = {"ALTA_MEDICA": "Alta médica", "TRASLADO": "Traslado", "ALTA_VOLUNTARIA": "Alta voluntaria", "FALLECIMIENTO": "Fallecimiento"}


def _medicamentos_en_uso(db: Session, persona: Persona) -> list[dict]:
    """Ítems de MIS recetas EMITIDAS aún vigentes (`POR_SURTIR`) o DESPACHADAS con tratamiento sin terminar (`EN_TRATAMIENTO`: despacho + duración). Incluye institución emisora y área de la atención
    (None si la atención es de nivel 4). Sin bitácora propia: quien llama audita."""
    h = ahora()
    filas = db.execute(select(Receta, RecetaItem, Despacho.despachado_en, Institucion.nombre_legal, Atencion.area, Atencion.sensible_n4)
                       .join(RecetaItem, RecetaItem.receta_id == Receta.id).outerjoin(Despacho, Despacho.receta_id == Receta.id)
                       .join(Institucion, Institucion.id == Receta.institucion_id).join(Atencion, Atencion.id == Receta.atencion_id)
                       .where(Receta.paciente_id == persona.id, Receta.estado.in_(("EMITIDA", "DESPACHADA")), Receta.emitida_en > h - timedelta(days=400))
                       .order_by(Receta.emitida_en.desc(), RecetaItem.orden)).all()
    out = []
    for r, it, despachado, institucion, area, n4 in filas:
        if r.estado == "EMITIDA" and r.vigente_hasta > h:
            situacion, hasta = "POR_SURTIR", r.vigente_hasta
        elif r.estado == "DESPACHADA" and despachado is not None and despachado + timedelta(days=it.duracion_dias) > h:
            situacion, hasta = "EN_TRATAMIENTO", despachado + timedelta(days=it.duracion_dias)
        else:
            continue
        out.append({"medicamento": it.medicamento, "presentacion": it.presentacion, "dosis": it.dosis, "via": it.via, "frecuencia": it.frecuencia, "folio": r.folio,
                    "situacion": situacion, "hasta": hasta, "institucion": institucion, "area": None if n4 else area})
    return out


def mi_resumen(request: Request, abre4: bool, persona: Persona, db: Session) -> dict:
    """Estado activo de MI expediente: enfermedades activas, medicamentos en uso, alergias activas y antecedentes quirúrgicos / transfusionales. Reutiliza `leer_propia` (mismas reglas de nivel 4 y misma
    bitácora). `restringidos` cuenta los registros de nivel 4 que siguen ocultos. Medicamentos en uso = ítems de recetas EMITIDAS aún vigentes (por surtir) + ítems de recetas DESPACHADAS cuyo
    tratamiento (fecha de despacho + duración indicada) no ha terminado; no existe una tabla aparte de «medicamentos en uso»."""
    restringidos = 0

    def leer(seccion: str) -> list:
        nonlocal restringidos
        s = leer_propia(seccion, request, False, 200, 0, abre4, persona, db)
        restringidos += s.restringidos
        return [i for i in s.items if not i.restringido]

    enfermedades = [i for i in leer("diagnosticos") if i.datos.get("estatus") == "ACTIVA"]
    alergias = [i for i in leer("alergias") if i.datos.get("estado") == "ACTIVA"]
    antecedentes = leer("antecedentes")
    medicamentos = _medicamentos_en_uso(db, persona)
    auditar("PORTAL_LECTURA_PROPIA", actor_tipo="persona", actor_id=persona.id, recurso="expediente", recurso_id=persona.id, ip=ip_cliente(request),
            detalle={"seccion": "medicamentos_en_uso", "devueltos": len(medicamentos), "restringidos": 0, "nivel4_abierto": False})
    return {"enfermedades": enfermedades, "medicamentos": medicamentos, "alergias": alergias, "restringidos": restringidos,
            "cirugias": [i for i in antecedentes if i.datos.get("tipo") == "QUIRURGICO"], "transfusiones": [i for i in antecedentes if i.datos.get("tipo") == "TRANSFUSIONAL"]}


def mis_atenciones(request: Request, abre4: bool, limite: int, offset: int, persona: Persona, db: Session) -> list[dict]:
    """Historial de MIS atenciones, de la más reciente a la más antigua: institución, fecha, tipo, profesional responsable, diagnóstico principal vigente y estatus. No lee notas SOAP ni signos
    vitales ni el motivo de consulta. Una atención de nivel 4 (o un diagnóstico principal de nivel 4) sale `restringido` salvo que `abre4`. Las interconsultas no existen en el backend: no se devuelven."""
    filas = db.execute(select(Atencion, Institucion.nombre_legal).join(Institucion, Institucion.id == Atencion.institucion_id).where(Atencion.paciente_id == persona.id)
                       .order_by(Atencion.abierta_en.desc(), Atencion.id).limit(limite).offset(offset)).all()
    ids = [a.id for a, _ in filas]
    medico_ids = {a.medico_responsable_id for a, _ in filas if a.medico_responsable_id}
    medicos = {m.id: f"{m.nombres} {m.apellidos}" for m in db.execute(select(Persona.id, Persona.nombres, Persona.apellidos).where(Persona.id.in_(medico_ids)))} if medico_ids else {}
    hijo = aliased(Diagnostico)
    dxs = {d.atencion_id: d for d in db.scalars(select(Diagnostico).where(Diagnostico.atencion_id.in_(ids), Diagnostico.principal.is_(True), ~exists().where(hijo.reemplaza_id == Diagnostico.id)))} if ids else {}
    items, restringidos, abiertos4 = [], 0, 0
    for a, institucion in filas:
        if a.sensible_n4 and not abre4:
            restringidos += 1
            items.append({"restringido": True, "creado_en": a.abierta_en})
            continue
        d = dxs.get(a.id)
        dx = None
        if d is not None and d.nivel_sensibilidad >= NIVEL_ULTRA and not abre4:
            restringidos += 1
            dx = {"restringido": True}
        elif d is not None:
            sens = descifrar_json(d.contenido_cifrado) if d.nivel_sensibilidad >= NIVEL_ULTRA else {"codigo_cie10": d.codigo_cie10, "descripcion": d.descripcion}
            dx = {"restringido": False, "codigo_cie10": sens.get("codigo_cie10"), "descripcion": sens.get("descripcion"), "estatus": d.estatus}
        if a.sensible_n4 or (d is not None and d.nivel_sensibilidad >= NIVEL_ULTRA):
            abiertos4 += 1
        items.append({"restringido": False, "creado_en": a.abierta_en, "institucion": institucion, "tipo": TIPOS_ATENCION.get(a.tipo_atencion, a.tipo_atencion), "area": a.area,
                      "medico": medicos.get(a.medico_responsable_id), "diagnostico": dx, "abierta": a.estado == "ABIERTA", "cerrada_en": a.cerrada_en,
                      "cierre": CIERRES.get(a.cierre_tipo or "", a.cierre_tipo)})
    auditar("PORTAL_LECTURA_PROPIA", actor_tipo="persona", actor_id=persona.id, recurso="expediente", recurso_id=persona.id, ip=ip_cliente(request),
            detalle={"seccion": "atenciones", "devueltos": len(items), "restringidos": restringidos, "nivel4_abierto": abiertos4 > 0})
    return items


# ------------------------------------------------------------------ Laboratorio, imagen y seguimiento (solo lectura; los usa el portal web)
_GRAVEDAD = {"NORMAL": 0, "ANORMAL": 1, "CRITICO": 2, "BAJO": 1, "ALTO": 1, "CRITICO_BAJO": 2, "CRITICO_ALTO": 2}


def _resultados(request: Request, abre4: bool, persona: Persona, db: Session) -> tuple[list[dict], list[dict], int]:
    """Lee MIS resultados con `leer_propia` (nivel 4 oculto salvo desbloqueo; bitácora incluida) y los separa en laboratorio (agrupado por parámetro, serie histórica ascendente) e imagenología."""
    s = leer_propia("resultados", request, False, 200, 0, abre4, persona, db)
    series: dict[tuple, dict] = {}
    imagenes = []
    for it in sorted((i for i in s.items if not i.restringido), key=lambda i: i.creado_en):
        d = it.datos
        if d.get("tipo_estudio") == "IMAGENOLOGIA":
            vs = d.get("valores") or []
            peor = max((v.get("bandera") or "NORMAL" for v in vs), key=lambda b: _GRAVEDAD.get(b, 0), default="NORMAL")
            imagenes.append({"folio": d.get("orden_folio"), "fecha": it.creado_en, "responsable": d.get("responsable"), "bandera": peor, "observaciones": d.get("observaciones"),
                             "hallazgos": [{"parametro": v.get("parametro"), "texto": v.get("valor_texto") or v.get("valor_numerico")} for v in vs], "enlace": None})
            continue
        for v in d.get("valores") or []:
            clave = ((v.get("parametro") or "").strip().lower(), v.get("unidad") or "")
            serie = series.setdefault(clave, {"parametro": (v.get("parametro") or "").strip(), "unidad": v.get("unidad"), "puntos": []})
            serie["puntos"].append({"fecha": it.creado_en, "valor": v.get("valor_numerico"), "texto": v.get("valor_texto"), "ref_min": v.get("ref_min"), "ref_max": v.get("ref_max"),
                                   "critico": bool(v.get("critico")), "bandera": v.get("bandera") or "NORMAL", "folio": d.get("orden_folio")})
    labs = list(series.values())
    for p in labs:
        p["ultimo"] = p["puntos"][-1]
        p["hay_critico"] = any(x["critico"] for x in p["puntos"])
    labs.sort(key=lambda p: (not p["ultimo"]["critico"], p["ultimo"]["bandera"] == "NORMAL", p["parametro"].lower()))
    imagenes.reverse()  # la más reciente primero
    return labs, imagenes, s.restringidos


def mi_laboratorio(request: Request, abre4: bool, persona: Persona, db: Session) -> tuple[list[dict], int]:
    labs, _, restringidos = _resultados(request, abre4, persona, db)
    return labs, restringidos


def mis_imagenes(request: Request, abre4: bool, persona: Persona, db: Session) -> tuple[list[dict], int]:
    """Estudios de imagen: el backend guarda el informe como texto dentro del resultado. No existe un enlace o visor de la imagen: `enlace` va siempre None (la referencia es el folio de la orden)."""
    _, imagenes, restringidos = _resultados(request, abre4, persona, db)
    return imagenes, restringidos


SV = ZoneInfo("America/El_Salvador")


def mi_seguimiento(request: Request, abre4: bool, persona: Persona, db: Session) -> tuple[list[dict], int]:
    """Calendario de seguimiento, de lo más próximo a lo más lejano: citas programadas futuras (servicio `mis_citas`), controles (`proximo_control_en` del egreso), vacunas con próxima dosis aún sin
    aplicar y tratamientos en curso (despacho + duración). Cada fila: tipo, cuando (instante o fecha), `con_hora`, área, institución y detalle; lo que no existe queda en None. Devuelve (filas, restringidos)."""
    ahora_sv = ahora().astimezone(SV)
    filas, restringidos = [], 0
    for c in mis_citas(estado="PROGRAMADA", persona=persona, db=db).items:
        cuando = datetime.combine(c.fecha, c.hora, tzinfo=SV)
        if cuando >= ahora_sv:
            filas.append({"tipo": "CITA", "cuando": cuando, "con_hora": True, "area": c.especialidad, "institucion": c.centro, "detalle": f"Con {c.medico}" + (f" · {c.motivo}" if c.motivo else "")})
    egresos = leer_propia("egresos", request, False, 200, 0, abre4, persona, db)
    restringidos += egresos.restringidos
    previstos = [i for i in egresos.items if not i.restringido and i.datos.get("proximo_control_en") and i.datos["proximo_control_en"] >= ahora()]
    donde = {r.id: r for r in db.execute(select(Atencion.id, Atencion.area, Atencion.sensible_n4, Institucion.nombre_legal).join(Institucion, Institucion.id == Atencion.institucion_id)
                                          .where(Atencion.id.in_([i.atencion_id for i in previstos])))} if previstos else {}
    for i in previstos:
        a = donde.get(i.atencion_id)
        filas.append({"tipo": "CONTROL", "cuando": i.datos["proximo_control_en"].astimezone(SV), "con_hora": True, "area": None if a is None or a.sensible_n4 else a.area,
                      "institucion": a.nombre_legal if a else None, "detalle": None})
    vacunas = leer_propia("vacunas", request, False, 200, 0, abre4, persona, db)
    restringidos += vacunas.restringidos
    puestas = [i.datos for i in vacunas.items if not i.restringido]
    for d in puestas:
        if d.get("proxima_dosis") and not any((o["vacuna"] or "").strip().lower() == (d["vacuna"] or "").strip().lower() and o["dosis_numero"] > d["dosis_numero"] for o in puestas):
            filas.append({"tipo": "VACUNA", "cuando": datetime.combine(d["proxima_dosis"], time.min, tzinfo=SV), "con_hora": False, "area": None, "institucion": None,
                          "detalle": f"{d['vacuna']} · dosis {d['dosis_numero'] + 1}", "atrasada": d["proxima_dosis"] < ahora_sv.date()})
    for m in _medicamentos_en_uso(db, persona):
        if m["situacion"] == "EN_TRATAMIENTO":
            filas.append({"tipo": "TRATAMIENTO", "cuando": m["hasta"].astimezone(SV), "con_hora": True, "area": m["area"], "institucion": m["institucion"],
                          "detalle": f"{m['medicamento']} · {m['dosis']} · {m['frecuencia']} (fin del tratamiento)"})
    auditar("PORTAL_LECTURA_PROPIA", actor_tipo="persona", actor_id=persona.id, recurso="expediente", recurso_id=persona.id, ip=ip_cliente(request),
            detalle={"seccion": "seguimiento", "devueltos": len(filas), "restringidos": restringidos, "nivel4_abierto": False})
    filas.sort(key=lambda f: f["cuando"])
    return filas, restringidos


# ------------------------------------------------------------------ Quién consultó mi expediente
@router.get("/accesos", response_model=AccesosOut, responses=ERR, summary="Quién consultó mi expediente",
            description="Historial de consultas de **otras personas e instituciones** a mis datos, tomado de la bitácora de auditoría: profesionales que leyeron mi expediente (con su vía de acceso y la sección), "
                        "farmacias que consultaron o despacharon una receta mía y laboratorios que consultaron mis órdenes pendientes. **Solo lo necesario**: fecha, quién, qué consultó y si abrió nivel 4; "
                        "no incluye IP, justificaciones clínicas, hashes ni datos internos. Mis propias lecturas no aparecen aquí.")
def accesos(request: Request, limite: int = Query(50, ge=1, le=100), offset: int = Query(0, ge=0), persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    yo = str(persona.id)
    mis_recetas_ids = [str(i) for i in db.scalars(select(Receta.id).where(Receta.paciente_id == persona.id))]
    filtro = or_(
        and_(Auditoria.accion == "ACCESO_EXPEDIENTE", Auditoria.recurso_id == yo, Auditoria.resultado == "OK", Auditoria.actor_id != yo),
        and_(Auditoria.accion == "LAB_CONSULTA_PENDIENTES", Auditoria.recurso_id == yo),
        and_(Auditoria.accion.in_(("RECETA_CONSULTADA", "RECETA_DESPACHADA")), Auditoria.recurso_id.in_(mis_recetas_ids or ["-"])))
    filas = db.execute(select(Auditoria.ts, Auditoria.accion, Auditoria.actor_tipo, Auditoria.actor_id, Auditoria.detalle).where(filtro)
                       .order_by(Auditoria.id.desc()).limit(limite).offset(offset)).all()
    ids = {uuid.UUID(f.actor_id) for f in filas if f.actor_id}
    from omega_core.models import PerfilProfesional
    pers = {p.id: p for p in db.execute(select(Persona.id, Persona.nombres, Persona.apellidos, PerfilProfesional.tipo, PerfilProfesional.especialidad, PerfilProfesional.institucion_id)
                                         .outerjoin(PerfilProfesional, PerfilProfesional.persona_id == Persona.id).where(Persona.id.in_(ids)))} if ids else {}
    insts = {i.id: i for i in db.execute(select(Institucion.id, Institucion.nombre_legal, Institucion.tipo).where(
        Institucion.id.in_(ids | {p.institucion_id for p in pers.values() if p.institucion_id})))} if ids else {}
    out = []
    for f in filas:
        aid = uuid.UUID(f.actor_id) if f.actor_id else None
        if f.accion == "ACCESO_EXPEDIENTE":
            p = pers.get(aid)
            est = insts.get(p.institucion_id).nombre_legal if p and p.institucion_id in insts else None
            out.append(AccesoExpedienteOut(fecha=f.ts, accedio=f"{p.nombres} {p.apellidos}" if p else "Profesional", tipo="PROFESIONAL",
                                           rol=" · ".join(x for x in (p.tipo if p else None, p.especialidad if p else None) if x) or None, establecimiento=est,
                                           via=f.detalle.get("via"), que_consulto=str(f.detalle.get("seccion", "expediente")), abrio_nivel4=bool(f.detalle.get("nivel4_abierto"))))
        else:
            i = insts.get(aid)
            tipo = "LABORATORIO" if f.accion == "LAB_CONSULTA_PENDIENTES" else "FARMACIA"
            que = "órdenes pendientes de laboratorio" if tipo == "LABORATORIO" else ("despacho de una receta" if f.accion == "RECETA_DESPACHADA" else "consulta de una receta")
            out.append(AccesoExpedienteOut(fecha=f.ts, accedio=i.nombre_legal if i else "Institución", tipo=tipo, rol=None, establecimiento=i.nombre_legal if i else None,
                                           via=None, que_consulto=que, abrio_nivel4=False))
    auditar("PORTAL_ACCESOS_CONSULTADOS", actor_tipo="persona", actor_id=persona.id, recurso="auditoria", recurso_id=persona.id, ip=ip_cliente(request), detalle={"devueltos": len(out)})
    return AccesosOut(devueltos=len(out), items=out)

