import hashlib
import json
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import exists, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, aliased

from core_expediente.deps import Profesional, profesional_activo
from core_expediente.service import asegurar_no_congelado, dui_o_422, identidad_minima, resolver_acceso
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Institucion
from omega_core.security.ratelimit import ip_cliente

from . import registro  # noqa: F401  (inyecta la sección `vacunas` en el expediente)
from .models import Vacuna
from .schemas import VacunaCreadaOut, VacunaIn

router = APIRouter(tags=["portal civil · vacunas (carga por profesionales)"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "No es profesional verificado y activo, o sin relación con el paciente"},
       404: {"description": "Registro a corregir inexistente"}, 409: {"description": "Vacuna duplicada o registro ya corregido"}, 423: {"description": "DUI congelado"}}
_SV = timezone(timedelta(hours=-6))


@router.post("/vacunas", response_model=VacunaCreadaOut, status_code=201, responses=ERR, summary="Registrar una vacuna aplicada",
             description="Cualquier **profesional de la salud verificado y activo** (médico o enfermera) puede cargar una vacuna, siempre que el paciente tenga una **atención activa en su institución** "
                         "o le haya dado **consentimiento** (así nadie escribe en la cartilla de un desconocido). El registro es **inmutable**: para corregir, envíe uno nuevo con `reemplaza_id` + "
                         "`motivo_correccion` (solo el autor o un profesional de la misma institución). El ciudadano lo ve en `/portal/mi-expediente/vacunas`. 423 si el DUI está congelado. Queda auditado.")
def registrar(datos: VacunaIn, request: Request, prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    ip, yo = ip_cliente(request), prof.persona.id
    ident = identidad_minima(db, dui_o_422(datos.dui))
    acceso = resolver_acceso(db, yo, prof.institucion_id, ident.id) if ident else None
    if acceso is None:
        auditar("VACUNA_DENEGADA", actor_tipo="persona", actor_id=yo, recurso="vacuna", resultado="FALLO", ip=ip,
                detalle={"motivo": "SIN_RELACION_CON_PACIENTE", "paciente_id": ident.id if ident else None})
        raise HTTPException(403, "Sin acceso a este paciente: requiere atención activa en su institución o consentimiento del paciente")
    asegurar_no_congelado(db, ident.id)
    if datos.fecha_aplicacion > datetime.now(_SV).date():
        raise HTTPException(422, "fecha_aplicacion no puede ser futura")
    prev = None
    if datos.reemplaza_id is not None:
        prev = db.scalar(select(Vacuna).where(Vacuna.id == datos.reemplaza_id).with_for_update())
        if prev is None or prev.paciente_id != ident.id:
            raise HTTPException(404, "El registro a corregir no existe en este expediente")
        if db.scalar(select(Vacuna.id).where(Vacuna.reemplaza_id == prev.id)) is not None:
            raise HTTPException(409, "Ese registro ya fue corregido: corrija la versión vigente")
        if yo != prev.registrado_por and prof.institucion_id != prev.institucion_id:
            raise HTTPException(403, "Solo el autor o un profesional de la misma institución puede corregir este registro")
    else:  # evita duplicar la misma dosis (misma vacuna, dosis y fecha) en la cartilla vigente
        hijo = aliased(Vacuna)
        dup = db.scalar(select(Vacuna.id).where(
            Vacuna.paciente_id == ident.id, Vacuna.vacuna == datos.vacuna, Vacuna.dosis_numero == datos.dosis_numero,
            Vacuna.fecha_aplicacion == datos.fecha_aplicacion, ~exists().where(hijo.reemplaza_id == Vacuna.id)).limit(1))
        if dup is not None:
            raise HTTPException(409, "Esa dosis ya está registrada (corríjala con reemplaza_id si hay un error)")
    est = db.scalar(select(Institucion.nombre_legal).where(Institucion.id == prof.institucion_id))
    vid, creado = uuid.uuid4(), datetime.now(timezone.utc)
    campos = {"vacuna": datos.vacuna, "codigo": datos.codigo, "dosis_numero": datos.dosis_numero, "lote": datos.lote, "fabricante": datos.fabricante,
              "fecha_aplicacion": datos.fecha_aplicacion, "via_aplicacion": datos.via_aplicacion, "proxima_dosis": datos.proxima_dosis, "observaciones": datos.observaciones}
    h = hashlib.sha256(json.dumps({"id": str(vid), "paciente": str(ident.id), "creado_en": creado.isoformat(), "reemplaza": str(prev.id) if prev else None, **campos},
                                  sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode()).hexdigest()
    v = Vacuna(id=vid, paciente_id=ident.id, nivel_sensibilidad=2, establecimiento=est, institucion_id=prof.institucion_id, registrado_por=yo, atencion_id=acceso.atencion_id,
               hash_contenido=h, creado_en=creado, reemplaza_id=prev.id if prev else None, motivo_correccion=datos.motivo_correccion, **campos)
    db.add(v)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Conflicto de versionado: ese registro ya fue corregido")
    auditar("VACUNA_CORREGIDA" if prev else "VACUNA_REGISTRADA", actor_tipo="persona", actor_id=yo, recurso="vacuna", recurso_id=v.id, ip=ip,
            detalle={"paciente_id": ident.id, "vacuna": v.vacuna, "dosis": v.dosis_numero, "reemplaza_id": v.reemplaza_id, "motivo": v.motivo_correccion,
                     "hash": h, "via_acceso": acceso.via})
    return VacunaCreadaOut(id=v.id, vacuna=v.vacuna, dosis_numero=v.dosis_numero, fecha_aplicacion=v.fecha_aplicacion, reemplaza_id=v.reemplaza_id,
                           hash_contenido=h, creado_en=creado)
