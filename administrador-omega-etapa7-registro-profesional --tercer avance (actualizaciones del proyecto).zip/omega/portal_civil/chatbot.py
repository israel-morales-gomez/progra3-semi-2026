"""Chatbot consultivo por reglas. NO agenda, NO diagnostica, NO receta: siempre redirige al módulo manual de citas.
Única consulta a datos: «¿dónde hay X?» usa la misma búsqueda de farmacias del portal (solo farmacias y disponibilidad aproximada, nunca datos de pacientes).

`ProveedorLLM` es la interfaz opcional para conectar un modelo de lenguaje más adelante. Hoy NO está conectada: `proveedor_llm = None`.
Si se conectara, solo se usaría para redactar respuestas de las intenciones informativas (nunca para agendar ni orientar clínicamente)."""
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Protocol


class ProveedorLLM(Protocol):
    def redactar(self, intencion: str, respuesta_base: str, mensaje: str) -> str:  # pragma: no cover - interfaz
        """Devuelve una versión mejor redactada de `respuesta_base`. No debe añadir consejo clínico."""
        ...


proveedor_llm: ProveedorLLM | None = None  # sin conectar a propósito


@dataclass
class Respuesta:
    intencion: str
    respuesta: str
    acciones: list[dict] = field(default_factory=list)
    consulta: str | None = None  # medicamento a buscar en farmacias (solo intención `disponibilidad`); lo resuelve el router con la búsqueda real


_ART = r"(?:el |la |los |las |un |una |unos |unas |algun |alguna |algunos |algunas )?"
_BUSCA_MED = [
    rf"donde (?:hay|venden|vende|encuentro|consigo|tienen|puedo (?:comprar|conseguir|encontrar)|se (?:vende|consigue|encuentra))\s+{_ART}(?P<m>.+)",
    rf"(?:hay|tienen|tiene|venden|vende) {_ART}(?P<m>.+?) en (?:alguna |algunas |las |la |una )?farmacias?",
    rf"farmacias? (?:que (?:tenga|tengan|venda|vendan)|con|donde (?:hay|tengan|venden)) {_ART}(?P<m>.+)",
]
_COLA = re.compile(r"\b(?:en|cerca|por|para|de mi|hoy|ahora|disponibles?|aqui|ahorita)\b.*$")
_FORMA = re.compile(r"^(?:pastillas?|tabletas?|capsulas?|jarabe|gotas|crema|pomada|medicina|medicamento)s? (?:de |para )?")
_NO_ES_MED = re.compile(r"clinica|hospital|doctor|medic[oa]\b|farmacia|laboratorio|cita|especialista|centro|consulta|emergencia|vacuna|recet|^que |^medicamentos?$|^medicinas?$|^pastillas?$")
SENAL_CLINICA = re.compile(r"dosis|cuanto (debo )?tomar|puedo tomar|sintoma|\btengo\b|diagnostic|que enfermedad|es grave|receta me|que medicamento")


def medicamento_buscado(n: str) -> str | None:
    """Extrae el medicamento de preguntas tipo «¿dónde hay X?» (texto ya normalizado). None si no es esa pregunta o si X no parece un medicamento."""
    for patron in _BUSCA_MED:
        m = re.search(patron, n)
        if not m:
            continue
        x = _COLA.sub("", re.sub(r"[?!.,;:¿¡]", " ", m.group("m")))
        x = _FORMA.sub("", re.sub(r"\s+", " ", x).strip()).strip()
        if 3 <= len(x) <= 60 and len(x.split()) <= 5 and re.search(r"[a-z]{3}", x) and not _NO_ES_MED.search(x):
            return x
    return None


CITAS = {"etiqueta": "Ir al módulo de citas (paso a paso)", "metodo": "GET", "ruta": "/citas/especialidades"}
MIS_CITAS = {"etiqueta": "Ver mis citas", "metodo": "GET", "ruta": "/citas"}

# (intención, patrón sobre texto sin tildes y en minúsculas, respuesta, acciones) — el orden es la prioridad.
REGLAS: list[tuple[str, str, str, list[dict]]] = [
    ("emergencia", r"emergencia|urgente|urgencia|no puedo respirar|dolor (fuerte )?(de|en) (el )?pecho|sangrado|desmay|convuls|infarto|sobredosis|suicid|quitarme la vida",
     "Si usted o alguien cerca está en peligro, NO espere una cita: llame al 911 o acuda de inmediato a la emergencia del hospital más cercano. "
     "Las citas no son para urgencias. Si se siente en crisis emocional, busque ayuda de una persona cercana o de un servicio de emergencia ahora mismo.", []),
    # `disponibilidad` no usa patrón: la decide `medicamento_buscado` (y solo si el mensaje no tiene señales clínicas, que siguen yendo a «diagnostico»).
    ("disponibilidad", r"",
     "Busco en el inventario de las farmacias.", []),
    ("diagnostico", r"diagnostic|que enfermedad|que tengo|tengo (fiebre|tos|dolor|gripe|diabetes)|sintoma|es grave|dosis|cuanto (debo )?tomar|que medicamento|pastilla|puedo tomar|receta me",
     "No puedo diagnosticar, interpretar síntomas ni indicar medicamentos o dosis: eso solo lo hace un profesional de la salud. "
     "Le recomiendo reservar una cita con el especialista adecuado desde el módulo de citas.", [CITAS]),
    ("reprogramar", r"reprogram|cambiar (mi |la )?(cita|fecha|hora)|mover (mi |la )?cita",
     "Para cambiar el horario de una cita vigente use «reprogramar» sobre esa cita (se libera el horario anterior y se reserva el nuevo en un solo paso). "
     "Debe elegir otro horario libre.", [MIS_CITAS]),
    ("cancelar", r"cancel|anular (mi |la )?cita|ya no (puedo )?(ir|asistir)",
     "Puede cancelar sus citas vigentes desde «Mis citas»; el horario queda libre para otras personas. Cancele con anticipación si no podrá asistir.", [MIS_CITAS]),
    ("agendar", r"agend|cita|reserv|turno|consulta (medica|con)|ver (a un|al) (doctor|medico)|sacar cita|apartar",
     "Yo no agendo citas, pero puede hacerlo usted en el módulo de citas, en cinco pasos: 1) especialidad, 2) centro de atención, 3) doctor, 4) fecha y 5) hora. "
     "Solo se muestran horarios realmente disponibles.", [CITAS]),
    ("privacidad", r"quien (vio|consulto|miro|abrio|accedio)|privacidad|acceso a mi|bitacora|auditoria|consintio|confidencial",
     "Usted puede ver quién consultó su expediente (fecha, quién y qué parte) en el registro de accesos. Todo acceso queda auditado.",
     [{"etiqueta": "Ver quién consultó mi expediente", "metodo": "GET", "ruta": "/portal/accesos"}]),
    ("expediente", r"expediente|historial|diagnosticos|resultados?|laboratorio|examen|vacuna|receta",
     "Puede ver su propio expediente en modo lectura (diagnósticos, recetas, resultados de laboratorio y vacunas) desde el portal. "
     "Los datos más sensibles (nivel 4) se muestran solo si usted los desbloquea con un código 2FA.",
     [{"etiqueta": "Mis diagnósticos", "metodo": "GET", "ruta": "/portal/mi-expediente/diagnosticos"}, {"etiqueta": "Mis vacunas", "metodo": "GET", "ruta": "/portal/mi-expediente/vacunas"}]),
    ("perfil", r"perfil|direccion|telefono|correo|datos de contacto|actualizar mis datos|estudiante|profesional",
     "Puede actualizar su contacto y dirección, y activar o desactivar sus perfiles de estudiante y profesional, desde su perfil. "
     "El DUI, el nombre y la fecha de nacimiento provienen del padrón y no se editan.", [{"etiqueta": "Mi perfil", "metodo": "GET", "ruta": "/portal/perfil"}]),
    ("2fa", r"2fa|codigo|verificacion|doble factor|nivel 4|desbloquear",
     "El código 2FA se envía a su contacto registrado y vence a los pocos minutos. No lo comparta con nadie: el personal de salud nunca se lo pedirá.", []),
    ("horarios", r"horario|a que hora|donde queda|centros?|hospital|clinica|especialidades",
     "Los centros, doctores y horarios libres dependen de la agenda que publica cada médico. Consúltelos en el módulo de citas, empezando por la especialidad.", [CITAS]),
    ("saludo", r"^(hola|buenas|buen dia|buenos dias|buenas tardes|buenas noches|hey|saludos)\b|gracias|ayuda|que puedes hacer",
     "¡Hola! Soy el asistente informativo del portal. Puedo orientarle sobre cómo agendar, cancelar o reprogramar citas, ver su expediente y vacunas, "
     "y proteger su privacidad. No doy diagnósticos ni agendo por usted.", [CITAS]),
]
FALLBACK = Respuesta("no_entendido", "No estoy seguro de haber entendido. Puedo ayudarle con: cómo agendar, cancelar o reprogramar una cita, ver su expediente o vacunas, "
                     "y saber quién consultó su expediente. Para temas de salud, reserve una cita con un profesional.", [CITAS])


def normalizar(t: str) -> str:
    t = unicodedata.normalize("NFKD", t.lower())
    return re.sub(r"\s+", " ", "".join(c for c in t if not unicodedata.combining(c))).strip()


def responder(mensaje: str) -> Respuesta:
    n = normalizar(mensaje)
    for intencion, patron, texto, acciones in REGLAS:
        if intencion == "disponibilidad":
            med = None if SENAL_CLINICA.search(n) else medicamento_buscado(n)
            if med:
                r = Respuesta(intencion, texto, list(acciones), consulta=med)
                break
            continue
        if re.search(patron, n):
            r = Respuesta(intencion, texto, list(acciones))
            break
    else:
        r = Respuesta(FALLBACK.intencion, FALLBACK.respuesta, list(FALLBACK.acciones))
    if proveedor_llm is not None and r.intencion not in ("emergencia", "diagnostico", "disponibilidad", "no_entendido"):
        r.respuesta = proveedor_llm.redactar(r.intencion, r.respuesta, mensaje)
    return r
