"""Historial farmacológico multicanal del ciudadano: recetas + administraciones hospitalarias + autocompras en una sola línea de tiempo, y alertas de
interacciones entre lo prescrito y lo autocomprado. Solo lee lo del titular que recibe como argumento (nunca un id de paciente desde fuera) y reutiliza
los servicios que ya existen: no duplica reglas ni consultas de recetas/autocompras."""
from datetime import date, datetime, time, timedelta, timezone

from fastapi import Request
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.models import Persona
from omega_core.models.base import ahora
from omega_core.security.ratelimit import ip_cliente

from . import interacciones, router_expediente, service_autocompras

_SV = timezone(timedelta(hours=-6))
VENTANA_AUTOCOMPRA_DIAS = 30  # una autocompra más antigua que esto ya no se cruza con las recetas (se sigue mostrando en la línea de tiempo)
TOPE = 200  # igual que el máximo de las lecturas de la API

CANALES = {
    "RECETA": "Receta médica",
    "ADMINISTRACION": "Administrado en hospital o urgencias",
    "AUTOCOMPRA": "Autocompra",
}


def _administraciones(db: Session, persona: Persona) -> list[dict]:
    """Canal de administraciones intrahospitalarias / urgencias (fármaco, dosis, vía, responsable, hospital, fecha y hora).
    PENDIENTE DE DATOS: hoy el expediente no guarda fármacos aplicados en la atención (eso llega con la bitácora integral del portal /profesional,
    parte 6b). Cuando exista esa tabla, basta devolver aquí dicts con las mismas claves que usa `linea_de_tiempo` y aparecerán en la línea de tiempo y en las alertas."""
    return []


def _como_instante(d: date) -> datetime:
    return datetime.combine(d, time.min, tzinfo=_SV)


def _entradas(request: Request, persona: Persona, db: Session) -> tuple[list[dict], list[str], list[str]]:
    """Todas las entradas (ya ordenadas, la más reciente primero) + medicamentos prescritos vigentes + medicamentos autocomprados recientes."""
    hoy = datetime.now(_SV).date()
    entradas: list[dict] = []
    prescritos: list[str] = []
    for r in router_expediente.mis_recetas(request, limite=TOPE, offset=0, persona=persona, db=db).items:
        entradas.append({"canal": "RECETA", "etiqueta": CANALES["RECETA"], "oficial": True, "fecha": r.emitida_en, "orden": (r.emitida_en, r.emitida_en),
                         "receta": r, "titulo": f"Receta {r.folio}"})
        en_tratamiento = r.vigente or (r.despachada_en is not None and any(r.despachada_en + timedelta(days=m.duracion_dias) >= ahora() for m in r.medicamentos))
        if r.estado != "ANULADA" and en_tratamiento:
            prescritos += [m.medicamento for m in r.medicamentos]
    for a in _administraciones(db, persona):
        entradas.append({"canal": "ADMINISTRACION", "etiqueta": CANALES["ADMINISTRACION"], "oficial": True, "orden": (a["fecha"], a["fecha"]), **a})
    autocomprados: list[str] = []
    for a in service_autocompras.listar(db, persona, TOPE):
        entradas.append({"canal": "AUTOCOMPRA", "etiqueta": "Declarada por el paciente", "oficial": False, "fecha": _como_instante(a.fecha_compra),
                         "orden": (_como_instante(a.fecha_compra), a.creado_en), "autocompra": a, "titulo": a.medicamento})
        if (hoy - a.fecha_compra).days <= VENTANA_AUTOCOMPRA_DIAS:
            autocomprados.append(a.medicamento)
    entradas.sort(key=lambda e: e["orden"], reverse=True)
    return entradas, prescritos, autocomprados


def leer(request: Request, persona: Persona, db: Session, limite: int, desplazamiento: int) -> dict:
    """Una página de la línea de tiempo + las alertas vigentes (siempre completas, no dependen de la página). Deja constancia en la bitácora."""
    entradas, prescritos, autocomprados = _entradas(request, persona, db)
    alertas = interacciones.detectar(prescritos, autocomprados)
    pagina = entradas[desplazamiento:desplazamiento + limite]
    auditar("PORTAL_LECTURA_PROPIA", actor_tipo="persona", actor_id=persona.id, recurso="expediente", recurso_id=persona.id, ip=ip_cliente(request),
            detalle={"seccion": "medicamentos", "devueltos": len(pagina), "restringidos": 0, "nivel4_abierto": False, "alertas": len(alertas)})
    return {"items": pagina, "alertas": alertas, "hay_siguiente": len(entradas) > desplazamiento + limite, "total": len(entradas)}
