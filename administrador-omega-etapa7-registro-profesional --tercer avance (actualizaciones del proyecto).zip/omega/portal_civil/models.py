import uuid
from datetime import date, datetime, time

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, SmallInteger, String, Text, Time, Uuid, text
from sqlalchemy.orm import Mapped, mapped_column

from omega_core.models.base import Base, ahora


def _fk(tabla: str, **kw):
    return mapped_column(Uuid, ForeignKey(f"{tabla}.id", ondelete="RESTRICT"), **kw)


class Vacuna(Base):
    """Registro de vacunación. Inmutable y versionado como el resto del expediente: una corrección es una fila nueva con `reemplaza_id`.
    Se expone como sección `vacunas` del expediente (comparte la mecánica de lectura de core_expediente)."""

    __tablename__ = "vacuna"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    paciente_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    nivel_sensibilidad: Mapped[int] = mapped_column(SmallInteger, default=2)
    vacuna: Mapped[str] = mapped_column(String(120))
    codigo: Mapped[str | None] = mapped_column(String(20))
    dosis_numero: Mapped[int] = mapped_column(SmallInteger)
    lote: Mapped[str | None] = mapped_column(String(40))
    fabricante: Mapped[str | None] = mapped_column(String(80))
    fecha_aplicacion: Mapped[date] = mapped_column(Date)
    via_aplicacion: Mapped[str | None] = mapped_column(String(40))
    proxima_dosis: Mapped[date | None] = mapped_column(Date)
    observaciones: Mapped[str | None] = mapped_column(String(500))
    establecimiento: Mapped[str] = mapped_column(String(200))  # nombre del establecimiento al momento de aplicar
    institucion_id: Mapped[uuid.UUID] = _fk("institucion")
    registrado_por: Mapped[uuid.UUID] = _fk("persona")
    atencion_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("atencion.id", ondelete="RESTRICT"))
    hash_contenido: Mapped[str] = mapped_column(String(64))
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    reemplaza_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("vacuna.id", ondelete="RESTRICT"), unique=True)
    motivo_correccion: Mapped[str | None] = mapped_column(String(300))
    __table_args__ = (
        CheckConstraint("nivel_sensibilidad = 2", name="nivel_estandar"),
        CheckConstraint("dosis_numero BETWEEN 1 AND 10", name="dosis_valida"),
        CheckConstraint("proxima_dosis IS NULL OR proxima_dosis > fecha_aplicacion", name="proxima_posterior"),
        Index("ix_vacuna_paciente_fecha", "paciente_id", "fecha_aplicacion"),
    )


class DesbloqueoN4(Base):
    """Desbloqueo temporal de datos nivel 4 en el portal: se obtiene verificando un código 2FA y vence a los pocos minutos. Solo se guarda el hash del token."""

    __tablename__ = "desbloqueo_nivel4"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    persona_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    expira_en: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    revocado_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class AgendaDisponibilidad(Base):
    """Bloque semanal de atención que define un médico (p. ej. lunes 08:00–12:00 en citas de 30 min). Se desactiva, no se borra."""

    __tablename__ = "agenda_disponibilidad"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    medico_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    institucion_id: Mapped[uuid.UUID] = _fk("institucion")
    dia_semana: Mapped[int] = mapped_column(SmallInteger)  # 0 = lunes … 6 = domingo
    hora_inicio: Mapped[time] = mapped_column(Time)
    hora_fin: Mapped[time] = mapped_column(Time)
    duracion_min: Mapped[int] = mapped_column(SmallInteger)
    vigente_desde: Mapped[date] = mapped_column(Date)
    vigente_hasta: Mapped[date | None] = mapped_column(Date)
    activo: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    desactivado_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        CheckConstraint("dia_semana BETWEEN 0 AND 6", name="dia_valido"),
        CheckConstraint("hora_fin > hora_inicio", name="horas_validas"),
        CheckConstraint("duracion_min BETWEEN 10 AND 120", name="duracion_valida"),
        CheckConstraint("vigente_hasta IS NULL OR vigente_hasta >= vigente_desde", name="vigencia_valida"),
    )


class Cita(Base):
    """Cita médica. El horario no se edita (reprogramar = cita nueva + la anterior queda REPROGRAMADA); solo cambia el estado.
    La doble reserva la impide la base de datos con índices únicos parciales."""

    __tablename__ = "cita"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    paciente_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    medico_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    institucion_id: Mapped[uuid.UUID] = _fk("institucion")
    especialidad: Mapped[str] = mapped_column(String(120))
    inicio: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    fin: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    estado: Mapped[str] = mapped_column(String(15), default="PROGRAMADA")  # PROGRAMADA | CANCELADA | REPROGRAMADA
    motivo: Mapped[str | None] = mapped_column(String(300))
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    reprogramada_de_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("cita.id", ondelete="RESTRICT"), unique=True)
    cerrada_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    motivo_cierre: Mapped[str | None] = mapped_column(String(300))
    __table_args__ = (
        CheckConstraint("estado IN ('PROGRAMADA','CANCELADA','REPROGRAMADA')", name="estado_valido"),
        CheckConstraint("fin > inicio", name="horas_validas"),
        # Bloqueo a nivel de base de datos: un médico no puede tener dos citas vigentes a la misma hora, ni un paciente.
        Index("uq_cita_medico_inicio", "medico_id", "inicio", unique=True, postgresql_where=text("estado = 'PROGRAMADA'")),
        Index("uq_cita_paciente_inicio", "paciente_id", "inicio", unique=True, postgresql_where=text("estado = 'PROGRAMADA'")),
    )


class Autocompra(Base):
    """Medicamento que el propio ciudadano declara haber comprado sin receta. NO es un registro clínico oficial: vive en su propia tabla,
    nunca se mezcla con `receta` ni con el expediente, y el origen queda fijo en la base de datos. Inmutable (sin edición)."""

    __tablename__ = "autocompra"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    paciente_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    medicamento: Mapped[str] = mapped_column(String(200))
    dosis: Mapped[str] = mapped_column(String(120))
    fecha_compra: Mapped[date] = mapped_column(Date)
    farmacia: Mapped[str | None] = mapped_column(String(200))
    origen: Mapped[str] = mapped_column(String(30), default="DECLARADA_POR_PACIENTE", server_default="DECLARADA_POR_PACIENTE")
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    __table_args__ = (
        CheckConstraint("origen = 'DECLARADA_POR_PACIENTE'", name="origen_declarado"),
        Index("ix_autocompra_paciente_fecha", "paciente_id", "fecha_compra"),
    )
