"""Autocompras declaradas por el ciudadano. Solo opera sobre la persona autenticada: no recibe ningún id de paciente desde fuera."""
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from core_expediente.service import asegurar_no_congelado
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.models import Persona

from .models import Autocompra
from .schemas_autocompras import AutocompraIn, AutocompraOut

_SV = timezone(timedelta(hours=-6))


def a_salida(a: Autocompra) -> AutocompraOut:
    return AutocompraOut(id=a.id, medicamento=a.medicamento, dosis=a.dosis, fecha_compra=a.fecha_compra, farmacia=a.farmacia,
                         origen=a.origen, creado_en=a.creado_en)


def registrar(db: Session, persona: Persona, datos: AutocompraIn, ip: str | None) -> Autocompra:
    asegurar_no_congelado(db, persona.id)
    if datos.fecha_compra > datetime.now(_SV).date():
        raise HTTPException(422, "fecha_compra no puede ser futura")
    a = Autocompra(paciente_id=persona.id, medicamento=datos.medicamento, dosis=datos.dosis, fecha_compra=datos.fecha_compra,
                   farmacia=datos.farmacia, origen="DECLARADA_POR_PACIENTE")
    db.add(a)
    db.commit()
    # La bitácora guarda qué se hizo y sobre qué registro, no el nombre del medicamento (dato de salud).
    auditar("AUTOCOMPRA_REGISTRADA", actor_tipo="persona", actor_id=persona.id, recurso="autocompra", recurso_id=a.id, ip=ip,
            detalle={"fecha_compra": a.fecha_compra, "con_farmacia": a.farmacia is not None, "origen": a.origen})
    return a


def listar(db: Session, persona: Persona, limite: int = 100) -> list[Autocompra]:
    return list(db.scalars(select(Autocompra).where(Autocompra.paciente_id == persona.id)
                           .order_by(Autocompra.fecha_compra.desc(), Autocompra.creado_en.desc()).limit(limite)))
