import json
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from main import app
from omega_core.database import SessionLocal

from .conftest import datos_persona, dui_nuevo, nit_nuevo
from .test_etapa2 import NAC, abrir, acciones_auditoria, auth, medico, ml, paciente_id, sql  # noqa: F401
from .test_etapa2c import alta_completa, login
from .test_etapa5a import medico_nuevo

SV = timezone(timedelta(hours=-6))


@pytest.fixture
def servicio():
    return f"Servicio {uuid.uuid4().hex[:8]}"


def cama(client, h, servicio, codigo):
    return client.post("/camas", headers=h, json={"servicio": servicio, "codigo": codigo})


def paciente_con_atencion(client, medico):
    d = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=d).status_code == 201
    return d, abrir(client, medico, d["dui"])


def ingresar(client, h, cama_id, at):
    return client.post(f"/camas/{cama_id}/ingresar", headers=h, json={"atencion_id": at})


def egresar(client, h, cama_id, motivo="ALTA_MEDICA", **kw):
    return client.post(f"/camas/{cama_id}/egresar", headers=h, json={"motivo": motivo} | kw)


def estado_cama(cama_id):
    return sql("SELECT estado FROM cama WHERE id = :i", i=cama_id)[0][0]


def medico_otra_institucion(client, omega_headers):
    """Segundo hospital (activo) con su propio médico verificado."""
    d = {"tipo": "HOSPITAL", "nombre_legal": "Hospital Regional de Prueba", "nit": nit_nuevo(), "codigo_minsal": f"H-{uuid.uuid4().hex[:8]}", "departamento": "Santa Ana", "municipio": "Santa Ana",
         "direccion": "Santa Ana", "telefono": "2400-0000", "correo": f"{uuid.uuid4().hex[:8]}@hosp.sv", "responsable_nombre": "Dr. Director", "responsable_dui": dui_nuevo(),
         "documento_permiso_ref": "up://permiso.pdf", "horario": "24 horas", "password": "HospClave12345"}
    r = client.post("/instituciones", json=d)
    assert r.status_code == 201, r.text
    hid = r.json()["id"]
    assert client.patch(f"/omega/instituciones/{hid}/estado", json={"estado": "ACTIVA", "motivo": "Permiso verificado"}, headers=omega_headers).status_code == 200
    p = datos_persona(fecha_nacimiento=NAC, profesional={"tipo": "DOCTOR", "especialidad": "Medicina Interna", "numero_junta": f"J{uuid.uuid4().hex[:7]}", "institucion_id": hid})
    r = client.post("/personas", json=p)
    assert r.status_code == 201, r.text
    assert client.patch(f"/omega/personas/{r.json()['id']}/verificacion", headers=omega_headers, json={"perfil": "profesional", "verificado": True, "motivo": "JVPM verificada"}).status_code == 200
    return login(client, p), hid


# ------------------------------------------------------------------ Altas y censo
def test_camas_por_institucion_y_servicio(client, medico, servicio, omega_headers):
    r = cama(client, medico, servicio, "mi-01")
    assert r.status_code == 201, r.text
    c = r.json()
    assert c["estado"] == "LIBRE" and c["codigo"] == "MI-01" and c["servicio"] == servicio and c["activa"] and c["ocupante"] is None
    assert cama(client, medico, servicio, "MI-01").status_code == 409  # mismo código en el mismo servicio (sin distinguir mayúsculas)
    assert cama(client, medico, "Otro " + servicio, "MI-01").status_code == 201  # en otro servicio sí
    assert cama(client, medico, servicio, "MI-02").status_code == 201
    for malo in ({"servicio": servicio, "codigo": "con espacio"}, {"servicio": "x", "codigo": "A1"}, {"servicio": servicio, "codigo": ""}, {"servicio": servicio, "codigo": "A1", "extra": 1}):
        assert client.post("/camas", headers=medico, json=malo).status_code == 422, malo
    lista = client.get("/camas", params={"servicio": servicio.upper()}, headers=medico).json()
    assert [x["codigo"] for x in lista] == ["MI-01", "MI-02"] and all(x["estado"] == "LIBRE" for x in lista)
    assert client.get("/camas", params={"servicio": servicio, "estado": "OCUPADA"}, headers=medico).json() == []
    # retirar / reactivar (no se borra)
    r = client.put(f"/camas/{c['id']}/activa", headers=medico, json={"activa": False, "motivo": "En mantenimiento"})
    assert r.status_code == 200 and r.json()["activa"] is False
    assert [x["codigo"] for x in client.get("/camas", params={"servicio": servicio}, headers=medico).json()] == ["MI-02"]
    assert len(client.get("/camas", params={"servicio": servicio, "incluir_retiradas": True}, headers=medico).json()) == 2
    assert client.put(f"/camas/{c['id']}/activa", headers=medico, json={"activa": True, "motivo": "x"}).status_code == 422
    assert client.put(f"/camas/{c['id']}/activa", headers=medico, json={"activa": True, "motivo": "Reparada"}).json()["activa"] is True
    ac = acciones_auditoria(c["id"])
    assert ac == ["CAMA_CREADA", "CAMA_RETIRADA", "CAMA_REACTIVADA"]
    # nadie sin perfil de personal de salud
    civil = datos_persona(fecha_nacimiento=NAC)
    client.post("/personas", json=civil)
    hc = login(client, civil)
    for m, ruta in (("get", "/camas"), ("get", "/camas/ocupacion"), ("post", "/camas")):
        assert getattr(client, m)(ruta, headers=hc, **({"json": {"servicio": servicio, "codigo": "Z1"}} if m == "post" else {})).status_code == 403
    assert client.get("/camas").status_code == 401
    # BD: las camas no se borran ni cambian de servicio/código
    for q in ("DELETE FROM cama WHERE id = :i", "UPDATE cama SET codigo = 'XX' WHERE id = :i", "UPDATE cama SET servicio = 'otro' WHERE id = :i", "TRUNCATE cama"):
        with pytest.raises(DBAPIError, match="cama|inmutable"):
            with SessionLocal() as db:
                db.execute(text(q), {"i": c["id"]})
                db.commit()


# ------------------------------------------------------------------ Ciclo ingreso → egreso → limpieza
def test_ingreso_egreso_y_limpieza(client, medico, servicio):
    c1, c2 = cama(client, medico, servicio, "A-01").json(), cama(client, medico, servicio, "A-02").json()
    d1, at1 = paciente_con_atencion(client, medico)
    d2, at2 = paciente_con_atencion(client, medico)
    r = ingresar(client, medico, c1["id"], at1)
    assert r.status_code == 201, r.text
    o = r.json()
    assert o["egreso_en"] is None and o["cama_estado"] == "OCUPADA" and o["servicio"] == servicio and o["atencion_id"] == at1
    assert estado_cama(c1["id"]) == "OCUPADA"
    # censo: nombre y folio, sin DUI
    cen = {x["codigo"]: x for x in client.get("/camas", params={"servicio": servicio}, headers=medico).json()}
    assert cen["A-01"]["estado"] == "OCUPADA" and cen["A-01"]["ocupante"]["atencion_id"] == at1 and cen["A-01"]["ocupante"]["paciente"].startswith(d1["nombres"])
    assert d1["dui"] not in json.dumps(cen) and cen["A-02"]["ocupante"] is None
    # una cama ocupada no se asigna a otro, y el mismo paciente no ocupa dos camas
    assert ingresar(client, medico, c1["id"], at2).status_code == 409
    r = ingresar(client, medico, c2["id"], at1)
    assert r.status_code == 409 and "ya ocupa la cama A-01" in r.json()["detail"]
    assert estado_cama(c2["id"]) == "LIBRE"
    # no se retira una cama ocupada
    assert client.put(f"/camas/{c1['id']}/activa", headers=medico, json={"activa": False, "motivo": "Fumigación"}).status_code == 409
    # egreso: la cama pasa a LIMPIEZA y no se ofrece hasta confirmar la limpieza
    assert egresar(client, medico, c2["id"]).status_code == 409  # cama sin paciente
    r = egresar(client, medico, c1["id"], "TRASLADO", nota="A UCI de otro hospital")
    assert r.status_code == 200, r.text
    assert r.json()["motivo_egreso"] == "TRASLADO" and r.json()["cama_estado"] == "LIMPIEZA" and r.json()["estancia_horas"] is not None
    assert estado_cama(c1["id"]) == "LIMPIEZA"
    assert egresar(client, medico, c1["id"]).status_code == 409  # ya egresado
    assert ingresar(client, medico, c1["id"], at2).status_code == 409  # en limpieza no se asigna
    assert client.post(f"/camas/{c2['id']}/limpieza-terminada", headers=medico).status_code == 409  # libre, no en limpieza
    r = client.post(f"/camas/{c1['id']}/limpieza-terminada", headers=medico)
    assert r.status_code == 200 and r.json()["estado"] == "LIBRE"
    # ahora sí: el paciente 1 puede cambiar de cama (nueva ocupación) y la cama liberada la toma otro
    assert ingresar(client, medico, c2["id"], at1).status_code == 201
    assert ingresar(client, medico, c1["id"], at2).status_code == 201
    assert client.get("/camas", params={"servicio": servicio, "estado": "OCUPADA"}, headers=medico).json().__len__() == 2
    # historial: dos ocupaciones de c1, la primera cerrada y la segunda abierta
    assert sql("SELECT count(*), count(egreso_en) FROM ocupacion_cama WHERE cama_id = :c", c=c1["id"]) == [(2, 1)]
    # bitácora
    ac = acciones_auditoria(c1["id"])
    assert ac[0] == "CAMA_CREADA" and ac.count("CAMA_INGRESO") == 2 and "CAMA_EGRESO" in ac and "CAMA_LIMPIEZA_TERMINADA" in ac and ac.count("CAMA_DENEGADA") >= 3
    ing = sql("SELECT detalle FROM auditoria WHERE recurso_id = :c AND accion = 'CAMA_INGRESO' ORDER BY id", c=c1["id"])[0][0]
    assert ing["atencion_id"] == at1 and ing["paciente_id"] == paciente_id(d1["dui"]) and ing["servicio"] == servicio
    eg = sql("SELECT detalle FROM auditoria WHERE recurso_id = :c AND accion = 'CAMA_EGRESO'", c=c1["id"])[0][0]
    assert eg["motivo"] == "TRASLADO" and eg["atencion_id"] == at1
    den = sql("SELECT detalle FROM auditoria WHERE recurso_id = :c AND accion = 'CAMA_DENEGADA' ORDER BY id", c=c1["id"])
    assert {x[0]["motivo"] for x in den} >= {"CAMA_NO_LIBRE"}


def test_ingreso_exige_atencion_activa_y_paciente_vivo(client, medico, servicio):
    c = cama(client, medico, servicio, "B-01").json()
    d, at = paciente_con_atencion(client, medico)
    # atención inexistente / de otra institución
    assert ingresar(client, medico, c["id"], str(uuid.uuid4())).status_code == 404
    # atención cerrada
    dc = datos_persona(fecha_nacimiento=NAC)
    client.post("/personas", json=dc)
    at_cerrada, _, _ = alta_completa(client, medico, dc)
    r = ingresar(client, medico, c["id"], at_cerrada)
    assert r.status_code == 409 and "no está abierta" in r.json()["detail"]
    # DUI congelado: 423 y la cama sigue libre
    df, atf = paciente_con_atencion(client, medico)
    r, _ = ml(client, df["dui"])
    assert r.status_code in (200, 201), r.text
    assert ingresar(client, medico, c["id"], atf).status_code == 423
    assert estado_cama(c["id"]) == "LIBRE"
    # retirada
    client.put(f"/camas/{c['id']}/activa", headers=medico, json={"activa": False, "motivo": "Sin colchón"})
    assert ingresar(client, medico, c["id"], at).status_code == 409
    motivos = {x[0]["motivo"] for x in sql("SELECT detalle FROM auditoria WHERE accion = 'CAMA_DENEGADA' AND recurso_id = :c", c=c["id"])}
    assert {"ATENCION_NO_ENCONTRADA", "ATENCION_CERRADA", "DUI_CONGELADO", "CAMA_RETIRADA"} <= motivos
    # extra y formatos
    assert client.post(f"/camas/{c['id']}/ingresar", headers=medico, json={"atencion_id": at, "x": 1}).status_code == 422
    assert client.post(f"/camas/{c['id']}/ingresar", headers=medico, json={"atencion_id": "no-es-uuid"}).status_code == 422
    assert client.post(f"/camas/{c['id']}/egresar", headers=medico, json={"motivo": "SE_FUE"}).status_code == 422


# ------------------------------------------------------------------ Sin doble asignación (bloqueo en BD)
def test_ingresos_simultaneos_a_la_misma_cama(client, medico, servicio):
    c = cama(client, medico, servicio, "C-01").json()
    ats = [paciente_con_atencion(client, medico)[1] for _ in range(6)]

    def intento(at):
        with TestClient(app, client=("127.0.0.1", 50002)) as cl:
            return ingresar(cl, medico, c["id"], at).status_code

    with ThreadPoolExecutor(6) as ex:
        codigos = list(ex.map(intento, ats))
    assert sorted(codigos) == [201] + [409] * 5, codigos
    assert sql("SELECT count(*) FROM ocupacion_cama WHERE cama_id = :c AND egreso_en IS NULL", c=c["id"])[0][0] == 1
    assert estado_cama(c["id"]) == "OCUPADA"


def test_un_paciente_no_ocupa_dos_camas_a_la_vez(client, medico, servicio):
    camas = [cama(client, medico, servicio, f"D-0{i}").json()["id"] for i in range(5)]
    d, at = paciente_con_atencion(client, medico)

    def intento(cid):
        with TestClient(app, client=("127.0.0.1", 50003)) as cl:
            return ingresar(cl, medico, cid, at).status_code

    with ThreadPoolExecutor(5) as ex:
        codigos = list(ex.map(intento, camas))
    assert sorted(codigos) == [201] + [409] * 4, codigos
    assert sql("SELECT count(*) FROM ocupacion_cama WHERE paciente_id = :p AND egreso_en IS NULL", p=paciente_id(d["dui"]))[0][0] == 1
    assert sorted(x[0] for x in sql("SELECT estado FROM cama WHERE id = ANY(:ids)", ids=camas)) == ["LIBRE"] * 4 + ["OCUPADA"]


def test_la_base_de_datos_rechaza_lo_que_la_api_no_haria(client, medico, servicio):
    c1, c2 = cama(client, medico, servicio, "E-01").json(), cama(client, medico, servicio, "E-02").json()
    d, at = paciente_con_atencion(client, medico)
    d2, at2 = paciente_con_atencion(client, medico)
    assert ingresar(client, medico, c1["id"], at).status_code == 201
    ins = ("INSERT INTO ocupacion_cama (id, cama_id, institucion_id, servicio, atencion_id, paciente_id, ingreso_en, ingresado_por) "
           "SELECT gen_random_uuid(), :c, institucion_id, (SELECT servicio FROM cama WHERE id = :c), id, paciente_id, now(), abierta_por FROM atencion WHERE id = :a")
    for q, p, patron in ((ins, {"c": c1["id"], "a": at2}, "LIBRE"),   # segunda ocupación sobre la misma cama
                         (ins, {"c": c2["id"], "a": at}, "uq_ocupacion_(paciente|atencion)_abierta"),  # mismo paciente en otra cama
                         ("UPDATE cama SET estado = 'LIMPIEZA' WHERE id = :c", {"c": c1["id"]}, "egrese primero"),  # soltar la cama con paciente adentro
                         ("UPDATE cama SET estado = 'OCUPADA' WHERE id = :c", {"c": c2["id"]}, "OCUPADA debe tener"),  # ocupada sin paciente
                         ("UPDATE ocupacion_cama SET paciente_id = (SELECT id FROM persona LIMIT 1) WHERE cama_id = :c", {"c": c1["id"]}, "egreso"),
                         ("DELETE FROM ocupacion_cama WHERE cama_id = :c", {"c": c1["id"]}, "no se borran"), ("TRUNCATE ocupacion_cama", {}, "inmutable|no se")):
        with pytest.raises(DBAPIError, match=patron):
            with SessionLocal() as db:
                db.execute(text(q), p)
                db.commit()
    # tras un egreso la ocupación cerrada es inmutable y la cama no puede saltar de LIMPIEZA a OCUPADA
    assert egresar(client, medico, c1["id"]).status_code == 200
    for q, patron in (("UPDATE ocupacion_cama SET egreso_en = now() WHERE cama_id = :c", "inmutable"), ("UPDATE cama SET estado = 'OCUPADA' WHERE id = :c", "transición|OCUPADA")):
        with pytest.raises(DBAPIError, match=patron):
            with SessionLocal() as db:
                db.execute(text(q), {"c": c1["id"]})
                db.commit()
    # camas retiradas u ocupadas por otra institución: la BD valida que la ocupación sea de la institución y servicio de la cama
    with pytest.raises(DBAPIError, match="institución y servicio|LIBRE"):
        with SessionLocal() as db:
            db.execute(text("INSERT INTO ocupacion_cama (id, cama_id, institucion_id, servicio, atencion_id, paciente_id, ingreso_en, ingresado_por) "
                            "SELECT gen_random_uuid(), :c, institucion_id, 'otro servicio', id, paciente_id, now(), abierta_por FROM atencion WHERE id = :a"), {"c": c2["id"], "a": at2})
            db.commit()


# ------------------------------------------------------------------ Solo el personal de esa institución
def test_solo_el_personal_de_la_institucion_gestiona_sus_camas(client, medico, omega_headers, servicio):
    ajeno, otra_id = medico_otra_institucion(client, omega_headers)
    c = cama(client, medico, servicio, "F-01").json()
    d, at = paciente_con_atencion(client, medico)
    assert ingresar(client, medico, c["id"], at).status_code == 201
    # el médico de otro hospital no ve, ingresa, egresa, limpia ni retira camas ajenas: 404 igual que si no existieran
    inex = str(uuid.uuid4())
    for m, ruta, body in (("post", f"/camas/{{}}/ingresar", {"atencion_id": at}), ("post", "/camas/{}/egresar", {"motivo": "OTRO"}), ("post", "/camas/{}/limpieza-terminada", None),
                          ("put", "/camas/{}/activa", {"activa": False, "motivo": "Intento ajeno"})):
        a = getattr(client, m)(ruta.format(c["id"]), headers=ajeno, **({"json": body} if body else {}))
        b = getattr(client, m)(ruta.format(inex), headers=ajeno, **({"json": body} if body else {}))
        assert a.status_code == b.status_code == 404 and a.json() == b.json(), ruta
    assert estado_cama(c["id"]) == "OCUPADA"
    assert client.get("/camas", params={"servicio": servicio}, headers=ajeno).json() == []
    # las camas que crea el ajeno son de SU institución y no se mezclan
    mia = cama(client, ajeno, servicio, "F-01")
    assert mia.status_code == 201 and mia.json()["id"] != c["id"]
    assert [x["id"] for x in client.get("/camas", params={"servicio": servicio}, headers=medico).json()] == [c["id"]]
    # tampoco puede ingresar a su cama una atención de otra institución
    assert ingresar(client, ajeno, mia.json()["id"], at).status_code == 404
    den = [x[0]["motivo"] for x in sql("SELECT detalle FROM auditoria WHERE accion = 'CAMA_DENEGADA' AND actor_id = :p", p=paciente_id_persona(ajeno, client))]
    assert den.count("OTRA_INSTITUCION") == 4
    # otro médico de LA MISMA institución sí puede operar (es su personal)
    colega = medico_nuevo(client, omega_headers)
    assert egresar(client, colega, c["id"]).status_code == 200
    assert client.post(f"/camas/{c['id']}/limpieza-terminada", headers=colega).json()["estado"] == "LIBRE"


def paciente_id_persona(h, client):
    # el id de quien hace la petición: se obtiene del propio token (sub)
    import base64
    payload = h["Authorization"].split()[1].split(".")[1]
    return json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))["sub"]


# ------------------------------------------------------------------ Resumen de ocupación del día
def test_resumen_de_ocupacion_por_servicio(client, medico, omega_headers, servicio):
    s2 = "Cuidados " + servicio
    a1, a2, a3 = (cama(client, medico, servicio, f"G-0{i}").json()["id"] for i in (1, 2, 3))
    b1, b2 = (cama(client, medico, s2, f"H-0{i}").json()["id"] for i in (1, 2))
    (d1, at1), (d2, at2), (d3, at3) = (paciente_con_atencion(client, medico) for _ in range(3))
    assert ingresar(client, medico, a1, at1).status_code == 201
    assert ingresar(client, medico, a2, at2).status_code == 201
    assert ingresar(client, medico, b1, at3).status_code == 201
    assert egresar(client, medico, a2, "ALTA_MEDICA").status_code == 200  # a2 → limpieza
    r = client.get("/camas/ocupacion", headers=medico)
    assert r.status_code == 200, r.text
    j = r.json()
    por = {s["servicio"]: s for s in j["servicios"]}
    assert j["fecha"] == str(datetime.now(SV).date())
    s_a, s_b = por[servicio], por[s2]
    assert (s_a["camas_activas"], s_a["ocupadas"], s_a["libres"], s_a["en_limpieza"], s_a["ocupacion_pct"]) == (3, 1, 1, 1, 33.3)
    assert (s_a["ingresos_del_dia"], s_a["egresos_del_dia"]) == (2, 1)
    assert (s_b["camas_activas"], s_b["ocupadas"], s_b["libres"], s_b["en_limpieza"], s_b["ocupacion_pct"]) == (2, 1, 1, 0, 50.0)
    assert (s_b["ingresos_del_dia"], s_b["egresos_del_dia"]) == (1, 0)
    # el total de la institución incluye al menos estos servicios y es coherente con la suma por servicio
    assert j["camas_activas"] == sum(s["camas_activas"] for s in j["servicios"]) and j["ocupadas"] == sum(s["ocupadas"] for s in j["servicios"])
    assert j["libres"] + j["en_limpieza"] + j["ocupadas"] == j["camas_activas"]
    # una cama retirada no cuenta
    client.put(f"/camas/{a3}/activa", headers=medico, json={"activa": False, "motivo": "Fuera de servicio"})
    s_a = {s["servicio"]: s for s in client.get("/camas/ocupacion", headers=medico).json()["servicios"]}[servicio]
    assert s_a["camas_activas"] == 2
    # solo ve los datos de su institución
    ajeno, _ = medico_otra_institucion(client, omega_headers)
    assert servicio not in [s["servicio"] for s in client.get("/camas/ocupacion", headers=ajeno).json()["servicios"]]
    # fechas: pasado (sin camas libres/limpieza) y futuro (422)
    ayer = str(datetime.now(SV).date() - timedelta(days=1))
    p = client.get("/camas/ocupacion", params={"fecha": ayer}, headers=medico).json()
    assert p["libres"] is None and p["en_limpieza"] is None and {s["servicio"]: s for s in p["servicios"]}[servicio]["ingresos_del_dia"] == 0
    assert client.get("/camas/ocupacion", params={"fecha": str(date.today() + timedelta(days=3))}, headers=medico).status_code == 422
    assert client.get("/camas/ocupacion", params={"fecha": "ayer"}, headers=medico).status_code == 422
    # sin datos de pacientes
    cuerpo = json.dumps(j)
    assert d1["dui"] not in cuerpo and d1["nombres"] + " " + d1["apellidos"] not in cuerpo and at1 not in cuerpo
    assert "CAMAS_OCUPACION_CONSULTADA" in [x[0] for x in sql("SELECT accion FROM auditoria WHERE actor_id = :p", p=paciente_id_persona(medico, client))]


def test_endpoints_documentados(client):
    paths = client.get("/openapi.json").json()["paths"]
    for p, ms in (("/camas", {"get", "post"}), ("/camas/ocupacion", {"get"}), ("/camas/{cama_id}/activa", {"put"}), ("/camas/{cama_id}/ingresar", {"post"}),
                  ("/camas/{cama_id}/egresar", {"post"}), ("/camas/{cama_id}/limpieza-terminada", {"post"})):
        assert ms <= set(paths[p]), p
        assert all(op.get("summary") and op.get("description") is not None for op in paths[p].values()), p
