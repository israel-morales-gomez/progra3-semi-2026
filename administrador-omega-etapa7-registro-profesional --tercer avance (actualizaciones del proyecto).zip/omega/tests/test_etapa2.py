import json
import time
from datetime import date

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from core_expediente.estado_vital import firma_ml
from omega_core.config import settings
from omega_core.database import SessionLocal
from omega_core.seed import DUI_MEDICO, PASSWORD_MEDICO

from .conftest import datos_persona

NAC = "1990-05-17"


def auth(t):
    return {"Authorization": f"Bearer {t}"}


@pytest.fixture
def medico(client):
    r = client.post("/auth/login/persona", json={"dui": DUI_MEDICO, "password": PASSWORD_MEDICO})
    assert r.status_code == 200, r.text
    return auth(r.json()["tokens"]["access_token"])


@pytest.fixture
def paciente(client):
    d = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=d).status_code == 201
    return d


def abrir(client, medico, dui, fase3=True, **extra):
    body = {"dui": dui, "tipo_atencion": "AMBULATORIA", "area": "Medicina General", "motivo_consulta": "Control general"} | extra
    r = client.post("/atenciones", json=body, headers=medico)
    assert r.status_code == 201, r.text
    at = r.json()["id"]
    if r.json()["fase"] == 1 and fase3:
        t = client.post(f"/atenciones/{at}/transicion", headers=medico, json={"a_fase": 2, "identidad_verificada": True, "antecedentes_revisados": True})
        assert t.status_code == 200, t.text
        tr = client.post(f"/atenciones/{at}/triaje", headers=medico, json={"nivel": "VERDE", "discriminador": "Sin signos de alarma"})
        assert tr.status_code == 200, tr.text
        t = client.post(f"/atenciones/{at}/transicion", headers=medico, json={"a_fase": 3})
        assert t.status_code == 200, t.text
    return at


def sql(q, **p):
    with SessionLocal() as db:
        return db.execute(text(q), p).all()


def acciones_auditoria(recurso_id: str) -> list[str]:
    return [r[0] for r in sql("SELECT accion FROM auditoria WHERE recurso_id = :r ORDER BY id", r=recurso_id)]


def nota(**extra):
    return {"subjetivo": "Dolor de cabeza", "objetivo": "TA 120/80", "analisis": "Cefalea tensional", "plan": "Paracetamol"} | extra


def test_expediente_unico_por_dui_con_todas_las_secciones(client, medico, paciente):
    dui = paciente["dui"]
    at = abrir(client, medico, dui)
    assert client.post(f"/atenciones/{at}/antecedentes", headers=medico,
                       json={"tipo": "PERSONAL_PATOLOGICO", "descripcion": "Diabetes tipo 2 desde 2015"}).status_code == 201
    assert client.post(f"/atenciones/{at}/alergias", headers=medico,
                       json={"sustancia": "penicilina", "severidad": "GRAVE", "reaccion": "urticaria"}).status_code == 201
    assert client.post(f"/atenciones/{at}/diagnosticos", headers=medico,
                       json={"codigo_cie10": "E11.9", "descripcion": "Diabetes mellitus tipo 2", "tipo": "DEFINITIVO", "principal": True}).status_code == 201
    assert client.post(f"/atenciones/{at}/diagnosticos", headers=medico,
                       json={"codigo_cie10": "NOEXISTE", "descripcion": "x", "tipo": "DEFINITIVO"}).status_code == 422
    r = client.post(f"/atenciones/{at}/signos-vitales", headers=medico, json={"ta_sistolica": 130, "ta_diastolica": 85, "fc": 78, "spo2": 98})
    assert r.status_code == 201
    assert client.post(f"/atenciones/{at}/signos-vitales", headers=medico, json={"ta_sistolica": 80, "ta_diastolica": 90}).status_code == 422
    n = client.post(f"/atenciones/{at}/notas", headers=medico, json=nota())
    assert n.status_code == 201 and n.json()["nivel_sensibilidad"] == 2 and len(n.json()["hash_contenido"]) == 64
    r = client.get(f"/expediente/{dui}", headers=medico)
    assert r.status_code == 200, r.text
    e = r.json()
    for sec in ("antecedentes", "alergias", "diagnosticos", "signos_vitales"):
        assert e[sec]["devueltos"] == 1, sec
    assert e["estado_vital"]["estado"] == "VIVO" and e["estado_vital"]["congelado"] is False
    assert client.get(f"/expediente/{dui}/notas", headers=medico).json()["devueltos"] == 1
    assert "REGISTRO_CLINICO" in acciones_auditoria(n.json()["id"])
    # un solo expediente por DUI: la atención de otra institución/otro paciente no lo mezcla
    otro = datos_persona()
    client.post("/personas", json=otro)
    assert client.get(f"/expediente/{otro['dui']}", headers=medico).status_code == 403  # sin atención activa ni consentimiento


def test_nota_soap_no_se_edita_se_corrige_con_nueva_version(client, medico, paciente):
    at = abrir(client, medico, paciente["dui"])
    n1 = client.post(f"/atenciones/{at}/notas", headers=medico, json=nota()).json()
    assert client.put(f"/atenciones/{at}/notas/{n1['id']}", json=nota(), headers=medico).status_code in (404, 405)
    assert client.patch(f"/atenciones/{at}/notas/{n1['id']}", json=nota(), headers=medico).status_code in (404, 405)
    # corrección sin motivo -> 422
    assert client.post(f"/atenciones/{at}/notas", headers=medico, json=nota(reemplaza_id=n1["id"])).status_code == 422
    r = client.post(f"/atenciones/{at}/notas", headers=medico,
                    json=nota(plan="Paracetamol 500 mg c/8h", reemplaza_id=n1["id"], motivo_correccion="Se omitió la dosis"))
    assert r.status_code == 201, r.text
    n2 = r.json()
    assert n2["reemplaza_id"] == n1["id"] and n2["id"] != n1["id"] and n2["hash_contenido"] != n1["hash_contenido"]
    # solo hay una versión vigente; el original sigue en el historial
    vig = client.get(f"/expediente/{paciente['dui']}/notas", headers=medico).json()
    assert vig["devueltos"] == 1 and vig["items"][0]["id"] == n2["id"] and "500 mg" in vig["items"][0]["datos"]["plan"]
    hist = client.get(f"/expediente/{paciente['dui']}/notas", params={"historial": True}, headers=medico).json()
    assert {i["id"] for i in hist["items"]} == {n1["id"], n2["id"]}
    # no se puede bifurcar la cadena: corregir dos veces la misma versión
    r = client.post(f"/atenciones/{at}/notas", headers=medico,
                    json=nota(reemplaza_id=n1["id"], motivo_correccion="otra corrección"))
    assert r.status_code == 409
    # auditoría de la creación y de la corrección
    assert "REGISTRO_CLINICO" in acciones_auditoria(n2["id"])
    # la base de datos rechaza UPDATE/DELETE aunque se salte la API
    for q in ("UPDATE nota_soap SET plan = 'alterado' WHERE id = :i", "DELETE FROM nota_soap WHERE id = :i"):
        with pytest.raises(DBAPIError, match="inmutable"):
            with SessionLocal() as db:
                db.execute(text(q), {"i": n1["id"]})
                db.commit()


def test_nivel4_cifrado_y_justificacion(client, medico, paciente):
    at = abrir(client, medico, paciente["dui"])
    secreto = "Paciente refiere ideacion suicida pasiva"
    n = client.post(f"/atenciones/{at}/notas", headers=medico, json=nota(subjetivo=secreto, confidencial=True)).json()
    assert n["nivel_sensibilidad"] == 4 and n["cifrado"] is True
    fila = sql("SELECT subjetivo, objetivo, contenido_cifrado FROM nota_soap WHERE id = :i", i=n["id"])[0]
    assert fila[0] is None and fila[1] is None and fila[2] and secreto not in fila[2]
    # VIH por CIE-10: nivel 4 automático
    d = client.post(f"/atenciones/{at}/diagnosticos", headers=medico,
                    json={"codigo_cie10": "B20", "descripcion": "Enfermedad por VIH", "tipo": "DEFINITIVO"}).json()
    assert d["nivel_sensibilidad"] == 4
    # lectura sin justificación -> stub restringido; con justificación -> contenido
    r = client.get(f"/expediente/{paciente['dui']}/notas", headers=medico).json()
    assert secreto not in json.dumps(r)
    r = client.get(f"/expediente/{paciente['dui']}/notas", params={"justificacion": "Valoración de riesgo en consulta"}, headers=medico)
    assert r.status_code == 200 and secreto in json.dumps(r.json())
    assert "ACCESO_EXPEDIENTE" in [a for a in acciones_auditoria(paciente_id(paciente["dui"]))]


def paciente_id(dui):
    return str(sql("SELECT id FROM persona WHERE dui = :d", d=dui)[0][0])


def ml(client, dui, **extra):
    body = {"dui": dui, "fecha_nacimiento": NAC, "fecha_hora_deceso": "2026-10-01T03:30:00-06:00",
            "causa_oficial": "Infarto agudo de miocardio", "causa_cie10": "I21.9", "entidad_certificadora": "Instituto de Medicina Legal",
            "numero_certificado": f"IML-{dui}", "token_verificacion": "tok-123"} | extra
    raw = json.dumps(body).encode()
    ts = str(int(time.time()))
    h = {"X-ML-Timestamp": ts, "X-ML-Firma": firma_ml(settings.medicina_legal_secret, ts, raw), "Content-Type": "application/json"}
    return client.post("/integraciones/medicina-legal/defunciones", content=raw, headers=h), body


def test_fallecimiento_congela_dui_y_guarda_causa(client, medico, paciente, omega_headers):
    dui = paciente["dui"]
    at = abrir(client, medico, dui)
    # firma inválida y homónimo
    raw = b"{}"
    assert client.post("/integraciones/medicina-legal/defunciones", content=raw,
                       headers={"X-ML-Timestamp": str(int(time.time())), "X-ML-Firma": "0" * 64}).status_code == 401
    r, _ = ml(client, dui, fecha_nacimiento="1980-01-01")
    assert r.status_code == 409
    assert sql("SELECT activo FROM persona WHERE dui = :d", d=dui)[0][0] is True
    # registro válido
    r, body = ml(client, dui)
    assert r.status_code == 200, r.text
    assert "causa" in json.dumps(r.json()).lower() or r.json()
    fila = sql("SELECT causa_oficial, causa_cie10, vigente, via, entidad_certificadora FROM defuncion WHERE persona_id = :p", p=paciente_id(dui))
    assert fila == [("Infarto agudo de miocardio", "I21.9", True, "MEDICINA_LEGAL", "Instituto de Medicina Legal")]
    # DUI congelado: cuenta inactiva, atención abierta cerrada por fallecimiento
    assert sql("SELECT activo FROM persona WHERE dui = :d", d=dui)[0][0] is False
    assert sql("SELECT estado, cierre_tipo FROM atencion WHERE id = :i", i=at) == [("CERRADA", "FALLECIMIENTO")]
    # no se puede escribir ni abrir atenciones (hook usado por recetas y citas)
    assert client.post("/atenciones", headers=medico, json={"dui": dui, "tipo_atencion": "AMBULATORIA", "area": "Medicina General",
                                                            "motivo_consulta": "Control"}).status_code == 423
    assert client.post(f"/atenciones/{at}/notas", headers=medico, json=nota()).status_code in (409, 423)
    with SessionLocal() as db:
        from fastapi import HTTPException
        from core_expediente.service import asegurar_no_congelado
        with pytest.raises(HTTPException) as e:
            asegurar_no_congelado(db, paciente_id(dui) and __import__("uuid").UUID(paciente_id(dui)))
        assert e.value.status_code == 423
    # el expediente sigue siendo legible por consentimiento/atención y muestra el estado vital
    assert client.get(f"/expediente/{dui}", headers=medico).status_code in (200, 403)
    # idempotente: mismo certificado y mismo contenido
    r2, _ = ml(client, dui)
    assert r2.status_code in (200, 409)
    assert sql("SELECT count(*) FROM defuncion WHERE persona_id = :p", p=paciente_id(dui))[0][0] == 1
    acc = acciones_auditoria(paciente_id(dui))
    assert any(a.startswith("DEFUNCION") or "FALLEC" in a or "ESTADO_VITAL" in a for a in acc), acc
    # la defunción no se puede borrar ni alterar desde SQL
    with pytest.raises(DBAPIError, match="defuncion"):
        with SessionLocal() as db:
            db.execute(text("DELETE FROM defuncion WHERE persona_id = :p"), {"p": paciente_id(dui)})
            db.commit()
    # solo Omega revierte (falso positivo)
    assert client.post(f"/omega/estado-vital/{dui}/revertir", headers=medico, json={"motivo": "intento no autorizado"}).status_code in (401, 403)
    r = client.post(f"/omega/estado-vital/{dui}/revertir", headers=omega_headers, json={"motivo": "Homónimo confirmado por Medicina Legal"})
    assert r.status_code == 200, r.text
    assert sql("SELECT activo FROM persona WHERE dui = :d", d=dui)[0][0] is True


def test_cadena_de_auditoria_integra(client, omega_headers):
    r = client.get("/auditoria/verificar", headers=omega_headers)
    assert r.status_code == 200 and r.json()["integra"] is True
