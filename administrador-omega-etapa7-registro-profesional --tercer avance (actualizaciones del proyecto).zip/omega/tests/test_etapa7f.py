"""Etapa 7 · parte 2d-3: /ciudadano/expediente · resumen, atenciones, laboratorio, imagen y seguimiento.
Humo (cada vista con datos reales de punta a punta) y permisos: el sujeto sale siempre de la sesión, todo es de solo lectura y ni el nivel 4 cerrado
ni las notas SOAP llegan al navegador. Lo que el backend no tiene (interconsultas, enlace a la imagen) debe verse como «Sin información»."""
import re
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import pytest

from web.ciudadano.router import PESTANAS as PESTANAS_WEB
from web.comun.portales import CIUDADANO

from .conftest import datos_persona
from .test_etapa2 import NAC, abrir, medico, nota, paciente_id, sql  # noqa: F401
from .test_etapa2b import EGRESO, trans
from .test_etapa2c import SECRETO

# El código CIE-10 del VIH como palabra completa: un folio hexadecimal al azar (p. ej. OL-612B20E05C) lo contiene por casualidad.
CODIGO_B20 = re.compile(r"(?<![A-Za-z0-9])B20(?![A-Za-z0-9])")
from .test_etapa3a import canje, emitir, farmacia, firmado  # noqa: F401
from .test_etapa3c import RX, hb, lab, orden, subir  # noqa: F401
from .test_etapa4a import desbloquear, pac, pac_h, vacuna  # noqa: F401
from .test_etapa4b import agenda, reservar  # noqa: F401
from .test_etapa7a import entrar_persona, nuevo, web  # noqa: F401  (web es un fixture)
from .test_etapa7d import _diag
from .test_etapa7e import _desafio, _verificar

EXP = "/ciudadano/expediente"
HX = {"HX-Request": "true"}
NUEVAS = ("resumen", "atenciones", "laboratorio", "imagen", "seguimiento")
TODAS = NUEVAS + ("diagnosticos", "recetas", "resultados", "vacunas", "medicamentos")
SV = ZoneInfo("America/El_Salvador")
SOAP_SUBJETIVO, SOAP_PLAN = "SOAP-SUBJETIVO-PRIVADO-7F", "SOAP-PLAN-PRIVADO-7F"


def _entrar(web, persona):
    assert entrar_persona(web, CIUDADANO, persona["dui"], persona["password"]).status_code == 303
    return web


def _textos(web, extra_headers=None, params=None) -> str:
    """Todo lo que el navegador recibe de las nueve pestañas: página completa y fragmento HTMX de cada una."""
    t = []
    for p in TODAS:
        for cab in ({}, HX):
            r = web.get(f"{EXP}?seccion={p}" if not cab else f"{EXP}/{p}", params=params, headers=(extra_headers or {}) | cab)
            assert r.status_code == 200, (p, cab, r.status_code)
            t.append(r.text)
    return "\n".join(t)


@pytest.fixture
def historia(client, medico, firmado, farmacia, lab, agenda, pac, pac_h):  # noqa: F811
    """Un expediente completo de `pac`: alergia, cirugía, transfusión, diagnósticos (uno de nivel 4), notas SOAP (una de nivel 4), 2 laboratorios (el último crítico), una imagen,
    una vacuna con próxima dosis, una receta despachada, una cita futura y un alta con control programado."""
    lab_h, lab_id = lab
    dui = pac["dui"]
    at = abrir(client, medico, dui)

    def registrar(ruta, cuerpo):
        r = client.post(f"/atenciones/{at}/{ruta}", headers=medico, json=cuerpo)
        assert r.status_code == 201, r.text

    registrar("alergias", {"sustancia": "latex", "severidad": "GRAVE", "reaccion": "Urticaria generalizada"})  # (no penicilina: bloquearía el despacho de amoxicilina)
    registrar("antecedentes", {"tipo": "QUIRURGICO", "descripcion": "Apendicectomía abierta"})
    registrar("antecedentes", {"tipo": "TRANSFUSIONAL", "descripcion": "Transfusión de dos unidades de glóbulos rojos"})
    registrar("diagnosticos", {"codigo_cie10": "I10", "descripcion": "Hipertensión esencial", "tipo": "DEFINITIVO", "principal": True})
    registrar("diagnosticos", {"codigo_cie10": "B20", "descripcion": "Enfermedad por VIH", "tipo": "DEFINITIVO"})  # nivel 4
    registrar("notas", nota(subjetivo=SOAP_SUBJETIVO, plan=SOAP_PLAN))
    registrar("notas", nota(subjetivo=SECRETO, confidencial=True))  # nivel 4
    for valor in (14, 6.5):  # el segundo es crítico (critico_min = 7)
        assert subir(client, lab_h, orden(client, medico, dui, lab_id).json()["folio"], [hb(valor)]).status_code == 201
    img = orden(client, medico, dui, lab_id, tipo="IMAGENOLOGIA", estudios=[RX]).json()
    assert subir(client, lab_h, img["folio"], [{"estudio": 1, "parametro": "Conclusión", "valor_texto": "Sin hallazgos agudos", "bandera": "NORMAL"}]).status_code == 201
    assert client.post("/vacunas", headers=medico, json=vacuna(dui)).status_code == 201
    rx = emitir(client, firmado, dui)
    assert rx.status_code == 201, rx.text
    d = client.post("/farmacia/recetas/despachar", json=canje(rx.json(), responsable="Lic. Pérez"), headers=farmacia)
    assert d.status_code in (200, 201), d.text
    assert reservar(client, pac_h, agenda, "08:30", motivo="Control de presión").status_code == 201
    control = (datetime.now(timezone.utc) + timedelta(days=10)).replace(microsecond=0)
    assert trans(client, medico, at, 4).status_code == 200
    r = trans(client, medico, at, 5, egreso=EGRESO | {"proximo_control_en": control.isoformat()})
    assert r.status_code == 200, r.text
    return {"at": at, "token_receta": rx.json()["token"], "folio_imagen": img["folio"], "control": control.astimezone(SV).strftime("%d/%m/%Y - %H:%M"),
            "cita": date.fromisoformat(agenda["fecha"]).strftime("%d/%m/%Y") + " - 08:30", "vacuna": (date.today() + timedelta(days=365)).strftime("%d/%m/%Y") + " - sin hora"}


# ------------------------------------------------------------------ Sin sesión y estructura
def test_las_nuevas_pestanas_existen_y_sin_sesion_van_al_login(web):
    assert set(TODAS) == set(PESTANAS_WEB)  # si se agrega una pestaña, estas pruebas deben cubrirla
    for p in NUEVAS:
        r = web.get(f"{EXP}?seccion={p}")
        assert r.status_code == 303 and r.headers["location"].startswith("/ciudadano/ingresar"), p
        r = web.get(f"{EXP}/{p}", headers=HX)
        assert r.status_code == 401 and r.headers["hx-redirect"].startswith("/ciudadano/ingresar"), p


def test_vistas_nuevas_sin_datos_dicen_sin_informacion_y_validan_la_pagina(web, pac):  # noqa: F811
    _entrar(web, pac)
    for p in NUEVAS:
        r = web.get(f"{EXP}/{p}", headers=HX)
        assert r.status_code == 200 and "<html" not in r.text, p
        assert web.get(f"{EXP}/{p}?pagina=0", headers=HX).status_code == 422, p
        assert web.get(f"{EXP}/{p}?pagina=abc", headers=HX).status_code == 422, p
        sin = web.get(f"{EXP}/{p}")  # sin HTMX: redirige a la página completa (respaldo sin JavaScript)
        assert sin.status_code == 303 and sin.headers["location"] == f"{EXP}?seccion={p}&pagina=1", p
        assert web.get(f"{EXP}?seccion={p}").status_code == 200, p
    for p in ("laboratorio", "imagen", "seguimiento"):
        assert "Sin información" in web.get(f"{EXP}/{p}", headers=HX).text, p
    assert web.get(f"{EXP}/resumen", headers=HX).text.count("Sin información") >= 5  # enfermedades, medicamentos, alergias, cirugías y transfusiones
    assert "Aún no hay atenciones" in web.get(f"{EXP}/atenciones", headers=HX).text


# ------------------------------------------------------------------ Humo con datos reales
def test_humo_resumen_y_atenciones(web, historia, pac):  # noqa: F811
    _entrar(web, pac)
    pagina = web.get(f"{EXP}?seccion=resumen")
    assert pagina.status_code == 200 and re.search(r'<a [^>]*aria-current="page"[^>]*>Resumen</a>', pagina.text, re.S)
    r = web.get(f"{EXP}/resumen", headers=HX).text
    for esperado in ("Enfermedades activas", "Hipertensión esencial", "I10", "Detectada el", "Medicamentos en uso", "Amoxicilina", "en tratamiento hasta el",
                     "Alergias", "Latex", "Grave", "Urticaria generalizada", "Apendicectomía abierta", "Transfusión de dos unidades", "Registrada el"):
        assert esperado in r, esperado
    assert "VIH" not in r and not CODIGO_B20.search(r) and "protegido" in r  # el diagnóstico de nivel 4 solo se cuenta, no se muestra

    a = web.get(f"{EXP}/atenciones", headers=HX).text
    for esperado in ("Ambulatoria", "Medicina General", "Hipertensión esencial", "I10", "Alta médica", "Profesional responsable", "Diagnóstico principal", "Fecha y hora"):
        assert esperado in a, esperado
    assert re.search(r"de \d{4}, \d{1,2}:\d{2} [ap]\. m\.", a)  # fecha y hora legibles, no ISO
    assert "Interconsultas" in a and "Sin información" in a  # el backend no tiene interconsultas: se dice, no se inventa


def test_humo_laboratorio_imagen_y_tendencia(web, historia, pac):  # noqa: F811
    _entrar(web, pac)
    lb = web.get(f"{EXP}/laboratorio", headers=HX).text
    for esperado in ("Hemoglobina", "6.5 g/dL", "12 – 16", "Crítico (bajo)", "Valor crítico: consulte a su médico", "Tendencia de 2 resultados", "tend-alerta", "tend-ref"):
        assert esperado in lb, esperado
    svg = re.search(r"<svg.*?</svg>", lb, re.S)
    assert svg and "<polyline" in svg.group(0)  # tendencia propia, sin librerías
    assert 'style="' not in svg.group(0) and "<script" not in svg.group(0) and "http" not in svg.group(0)  # compatible con la CSP del portal
    assert "<script" not in lb
    im = web.get(f"{EXP}/imagen", headers=HX).text
    assert historia["folio_imagen"] in im and "Sin hallazgos agudos" in im
    assert "Enlace a la imagen" in im and "Sin información" in im  # no existe enlace/visor en el backend


def test_humo_seguimiento_en_orden_con_fecha_y_hora(web, historia, pac):  # noqa: F811
    _entrar(web, pac)
    t = web.get(f"{EXP}/seguimiento", headers=HX).text
    for esperado in ("Cita", "Control", "Vacuna pendiente", "Tratamiento continuo", "Control de presión", "Influenza · dosis 2", "fin del tratamiento", "Medicina General"):
        assert esperado in t, esperado
    assert historia["cita"] in t and historia["control"] in t and historia["vacuna"] in t  # DD/MM/AAAA - HH:MM (la vacuna solo tiene fecha)
    assert t.index(historia["cita"]) < t.index("fin del tratamiento") < t.index(historia["control"]) < t.index(historia["vacuna"])  # de lo más próximo a lo más lejano
    assert "Sin información de:" not in t  # las cuatro categorías tienen datos
    assert t.count("Sin información") >= 1  # área/institución de la vacuna no existen en el backend
    p = pac["dui"]
    for seccion in ("atenciones", "seguimiento"):
        web.get(f"{EXP}/{seccion}", headers=HX)
        n = sql("SELECT count(*) FROM auditoria WHERE accion = 'PORTAL_LECTURA_PROPIA' AND actor_id = :p AND detalle->>'seccion' = :s", p=paciente_id(p), s=seccion)[0][0]
        assert n >= 1, seccion  # cada lectura queda en la bitácora


# ------------------------------------------------------------------ Permisos
def test_el_sujeto_sale_de_la_sesion_en_las_vistas_nuevas(web, client, medico, historia, pac, pac_h, codigos_2fa):  # noqa: F811
    a, b = pac, datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=b).status_code == 201
    _diag(client, medico, abrir(client, medico, b["dui"]), "K29.7", "Gastritis de la persona B")
    id_a, id_b = paciente_id(a["dui"]), paciente_id(b["dui"])
    token_a = desbloquear(client, pac_h, codigos_2fa)  # un desbloqueo válido de A tampoco abre nada en la web de B
    ajeno = ("Hipertensión", "Hemoglobina", "Apendicectomía", "Influenza", "Amoxicilina", "Control de presión", "Latex", "Sin hallazgos", historia["folio_imagen"], a["dui"], id_a)
    manipulados = {"dui": a["dui"], "paciente_id": id_a, "persona_id": id_a, "id": id_a, "sujeto": id_a, "historial": "true", "justificacion": "quiero ver lo de A"}

    nav_b = _entrar(web, b)
    for params in ({}, manipulados):
        todo = _textos(nav_b, {"X-Desbloqueo-N4": token_a}, params)
        for dato in ajeno:
            assert dato not in todo, (dato, params)
    assert "Gastritis de la persona B" in nav_b.get(f"{EXP}/resumen", params=manipulados, headers=HX).text  # siempre el expediente de la sesión
    assert "Gastritis de la persona B" in nav_b.get(f"{EXP}/atenciones", params=manipulados, headers=HX).text
    for p in ("laboratorio", "imagen", "seguimiento"):
        assert "Sin información" in nav_b.get(f"{EXP}/{p}", params=manipulados, headers=HX).text, p
    for p in NUEVAS:  # el id o el DUI de otra persona no es una ruta: no existen rutas por id
        for ruta in (f"{EXP}/{p}/{id_a}", f"{EXP}/{id_a}/{p}", f"{EXP}/{p}/{a['dui']}"):
            assert nav_b.get(ruta, headers=HX).status_code == 404, ruta
    nav_a = _entrar(nuevo(50079), a)  # y A ve lo suyo, nada de B
    assert "Hemoglobina" in nav_a.get(f"{EXP}/laboratorio", params={"dui": b["dui"], "persona_id": id_b}, headers=HX).text
    assert "Gastritis" not in _textos(nav_a, params={"dui": b["dui"], "persona_id": id_b})


def test_las_vistas_nuevas_son_de_solo_lectura(web, client, historia, pac):  # noqa: F811
    pid = paciente_id(pac["dui"])
    q = ("SELECT (SELECT count(*) FROM cita WHERE paciente_id = :p) + (SELECT count(*) FROM vacuna WHERE paciente_id = :p) + (SELECT count(*) FROM atencion WHERE paciente_id = :p)"
         " + (SELECT count(*) FROM alergia WHERE paciente_id = :p) + (SELECT count(*) FROM diagnostico WHERE paciente_id = :p) + (SELECT count(*) FROM resultado_lab WHERE paciente_id = :p)"
         " + (SELECT count(*) FROM egreso WHERE paciente_id = :p) + (SELECT count(*) FROM receta WHERE paciente_id = :p)")
    antes = sql(q, p=pid)[0][0]
    nav = _entrar(web, pac)
    for p in NUEVAS:
        for metodo in ("post", "put", "patch", "delete"):
            assert getattr(nav, metodo)(f"{EXP}/{p}").status_code in (403, 405), (p, metodo)
            assert getattr(nav, metodo)(f"{EXP}?seccion={p}").status_code in (403, 405), (p, metodo)
    for p in NUEVAS:
        nav.get(f"{EXP}/{p}", headers=HX)
    assert sql(q, p=pid)[0][0] == antes


def test_nivel4_y_notas_soap_no_se_exponen(web, client, historia, pac, pac_h, codigos_2fa):  # noqa: F811
    prohibido = (SECRETO, SOAP_SUBJETIVO, SOAP_PLAN, "Control general", "Dolor de cabeza", "Cefalea tensional", historia["token_receta"])  # SOAP completo, motivo de consulta y token de canje
    nivel4 = ("VIH",)  # y el código B20 como palabra completa, más abajo
    nav = _entrar(web, pac)
    cerrado = _textos(nav)
    for dato in prohibido + nivel4:
        assert dato not in cerrado, dato
    assert not CODIGO_B20.search(cerrado)
    assert "registro protegido" in nav.get(f"{EXP}/resumen", headers=HX).text
    token = desbloquear(client, pac_h, codigos_2fa)  # el token de la API en la cabecera no abre nada en la web
    con_token = _textos(nav, {"X-Desbloqueo-N4": token}, {"justificacion": "necesito verlo todo", "historial": "true"})
    for dato in prohibido + nivel4:
        assert dato not in con_token, dato
    assert not CODIGO_B20.search(con_token)

    did = _desafio(nav, volver="resumen")  # …pero el desbloqueo 2FA de la propia sesión sí abre SU diagnóstico de nivel 4
    ok = _verificar(nav, did, codigos_2fa[-1], volver="resumen")
    assert ok.status_code == 303 and ok.headers["location"] == f"{EXP}?seccion=resumen"
    abierto = nav.get(f"{EXP}?seccion=resumen")
    assert "Enfermedad por VIH" in abierto.text and "abiertos hasta" in abierto.text
    for dato in prohibido:  # y aun abierto, las notas SOAP, el motivo de consulta y el token de la receta jamás se muestran
        assert dato not in _textos(nav), dato
