import json
import re
import threading
import uuid

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import event, text
from sqlalchemy.exc import IntegrityError

from laboratorio.schemas import ValorIn
from laboratorio.service import calcular_bandera
from main import app
from omega_core.database import SessionLocal, engine
from omega_core.security.campos import descifrar_json

from .conftest import datos_persona, dui_nuevo, nit_nuevo
from .test_etapa2 import NAC, abrir, acciones_auditoria, auth, medico, ml, nota, paciente_id, sql  # noqa: F401
from .test_etapa3a import farmacia  # noqa: F401  (farmacia semilla autenticada)


def registrar_lab(client, omega_headers, codigos_2fa) -> tuple[dict, str]:
    nit, clave = nit_nuevo(), "LabClave12345"
    d = {"tipo": "LABORATORIO", "nombre_legal": "Laboratorio Clínico de Prueba", "nit": nit, "codigo_minsal": f"LAB-{uuid.uuid4().hex[:8]}", "departamento": "San Miguel",
         "municipio": "San Miguel", "direccion": "San Miguel", "telefono": "2600-0000", "correo": f"{uuid.uuid4().hex[:8]}@lab.sv", "responsable_nombre": "Lic. Química",
         "responsable_dui": dui_nuevo(), "responsable_junta": "JVQF-777", "documento_permiso_ref": "up://permiso.pdf", "password": clave}
    r = client.post("/instituciones", json=d)
    assert r.status_code == 201, r.text
    lab_id = r.json()["id"]
    assert client.patch(f"/omega/instituciones/{lab_id}/estado", json={"estado": "ACTIVA", "motivo": "Documentos verificados"}, headers=omega_headers).status_code == 200
    r = client.post("/auth/login/institucion", json={"identificador": nit, "password": clave})
    assert r.status_code == 200 and r.json()["requiere_2fa"] is True, r.text
    r = client.post("/auth/2fa/verificar", json={"desafio_id": r.json()["desafio_id"], "codigo": codigos_2fa[-1]})
    assert r.status_code == 200, r.text
    return auth(r.json()["tokens"]["access_token"]), lab_id


@pytest.fixture
def lab(client, omega_headers, codigos_2fa):
    return registrar_lab(client, omega_headers, codigos_2fa)


@pytest.fixture
def pac(client):
    d = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=d).status_code == 201
    return d


HEMO = {"nombre": "Hemograma completo", "codigo": "HEM-01"}
RX = {"nombre": "Radiografía de tórax PA", "modalidad": "RX"}


def orden(client, medico, dui, lab_id, tipo="LABORATORIO", estudios=(HEMO,), **kw):
    return client.post("/laboratorio/ordenes", headers=medico, json={"dui": dui, "tipo": tipo, "laboratorio_id": lab_id, "estudios": list(estudios)} | kw)


def hb(valor, **kw):
    return {"estudio": 1, "parametro": "Hemoglobina", "valor_numerico": valor, "unidad": "g/dL", "ref_min": 12, "ref_max": 16, "critico_min": 7, "critico_max": 20} | kw


def subir(client, lab_h, folio, valores, **kw):
    return client.post(f"/laboratorio/ordenes/{folio}/resultados", headers=lab_h, json={"responsable": "Lic. Pérez", "valores": valores} | kw)


def estado(folio):
    return sql("SELECT estado FROM orden_lab WHERE folio = :f", f=folio)[0][0]


@pytest.mark.parametrize("v,esperada,critico", [
    (14, "NORMAL", False), (10, "BAJO", False), (18, "ALTO", False), (6.9, "CRITICO_BAJO", True), (20.5, "CRITICO_ALTO", True), (7, "BAJO", False), (12, "NORMAL", False)])
def test_banderas_numericas_las_calcula_el_servidor(v, esperada, critico):
    assert calcular_bandera(ValorIn(**hb(v))) == (esperada, critico)


def test_banderas_de_texto_y_validaciones_de_valor():
    assert calcular_bandera(ValorIn(estudio=1, parametro="Hallazgos", valor_texto="Neumotórax a tensión", bandera="CRITICO")) == ("CRITICO", True)
    assert calcular_bandera(ValorIn(estudio=1, parametro="Hallazgos", valor_texto="Sin alteraciones")) == ("NORMAL", False)
    for malo in (hb(10) | {"valor_texto": "x"}, {"estudio": 1, "parametro": "p"}, hb(10) | {"bandera": "NORMAL"}, hb(10, critico_min=15),
                 {"estudio": 1, "parametro": "p", "valor_texto": "x", "ref_min": 1}):
        with pytest.raises(ValueError):
            ValorIn(**malo)


def test_creacion_de_ordenes_y_reglas(client, medico, pac, lab):
    lab_h, lab_id = lab
    dui = pac["dui"]
    assert orden(client, medico, dui, lab_id).status_code == 403  # sin atención abierta
    abrir(client, medico, dui, fase3=False)
    assert orden(client, medico, dui, lab_id).status_code == 409  # fase 1
    d2 = datos_persona()
    client.post("/personas", json=d2)
    abrir(client, medico, d2["dui"])
    assert orden(client, medico, d2["dui"], str(uuid.uuid4())).status_code == 404  # destino inexistente
    assert orden(client, medico, d2["dui"], lab_id, tipo="IMAGENOLOGIA").status_code == 422  # imagen sin modalidad
    assert orden(client, medico, d2["dui"], lab_id, estudios=[RX]).status_code == 422  # laboratorio con modalidad
    assert orden(client, medico, d2["dui"], lab_id, estudios=[]).status_code == 422
    assert orden(client, medico, d2["dui"], lab_id, tipo="OTRO").status_code == 422
    # un hospital o farmacia no es un destino válido
    hosp = sql("SELECT id FROM institucion WHERE tipo = 'HOSPITAL' LIMIT 1")[0][0]
    assert orden(client, medico, d2["dui"], str(hosp)).status_code == 404
    r = orden(client, medico, d2["dui"], lab_id, estudios=[HEMO, {"nombre": "Glucosa en ayunas"}], prioridad="URGENTE")
    assert r.status_code == 201, r.text
    o = r.json()
    assert o["folio"].startswith("OL-") and o["estado"] == "PENDIENTE" and o["nivel_sensibilidad"] == 2 and [e["n"] for e in o["estudios"]] == [1, 2]
    assert o["laboratorio"]["id"] == lab_id
    assert [x["folio"] for x in client.get("/laboratorio/ordenes", headers=medico, params={"estado": "PENDIENTE"}).json()][0] == o["folio"]
    dirs = client.get("/laboratorio/directorio", headers=medico).json()
    assert lab_id in [x["id"] for x in dirs] or len(dirs) == 200  # el directorio se corta en 200: con una base de pruebas muy usada el laboratorio nuevo puede quedar fuera
    oid = str(sql("SELECT id FROM orden_lab WHERE folio = :f", f=o["folio"])[0][0])
    assert "ORDEN_LAB_CREADA" in acciones_auditoria(oid)
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'ORDEN_LAB_DENEGADA' AND detalle->>'paciente_id' = :p", p=paciente_id(dui))[0][0] >= 1
    # imagenología
    r = orden(client, medico, d2["dui"], lab_id, tipo="IMAGENOLOGIA", estudios=[RX])
    assert r.status_code == 201 and r.json()["estudios"][0]["modalidad"] == "RX"
    # la orden es inmutable en la base
    for q in ("UPDATE orden_lab SET laboratorio_id = (SELECT id FROM institucion LIMIT 1) WHERE folio = :f", "DELETE FROM orden_lab WHERE folio = :f",
              "UPDATE orden_lab SET estado = 'PENDIENTE' WHERE folio = :f AND estado = 'PENDIENTE' AND folio <> folio"):
        if "folio <> folio" in q:
            continue
        with pytest.raises(Exception, match="inmutable|no se eliminan"):
            with SessionLocal() as db:
                db.execute(text(q), {"f": o["folio"]})
                db.commit()


def test_flujo_resultados_inyeccion_alerta_y_completar_una_vez(client, medico, pac, lab, omega_headers, codigos_2fa):
    lab_h, lab_id = lab
    otro_lab, _ = registrar_lab(client, omega_headers, codigos_2fa)
    dui = pac["dui"]
    at = abrir(client, medico, dui)
    o = orden(client, medico, dui, lab_id, estudios=[HEMO, {"nombre": "Glucosa"}]).json()
    # el laboratorio destino la ve; otro laboratorio y un DUI inexistente reciben lista vacía (no se puede sondear)
    p = client.get(f"/laboratorio/pendientes/{dui}", headers=lab_h)
    assert p.status_code == 200 and [x["folio"] for x in p.json()] == [o["folio"]]
    assert p.json()[0]["paciente"]["dui"] == dui and p.json()[0]["paciente"]["edad_anios"] >= 30
    assert client.get(f"/laboratorio/pendientes/{dui}", headers=otro_lab).json() == []
    assert client.get(f"/laboratorio/pendientes/{dui_nuevo()}", headers=lab_h).json() == []
    # resultado incompleto / estudio inexistente / orden ajena
    assert subir(client, lab_h, o["folio"], [hb(14)]).status_code == 409
    assert subir(client, lab_h, o["folio"], [hb(14), {"estudio": 9, "parametro": "x", "valor_texto": "y"}]).status_code == 422
    assert subir(client, otro_lab, o["folio"], [hb(14)]).status_code == 404
    assert estado(o["folio"]) == "PENDIENTE"
    # resultado con un valor crítico
    glu = {"estudio": 2, "parametro": "Glucosa", "valor_numerico": 28, "unidad": "mg/dL", "ref_min": 70, "ref_max": 100, "critico_min": 40, "critico_max": 500}
    r = subir(client, lab_h, o["folio"], [hb(13.5), glu], observaciones="Muestra hemolizada leve")
    assert r.status_code == 201, r.text
    res = r.json()
    assert res["hay_critico"] is True and res["alerta_critica_generada"] is True
    assert [(v["parametro"], v["bandera"], v["critico"]) for v in res["valores"]] == [("Hemoglobina", "NORMAL", False), ("Glucosa", "CRITICO_BAJO", True)]
    assert estado(o["folio"]) == "COMPLETADA"
    # ya no figura como pendiente y no se completa dos veces
    assert client.get(f"/laboratorio/pendientes/{dui}", headers=lab_h).json() == []
    r2 = subir(client, lab_h, o["folio"], [hb(13.5), glu])
    assert r2.status_code == 409 and "ORDEN_YA_COMPLETADA" in r2.json()["detail"]["motivos"]
    assert sql("SELECT count(*) FROM resultado_lab WHERE orden_folio = :f", f=o["folio"]) == [(1,)]
    # inyectado al expediente (sección y resumen), visible al médico con atención activa y al propio paciente
    sec = client.get(f"/expediente/{dui}/resultados", headers=medico)
    assert sec.status_code == 200 and sec.json()["devueltos"] == 1
    datos = sec.json()["items"][0]["datos"]
    assert datos["orden_folio"] == o["folio"] and datos["hay_critico"] is True and datos["valores"][1]["bandera"] == "CRITICO_BAJO"
    assert datos["observaciones"] == "Muestra hemolizada leve"
    assert client.get(f"/expediente/{dui}", headers=medico).json()["resultados"]["devueltos"] == 1
    tk = client.post("/auth/login/persona", json={"dui": dui, "password": pac["password"]}).json()["tokens"]["access_token"]
    assert client.get("/mi-expediente/resultados", headers=auth(tk)).json()["devueltos"] == 1
    # alerta visible solo para el médico que pidió la orden
    al = client.get("/laboratorio/alertas-criticas", headers=medico).json()
    mia = [a for a in al if a["orden_folio"] == o["folio"]]
    assert len(mia) == 1 and mia[0]["estado"] == "PENDIENTE" and mia[0]["restringido"] is False
    assert mia[0]["valores_criticos"][0]["parametro"] == "Glucosa" and mia[0]["paciente_dui"] == dui and mia[0]["n_criticos"] == 1
    assert client.get("/laboratorio/alertas-criticas", headers=auth(tk)).status_code in (401, 403)  # un civil no
    assert client.get("/laboratorio/alertas-criticas", headers=lab_h).status_code in (401, 403)  # ni el laboratorio
    rec = client.post(f"/laboratorio/alertas-criticas/{mia[0]['id']}/reconocer", headers=medico, json={"comentario": "Se indicó dextrosa IV"})
    assert rec.status_code == 200 and rec.json()["estado"] == "RECONOCIDA"
    assert o["folio"] not in [a["orden_folio"] for a in client.get("/laboratorio/alertas-criticas", headers=medico).json()]
    # bitácora
    rid = str(sql("SELECT id FROM resultado_lab WHERE orden_folio = :f", f=o["folio"])[0][0])
    assert "RESULTADO_LAB_SUBIDO" in acciones_auditoria(rid) and "ALERTA_CRITICA_GENERADA" in acciones_auditoria(mia[0]["id"])
    assert "ALERTA_CRITICA_RECONOCIDA" in acciones_auditoria(mia[0]["id"])
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'RESULTADO_LAB_RECHAZADO' AND detalle->>'folio' = :f", f=o["folio"])[0][0] == 1
    # resultados y alertas son inmutables en la base
    for q in ("UPDATE resultado_lab SET hay_critico = false WHERE orden_folio = :f", "DELETE FROM resultado_lab WHERE orden_folio = :f",
              "DELETE FROM alerta_critica WHERE orden_folio = :f", "UPDATE alerta_critica SET n_criticos = 0 WHERE orden_folio = :f"):
        with pytest.raises(Exception, match="inmutable|no se eliminan"):
            with SessionLocal() as db:
                db.execute(text(q), {"f": o["folio"]})
                db.commit()


def test_imagenologia_con_hallazgo_critico_y_sin_critico(client, medico, pac, lab):
    lab_h, lab_id = lab
    dui = pac["dui"]
    abrir(client, medico, dui)
    o = orden(client, medico, dui, lab_id, tipo="IMAGENOLOGIA", estudios=[RX], prioridad="URGENTE").json()
    r = subir(client, lab_h, o["folio"], [{"estudio": 1, "parametro": "Conclusión", "valor_texto": "Neumotórax a tensión derecho", "bandera": "CRITICO"}])
    assert r.status_code == 201 and r.json()["hay_critico"] and r.json()["valores"][0]["bandera"] == "CRITICO"
    o2 = orden(client, medico, dui, lab_id, estudios=[HEMO]).json()
    r = subir(client, lab_h, o2["folio"], [hb(14)])
    assert r.status_code == 201 and r.json()["hay_critico"] is False and r.json()["alerta_critica_generada"] is False
    assert sql("SELECT count(*) FROM alerta_critica WHERE orden_folio = :f", f=o2["folio"]) == [(0,)]


def test_nivel4_resultado_cifrado_y_alerta_sin_valores(client, medico, pac, lab):
    lab_h, lab_id = lab
    dui = pac["dui"]
    abrir(client, medico, dui)
    o = orden(client, medico, dui, lab_id, estudios=[{"nombre": "Prueba de VIH (4ª generación)"}]).json()
    assert o["nivel_sensibilidad"] == 4
    r = subir(client, lab_h, o["folio"], [{"estudio": 1, "parametro": "VIH Ag/Ac", "valor_texto": "REACTIVO", "bandera": "CRITICO"}])
    assert r.status_code == 201, r.text
    assert r.json()["alerta_critica_generada"] is True
    fila = sql("SELECT valores, observaciones, contenido_cifrado, nivel_sensibilidad FROM resultado_lab WHERE orden_folio = :f", f=o["folio"])[0]
    assert fila[0] is None and fila[1] is None and fila[3] == 4 and "REACTIVO" not in fila[2]
    assert descifrar_json(fila[2])["valores"][0]["valor_texto"] == "REACTIVO"  # Fernet con CLAVE_CAMPOS (security/campos.py)
    # el expediente lo muestra restringido; la alerta no revela el valor
    s = client.get(f"/expediente/{dui}/resultados", headers=medico)
    assert s.json()["restringidos"] == 1 and "REACTIVO" not in json.dumps(s.json())
    a = [x for x in client.get("/laboratorio/alertas-criticas", headers=medico).json() if x["orden_folio"] == o["folio"]][0]
    assert a["restringido"] is True and a["valores_criticos"] is None and "REACTIVO" not in json.dumps(a)
    assert sql("SELECT detalle FROM alerta_critica WHERE orden_folio = :f", f=o["folio"]) == [(None,)]


def test_dui_congelado_no_admite_ordenes_ni_resultados(client, medico, lab):
    lab_h, lab_id = lab
    d = datos_persona(fecha_nacimiento=NAC)
    client.post("/personas", json=d)
    abrir(client, medico, d["dui"])
    pendiente = orden(client, medico, d["dui"], lab_id).json()
    assert client.get(f"/laboratorio/pendientes/{d['dui']}", headers=lab_h).json() != []
    r, _ = ml(client, d["dui"])  # Medicina Legal registra el fallecimiento
    assert r.status_code == 200, r.text
    r = orden(client, medico, d["dui"], lab_id)
    assert r.status_code == 423
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'ORDEN_LAB_DENEGADA' AND resultado = 'FALLO' AND detalle->>'motivo' = 'DUI_CONGELADO'  AND detalle->>'paciente_id' = :p",
               p=paciente_id(d["dui"]))[0][0] >= 1
    # la orden pendiente de antes desaparece del laboratorio y no admite resultados
    assert client.get(f"/laboratorio/pendientes/{d['dui']}", headers=lab_h).json() == []
    assert subir(client, lab_h, pendiente["folio"], [hb(14)]).status_code == 423
    assert estado(pendiente["folio"]) == "PENDIENTE"
    # defensa en la base de datos: ni saltando la API
    with pytest.raises(IntegrityError, match="fallecido"):
        with SessionLocal() as db:
            db.execute(text("INSERT INTO orden_lab (id, folio, tipo, paciente_id, medico_id, institucion_emisora_id, laboratorio_id, atencion_id, prioridad, nivel_sensibilidad, estado, creada_en) "
                            "SELECT gen_random_uuid(), 'OL-FANTASMA', tipo, paciente_id, medico_id, institucion_emisora_id, laboratorio_id, atencion_id, prioridad, 2, 'PENDIENTE', now() "
                            "FROM orden_lab WHERE folio = :f"), {"f": pendiente["folio"]})
            db.commit()
    with pytest.raises(IntegrityError, match="fallecido"):
        with SessionLocal() as db:
            db.execute(text("INSERT INTO resultado_lab (id, paciente_id, atencion_id, institucion_id, nivel_sensibilidad, hash_contenido, creado_en, orden_id, orden_folio, tipo_estudio, "
                            "responsable, hay_critico, valores, observaciones) SELECT gen_random_uuid(), paciente_id, atencion_id, laboratorio_id, 2, 'h', now(), id, folio, tipo, 'x', false, "
                            "'[]'::jsonb, '' FROM orden_lab WHERE folio = :f"), {"f": pendiente["folio"]})
            db.commit()


def test_completar_una_sola_vez_tambien_en_base_y_con_concurrencia(client, medico, pac, lab):
    lab_h, lab_id = lab
    abrir(client, medico, pac["dui"])
    o = orden(client, medico, pac["dui"], lab_id).json()
    n, barrera, codigos = 6, threading.Barrier(6), []

    def intento():
        with TestClient(app, client=("127.0.0.1", 50003)) as c:
            barrera.wait()
            codigos.append(subir(c, lab_h, o["folio"], [hb(6.0)]).status_code)

    hilos = [threading.Thread(target=intento) for _ in range(n)]
    [h.start() for h in hilos]
    [h.join() for h in hilos]
    assert sorted(codigos) == [201] + [409] * (n - 1), codigos
    assert sql("SELECT count(*) FROM resultado_lab WHERE orden_folio = :f", f=o["folio"]) == [(1,)]
    assert sql("SELECT count(*) FROM alerta_critica WHERE orden_folio = :f", f=o["folio"]) == [(1,)]  # una sola alerta
    ins = text("INSERT INTO resultado_lab (id, paciente_id, atencion_id, institucion_id, nivel_sensibilidad, hash_contenido, creado_en, orden_id, orden_folio, tipo_estudio, "
               "responsable, hay_critico, valores, observaciones) SELECT gen_random_uuid(), paciente_id, atencion_id, laboratorio_id, 2, 'h', now(), id, folio, tipo, 'x', false, "
               "'[]'::jsonb, '' FROM orden_lab WHERE folio = :f")
    with pytest.raises(IntegrityError):  # SQL directo sobre una orden ya completada
        with SessionLocal() as db:
            db.execute(ins, {"f": o["folio"]})
            db.commit()


# ------------------------------------------------------------------ Mínimo privilegio: farmacia y laboratorio no leen datos clínicos fuera de lo necesario
PROHIBIDAS = ("diagnostico", "nota_soap", "antecedente", "alergia", "signos_vitales", "egreso")


def test_laboratorio_solo_lee_la_orden(client, medico, pac, lab):
    lab_h, lab_id = lab
    dui = pac["dui"]
    at = abrir(client, medico, dui)
    client.post(f"/atenciones/{at}/diagnosticos", headers=medico, json={"codigo_cie10": "E11.9", "descripcion": "Diabetes mellitus tipo 2 descompensada", "tipo": "DEFINITIVO", "principal": True})
    client.post(f"/atenciones/{at}/notas", headers=medico, json=nota(subjetivo="Poliuria y polidipsia marcadas"))
    client.post(f"/atenciones/{at}/antecedentes", headers=medico, json={"tipo": "FAMILIAR", "descripcion": "Madre con cáncer de mama"})
    client.post(f"/atenciones/{at}/alergias", headers=medico, json={"sustancia": "penicilina", "severidad": "GRAVE"})
    client.post(f"/atenciones/{at}/signos-vitales", headers=medico, json={"ta_sistolica": 150, "ta_diastolica": 95})
    o = orden(client, medico, dui, lab_id).json()
    vistas = []
    fn = lambda conn, cur, stmt, *a: vistas.append(stmt.lower())  # noqa: E731
    event.listen(engine, "before_cursor_execute", fn)
    try:
        p = client.get(f"/laboratorio/pendientes/{dui}", headers=lab_h)
        r = subir(client, lab_h, o["folio"], [hb(14)])
    finally:
        event.remove(engine, "before_cursor_execute", fn)
    assert p.status_code == 200 and r.status_code == 201
    todo = " ".join(vistas)
    for t in PROHIBIDAS + ("atencion",):
        assert f"from {t}" not in todo and f"join {t}" not in todo, f"el laboratorio leyó la tabla {t}"
    assert "from resultado_lab" not in todo and "from alerta_critica" not in todo  # tampoco resultados ajenos
    for st in vistas:
        if "from persona" in st:
            assert not any(c in st for c in ("password_hash", "correo", "telefono", "totp", "permisos")), st
        if re.search(r"from orden_lab\s", st):
            assert "laboratorio_id" in st, "toda consulta de órdenes debe filtrar por el laboratorio"
    texto = json.dumps(p.json() + [r.json()], ensure_ascii=False).lower()
    for prohibido in ("diabetes", "e11", "poliuria", "cáncer", "mama", "penicilina", "alerg", "diagnos", "soap", "antecedente", "signos"):
        assert prohibido not in texto, prohibido
    assert not re.search(r"(?<![\d.])150(?![\d.])", texto), "150"  # la TA del paciente, como número suelto (no como parte de una hora o un id)
    assert set(p.json()[0]) == {"folio", "tipo", "prioridad", "creada_en", "paciente", "estudios"} and set(p.json()[0]["paciente"]) == {"dui", "nombre", "edad_anios"}


def test_farmacia_tampoco_ve_ordenes_ni_resultados(client, medico, pac, lab, farmacia):
    lab_h, lab_id = lab
    abrir(client, medico, pac["dui"])
    o = orden(client, medico, pac["dui"], lab_id).json()
    subir(client, lab_h, o["folio"], [hb(14)])
    # la farmacia no entra a ningún endpoint del laboratorio
    for r in (client.get(f"/laboratorio/pendientes/{pac['dui']}", headers=farmacia), subir(client, farmacia, o["folio"], [hb(14)]),
              client.get("/laboratorio/ordenes", headers=farmacia), client.get("/laboratorio/alertas-criticas", headers=farmacia),
              client.get("/laboratorio/directorio", headers=farmacia)):
        assert r.status_code in (401, 403), r.text
    # y el laboratorio no entra a los de farmacia
    for r in (client.get("/farmacia/inventario/lotes", headers=lab_h), client.post("/farmacia/recetas/consulta", headers=lab_h, json={"folio": "RX-AAAAAAAAAA", "token": "AAAA-BBBB-CCCC-DDDD"}),
              client.post("/farmacia/recetas/despachar", headers=lab_h, json={"folio": "RX-AAAAAAAAAA", "token": "AAAA-BBBB-CCCC-DDDD"})):
        assert r.status_code in (401, 403), r.text


CLINICOS = [("GET", "/expediente/{dui}"), ("GET", "/expediente/{dui}/antecedentes"), ("GET", "/expediente/{dui}/alergias"), ("GET", "/expediente/{dui}/diagnosticos"),
            ("GET", "/expediente/{dui}/signos-vitales"), ("GET", "/expediente/{dui}/notas"), ("GET", "/expediente/{dui}/egresos"), ("GET", "/expediente/{dui}/resultados"),
            ("GET", "/mi-expediente"), ("GET", "/mi-expediente/notas"), ("GET", "/atenciones"), ("GET", "/revisiones-bypass"), ("GET", "/mi-expediente/consentimientos")]


@pytest.mark.parametrize("metodo,ruta", CLINICOS)
def test_credenciales_de_farmacia_y_laboratorio_no_abren_endpoints_clinicos(client, medico, pac, lab, farmacia, metodo, ruta):
    lab_h, _ = lab
    abrir(client, medico, pac["dui"])
    for h in (lab_h, farmacia):
        r = client.request(metodo, ruta.format(dui=pac["dui"]), headers=h)
        assert r.status_code in (401, 403), (ruta, r.status_code, r.text[:200])
        assert pac["nombres"] not in r.text and "diagnos" not in r.text.lower()
    assert client.get(ruta.format(dui=pac["dui"])).status_code == 401
