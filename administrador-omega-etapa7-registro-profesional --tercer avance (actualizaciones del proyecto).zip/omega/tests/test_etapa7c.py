"""Etapa 7 · parte 2a: portal /ciudadano (inicio, perfil, activar/desactivar perfiles). Pruebas de humo y de permisos:
sin sesión → login de /ciudadano; un ciudadano solo edita su propio perfil; todo cambio queda en la bitácora de auditoría."""
import re

import pytest
from sqlalchemy import text

from omega_core.database import SessionLocal
from omega_core.seed import DUI_CIVIL, DUI_MEDICO, PASSWORD_CIVIL, PASSWORD_MEDICO
from web.comun.portales import CIUDADANO

from .test_etapa2 import sql
from .test_etapa7a import entrar_persona, nuevo, token_de, web  # noqa: F401  (web es un fixture)


def _id(dui: str) -> str:
    return str(sql("SELECT id FROM persona WHERE dui = :d", d=dui)[0][0])


def _auditoria(accion: str, persona_id: str) -> list:
    return sql("SELECT detalle FROM auditoria WHERE accion = :a AND actor_id = :p ORDER BY id", a=accion, p=persona_id)


def _entrar(web, dui=DUI_CIVIL, clave=PASSWORD_CIVIL):
    assert entrar_persona(web, CIUDADANO, dui, clave).status_code == 303
    return web


def _post(web, ruta, campos, pagina="/ciudadano/perfil", **kw):
    return web.post(ruta, data={"csrf_token": token_de(web.get(pagina).text)} | campos, **kw)


@pytest.fixture
def contacto_civil():
    """Restaura los datos de contacto del ciudadano de prueba al terminar."""
    antes = sql("SELECT correo, telefono, departamento, municipio, direccion FROM persona WHERE dui = :d", d=DUI_CIVIL)[0]
    yield
    with SessionLocal() as db:
        db.execute(text("UPDATE persona SET correo = :c, telefono = :t, departamento = :d, municipio = :m, direccion = :x WHERE dui = :u"),
                   dict(c=antes[0], t=antes[1], d=antes[2], m=antes[3], x=antes[4], u=DUI_CIVIL))
        db.commit()


# ------------------------------------------------------------------ Sin sesión
@pytest.mark.parametrize("ruta", ["/ciudadano/panel", "/ciudadano/perfil", "/ciudadano/expediente"])
def test_sin_sesion_las_paginas_redirigen_al_login_de_ciudadano(web, ruta):
    r = web.get(ruta)
    assert r.status_code == 303 and r.headers["location"].startswith("/ciudadano/ingresar")


def test_sin_sesion_las_acciones_redirigen_y_no_cambian_nada(web):
    antes = sql("SELECT correo FROM persona WHERE dui = :d", d=DUI_CIVIL)
    for ruta in ("/ciudadano/perfil", "/ciudadano/perfil/profesional/estado", "/ciudadano/perfil/estudiante/estado"):
        r = web.post(ruta, data={"correo": "intruso@example.sv", "activo": "0"})
        assert r.status_code == 303 and r.headers["location"].startswith("/ciudadano/ingresar"), ruta
    assert sql("SELECT correo FROM persona WHERE dui = :d", d=DUI_CIVIL) == antes


# ------------------------------------------------------------------ Humo
def test_inicio_y_cabecera_propia(web):
    _entrar(web)
    p = web.get("/ciudadano/panel")
    assert p.status_code == 200 and "Ciudadano Demo" in p.text and "Ciudadano" in p.text
    menu = re.search(r'<nav id="menu".*?</nav>', p.text, re.S).group(0)
    assert re.findall(r">(Inicio|Mi expediente|Perfil|Salir)<", menu) == ["Inicio", "Mi expediente", "Perfil", "Salir"]
    for otro in ("/profesional", "/institucion", "/farmacia", "/laboratorio", "/universidad", "/omega"):  # ningún enlace a otros portales
        assert f'href="{otro}' not in p.text, otro
    assert 'href="/ciudadano/perfil"' in p.text and 'href="/ciudadano/expediente"' in p.text
    assert web.get("/ciudadano/expediente").status_code == 200 and web.get("/ciudadano/cuenta").status_code == 200


def test_inicio_muestra_los_perfiles_activos_del_titular(web):
    _entrar(web, DUI_MEDICO, PASSWORD_MEDICO)
    t = web.get("/ciudadano/panel").text
    assert "Médico Demo" in t and "Profesional · activo" in t and "Estudiante" not in t.split("Sus perfiles activos")[1].split("</ul>")[0]
    perfil = web.get("/ciudadano/perfil")
    assert perfil.status_code == 200 and "medico@example.sv" in perfil.text and 'role="switch"' in perfil.text


# ------------------------------------------------------------------ Editar perfil
def test_editar_contacto_valida_guarda_y_audita(web, contacto_civil):
    _entrar(web)
    pid = _id(DUI_CIVIL)
    antes = len(_auditoria("PORTAL_PERFIL_ACTUALIZADO", pid))
    r = _post(web, "/ciudadano/perfil", {"correo": "Nuevo.Correo@Example.sv", "telefono": "7123-4567", "departamento": "Usulután", "municipio": "Santa Elena", "direccion": "Barrio El Centro 12"})
    assert r.status_code == 303 and r.headers["location"] == "/ciudadano/perfil?aviso=guardado"
    fila = sql("SELECT correo, telefono, departamento, municipio, direccion FROM persona WHERE dui = :d", d=DUI_CIVIL)[0]
    assert fila == ("nuevo.correo@example.sv", "+50371234567", "Usulután", "Santa Elena", "Barrio El Centro 12")  # mismas normalizaciones que la API
    nuevas = _auditoria("PORTAL_PERFIL_ACTUALIZADO", pid)
    assert len(nuevas) == antes + 1 and nuevas[-1][0]["campos"] == ["correo", "departamento", "direccion", "municipio", "telefono"]
    assert "Sus datos se guardaron" in web.get("/ciudadano/perfil?aviso=guardado").text
    # sin cambios: no se escribe nada ni se audita
    r = _post(web, "/ciudadano/perfil", {"correo": "nuevo.correo@example.sv", "telefono": "+50371234567", "departamento": "Usulután", "municipio": "Santa Elena", "direccion": "Barrio El Centro 12"})
    assert r.status_code == 303 and r.headers["location"].endswith("aviso=sin_cambios") and len(_auditoria("PORTAL_PERFIL_ACTUALIZADO", pid)) == antes + 1


def test_editar_contacto_rechaza_lo_invalido_sin_guardar(web, contacto_civil):
    _entrar(web)
    pid = _id(DUI_CIVIL)
    antes, n = sql("SELECT correo, telefono FROM persona WHERE dui = :d", d=DUI_CIVIL), len(_auditoria("PORTAL_PERFIL_ACTUALIZADO", pid))
    casos = [({"correo": "no-es-correo", "telefono": "7123-4567"}, "correo"), ({"correo": "ok@example.sv", "telefono": "123"}, "Teléfono inválido"),
             ({"correo": "", "telefono": "7123-4567"}, "El correo no puede quedar vacío"), ({"correo": "ok@example.sv", "telefono": ""}, "El teléfono no puede quedar vacío"),
             ({"correo": "ok@example.sv", "telefono": "7123-4567", "direccion": "x"}, "al menos 3 caracteres")]
    for campos, texto in casos:
        r = _post(web, "/ciudadano/perfil", campos)
        assert r.status_code == 422 and texto in r.text and "Revise los campos marcados" in r.text, campos
    r = _post(web, "/ciudadano/perfil", {"correo": "medico@example.sv", "telefono": "7123-4567"})  # correo de otra persona
    assert r.status_code == 409 and "ya está registrado" in r.text
    assert sql("SELECT correo, telefono FROM persona WHERE dui = :d", d=DUI_CIVIL) == antes and len(_auditoria("PORTAL_PERFIL_ACTUALIZADO", pid)) == n


def test_editar_perfil_exige_csrf(web, contacto_civil):
    _entrar(web)
    antes = sql("SELECT correo FROM persona WHERE dui = :d", d=DUI_CIVIL)
    assert web.post("/ciudadano/perfil", data={"correo": "otro@example.sv", "telefono": "7123-4567"}).status_code == 403
    assert sql("SELECT correo FROM persona WHERE dui = :d", d=DUI_CIVIL) == antes  # sin token no se toca nada


# ------------------------------------------------------------------ Permisos: solo el propio perfil
def test_un_ciudadano_solo_edita_su_propio_perfil(web, contacto_civil):
    medico_antes = sql("SELECT correo, telefono, direccion FROM persona WHERE dui = :d", d=DUI_MEDICO)
    auditoria_medico = len(_auditoria("PORTAL_PERFIL_ACTUALIZADO", _id(DUI_MEDICO)))
    _entrar(web)
    # el formulario no admite elegir a quién editar: DUI, id o persona enviados de más se ignoran y la edición cae en la cuenta de la sesión
    r = _post(web, "/ciudadano/perfil", {"correo": "civil.propio@example.sv", "telefono": "7123-4567", "dui": DUI_MEDICO, "persona_id": _id(DUI_MEDICO), "id": _id(DUI_MEDICO)})
    assert r.status_code == 303
    assert sql("SELECT correo FROM persona WHERE dui = :d", d=DUI_CIVIL)[0][0] == "civil.propio@example.sv"
    assert sql("SELECT correo, telefono, direccion FROM persona WHERE dui = :d", d=DUI_MEDICO) == medico_antes
    assert len(_auditoria("PORTAL_PERFIL_ACTUALIZADO", _id(DUI_MEDICO))) == auditoria_medico  # nada queda registrado a nombre del médico
    assert len(_auditoria("PORTAL_PERFIL_ACTUALIZADO", _id(DUI_CIVIL))) >= 1


def test_ciudadano_no_puede_cambiar_el_perfil_de_otro_ni_los_datos_del_padron(web, contacto_civil):
    _entrar(web)
    antes = sql("SELECT nombres, apellidos, dui, fecha_nacimiento FROM persona WHERE dui = :d", d=DUI_CIVIL)
    _post(web, "/ciudadano/perfil", {"correo": "civil@example.sv", "telefono": "+50370000003", "nombres": "Otro", "apellidos": "Nombre", "fecha_nacimiento": "1990-01-01"})
    assert sql("SELECT nombres, apellidos, dui, fecha_nacimiento FROM persona WHERE dui = :d", d=DUI_CIVIL) == antes
    assert 'name="nombres"' not in web.get("/ciudadano/perfil").text  # el formulario ni siquiera ofrece esos campos


# ------------------------------------------------------------------ Activar / desactivar perfiles
def test_activar_y_desactivar_perfil_profesional_con_las_reglas_del_servicio(web):
    _entrar(web, DUI_MEDICO, PASSWORD_MEDICO)
    pid = _id(DUI_MEDICO)
    n = len(_auditoria("PORTAL_PERFIL_ESTADO", pid))
    try:
        r = _post(web, "/ciudadano/perfil/profesional/estado", {"activo": "0"}, headers={"HX-Request": "true"})  # como lo envía el interruptor (htmx)
        assert r.status_code == 200 and 'id="perfiles"' in r.text and "<html" not in r.text and "desactivado" in r.text
        assert sql("SELECT activo, verificado FROM perfil_profesional WHERE persona_id = :p", p=pid) == [(False, True)]  # conserva su verificación
        r = _post(web, "/ciudadano/perfil/profesional/estado", {"activo": "1"})  # sin htmx: redirige al perfil
        assert r.status_code == 303 and r.headers["location"] == "/ciudadano/perfil"
        assert sql("SELECT activo, verificado FROM perfil_profesional WHERE persona_id = :p", p=pid) == [(True, True)]
        nuevas = _auditoria("PORTAL_PERFIL_ESTADO", pid)[n:]
        assert [a[0]["despues"] for a in nuevas] == [False, True] and all(a[0]["antes"] is not None and a[0]["verificado"] is True for a in nuevas)
    finally:
        with SessionLocal() as db:
            db.execute(text("UPDATE perfil_profesional SET activo = true WHERE persona_id = :p"), {"p": pid})
            db.commit()


def test_perfil_no_registrado_no_se_puede_activar_ni_desactivar(web):
    _entrar(web)  # el ciudadano de prueba no tiene perfil profesional ni de estudiante
    pid = _id(DUI_CIVIL)
    n = len(_auditoria("PORTAL_PERFIL_ESTADO", pid))
    for perfil in ("profesional", "estudiante"):
        r = _post(web, f"/ciudadano/perfil/{perfil}/estado", {"activo": "1"}, headers={"HX-Request": "true"})
        assert r.status_code == 404 and f"No tiene perfil de {perfil} registrado" in r.text
    assert len(_auditoria("PORTAL_PERFIL_ESTADO", pid)) == n
    assert _post(web, "/ciudadano/perfil/administrador/estado", {"activo": "1"}).status_code == 422  # solo existen estos dos perfiles


def test_cambiar_estado_exige_csrf_y_actua_solo_sobre_la_cuenta_de_la_sesion(web):
    _entrar(web)
    medico = sql("SELECT activo FROM perfil_profesional WHERE persona_id = :p", p=_id(DUI_MEDICO))
    assert web.post("/ciudadano/perfil/profesional/estado", data={"activo": "0"}).status_code == 403
    _post(web, "/ciudadano/perfil/profesional/estado", {"activo": "0", "persona_id": _id(DUI_MEDICO), "dui": DUI_MEDICO})  # 404 para el civil: no toca al médico
    assert sql("SELECT activo FROM perfil_profesional WHERE persona_id = :p", p=_id(DUI_MEDICO)) == medico
