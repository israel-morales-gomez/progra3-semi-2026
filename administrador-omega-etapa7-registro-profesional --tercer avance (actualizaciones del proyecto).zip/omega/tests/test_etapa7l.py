"""Etapa 7 · integración web del expediente civil · parte 4: asistente virtual y búsqueda de farmacias en /ciudadano."""
from web.comun.portales import CIUDADANO

from .test_etapa2 import paciente_id, sql  # noqa: F401
from .test_etapa4a import pac  # noqa: F401
from .test_etapa7a import entrar_persona, nuevo, token_de, web  # noqa: F401
from .test_etapa7h import farmacia_en, med_unico, poner_lote

ASIS, FARM = "/ciudadano/asistente", "/ciudadano/farmacias"
HX = {"HX-Request": "true"}


def _entrar(web, persona):
    assert entrar_persona(web, CIUDADANO, persona["dui"], persona["password"]).status_code == 303
    return web


def _preguntar(w, texto, **kw):
    return w.post(ASIS, data={"csrf_token": token_de(w.get(ASIS).text), "mensaje": texto}, **kw)


def test_humo_y_avisos_permanentes_del_asistente(web, pac):
    assert nuevo(50401).get(ASIS).status_code == 303 and nuevo(50402).get(FARM).status_code == 303
    _entrar(web, pac)
    r = web.get(ASIS)
    assert r.status_code == 200 and "No agenda citas, no diagnostica y no indica medicamentos" in r.text and "911" in r.text and "no se guarda su texto" in r.text
    assert web.get(FARM).status_code == 200 and "Nunca se muestran cantidades exactas" in web.get(FARM).text


def test_csrf_es_obligatorio_y_el_mensaje_vacio_se_rechaza(web, pac):
    _entrar(web, pac)
    assert web.post(ASIS, data={"mensaje": "hola"}).status_code == 403
    assert web.post(ASIS, data={"csrf_token": "0" * 64, "mensaje": "hola"}).status_code == 403
    r = _preguntar(web, "   ")
    assert r.status_code == 422 and "Escriba su pregunta" in r.text
    assert _preguntar(web, "x" * 501).status_code == 422


def test_pedir_una_cita_redirige_al_modulo_manual_y_no_agenda_nada(web, pac):
    _entrar(web, pac)
    r = _preguntar(web, "quiero agendar una cita")
    assert r.status_code == 200 and "no agendo" in r.text.lower() and 'href="/ciudadano/citas"' in r.text
    assert sql("SELECT count(*) FROM cita WHERE paciente_id = :p", p=paciente_id(pac["dui"]))[0][0] == 0
    assert "Soy un asistente informativo" in r.text  # aviso en cada respuesta


def test_el_texto_se_escapa_y_el_fragmento_htmx_no_trae_la_pagina(web, pac):
    _entrar(web, pac)
    r = _preguntar(web, "<script>alert(1)</script> quiero agendar una cita")
    assert "<script>alert(1)</script>" not in r.text and "&lt;script&gt;alert(1)&lt;/script&gt;" in r.text
    frag = _preguntar(web, "hola, ¿qué puedo hacer aquí?", headers=HX)
    assert frag.status_code == 200 and "<html" not in frag.text and "Asistente" in frag.text and "Usted" in frag.text


def test_la_bitacora_guarda_la_intencion_y_nunca_el_texto(web, pac):
    _entrar(web, pac)
    unico = med_unico()
    assert _preguntar(web, f"tengo dolor de cabeza fuerte con {unico}").status_code == 200
    filas = sql("SELECT detalle::text FROM auditoria WHERE accion = 'CHATBOT_CONSULTA' AND actor_id = :a", a=paciente_id(pac["dui"]))
    assert filas and all(unico not in f[0] and "dolor" not in f[0] for f in filas)


def test_busqueda_de_farmacias_con_disponibilidad_precios_y_comparacion(web, client, omega_headers, pac):
    h1, farm1, _ = farmacia_en(client, omega_headers, "Usulután", "Santa Elena")
    h2, farm2, _ = farmacia_en(client, omega_headers, "Usulután", "Santa Elena")
    med, solo = med_unico(), med_unico()
    poner_lote(client, h1, med, cantidad=40, precio_unitario=3.25)
    poner_lote(client, h2, med, cantidad=40, precio_unitario=2.75)
    poner_lote(client, h1, solo, cantidad=40, precio_unitario=1.50)  # una sola farmacia con precio: sin comparación
    _entrar(web, pac)
    r = web.get(FARM, params={"medicamento": med, "departamento": "Usulután", "municipio": "Santa Elena"})
    assert r.status_code == 200 and farm1 in r.text and farm2 in r.text and "Disponibilidad media" in r.text
    assert "$3.25" in r.text and "$2.75" in r.text and "Comparación de precios" in r.text and "aproximada" in r.text
    assert "40 unidades" not in r.text  # nunca la cantidad exacta del inventario
    barato = web.get(FARM, params={"medicamento": med, "orden": "precio"})
    assert barato.text.index(farm2) < barato.text.index(farm1)  # menor precio primero
    u = web.get(FARM, params={"medicamento": solo})
    assert farm1 in u.text and "Comparación de precios" not in u.text and farm2 not in u.text
    assert "No encontramos farmacias" in web.get(FARM, params={"medicamento": med_unico()}).text
    assert "No encontramos farmacias" in web.get(FARM, params={"medicamento": med, "municipio": "Municipio Inexistente"}).text
    corto = web.get(FARM, params={"medicamento": "ab"})
    assert corto.status_code == 422 and "entre 3 y 60" in corto.text
    assert web.get(FARM, params={"medicamento": "x" * 61}).status_code == 422
    assert web.get(FARM, params={"medicamento": med, "orden": "cualquiera"}).status_code == 200  # orden inválido se ignora


def test_el_asistente_responde_donde_hay_x_y_enlaza_a_la_busqueda(web, client, omega_headers, pac):
    h, farm, _ = farmacia_en(client, omega_headers, "Usulután", "Santa Elena")
    med = med_unico()
    poner_lote(client, h, med, cantidad=40, precio_unitario=3.25)
    _entrar(web, pac)
    r = _preguntar(web, f"¿Dónde hay {med}?")
    assert r.status_code == 200 and farm in r.text and "$3.25" in r.text and f"/ciudadano/farmacias?medicamento={med}" in r.text
    assert 'href="/ciudadano/citas"' in r.text  # sigue ofreciendo el módulo manual de citas
    clinica = _preguntar(web, f"dónde hay {med}, qué dosis tomo")
    assert clinica.status_code == 200 and farm not in clinica.text  # lo clínico no se contesta con farmacias
    assert "No encontré" in _preguntar(web, f"donde puedo comprar {med_unico()}").text
