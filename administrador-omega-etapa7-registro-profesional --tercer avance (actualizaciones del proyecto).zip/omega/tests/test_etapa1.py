import pyotp
import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from omega_core.auditoria.servicio import verificar_cadena
from omega_core.database import SessionLocal
from omega_core.seed import CODIGO_HOSPITAL, DUI_CIVIL, DUI_MEDICO, DUI_OMEGA, PASSWORD_CIVIL, PASSWORD_HOSPITAL, PASSWORD_OMEGA, TOTP_OMEGA

from .conftest import datos_persona, dui_nuevo, nit_nuevo


def auth(token):
    return {"Authorization": f"Bearer {token}"}


def test_health_y_cabeceras(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["x-frame-options"] == "DENY"
    assert "default-src 'none'" in r.headers["content-security-policy"]


def test_registro_persona_multiperfil_y_validaciones(client):
    d = datos_persona(
        estudiante={"carne": f"AB{dui_nuevo()[:5]}", "universidad_nombre": "UES", "carrera": "Doctorado en Medicina", "ciclo": "Año 6",
                    "correo_institucional": f"{dui_nuevo()[:8]}@ues.edu.sv"},
        profesional={"tipo": "ENFERMERA", "numero_junta": f"JVPE-{dui_nuevo()}", "especialidad": "UCI"},
    )
    r = client.post("/personas", json=d)
    assert r.status_code == 201, r.text
    p = r.json()
    assert set(p["roles"]) == {"CIVIL", "ESTUDIANTE", "PROFESIONAL"}
    assert p["profesional"]["junta"] == "JVPE" and p["profesional"]["verificado"] is False
    assert "password" not in p and "password_hash" not in p
    assert client.post("/personas", json=d).status_code == 409  # duplicado
    assert client.post("/personas", json=datos_persona(password="corta")).status_code == 422
    assert client.post("/personas", json=datos_persona(dui="123")).status_code == 422
    assert client.post("/personas", json=datos_persona(roles=["OMEGA"])).status_code == 422  # sin mass-assignment


def test_login_persona_refresh_rotacion_y_reuso(client):
    d = datos_persona()
    assert client.post("/personas", json=d).status_code == 201
    assert client.post("/auth/login/persona", json={"dui": d["dui"], "password": "mala"}).status_code == 401
    r = client.post("/auth/login/persona", json={"dui": d["dui"], "password": d["password"]})
    assert r.status_code == 200
    t = r.json()["tokens"]
    me = client.get("/personas/me", headers=auth(t["access_token"]))
    assert me.status_code == 200 and me.json()["dui"] == d["dui"]
    assert client.get("/personas/me", headers=auth(t["refresh_token"])).status_code == 401  # refresh no sirve como acceso
    r2 = client.post("/auth/refresh", json={"refresh_token": t["refresh_token"]})
    assert r2.status_code == 200
    nuevo = r2.json()
    assert client.post("/auth/refresh", json={"refresh_token": t["refresh_token"]}).status_code == 401  # reuso detectado
    assert client.post("/auth/refresh", json={"refresh_token": nuevo["refresh_token"]}).status_code == 401  # sesión revocada
    # JWT manipulado
    assert client.get("/personas/me", headers=auth(t["access_token"][:-3] + "abc")).status_code == 401


def test_perfil_se_puede_actualizar_y_agregar(client):
    d = datos_persona()
    client.post("/personas", json=d)
    tk = client.post("/auth/login/persona", json={"dui": d["dui"], "password": d["password"]}).json()["tokens"]["access_token"]
    est = {"carne": f"ZZ{dui_nuevo()[:5]}", "universidad_nombre": "UNIVO", "carrera": "Enfermería", "ciclo": "Ciclo 3",
           "correo_institucional": "zz99999@univo.edu.sv"}
    assert client.put("/personas/me/perfiles/estudiante", json=est, headers=auth(tk)).status_code == 200
    est["ciclo"] = "Ciclo 4"
    assert client.put("/personas/me/perfiles/estudiante", json=est, headers=auth(tk)).json()["ciclo"] == "Ciclo 4"
    r = client.put("/personas/me/perfiles/profesional", json={"tipo": "DOCTOR", "numero_junta": f"J{dui_nuevo()}"}, headers=auth(tk))
    assert r.status_code == 200
    assert set(client.get("/personas/me", headers=auth(tk)).json()["roles"]) == {"CIVIL", "ESTUDIANTE", "PROFESIONAL"}
    r = client.patch("/personas/me", json={"telefono": "2222-3333"}, headers=auth(tk))
    assert r.json()["telefono"] == "+50322223333"


def test_login_seed_civil_y_medico(client):
    assert client.post("/auth/login/persona", json={"dui": DUI_CIVIL, "password": PASSWORD_CIVIL}).status_code == 200
    r = client.post("/auth/login/persona", json={"dui": DUI_MEDICO, "password": "Medico#Dev2026"})
    assert r.status_code == 200
    me = client.get("/personas/me", headers=auth(r.json()["tokens"]["access_token"])).json()
    assert "PROFESIONAL" in me["roles"] and "receta:emitir" in me["permisos"]


def test_omega_no_entra_por_login_normal_y_se_pide_totp(client):
    assert client.post("/auth/login/persona", json={"dui": DUI_OMEGA, "password": PASSWORD_OMEGA}).status_code == 401
    r = client.post("/omega/login", json={"dui": DUI_OMEGA, "password": PASSWORD_OMEGA, "totp": "000000"})
    assert r.status_code == 401


def test_omega_totp_replay_e_ip(client, omega_headers):
    me = client.get("/omega/me", headers=omega_headers)
    assert me.status_code == 200 and "omega:administrar" in me.json()["permisos"]
    # un código TOTP ya usado no sirve de nuevo (el fixture dejó registrado su paso)
    r = client.post("/omega/login", json={"dui": DUI_OMEGA, "password": PASSWORD_OMEGA, "totp": pyotp.TOTP(TOTP_OMEGA).now()})
    assert r.status_code == 401
    # IP fuera de la lista: ni el login ni un token válido sirven
    from fastapi.testclient import TestClient
    from main import app
    with TestClient(app, client=("10.9.9.9", 4000)) as externo:
        assert externo.post("/omega/login", json={"dui": DUI_OMEGA, "password": PASSWORD_OMEGA, "totp": "123456"}).status_code == 403
        assert externo.get("/omega/me", headers=omega_headers).status_code == 403
    # un token de persona no abre endpoints de Omega
    tk = client.post("/auth/login/persona", json={"dui": DUI_CIVIL, "password": PASSWORD_CIVIL}).json()["tokens"]["access_token"]
    assert client.get("/omega/me", headers=auth(tk)).status_code == 403
    assert client.get("/auditoria", headers=auth(tk)).status_code == 403


def test_institucion_registro_aprobacion_y_2fa(client, omega_headers, codigos_2fa):
    nit = nit_nuevo()
    d = {"tipo": "LABORATORIO", "nombre_legal": "Laboratorio Prueba", "nit": nit, "codigo_minsal": "LAB-9001-" + nit[-6:-2],
         "direccion": "San Miguel", "telefono": "2600-0000", "correo": "lab@example.sv", "responsable_nombre": "Lic. Química",
         "responsable_dui": dui_nuevo(), "responsable_junta": "JVQF-777", "documento_permiso_ref": "up://permiso.pdf",
         "password": "LabClave123"}
    assert client.post("/instituciones", json={**d, "codigo_minsal": None}).status_code == 422  # faltan campos del tipo
    r = client.post("/instituciones", json=d)
    assert r.status_code == 201 and r.json()["estado"] == "PENDIENTE" and r.json()["requiere_2fa"] is True
    inst_id = r.json()["id"]
    login = {"identificador": nit, "password": d["password"]}
    assert client.post("/auth/login/institucion", json=login).status_code == 401  # pendiente de aprobación
    r = client.patch(f"/omega/instituciones/{inst_id}/estado", json={"estado": "ACTIVA", "motivo": "Documentos verificados"}, headers=omega_headers)
    assert r.status_code == 200 and r.json()["estado"] == "ACTIVA"

    r = client.post("/auth/login/institucion", json=login)
    assert r.status_code == 200 and r.json()["requiere_2fa"] is True and r.json()["tokens"] is None
    desafio = r.json()["desafio_id"]
    assert len(codigos_2fa) == 1
    assert client.post("/auth/2fa/verificar", json={"desafio_id": desafio, "codigo": "000000"}).status_code == 401
    r = client.post("/auth/2fa/verificar", json={"desafio_id": desafio, "codigo": codigos_2fa[0]})
    assert r.status_code == 200
    tk = r.json()["tokens"]["access_token"]
    assert client.get("/instituciones/me", headers=auth(tk)).json()["nit"] == nit
    assert client.post("/auth/2fa/verificar", json={"desafio_id": desafio, "codigo": codigos_2fa[0]}).status_code == 401  # un solo uso
    # también entra por código de establecimiento
    assert client.post("/auth/login/institucion", json={"identificador": d["codigo_minsal"].lower(), "password": d["password"]}).json()["requiere_2fa"]


def test_hospital_semilla_y_farmacia_sin_2fa(client, codigos_2fa):
    r = client.post("/auth/login/institucion", json={"identificador": CODIGO_HOSPITAL, "password": PASSWORD_HOSPITAL})
    assert r.status_code == 200 and r.json()["requiere_2fa"] is True


def test_rate_limit_login(client):
    d = datos_persona()
    client.post("/personas", json=d)
    codigos = [client.post("/auth/login/persona", json={"dui": d["dui"], "password": "incorrecta"}).status_code for _ in range(10)]
    assert 429 in codigos
    # con la cuenta bloqueada ni la clave correcta pasa
    assert client.post("/auth/login/persona", json={"dui": d["dui"], "password": d["password"]}).status_code == 429


def test_auditoria_cadena_e_inmutabilidad(client, omega_headers):
    r = client.get("/auditoria/verificar", headers=omega_headers)
    assert r.status_code == 200 and r.json()["integra"] is True and r.json()["registros_verificados"] > 0
    lista = client.get("/auditoria?limit=3", headers=omega_headers).json()
    assert len(lista) == 3 and lista[0]["hash_prev"] == lista[1]["hash"]
    assert " - " in lista[0]["fecha_local"]
    # el trigger bloquea UPDATE / DELETE / TRUNCATE
    for sql in ("UPDATE auditoria SET accion='X' WHERE id=1", "DELETE FROM auditoria WHERE id=1", "TRUNCATE auditoria"):
        with SessionLocal() as db:
            with pytest.raises(DBAPIError, match="append-only"):
                db.execute(text(sql))
                db.commit()


def test_verificacion_detecta_manipulacion(client):
    """Se desactiva el trigger DENTRO de una transacción que luego se revierte, para simular a un atacante con acceso a la BD."""
    with SessionLocal() as db:
        db.execute(text("ALTER TABLE auditoria DISABLE TRIGGER trg_auditoria_sin_update_delete"))
        db.execute(text("UPDATE auditoria SET detalle = '{\"alterado\": true}'::jsonb WHERE id = (SELECT min(id) FROM auditoria)"))
        res = verificar_cadena(db)
        db.rollback()
    assert res["integra"] is False and "hash" in res["motivo"]
    with SessionLocal() as db:
        assert verificar_cadena(db)["integra"] is True
