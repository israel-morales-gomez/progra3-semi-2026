"""Etapa 7 · portal profesional: notas SOAP, diagnósticos y signos vitales desde la web (con base de datos).

La web solo presenta: se prueba que use las reglas de la API (fases, médico, principal único, nivel 4, versionado, cierre).
"""
import html
import re

import pytest
from sqlalchemy import text

from omega_core.database import SessionLocal
from omega_core.seed import DUI_MEDICO
from web.comun.portales import PROFESIONAL

from .test_etapa2 import abrir, medico, sql  # noqa: F401
from .test_etapa4a import pac  # noqa: F401
from .test_etapa7a import entrar_persona, token_de, web  # noqa: F401  (web es un fixture)

P = "/profesional"
NOTA = {"subjetivo": "Cefalea de 2 días", "objetivo": "TA 120/80, sin focalidad", "analisis": "Cefalea tensional", "plan": "Reposo e hidratación"}
DX = {"codigo_cie10": "G44.2", "descripcion": "Cefalea tensional", "tipo": "DEFINITIVO", "estatus": "ACTIVA", "principal": "on"}


def _atencion(client, medico, pac, **extra):  # noqa: F811
    return abrir(client, medico, pac["dui"], **extra)


def _entrar(web):
    r = entrar_persona(web, PROFESIONAL)
    assert r.status_code == 303, r.text


def _post(web, at, ruta, campos):
    """POST como lo hace HTMX: el token CSRF sale de la propia página de la atención."""
    pagina = web.get(f"{P}/atenciones/{at}")
    assert pagina.status_code == 200, pagina.text
    return web.post(f"{P}/atenciones/{at}/{ruta}", data={"csrf_token": token_de(pagina.text)} | campos, headers={"HX-Request": "true"})


def _texto(r):
    return html.unescape(re.sub(r"<[^>]+>", " ", r.text))


def _auditoria(accion, recurso_id=None):
    q = "SELECT count(*) FROM auditoria WHERE accion = :a" + (" AND recurso_id = :r" if recurso_id else "")
    return sql(q, a=accion, **({"r": recurso_id} if recurso_id else {}))[0][0]


def test_sin_sesion_las_rutas_nuevas_no_se_abren(web):
    for ruta in ("notas", "diagnosticos", "signos-vitales", "clinico/ver"):
        assert web.post(f"{P}/atenciones/00000000-0000-0000-0000-000000000000/{ruta}", data={}).status_code in (303, 401, 403)
    assert web.get(f"{P}/atenciones/00000000-0000-0000-0000-000000000000/clinico").status_code in (303, 401)


def test_flujo_completo_nota_diagnostico_signos_y_cierre(web, client, medico, pac):  # noqa: F811
    at = _atencion(client, medico, pac)
    _entrar(web)
    pagina = web.get(f"{P}/atenciones/{at}")
    assert "Registro clínico" in pagina.text and "Nueva nota SOAP" in pagina.text and "Nuevo diagnóstico" in pagina.text
    assert re.search(r"Nota SOAP\s*<strong>Falta", pagina.text) and re.search(r"Diagnóstico principal\s*<strong>Falta", pagina.text)

    # El cierre exige nota y diagnóstico principal: la regla es la de la máquina, no de la web.
    cierre = {"a_fase": "5", "tipo_egreso": "ALTA_MEDICA", "condicion_egreso": "Estable", "resumen_egreso": "Cefalea tensional resuelta", "plan_seguimiento": "Control en 15 días"}
    _post(web, at, "transicion", {"a_fase": "4"})
    r = _post(web, at, "transicion", cierre)
    assert r.status_code == 409 and "nota SOAP" in _texto(r)

    r = _post(web, at, "signos-vitales", {"ta_sistolica": "120", "ta_diastolica": "80", "fc": "72", "temperatura": "36,6", "peso_kg": "70", "talla_cm": "175"})
    assert r.status_code == 200 and "Signos vitales registrados." in r.text and "TA 120/80 mmHg" in r.text and "Temp 36.6" in r.text and "IMC 22.9" in r.text
    r = _post(web, at, "notas", NOTA)
    assert r.status_code == 200 and "Nota SOAP registrada." in r.text and "Cefalea de 2 días" in r.text
    r = _post(web, at, "diagnosticos", DX)
    assert r.status_code == 200 and "Diagnóstico registrado." in r.text and "G44.2" in r.text and "Principal" in r.text
    assert re.search(r"Nota SOAP\s*<strong>Sí", r.text) and re.search(r"Diagnóstico principal\s*<strong>Sí", r.text)

    r = _post(web, at, "transicion", cierre)
    assert r.status_code == 200 and "Atención cerrada." in r.text
    # Cerrada: la lectura por la atención activa termina; el registro ya no se ofrece para nuevas notas.
    r = web.get(f"{P}/atenciones/{at}/clinico")
    assert r.status_code == 200 and "terminó con el alta" in r.text and "Nueva nota SOAP" not in r.text
    assert _post(web, at, "notas", NOTA).status_code == 409  # la API lo rechaza: atención cerrada sin corrección
    # Bitácora: los registros salen por la misma vía que la API.
    assert _auditoria("REGISTRO_CLINICO") >= 3


def test_validaciones_y_reglas_de_la_api(web, client, medico, pac):  # noqa: F811
    at = _atencion(client, medico, pac)
    _entrar(web)
    r = _post(web, at, "notas", NOTA | {"plan": ""})
    assert r.status_code == 422 and "plan" in _texto(r) and "Cefalea de 2 días" in r.text  # conserva lo escrito
    r = _post(web, at, "diagnosticos", DX | {"codigo_cie10": "ZZZ"})
    assert r.status_code == 422 and "CIE-10" in _texto(r)
    assert _post(web, at, "signos-vitales", {}).status_code == 422  # al menos una medida
    assert _post(web, at, "signos-vitales", {"ta_sistolica": "80", "ta_diastolica": "90"}).status_code == 422
    assert _post(web, at, "diagnosticos", DX).status_code == 200
    r = _post(web, at, "diagnosticos", DX | {"codigo_cie10": "I10", "descripcion": "Hipertensión"})
    assert r.status_code == 409 and "diagnóstico principal vigente" in _texto(r)
    r = _post(web, at, "diagnosticos", DX | {"codigo_cie10": "I10", "descripcion": "Hipertensión", "principal": ""})
    assert r.status_code == 200  # comorbilidad
    assert sql("SELECT count(*) FROM diagnostico WHERE atencion_id = :a", a=at)[0][0] == 2


def test_nota_y_diagnostico_solo_en_fases_3_y_4(web, client, medico, pac):  # noqa: F811
    at = _atencion(client, medico, pac, fase3=False)  # queda en fase 1
    _entrar(web)
    pagina = web.get(f"{P}/atenciones/{at}")
    assert "Nueva nota SOAP" not in pagina.text and "fases 3 (Ejecución)" in pagina.text
    assert "Registrar signos vitales" in pagina.text  # los signos se toman desde la fase 1
    assert _post(web, at, "notas", NOTA).status_code == 409
    assert _post(web, at, "diagnosticos", DX).status_code == 409
    assert _post(web, at, "signos-vitales", {"fc": "80"}).status_code == 200


def test_correccion_versiona_y_no_edita(web, client, medico, pac):  # noqa: F811
    at = _atencion(client, medico, pac)
    _entrar(web)
    _post(web, at, "notas", NOTA)
    original = sql("SELECT id FROM nota_soap WHERE atencion_id = :a", a=at)[0][0]
    pagina = web.get(f"{P}/atenciones/{at}")
    r = web.post(f"{P}/atenciones/{at}/clinico/ver", data={"csrf_token": token_de(pagina.text), "corregir": str(original)})
    assert r.status_code == 200 and "Corregir nota SOAP" in r.text and "Cefalea de 2 días" in r.text and f'name="reemplaza_id" value="{original}"' in r.text
    # Sin motivo no se guarda; el formulario sigue siendo de corrección.
    r = _post(web, at, "notas", NOTA | {"reemplaza_id": str(original), "analisis": "Migraña"})
    assert r.status_code == 422 and "motivo_correccion" in _texto(r) and "Corregir nota SOAP" in r.text
    r = _post(web, at, "notas", NOTA | {"reemplaza_id": str(original), "analisis": "Migraña sin aura", "motivo_correccion": "Error de impresión"})
    assert r.status_code == 200 and "Corrección de la nota registrada." in r.text
    assert "Migraña sin aura" in r.text and "Cefalea tensional" not in r.text  # solo la vigente
    assert "Error de impresión" in r.text
    # El original sigue intacto; corregir dos veces el mismo es un conflicto.
    assert sql("SELECT analisis FROM nota_soap WHERE id = :i", i=str(original))[0][0] == "Cefalea tensional"
    r = _post(web, at, "notas", NOTA | {"reemplaza_id": str(original), "motivo_correccion": "Otra vez"})
    assert r.status_code == 409
    # Un id inventado nunca se precarga.
    r = web.post(f"{P}/atenciones/{at}/clinico/ver", data={"csrf_token": token_de(pagina.text), "corregir": "no-es-uuid"})
    assert r.status_code == 200 and "Corregir nota SOAP" not in r.text


def test_nivel_4_sale_restringido_y_se_abre_con_justificacion(web, client, medico, pac):  # noqa: F811
    at = _atencion(client, medico, pac)
    _entrar(web)
    r = _post(web, at, "diagnosticos", {"codigo_cie10": "F32.1", "descripcion": "Episodio depresivo moderado", "tipo": "DEFINITIVO", "principal": "on"})
    assert r.status_code == 200 and "Nivel 4" in r.text
    assert "Episodio depresivo" not in r.text and "F32" not in r.text and "Contenido de nivel 4 restringido" in r.text
    assert sql("SELECT codigo_cie10, contenido_cifrado IS NOT NULL FROM diagnostico WHERE atencion_id = :a", a=at)[0] == (None, True)
    # El principal cuenta para el cierre aunque su contenido esté cifrado.
    assert re.search(r"Diagnóstico principal\s*<strong>Sí", r.text)
    # Nota confidencial: también cifrada.
    r = _post(web, at, "notas", NOTA | {"confidencial": "on"})
    assert "Cefalea de 2 días" not in r.text and sql("SELECT subjetivo IS NULL FROM nota_soap WHERE atencion_id = :a", a=at)[0][0] is True

    pagina = web.get(f"{P}/atenciones/{at}")
    assert "Abrir nivel 4" in pagina.text and "Episodio depresivo" not in pagina.text
    previas = _auditoria("ACCESO_EXPEDIENTE")
    corta = web.post(f"{P}/atenciones/{at}/clinico/ver", data={"csrf_token": token_de(pagina.text), "justificacion": "corta"})
    assert "al menos 10 caracteres" in corta.text and "Episodio depresivo" not in corta.text
    ok = web.post(f"{P}/atenciones/{at}/clinico/ver", data={"csrf_token": token_de(pagina.text), "justificacion": "Seguimiento clínico del episodio"})
    assert ok.status_code == 200 and "Episodio depresivo moderado" in ok.text and "F32.1" in ok.text and "Cefalea de 2 días" in ok.text
    assert _auditoria("ACCESO_EXPEDIENTE") > previas
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'ACCESO_EXPEDIENTE' AND detalle->>'justificacion' = 'Seguimiento clínico del episodio'")[0][0] >= 1
    # Una recarga posterior vuelve a restringirlo: la justificación no se guarda en la sesión.
    assert "Episodio depresivo" not in web.get(f"{P}/atenciones/{at}/clinico").text


def test_atencion_de_salud_mental_cifra_todo(web, client, medico, pac):  # noqa: F811
    at = _atencion(client, medico, pac, area="Psiquiatría")
    _entrar(web)
    pagina = web.get(f"{P}/atenciones/{at}")
    assert "Esta atención es de nivel 4" in pagina.text and "Confidencial (nivel 4" not in pagina.text
    r = _post(web, at, "notas", NOTA)
    assert "Cefalea de 2 días" not in r.text
    assert sql("SELECT nivel_sensibilidad, subjetivo FROM nota_soap WHERE atencion_id = :a", a=at)[0] == (4, None)


def test_la_plantilla_se_vuelve_a_comprobar_en_cada_post(web, client, medico, pac):  # noqa: F811
    at = _atencion(client, medico, pac)
    _entrar(web)
    def rol(valor):
        with SessionLocal() as db:
            db.execute(text("UPDATE perfil_profesional SET rol_clave = :r WHERE persona_id = (SELECT id FROM persona WHERE dui = :d)"), {"r": valor, "d": DUI_MEDICO})
            db.commit()
    try:
        rol("radiologo_pacs")  # apoyo LIS: de consulta
        previas = _auditoria("WEB_AREA_DENEGADA")
        for ruta, campos in (("notas", NOTA), ("diagnosticos", DX), ("signos-vitales", {"fc": "70"})):
            assert _post(web, at, ruta, campos).status_code == 403
        assert _auditoria("WEB_AREA_DENEGADA") == previas + 3
        assert sql("SELECT count(*) FROM nota_soap WHERE atencion_id = :a", a=at)[0][0] == 0
        pagina = web.get(f"{P}/atenciones/{at}")
        assert "Nueva nota SOAP" not in pagina.text and "Registrar signos vitales" not in pagina.text
    finally:
        rol(None)


def test_permisos_de_las_plantillas():
    from types import SimpleNamespace as NS
    from web.profesional.roles import plantilla_de

    def p(tipo, rol):
        return plantilla_de(NS(profesional=NS(activo=True, tipo=tipo, especialidad=None, rol_clave=rol)))
    assert all(p("DOCTOR", "cardiologo").permite(a) for a in ("notar", "diagnosticar", "signos"))
    assert all(p("DOCTOR", "cirujano_general").permite(a) for a in ("notar", "diagnosticar", "signos"))
    enf = p("ENFERMERA", "enfermero_general")
    assert enf.permite("signos") and not enf.permite("notar") and not enf.permite("diagnosticar")
    for clave in ("radiologo_pacs", "analista_de_laboratorio", "epidemiologo"):
        assert not any(p("DOCTOR", clave).permite(a) for a in ("notar", "diagnosticar", "signos"))


def test_las_rutas_de_registro_exigen_csrf(web, client, medico, pac):  # noqa: F811
    at = _atencion(client, medico, pac)
    _entrar(web)
    for ruta in ("notas", "diagnosticos", "signos-vitales", "clinico/ver"):
        assert web.post(f"{P}/atenciones/{at}/{ruta}", data={"subjetivo": "x"}).status_code == 403
    assert sql("SELECT count(*) FROM nota_soap WHERE atencion_id = :a", a=at)[0][0] == 0


def test_el_contenido_clinico_se_escapa(web, client, medico, pac):  # noqa: F811
    at = _atencion(client, medico, pac)
    _entrar(web)
    r = _post(web, at, "notas", NOTA | {"subjetivo": '<script>alert("x")</script>'})
    assert r.status_code == 200 and "<script>alert" not in r.text and "&lt;script&gt;" in r.text
