"""Etapa 7 · parte 2c: /ciudadano · desbloqueo 2FA del nivel 4, «Quién consultó mi expediente» y aislamiento de la cookie.
Pruebas de humo y de permisos: el desbloqueo vive en la sesión web (el token nunca llega al navegador), se pierde al cerrar sesión, y la cookie
del ciudadano no abre ninguna URL de los otros portales."""
import html
import importlib
import re
import uuid

from fastapi.testclient import TestClient
from sqlalchemy import text

from main import app
from omega_core.database import SessionLocal
from omega_core.seed import DUI_MEDICO
from web.comun.portales import CIUDADANO, PORTALES

from .conftest import datos_persona
from .test_etapa2 import NAC, abrir, medico, paciente_id, sql  # noqa: F401
from .test_etapa4a import pac, pac_h  # noqa: F401
from .test_etapa7a import entrar_persona, h, nuevo, sesion_cookie, token_de, web  # noqa: F401  (web es un fixture)
from .test_etapa7d import _diag

EXP = "/ciudadano/expediente"
N4 = "/ciudadano/nivel4"
ACC = "/ciudadano/accesos"
HX = {"HX-Request": "true"}


def _entrar(web, persona):
    assert entrar_persona(web, CIUDADANO, persona["dui"], persona["password"]).status_code == 303
    return web


def _post(web, ruta, campos=None, pagina=N4):
    """POST con el token CSRF de la página indicada (necesita sesión abierta)."""
    return web.post(ruta, data={"csrf_token": token_de(web.get(pagina).text)} | (campos or {}))


def _desafio(web, volver="diagnosticos"):
    r = _post(web, f"{N4}/codigo", {"volver": volver})
    assert r.status_code == 200, r.text
    m = re.search(r'name="desafio_id" value="([0-9a-f-]{36})"', r.text)
    assert m, "no se mostró el formulario del código"
    return m.group(1)


def _verificar(web, desafio, codigo, volver="diagnosticos"):
    return _post(web, f"{N4}/verificar", {"desafio_id": desafio, "codigo": codigo, "volver": volver})


def _ejecutar(q, **p):
    with SessionLocal() as db:  # `sql` solo lee: para escribir hay que confirmar
        db.execute(text(q), p)
        db.commit()


def _con_vih(client, medico, pac):
    _diag(client, medico, abrir(client, medico, pac["dui"]), "B20", "Enfermedad por VIH")  # nivel 4


# ------------------------------------------------------------------ Sin sesión
def test_sin_sesion_las_rutas_nuevas_van_al_login(web):
    for ruta in (N4, ACC, f"{ACC}?pagina=2", f"{N4}?volver=vacunas"):
        r = web.get(ruta)
        assert r.status_code == 303 and r.headers["location"].startswith("/ciudadano/ingresar"), ruta
    for ruta in (f"{N4}/codigo", f"{N4}/verificar", f"{N4}/bloquear"):
        r = web.post(ruta, data={"desafio_id": str(uuid.uuid4()), "codigo": "123456"})
        assert r.status_code in (303, 403), ruta  # sin sesión no hay desbloqueo posible


# ------------------------------------------------------------------ Desbloqueo 2FA
def test_desbloqueo_2fa_abre_el_nivel4_en_esta_sesion_y_se_pierde_al_cerrar_sesion(web, client, medico, pac, codigos_2fa):  # noqa: F811
    _con_vih(client, medico, pac)
    _entrar(web, pac)
    antes = web.get(EXP)
    assert "1 registro protegido" in antes.text and "VIH" not in antes.text and "B20" not in antes.text
    assert f"{N4}?volver=diagnosticos" in antes.text  # enlace para abrirlo

    pagina = web.get(f"{N4}?volver=diagnosticos")
    assert pagina.status_code == 200 and "Enviarme el código" in pagina.text and pagina.headers["cache-control"] == "no-store"
    did = _desafio(web)
    assert len(codigos_2fa) == 1  # el código sale por el mismo servicio 2FA de la API

    mal = "000000" if codigos_2fa[-1] != "000000" else "111111"
    r = _verificar(web, did, mal)
    assert r.status_code == 401 and "Código inválido o vencido" in r.text and did in r.text  # se puede reintentar con el mismo desafío
    assert "VIH" not in web.get(EXP).text  # un intento fallido no abre nada

    r = _verificar(web, did, "12ab")  # formato incorrecto: no gasta un intento
    assert r.status_code == 422 and "6 dígitos" in r.text
    ok = _verificar(web, did, codigos_2fa[-1])
    assert ok.status_code == 303 and ok.headers["location"] == f"{EXP}?seccion=diagnosticos"

    abierto = web.get(EXP)
    assert abierto.status_code == 200 and "Enfermedad por VIH" in abierto.text and "B20" in abierto.text and "abiertos hasta" in abierto.text
    assert abierto.headers["cache-control"] == "no-store"
    assert "Enfermedad por VIH" in web.get(f"{EXP}/diagnosticos", headers=HX).text  # también el fragmento HTMX
    assert "1 registro protegido" not in abierto.text
    fila = sql("SELECT n4_desbloqueo_id FROM sesion_web WHERE token_hash = :h", h=h(sesion_cookie(web)))[0][0]
    assert fila is not None
    assert sql("SELECT revocado_en FROM desbloqueo_nivel4 WHERE id = :i", i=fila) == [(None,)]
    # el token nunca llega al navegador: ni en la página ni como cookie (la sesión solo guarda el id del desbloqueo, en el servidor)
    assert "X-Desbloqueo" not in abierto.text and {c for c in web.cookies.keys()} <= {CIUDADANO.cookie_sesion, CIUDADANO.cookie_csrf}
    auditoria = [a[0] for a in sql("SELECT accion FROM auditoria WHERE actor_id = :p ORDER BY id", p=paciente_id(pac["dui"]))]
    assert "PORTAL_NIVEL4_DESAFIO" in auditoria and auditoria.count("PORTAL_NIVEL4_DESBLOQUEO") == 2  # un fallo y un éxito, ambos en la bitácora
    abiertos = sql("SELECT detalle->>'nivel4_abierto' FROM auditoria WHERE accion = 'PORTAL_LECTURA_PROPIA' AND actor_id = :p ORDER BY id DESC LIMIT 1", p=paciente_id(pac["dui"]))
    assert abiertos == [("true",)]

    # cerrar sesión: el desbloqueo se revoca y una sesión nueva empieza bloqueada
    valor = sesion_cookie(web)
    assert _post(web, "/ciudadano/salir", pagina="/ciudadano/panel").status_code == 303
    assert sql("SELECT revocado_en IS NOT NULL FROM desbloqueo_nivel4 WHERE id = :i", i=fila) == [(True,)]
    assert sql("SELECT n4_desbloqueo_id FROM sesion_web WHERE token_hash = :h", h=h(valor)) == [(None,)]
    web.cookies.set(CIUDADANO.cookie_sesion, valor, path="/ciudadano")
    assert web.get(EXP).status_code == 303  # la cookie vieja no sirve
    nuevo_nav = _entrar(nuevo(50131), pac)
    t = nuevo_nav.get(EXP).text
    assert "VIH" not in t and "B20" not in t and "1 registro protegido" in t


def test_el_desbloqueo_es_de_una_sola_sesion(web, client, medico, pac, codigos_2fa):  # noqa: F811
    _con_vih(client, medico, pac)
    uno, otro = _entrar(web, pac), _entrar(nuevo(50132), pac)
    assert _verificar(uno, _desafio(uno), codigos_2fa[-1]).status_code == 303
    assert "Enfermedad por VIH" in uno.get(EXP).text
    t = otro.get(EXP).text  # la misma persona en otro navegador sigue bloqueada
    assert "VIH" not in t and "1 registro protegido" in t


def test_limite_de_intentos_del_desafio(web, client, medico, pac, codigos_2fa):  # noqa: F811
    _con_vih(client, medico, pac)
    _entrar(web, pac)
    did = _desafio(web)
    correcto = codigos_2fa[-1]
    mal = "000000" if correcto != "000000" else "111111"
    for _ in range(5):  # MAX_INTENTOS del backend
        assert _verificar(web, did, mal).status_code == 401
    r = _verificar(web, did, correcto)  # agotado: ni el código correcto lo abre
    assert r.status_code in (401, 429) and "Enfermedad por VIH" not in web.get(EXP).text
    assert sql("SELECT n4_desbloqueo_id FROM sesion_web WHERE token_hash = :h", h=h(sesion_cookie(web))) == [(None,)]
    did2 = _desafio(web)  # un código nuevo sí funciona
    assert _verificar(web, did2, codigos_2fa[-1]).status_code == 303


def test_limite_de_solicitudes_de_codigo(web, pac, codigos_2fa):  # noqa: F811
    _entrar(web, pac)
    for _ in range(5):
        assert _post(web, f"{N4}/codigo").status_code == 200
    r = _post(web, f"{N4}/codigo")
    assert r.status_code == 429 and "Demasiadas solicitudes" in r.text and len(codigos_2fa) == 5


def test_un_desafio_ajeno_o_inventado_no_desbloquea(web, client, medico, pac, codigos_2fa):  # noqa: F811
    _con_vih(client, medico, pac)
    otra = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=otra).status_code == 201
    ajena = _entrar(nuevo(50133), otra)
    did_ajeno = _desafio(ajena)
    codigo_ajeno = codigos_2fa[-1]
    _entrar(web, pac)
    r = _verificar(web, did_ajeno, codigo_ajeno)  # el desafío y el código de OTRA persona
    assert r.status_code == 401 and "VIH" not in web.get(EXP).text
    assert _verificar(web, str(uuid.uuid4()), "123456").status_code == 401
    assert _verificar(web, "no-es-un-uuid", "123456").status_code == 401
    assert sql("SELECT n4_desbloqueo_id FROM sesion_web WHERE token_hash = :h", h=h(sesion_cookie(web))) == [(None,)]
    # la persona ajena sí abre lo SUYO, pero no el expediente de pac
    assert _verificar(ajena, did_ajeno, codigo_ajeno).status_code == 303
    t = ajena.get(EXP, params={"dui": pac["dui"], "persona_id": paciente_id(pac["dui"])}).text
    assert "VIH" not in t and pac["dui"] not in t


def test_el_desbloqueo_vence_y_se_puede_ocultar_antes(web, client, medico, pac, codigos_2fa):  # noqa: F811
    _con_vih(client, medico, pac)
    _entrar(web, pac)
    assert _verificar(web, _desafio(web), codigos_2fa[-1]).status_code == 303
    assert "Enfermedad por VIH" in web.get(EXP).text
    fila = sql("SELECT n4_desbloqueo_id FROM sesion_web WHERE token_hash = :h", h=h(sesion_cookie(web)))[0][0]
    _ejecutar("UPDATE desbloqueo_nivel4 SET expira_en = now() - interval '1 second' WHERE id = :i", i=fila)  # vence
    t = web.get(EXP).text
    assert "VIH" not in t and "1 registro protegido" in t  # vuelve a quedar bloqueado, sin error
    assert sql("SELECT n4_desbloqueo_id FROM sesion_web WHERE token_hash = :h", h=h(sesion_cookie(web))) == [(None,)]

    assert _verificar(web, _desafio(web), codigos_2fa[-1]).status_code == 303  # se abre otra vez…
    assert "Enfermedad por VIH" in web.get(EXP).text
    r = _post(web, f"{N4}/bloquear", {"volver": "diagnosticos"}, pagina=EXP)  # …y «Ocultar ahora» lo cierra
    assert r.status_code == 303 and r.headers["location"] == f"{EXP}?seccion=diagnosticos"
    assert "VIH" not in web.get(EXP).text
    assert "PORTAL_NIVEL4_BLOQUEO" in [a[0] for a in sql("SELECT accion FROM auditoria WHERE actor_id = :p", p=paciente_id(pac["dui"]))]


def test_las_rutas_de_desbloqueo_exigen_csrf(web, pac, codigos_2fa):  # noqa: F811
    _entrar(web, pac)
    for ruta in (f"{N4}/codigo", f"{N4}/verificar", f"{N4}/bloquear"):
        assert web.post(ruta, data={"desafio_id": str(uuid.uuid4()), "codigo": "123456"}).status_code == 403, ruta
    assert codigos_2fa == []  # sin token no se envía ningún código


# ------------------------------------------------------------------ Quién consultó mi expediente
def test_quien_consulto_muestra_solo_quien_institucion_fecha_y_motivo(web, client, medico, pac, pac_h, codigos_2fa):  # noqa: F811
    dui = pac["dui"]
    at = abrir(client, medico, dui)
    _diag(client, medico, at, "B20", "Enfermedad por VIH")
    assert client.get(f"/expediente/{dui}", headers=medico, params={"justificacion": "Valoración confidencial de riesgo suicida"}).status_code == 200
    client.get("/portal/mi-expediente/diagnosticos", headers=pac_h)  # mi propia lectura: no debe aparecer
    esperado = client.get("/portal/accesos", headers=pac_h).json()["items"]
    assert esperado and esperado[0]["tipo"] == "PROFESIONAL"

    r = _entrar(web, pac).get(ACC)
    assert r.status_code == 200 and r.headers["cache-control"] == "no-store"
    texto = r.text
    assert html.escape(esperado[0]["accedio"]) in texto
    assert esperado[0]["establecimiento"] and html.escape(esperado[0]["establecimiento"]) in texto
    assert "Atención médica en curso" in texto  # motivo
    assert texto.count('<li class="registro">') == len(esperado)
    assert re.search(r"Fecha</dt><dd>\d{1,2} de \w+ de \d{4}, \d{1,2}:\d{2} [ap]\. m\.", texto)  # fecha legible
    # sin datos clínicos ni internos: ni diagnóstico, ni justificación, ni IP, ni sección, ni la propia lectura
    for prohibido in ("VIH", "B20", "riesgo suicida", "justificacion", "127.0.0.1", "testclient", "hash", "nivel 4", "nivel4", "resumen", "diagnosticos", pac["dui"]):
        assert prohibido not in texto, prohibido
    assert "PORTAL_ACCESOS_CONSULTADOS" in [a[0] for a in sql("SELECT accion FROM auditoria WHERE actor_id = :p", p=paciente_id(dui))]  # consultar la lista también queda en la bitácora


def test_quien_consulto_es_siempre_el_de_la_sesion_y_pagina(web, client, medico, pac):
    otra = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=otra).status_code == 201
    abrir(client, medico, pac["dui"])
    for _ in range(12):
        assert client.get(f"/expediente/{pac['dui']}", headers=medico).status_code == 200
    nav = _entrar(web, pac)
    p1, p2 = nav.get(ACC).text, nav.get(f"{ACC}?pagina=2").text
    assert p1.count('<li class="registro">') == 10 and "Siguiente" in p1 and "Anterior" not in p1
    assert p2.count('<li class="registro">') == 2 and "Anterior" in p2 and "Siguiente" not in p2
    assert "No hay más consultas" in nav.get(f"{ACC}?pagina=3").text
    for malo in ("0", "-1", "abc", "99999"):
        assert nav.get(f"{ACC}?pagina={malo}").status_code == 422, malo
    # otra persona, aunque manipule parámetros, no ve las consultas de pac
    ajena = _entrar(nuevo(50134), otra)
    t = ajena.get(ACC, params={"dui": pac["dui"], "persona_id": paciente_id(pac["dui"]), "id": paciente_id(pac["dui"])}).text
    assert "Nadie ha consultado" in t and t.count('<li class="registro">') == 0
    for metodo in ("post", "put", "patch", "delete"):
        assert getattr(nav, metodo)(ACC).status_code in (403, 405), metodo  # solo lectura


# ------------------------------------------------------------------ Aislamiento: la cookie de /ciudadano no abre otros portales
def _rutas_de_otros_portales():
    """Todas las rutas web REALES de los portales distintos de ciudadano, leídas de los routers de cada portal (con su prefijo ya aplicado).
    Se leen de los routers y no de `app.routes` porque las versiones recientes de FastAPI no aplanan los routers incluidos."""
    for p in PORTALES:
        if p is CIUDADANO:
            continue
        for r in importlib.import_module(f"web.{p.slug}.router").router.routes:
            path, metodos = getattr(r, "path", ""), getattr(r, "methods", None) or set()
            if (path == p.base or path.startswith(p.base + "/")) and "/static" not in path:
                yield p, re.sub(r"\{[^}]+\}", str(uuid.uuid4()), path), metodos


def test_la_cookie_de_ciudadano_no_abre_ninguna_url_de_otro_portal(web):
    assert entrar_persona(web, CIUDADANO, *_credenciales_medico()).status_code == 303  # persona con perfil profesional: el caso más tentador
    assert web.get("/ciudadano/panel").status_code == 200
    valor = sesion_cookie(web)
    rutas = list(_rutas_de_otros_portales())
    assert len(rutas) > 10 and {p.slug for p, _, _ in rutas} == {p.slug for p in PORTALES if p is not CIUDADANO}  # se probó cada portal

    # (a) el navegador del ciudadano (jar normal) y (b) la cookie inyectada con el nombre y la ruta de CADA otro portal
    inyectado = TestClient(app, client=("127.0.0.1", 50135), follow_redirects=False, raise_server_exceptions=False)
    for p in PORTALES:
        if p is not CIUDADANO:
            inyectado.cookies.set(p.cookie_sesion, valor, path=p.base)
    inyectado.cookies.set(CIUDADANO.cookie_sesion, valor, path="/")  # incluso con Path=/ para que viaje a todas partes
    for navegador in (web, inyectado):
        for p, ruta, metodos in rutas:
            publica = ruta.endswith(("/ingresar", "/ingresar/2fa", "/registro"))
            if "GET" in metodos:
                r = navegador.get(ruta)
                if publica:
                    assert r.status_code in (200, 303, 404, 405), (p.slug, ruta)  # páginas de login/registro del propio portal: públicas
                    assert "Salir" not in r.text  # y se muestran SIN sesión: la cabecera no ofrece «Salir»
                elif r.status_code in (301, 302, 303, 307):
                    assert "/ingresar" in r.headers["location"], (p.slug, ruta, r.headers["location"])  # lo manda al login, no a un panel
                else:
                    assert r.status_code in (401, 403, 404, 405, 422), (p.slug, ruta, r.status_code)
            for m in metodos - {"GET", "HEAD", "OPTIONS"}:
                r = navegador.request(m, ruta, data={"x": "1"})
                assert not 200 <= r.status_code < 300, (p.slug, m, ruta, r.status_code)  # ningún cambio de estado pasa con esa cookie
    # la sesión del ciudadano sigue intacta (ninguno de esos intentos la revocó) y no autentica la API JSON
    assert sql("SELECT revocada FROM sesion_web WHERE token_hash = :h", h=h(valor)) == [(False,)]
    assert web.get("/ciudadano/panel").status_code == 200
    assert inyectado.get("/portal/accesos").status_code == 401 and inyectado.get("/auditoria").status_code in (401, 403, 404)


def _credenciales_medico():
    from omega_core.seed import PASSWORD_MEDICO
    return DUI_MEDICO, PASSWORD_MEDICO
