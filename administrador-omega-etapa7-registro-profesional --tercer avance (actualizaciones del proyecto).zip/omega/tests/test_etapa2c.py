import json

from omega_core.security.campos import descifrar_json
from omega_core.seed import DUI_MEDICO

from .conftest import datos_persona, dui_nuevo
from .test_etapa2 import abrir, acciones_auditoria, auth, medico, nota, paciente_id, sql  # noqa: F401
from .test_etapa2b import EGRESO, trans

SECRETO = "Paciente con ideacion suicida pasiva, en seguimiento"


def alta_completa(client, medico, d):
    """Atención hasta el alta (fase 5) con una nota normal, una nota psiquiátrica nivel 4 y un diagnóstico de VIH (nivel 4)."""
    at = abrir(client, medico, d["dui"])
    n2 = client.post(f"/atenciones/{at}/notas", headers=medico, json=nota()).json()
    n4 = client.post(f"/atenciones/{at}/notas", headers=medico, json=nota(subjetivo=SECRETO, confidencial=True)).json()
    assert client.post(f"/atenciones/{at}/diagnosticos", headers=medico,
                       json={"codigo_cie10": "J06.9", "descripcion": "IVRA", "tipo": "DEFINITIVO", "principal": True}).status_code == 201
    assert client.post(f"/atenciones/{at}/diagnosticos", headers=medico,
                       json={"codigo_cie10": "B20", "descripcion": "VIH", "tipo": "DEFINITIVO"}).json()["nivel_sensibilidad"] == 4
    assert trans(client, medico, at, 4).status_code == 200
    r = trans(client, medico, at, 5, egreso=EGRESO)
    assert r.status_code == 200 and r.json()["estado"] == "CERRADA"
    return at, n2, n4


def login(client, d):
    r = client.post("/auth/login/persona", json={"dui": d["dui"], "password": d["password"]})
    assert r.status_code == 200, r.text
    return auth(r.json()["tokens"]["access_token"])


def test_acceso_por_atencion_activa_consentimiento_y_auditoria(client, medico):
    d = datos_persona()
    client.post("/personas", json=d)
    pid = paciente_id(d["dui"])
    pac = login(client, d)
    # sin atención ni consentimiento: denegado y auditado; mismo mensaje exista o no el DUI
    r1 = client.get(f"/expediente/{d['dui']}", headers=medico)
    r2 = client.get(f"/expediente/{dui_nuevo()}", headers=medico)
    assert r1.status_code == r2.status_code == 403 and r1.json() == r2.json()
    assert "ACCESO_EXPEDIENTE_DENEGADO" in acciones_auditoria(pid)
    # con atención activa: permitido y auditado
    at = abrir(client, medico, d["dui"], fase3=False)
    assert client.get(f"/expediente/{d['dui']}", headers=medico).status_code == 200
    assert acciones_auditoria(pid).count("ACCESO_EXPEDIENTE") >= 1
    # el alta cierra el episodio y con él el acceso
    client.post(f"/atenciones/{at}/transicion", headers=medico, json={"a_fase": 2, "identidad_verificada": True, "antecedentes_revisados": True})
    assert client.get(f"/expediente/{d['dui']}", headers=medico).status_code == 200  # sigue abierta


def test_alta_consentimiento_y_nivel4(client, medico):
    d = datos_persona()
    client.post("/personas", json=d)
    pid, pac = paciente_id(d["dui"]), login(client, d)
    at, n2, n4 = alta_completa(client, medico, d)
    # --- alta: resumen de egreso y plan de seguimiento guardados; episodio cerrado
    assert sql("SELECT estado, fase, cierre_tipo FROM atencion WHERE id = :i", i=at) == [("CERRADA", 5, "ALTA_MEDICA")]
    assert sql("SELECT resumen, plan_seguimiento FROM egreso WHERE atencion_id = :i", i=at) == [(EGRESO["resumen_egreso"], EGRESO["plan_seguimiento"])]
    # --- sin atención activa ya no hay acceso
    assert client.get(f"/expediente/{d['dui']}/notas", headers=medico).status_code == 403
    # --- consentimiento a profesional (sin nivel 4)
    c = client.post("/mi-expediente/consentimientos", headers=pac, json={"profesional_dui": DUI_MEDICO, "dias": 7})
    assert c.status_code == 201, c.text
    r = client.get(f"/expediente/{d['dui']}/notas", params={"justificacion": "Control de seguimiento clínico"}, headers=medico)
    assert r.status_code == 200
    items = {i["id"]: i for i in r.json()["items"]}
    assert items[n2["id"]]["restringido"] is False and items[n2["id"]]["datos"]["plan"] == "Paracetamol"
    assert items[n4["id"]]["restringido"] is True and items[n4["id"]]["datos"] is None and SECRETO not in json.dumps(r.json())
    eg = client.get(f"/expediente/{d['dui']}/egresos", headers=medico).json()["items"]
    assert eg and eg[0]["datos"]["plan_seguimiento"] == EGRESO["plan_seguimiento"]
    # --- consentimiento con nivel 4 + justificación obligatoria
    c4 = client.post("/mi-expediente/consentimientos", headers=pac, json={"profesional_dui": DUI_MEDICO, "dias": 7, "incluye_nivel4": True}).json()
    sin = client.get(f"/expediente/{d['dui']}/notas", headers=medico).json()
    assert SECRETO not in json.dumps(sin)  # sin justificación sigue restringido
    assert client.get(f"/expediente/{d['dui']}/notas", params={"justificacion": "corta"}, headers=medico).status_code == 422
    con = client.get(f"/expediente/{d['dui']}/notas", params={"justificacion": "Valoración de riesgo suicida en urgencias"}, headers=medico)
    assert SECRETO in json.dumps(con.json())
    det = sql("SELECT detalle FROM auditoria WHERE recurso_id = :r AND accion = 'ACCESO_EXPEDIENTE' ORDER BY id DESC LIMIT 1", r=pid)[0][0]
    assert "Valoración de riesgo" in json.dumps(det, ensure_ascii=False)  # la justificación queda en la bitácora
    # --- el paciente ve su expediente, pero no abre el contenido nivel 4
    mio = client.get("/mi-expediente/notas", headers=pac)
    assert mio.status_code == 200 and SECRETO not in json.dumps(mio.json())
    # --- revocar: efecto inmediato
    for cid in {c.json()["id"], c4["id"]}:
        assert client.post(f"/mi-expediente/consentimientos/{cid}/revocar", headers=pac).status_code == 200
    assert client.get(f"/expediente/{d['dui']}/notas", headers=medico).status_code == 403
    assert "CONSENTIMIENTO_REVOCADO" in acciones_auditoria(c4["id"])
    # otro paciente no puede revocar/otorgar sobre mi expediente
    otro = datos_persona()
    client.post("/personas", json=otro)
    assert client.post(f"/mi-expediente/consentimientos/{c4['id']}/revocar", headers=login(client, otro)).status_code == 404


def test_nivel4_cifrado_con_campos_py_y_clave_del_env(client, medico):
    d = datos_persona()
    client.post("/personas", json=d)
    _, _, n4 = alta_completa(client, medico, d)
    fila = sql("SELECT contenido_cifrado, subjetivo FROM nota_soap WHERE id = :i", i=n4["id"])[0]
    assert fila[1] is None and SECRETO not in fila[0]
    assert descifrar_json(fila[0])["subjetivo"] == SECRETO  # Fernet con CLAVE_CAMPOS vía security/campos.py
    vih = sql("SELECT codigo_cie10, descripcion, contenido_cifrado FROM diagnostico WHERE paciente_id = :p AND nivel_sensibilidad = 4", p=paciente_id(d["dui"]))
    assert vih and vih[0][1] is None and vih[0][2]
