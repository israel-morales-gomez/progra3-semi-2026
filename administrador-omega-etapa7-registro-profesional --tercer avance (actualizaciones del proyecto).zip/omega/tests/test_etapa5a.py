import json
import uuid
from datetime import date, timedelta

import pytest
from sqlalchemy import event, text
from sqlalchemy.exc import DBAPIError

from omega_core.database import SessionLocal, engine
from omega_core.seed import DUI_MEDICO, NIT_FARMACIA, NIT_HOSPITAL, PASSWORD_FARMACIA, PASSWORD_HOSPITAL

from .conftest import datos_persona, dui_nuevo, nit_nuevo
from .test_etapa2 import NAC, abrir, acciones_auditoria, auth, medico, ml, paciente_id, sql  # noqa: F401
from .test_etapa2c import login
from .test_etapa3a import AMOX, PARA, PIN, canje, farmacia, firmado  # noqa: F401
from .test_etapa3c import HEMO, lab, registrar_lab  # noqa: F401

DIAG = {"codigo_cie10": "J06.9", "descripcion": "Infección respiratoria aguda de vías superiores", "tipo": "DEFINITIVO", "principal": True}


# ------------------------------------------------------------------ Fixtures y ayudas
@pytest.fixture
def hospital(client, codigos_2fa):
    r = client.post("/auth/login/institucion", json={"identificador": NIT_HOSPITAL, "password": PASSWORD_HOSPITAL})
    assert r.status_code == 200 and r.json()["requiere_2fa"] is True, r.text
    r = client.post("/auth/2fa/verificar", json={"desafio_id": r.json()["desafio_id"], "codigo": codigos_2fa[-1]})
    assert r.status_code == 200, r.text
    return auth(r.json()["tokens"]["access_token"])


@pytest.fixture
def universidad(client, omega_headers):
    d = {"tipo": "UNIVERSIDAD", "nombre_legal": "Universidad de Prueba", "nit": nit_nuevo(), "credencial_autorizacion": f"MINED-{uuid.uuid4().hex[:6]}", "departamento": "San Salvador",
         "municipio": "San Salvador", "direccion": "Campus central", "telefono": "2200-0000", "correo": f"{uuid.uuid4().hex[:8]}@uni.edu.sv", "responsable_nombre": "Dr. Decano", "responsable_cargo": "Coordinador de prácticas",
         "responsable_dui": dui_nuevo(), "responsable_correo": "decano@uni.edu.sv", "responsable_telefono": "7000-1111", "password": "UniClave12345"}
    r = client.post("/instituciones", json=d)
    assert r.status_code == 201, r.text
    uid = r.json()["id"]
    assert client.patch(f"/omega/instituciones/{uid}/estado", json={"estado": "ACTIVA", "motivo": "Credenciales verificadas"}, headers=omega_headers).status_code == 200
    return uid


def crear_estudiante(client, omega_headers, uni_id, verificar=True, con_universidad=True):
    d = datos_persona(fecha_nacimiento=NAC, estudiante={"carne": f"C{uuid.uuid4().hex[:8]}", "universidad_nombre": "Universidad de Prueba", "carrera": "Doctorado en Medicina", "ciclo": "Internado rotatorio",
                                                         "correo_institucional": f"{uuid.uuid4().hex[:8]}@uni.edu.sv", **({"universidad_id": uni_id} if con_universidad else {})})
    r = client.post("/personas", json=d)
    assert r.status_code == 201, r.text
    if verificar:
        pid = r.json()["id"]
        assert client.patch(f"/omega/personas/{pid}/verificacion", headers=omega_headers, json={"perfil": "estudiante", "verificado": True, "motivo": "Carné verificado"}).status_code == 200
    return d, login(client, d)


def asignar(client, hospital, est, nivel="INTERNADO", tutor=DUI_MEDICO, **kw):
    return client.post("/practicas", headers=hospital, json={"estudiante_dui": est["dui"], "tutor_dui": tutor, "nivel": nivel} | kw)


@pytest.fixture
def interno(client, omega_headers, hospital, universidad):
    d, h = crear_estudiante(client, omega_headers, universidad)
    r = asignar(client, hospital, d)
    assert r.status_code == 201, r.text
    return {"dui": d["dui"], "h": h, "asig": r.json()["id"], "uni": universidad}


@pytest.fixture
def pac(client):
    d = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=d).status_code == 201
    return d


def borrador_diag(client, h, at, **kw):
    return client.post("/practica/borradores/diagnostico", headers=h, json={"atencion_id": at} | DIAG | kw)


def borrador_rx(client, h, at, meds=(AMOX,), **kw):
    return client.post("/practica/borradores/receta", headers=h, json={"atencion_id": at, "medicamentos": list(meds)} | kw)


def borrador_ol(client, h, at, lab_id, **kw):
    return client.post("/practica/borradores/orden-lab", headers=h, json={"atencion_id": at, "tipo": "LABORATORIO", "laboratorio_id": lab_id, "estudios": [HEMO]} | kw)


def medico_nuevo(client, omega_headers):
    """Segundo médico verificado del mismo hospital (no es el tutor)."""
    hid = sql("SELECT id FROM institucion WHERE nit = :n", n=NIT_HOSPITAL)[0][0]
    d = datos_persona(fecha_nacimiento=NAC, profesional={"tipo": "DOCTOR", "especialidad": "Cardiología", "numero_junta": f"J{uuid.uuid4().hex[:7]}", "institucion_id": str(hid)})
    r = client.post("/personas", json=d)
    assert r.status_code == 201, r.text
    assert client.patch(f"/omega/personas/{r.json()['id']}/verificacion", headers=omega_headers, json={"perfil": "profesional", "verificado": True, "motivo": "JVPM verificada"}).status_code == 200
    return login(client, d)


def cofirmar(client, med, bid, accion="aprobar", **body):
    return client.post(f"/cofirma/borradores/{bid}/{accion}", headers=med, json=body)


def tabla(t, pid):
    return sql(f"SELECT count(*) FROM {t} WHERE paciente_id = :p", p=pid)[0][0]


# ------------------------------------------------------------------ Asignación (hospital)
def test_asignacion_valida_estudiante_tutor_y_unicidad(client, omega_headers, hospital, universidad, farmacia, medico):
    # estudiante sin verificar / sin universidad → 422
    d, _ = crear_estudiante(client, omega_headers, universidad, verificar=False)
    assert asignar(client, hospital, d).status_code == 422
    d, _ = crear_estudiante(client, omega_headers, universidad, con_universidad=False)
    assert asignar(client, hospital, d).status_code == 422
    d, h = crear_estudiante(client, omega_headers, universidad)
    # tutor que no es médico de este centro / persona inexistente / el mismo estudiante
    civil = datos_persona()
    client.post("/personas", json=civil)
    assert asignar(client, hospital, d, tutor=civil["dui"]).status_code == 422
    assert asignar(client, hospital, d, tutor=dui_nuevo()).status_code == 422
    assert asignar(client, hospital, d, tutor=d["dui"]).status_code == 422
    assert asignar(client, hospital, d, nivel="CIRUJANO").status_code == 422
    # sin asignación el estudiante no puede operar
    assert client.get("/practica/mi-asignacion", headers=h).status_code == 403
    r = asignar(client, hospital, d, nivel="PRIMER_ANO_CLINICA")
    assert r.status_code == 201, r.text
    a = r.json()
    assert a["nivel"] == "PRIMER_ANO_CLINICA" and a["tutor"]["dui"] == DUI_MEDICO and a["universidad_id"] == universidad and a["activa"]
    assert any("signos vitales" in x for x in a["alcance"]) and not any("borradores" in x for x in a["alcance"])
    assert asignar(client, hospital, d).status_code == 409  # una sola asignación activa
    mi = client.get("/practica/mi-asignacion", headers=h).json()
    assert mi["id"] == a["id"]
    assert a["id"] in [x["id"] for x in client.get("/practicas", headers=hospital).json()]
    # solo hospitales/clínicas; ni farmacia, ni médico, ni estudiante
    assert client.post("/practicas", headers=farmacia, json={"estudiante_dui": d["dui"], "tutor_dui": DUI_MEDICO, "nivel": "INTERNADO"}).status_code == 403
    assert client.post("/practicas", headers=medico, json={"estudiante_dui": d["dui"], "tutor_dui": DUI_MEDICO, "nivel": "INTERNADO"}).status_code in (401, 403)
    assert client.post("/practicas", headers=h, json={"estudiante_dui": d["dui"], "tutor_dui": DUI_MEDICO, "nivel": "INTERNADO"}).status_code in (401, 403)
    assert client.post("/practicas", headers=hospital, json={"estudiante_dui": d["dui"], "tutor_dui": DUI_MEDICO, "nivel": "INTERNADO", "extra": 1}).status_code == 422
    assert acciones_auditoria(a["id"]) == ["PRACTICA_ASIGNADA"]
    # finalizar
    assert client.post(f"/practicas/{a['id']}/finalizar", headers=hospital, json={"motivo": "x"}).status_code == 422
    assert client.post(f"/practicas/{a['id']}/finalizar", headers=hospital, json={"motivo": "Fin de la rotación"}).json()["activa"] is False
    assert client.post(f"/practicas/{a['id']}/finalizar", headers=hospital, json={"motivo": "Fin de la rotación"}).status_code == 409
    assert client.get("/practica/mi-asignacion", headers=h).status_code == 403
    assert acciones_auditoria(a["id"]) == ["PRACTICA_ASIGNADA", "PRACTICA_FINALIZADA"]


# ------------------------------------------------------------------ Alcance por nivel
def test_primer_ano_solo_lee_y_toma_signos(client, omega_headers, hospital, universidad, medico, pac):
    d, h = crear_estudiante(client, omega_headers, universidad)
    asignar(client, hospital, d, nivel="PRIMER_ANO_CLINICA")
    dui = pac["dui"]
    at = abrir(client, medico, dui)
    client.post(f"/atenciones/{at}/diagnosticos", headers=medico, json=DIAG)
    client.post(f"/atenciones/{at}/diagnosticos", headers=medico, json={"codigo_cie10": "F32.1", "descripcion": "Episodio depresivo moderado", "tipo": "DEFINITIVO"})
    # otra atención abierta sin médico responsable (fase 1): el estudiante no la ve
    otro = datos_persona(fecha_nacimiento=NAC)
    client.post("/personas", json=otro)
    at_ajena = abrir(client, medico, otro["dui"], fase3=False)
    lista = client.get("/practica/atenciones", headers=h).json()
    assert at in [a["id"] for a in lista] and at_ajena not in [a["id"] for a in lista]
    # lectura solo lectura; el nivel 4 nunca se abre
    r = client.get(f"/practica/atenciones/{at}/expediente/diagnosticos", headers=h)
    assert r.status_code == 200
    items = r.json()["items"]
    assert any(i["datos"]["codigo_cie10"] == "J06.9" for i in items if not i["restringido"])
    assert r.json()["restringidos"] == 1 and "F32" not in json.dumps(r.json()) and "depresivo" not in json.dumps(r.json())
    assert client.get(f"/practica/atenciones/{at_ajena}/expediente/diagnosticos", headers=h).status_code == 404
    assert client.get(f"/practica/atenciones/{at}/expediente/diagnosticos", params={"justificacion": "quiero ver todo ahora"}, headers=h).json()["restringidos"] == 1
    for m in ("post", "put", "patch", "delete"):
        assert getattr(client, m)(f"/practica/atenciones/{at}/expediente/diagnosticos", headers=h).status_code == 405
    # signos vitales: sí; quedan a nombre del estudiante y con el tutor supervisor en la bitácora
    r = client.post(f"/practica/atenciones/{at}/signos-vitales", headers=h, json={"ta_sistolica": 118, "ta_diastolica": 76, "fc": 72})
    assert r.status_code == 201, r.text
    ac = sql("SELECT detalle FROM auditoria WHERE recurso_id = :r AND accion = 'REGISTRO_CLINICO'", r=r.json()["id"])[0][0]
    assert ac["redactado_por"] == paciente_id(d["dui"]) and ac["autorizado_por"] == paciente_id(DUI_MEDICO)
    assert sql("SELECT registrado_por FROM signos_vitales WHERE id = :i", i=r.json()["id"])[0][0] == uuid.UUID(paciente_id(d["dui"]))
    assert client.post(f"/practica/atenciones/{at_ajena}/signos-vitales", headers=h, json={"fc": 70}).status_code == 404
    assert client.post(f"/practica/atenciones/{at}/signos-vitales", headers=h, json={"fc": 70, "reemplaza_id": str(uuid.uuid4()), "motivo_correccion": "corrijo yo"}).status_code == 422
    # nada más: ni borradores ni registros clínicos directos
    for ruta in ("/practica/borradores/diagnostico", "/practica/borradores/receta", "/practica/borradores/orden-lab"):
        body = {"atencion_id": at} | ({"medicamentos": [AMOX]} if "receta" in ruta else {"tipo": "LABORATORIO", "laboratorio_id": str(uuid.uuid4()), "estudios": [HEMO]} if "orden" in ruta else DIAG)
        assert client.post(ruta, headers=h, json=body).status_code == 403
    assert client.post(f"/atenciones/{at}/diagnosticos", headers=h, json=DIAG).status_code == 403
    assert client.post("/recetas", headers=h, json={"dui": dui, "pin": PIN, "medicamentos": [AMOX]}).status_code in (401, 403)
    assert client.get(f"/expediente/{dui}", headers=h).status_code == 403
    assert tabla("diagnostico", paciente_id(dui)) == 2 and tabla("borrador", paciente_id(dui)) == 0
    assert "BORRADOR_DENEGADO" in [a[0] for a in sql("SELECT accion FROM auditoria WHERE actor_id = :p", p=paciente_id(d["dui"]))]
    assert "ACCESO_EXPEDIENTE" in [a[0] for a in sql("SELECT accion FROM auditoria WHERE actor_id = :p", p=paciente_id(d["dui"]))]
    # un ciudadano común no entra
    assert client.get("/practica/atenciones", headers=login(client, pac)).status_code == 403
    assert client.get("/practica/atenciones").status_code == 401


def test_desactivar_perfil_de_estudiante_corta_el_acceso(client, interno):
    assert client.get("/practica/mi-asignacion", headers=interno["h"]).status_code == 200
    assert client.put("/portal/perfil/estudiante/estado", headers=interno["h"], json={"activo": False}).status_code == 200
    assert client.get("/practica/mi-asignacion", headers=interno["h"]).status_code == 403
    assert client.put("/portal/perfil/estudiante/estado", headers=interno["h"], json={"activo": True}).status_code == 200
    assert client.get("/practica/mi-asignacion", headers=interno["h"]).status_code == 200


# ------------------------------------------------------------------ Borrador pendiente: nunca visible
def test_borrador_sin_cofirma_no_existe_para_farmacia_ni_laboratorio(client, medico, firmado, farmacia, lab, interno, pac):
    lab_h, lab_id = lab
    dui, h = pac["dui"], interno["h"]
    at = abrir(client, medico, dui)
    pid = paciente_id(dui)
    b1, b2, b3 = borrador_diag(client, h, at), borrador_rx(client, h, at), borrador_ol(client, h, at, lab_id)
    for b in (b1, b2, b3):
        assert b.status_code == 201, b.text
        assert b.json()["estado"] == "PENDIENTE_VALIDACION" and b.json()["estado_texto"] == "Borrador Pendiente de Validación" and b.json()["tutor"]["dui"] == DUI_MEDICO
    # no existe ningún registro real
    for t in ("receta", "orden_lab", "diagnostico"):
        assert tabla(t, pid) == 0, t
    assert sql("SELECT count(*) FROM receta_item ri JOIN receta r ON r.id = ri.receta_id WHERE r.paciente_id = :p", p=pid)[0][0] == 0
    assert client.get(f"/expediente/{dui}/diagnosticos", headers=medico).json()["devueltos"] == 0
    assert client.get(f"/portal/mi-expediente/diagnosticos", headers=login(client, pac)).json()["devueltos"] == 0
    # el laboratorio no ve ninguna orden pendiente; la farmacia no tiene folio ni token que canjear
    assert client.get(f"/laboratorio/pendientes/{dui}", headers=lab_h).json() == []
    assert client.post("/farmacia/recetas/consulta", headers=farmacia, json={"folio": "RX-" + "0" * 10, "token": "AAAA-BBBB-CCCC-DDDD"}).status_code == 404
    # SQL espía: ni farmacia ni laboratorio consultan jamás la tabla de borradores
    vistas = []
    fn = lambda conn, cur, stmt, *a: vistas.append(stmt.lower())  # noqa: E731
    event.listen(engine, "before_cursor_execute", fn)
    try:
        client.get(f"/laboratorio/pendientes/{dui}", headers=lab_h)
        client.post("/farmacia/recetas/consulta", headers=farmacia, json={"folio": "RX-" + "0" * 10, "token": "AAAA-BBBB-CCCC-DDDD"})
    finally:
        event.remove(engine, "before_cursor_execute", fn)
    assert vistas and not any("borrador" in s for s in vistas)
    # el contenido del borrador está cifrado en la base de datos
    crudo = sql("SELECT contenido_cifrado FROM borrador WHERE id = :i", i=b2.json()["id"])[0][0]
    assert "moxicilina" not in crudo and "500 mg" not in crudo
    # solo su autor y su tutor lo ven
    assert client.get(f"/practica/borradores/{b1.json()['id']}", headers=h).json()["contenido"]["codigo_cie10"] == "J06.9"
    assert client.get("/practica/borradores", headers=h).json()["total"] == 3
    assert client.get("/practica/borradores", params={"estado": "APROBADO"}, headers=h).json()["total"] == 0
    ac = sql("SELECT detalle FROM auditoria WHERE recurso_id = :r AND accion = 'BORRADOR_REDACTADO'", r=b1.json()["id"])[0][0]
    assert ac["redactado_por"] == paciente_id(interno["dui"]) and ac["autorizado_por"] is None and ac["tutor_id"] == paciente_id(DUI_MEDICO)
    # validaciones del borrador
    assert borrador_diag(client, h, at, codigo_cie10="no-es-cie10").status_code == 422
    assert borrador_diag(client, h, at, reemplaza_id=str(uuid.uuid4()), motivo_correccion="corrijo yo").status_code == 422
    assert borrador_rx(client, h, at, meds=[]).status_code == 422
    assert borrador_ol(client, h, at, lab_id, tipo="IMAGENOLOGIA").status_code == 422  # imagenología exige modalidad
    assert borrador_diag(client, h, str(uuid.uuid4())).status_code == 404
    fase1 = datos_persona(fecha_nacimiento=NAC)
    client.post("/personas", json=fase1)
    assert borrador_diag(client, h, abrir(client, medico, fase1["dui"], fase3=False)).status_code == 404  # no supervisada (sin médico responsable)


# ------------------------------------------------------------------ Co-firma
def test_cofirma_aprueba_y_recien_entonces_llega_a_farmacia_y_laboratorio(client, medico, firmado, farmacia, lab, interno, pac):
    lab_h, lab_id = lab
    dui, h = pac["dui"], interno["h"]
    at, pid = abrir(client, medico, dui), paciente_id(dui)
    bd, br, bo = (x.json()["id"] for x in (borrador_diag(client, h, at), borrador_rx(client, h, at, meds=[AMOX, PARA]), borrador_ol(client, h, at, lab_id)))
    pend = client.get("/cofirma/borradores", headers=medico).json()
    assert {bd, br, bo} <= {b["id"] for b in pend["items"]}
    assert all(b["redactado_por"]["dui"] == interno["dui"] for b in pend["items"] if b["id"] in (bd, br, bo))
    # diagnóstico
    r = cofirmar(client, medico, bd)
    assert r.status_code == 200 and r.json()["estado"] == "APROBADO" and r.json()["resultado_tipo"] == "diagnostico", r.text
    d = client.get(f"/expediente/{dui}/diagnosticos", headers=medico).json()["items"]
    assert len(d) == 1 and d[0]["datos"]["codigo_cie10"] == "J06.9" and d[0]["registrado_por"] == paciente_id(DUI_MEDICO)  # queda a nombre del médico
    assert tabla("receta", pid) == 0 and tabla("orden_lab", pid) == 0  # lo demás sigue sin existir
    # receta: exige el PIN del médico; PIN malo no la consume
    assert cofirmar(client, medico, br).status_code == 422
    assert cofirmar(client, medico, br, pin="PinEquivocado1").status_code == 401
    assert tabla("receta", pid) == 0 and client.get(f"/cofirma/borradores/{br}", headers=medico).json()["estado"] == "PENDIENTE_VALIDACION"
    r = cofirmar(client, medico, br, pin=PIN, comentario="Dosis correctas")
    assert r.status_code == 200, r.text
    rx = r.json()
    assert rx["folio"].startswith("RX-") and rx["token"] and rx["resultado_tipo"] == "receta"
    # ahora sí la farmacia puede canjearla
    c = client.post("/farmacia/recetas/consulta", headers=farmacia, json={"folio": rx["folio"], "token": rx["token"]})
    assert c.status_code == 200 and len(c.json()["medicamentos"]) == 2, c.text
    assert sql("SELECT medico_id FROM receta WHERE folio = :f", f=rx["folio"])[0][0] == uuid.UUID(paciente_id(DUI_MEDICO))
    # orden de laboratorio
    assert client.get(f"/laboratorio/pendientes/{dui}", headers=lab_h).json() == []
    r = cofirmar(client, medico, bo)
    assert r.status_code == 200 and r.json()["folio"].startswith("OL-"), r.text
    assert [o["folio"] for o in client.get(f"/laboratorio/pendientes/{dui}", headers=lab_h).json()] == [r.json()["folio"]]
    # doble decisión
    for acc, body in (("aprobar", {}), ("rechazar", {"comentario": "de nuevo no"}), ("corregir", {"comentario": "de nuevo no", "diagnostico": DIAG})):
        assert cofirmar(client, medico, bd, acc, **body).status_code == 409
    # el estudiante ve el resultado y el comentario
    mi = client.get(f"/practica/borradores/{br}", headers=h).json()
    assert mi["estado"] == "APROBADO" and mi["comentario"] == "Dosis correctas" and mi["autorizado_por"]["dui"] == DUI_MEDICO and mi["resultado_id"] == rx["resultado_id"] and "token" not in json.dumps(mi)
    # AUDITORÍA DUAL: redactó = estudiante, autorizó = tutor, en el borrador y en el registro real
    est, tut = paciente_id(interno["dui"]), paciente_id(DUI_MEDICO)
    for rid, acc_real in ((bd, "REGISTRO_CLINICO"), (br, "RECETA_EMITIDA"), (bo, "ORDEN_LAB_CREADA")):
        cof = sql("SELECT accion, detalle, actor_id FROM auditoria WHERE recurso_id = :r AND accion LIKE 'COFIRMA%'", r=rid)
        assert [c[0] for c in cof] == ["COFIRMA_APROBADA"] and cof[0][1]["redactado_por"] == est and cof[0][1]["autorizado_por"] == tut and cof[0][2] == tut
        res = cof[0][1]["resultado_id"]
        real = sql("SELECT detalle FROM auditoria WHERE recurso_id = :r AND accion = :a", r=res, a=acc_real)
        assert real and real[0][0]["redactado_por"] == est and real[0][0]["autorizado_por"] == tut and real[0][0]["borrador_id"] == rid
    assert "BORRADOR_REDACTADO" in acciones_auditoria(bd)


def test_solo_el_tutor_asignado_cofirma(client, omega_headers, medico, firmado, interno, pac):
    h, dui = interno["h"], pac["dui"]
    at = abrir(client, medico, dui)
    bid = borrador_diag(client, h, at).json()["id"]
    otro = medico_nuevo(client, omega_headers)
    # otro médico del mismo hospital: no lo ve en su lista, ni lo puede decidir
    assert client.get("/cofirma/borradores", headers=otro).json()["total"] == 0
    assert client.get(f"/cofirma/borradores/{bid}", headers=otro).status_code == 403
    for acc, body in (("aprobar", {}), ("rechazar", {"comentario": "no es mío"}), ("corregir", {"comentario": "no es mío", "diagnostico": DIAG})):
        assert cofirmar(client, otro, bid, acc, **body).status_code == 403
    # el propio estudiante tampoco (ni siquiera es médico), ni un civil
    for acc in ("aprobar", "rechazar", "corregir"):
        assert client.post(f"/cofirma/borradores/{bid}/{acc}", headers=h, json={"comentario": "me autorizo"}).status_code in (401, 403)
    assert client.post(f"/cofirma/borradores/{bid}/aprobar", headers=login(client, pac), json={}).status_code in (401, 403)
    assert client.post(f"/cofirma/borradores/{bid}/aprobar", json={}).status_code == 401
    assert acciones_auditoria(bid).count("COFIRMA_DENEGADA") == 4
    assert client.get(f"/cofirma/borradores/{bid}", headers=medico).json()["estado"] == "PENDIENTE_VALIDACION"
    assert tabla("diagnostico", paciente_id(dui)) == 0
    # y la propia base de datos lo impide aunque se saltara la API
    for q in ("UPDATE borrador SET estado='APROBADO', decidido_en=now(), decidido_por=:otro, resultado_tipo='diagnostico', resultado_id=gen_random_uuid() WHERE id=:b",
              "UPDATE borrador SET estado='APROBADO', decidido_en=now(), decidido_por=:tut WHERE id=:b",   # sin registro creado
              "UPDATE borrador SET estado='RECHAZADO', decidido_en=now(), decidido_por=:tut WHERE id=:b",  # sin comentario
              "UPDATE borrador SET tutor_id=:otro WHERE id=:b", "UPDATE borrador SET contenido_cifrado='x' WHERE id=:b", "DELETE FROM borrador WHERE id=:b", "TRUNCATE borrador"):
        with pytest.raises(DBAPIError, match="borrador"):
            with SessionLocal() as db:
                db.execute(text(q), {"otro": sql("SELECT id FROM persona WHERE dui = :d", d=interno["dui"])[0][0], "tut": paciente_id(DUI_MEDICO), "b": bid})
                db.commit()


def test_corregir_y_rechazar_con_comentario(client, medico, interno, pac):
    h, dui = interno["h"], pac["dui"]
    at, pid = abrir(client, medico, dui), paciente_id(dui)
    b1, b2 = borrador_diag(client, h, at).json()["id"], None
    # corregir: comentario obligatorio y solo el campo del tipo
    assert cofirmar(client, medico, b1, "corregir", diagnostico=DIAG | {"codigo_cie10": "J20.9"}).status_code == 422
    assert cofirmar(client, medico, b1, "corregir", comentario="Es bronquitis", receta={"medicamentos": [AMOX]}).status_code == 422
    assert cofirmar(client, medico, b1, "corregir", comentario="Es bronquitis").status_code == 422
    assert cofirmar(client, medico, b1, "corregir", comentario="Es bronquitis", diagnostico=DIAG | {"codigo_cie10": "J20.9", "descripcion": "Bronquitis aguda"} | {"reemplaza_id": str(uuid.uuid4())}).status_code == 422
    r = cofirmar(client, medico, b1, "corregir", comentario="Es bronquitis, no resfriado", diagnostico=DIAG | {"codigo_cie10": "J20.9", "descripcion": "Bronquitis aguda"})
    assert r.status_code == 200 and r.json()["estado"] == "CORREGIDO", r.text
    d = client.get(f"/expediente/{dui}/diagnosticos", headers=medico).json()["items"]
    assert [i["datos"]["codigo_cie10"] for i in d] == ["J20.9"]  # en el expediente queda lo que el médico corrigió
    v = client.get(f"/cofirma/borradores/{b1}", headers=medico).json()
    assert v["contenido"]["codigo_cie10"] == "J06.9" and v["contenido_final"]["codigo_cie10"] == "J20.9" and v["comentario"] == "Es bronquitis, no resfriado"  # se conservan ambos
    assert client.get(f"/practica/borradores/{b1}", headers=h).json()["estado_texto"] == "Corregido y co-firmado por el tutor"
    cof = sql("SELECT accion, detalle FROM auditoria WHERE recurso_id = :r AND accion LIKE 'COFIRMA%'", r=b1)
    assert cof[0][0] == "COFIRMA_CORREGIDA" and cof[0][1]["redactado_por"] == paciente_id(interno["dui"]) and cof[0][1]["autorizado_por"] == paciente_id(DUI_MEDICO)
    # rechazar: sin comentario no; con comentario no se crea nada
    at2 = abrir(client, medico, (lambda p: (client.post("/personas", json=p), p["dui"])[1])(datos_persona(fecha_nacimiento=NAC)))
    b2 = borrador_rx(client, h, at2, meds=[AMOX]).json()["id"]
    assert cofirmar(client, medico, b2, "rechazar").status_code == 422
    assert cofirmar(client, medico, b2, "rechazar", comentario="no").status_code == 422
    r = cofirmar(client, medico, b2, "rechazar", comentario="Alergia a penicilinas, no corresponde")
    assert r.status_code == 200 and r.json()["estado"] == "RECHAZADO" and r.json()["token"] is None and r.json()["resultado_id"] is None
    assert sql("SELECT count(*) FROM receta WHERE atencion_id = :a", a=at2)[0][0] == 0
    s = client.get(f"/practica/borradores/{b2}", headers=h).json()
    assert s["estado"] == "RECHAZADO" and "Alergia" in s["comentario"] and s["autorizado_por"] is None
    rec = sql("SELECT detalle FROM auditoria WHERE recurso_id = :r AND accion = 'COFIRMA_RECHAZADA'", r=b2)[0][0]
    assert rec["redactado_por"] == paciente_id(interno["dui"]) and rec["autorizado_por"] is None and rec["rechazado_por"] == paciente_id(DUI_MEDICO)
    # decidido = inmutable en la BD
    with pytest.raises(DBAPIError, match="inmutable"):
        with SessionLocal() as db:
            db.execute(text("UPDATE borrador SET estado = 'PENDIENTE_VALIDACION' WHERE id = :b"), {"b": b2})
            db.commit()
    assert client.get("/cofirma/borradores", params={"estado": "RECHAZADO"}, headers=medico).json()["total"] >= 1


def test_corregir_orden_y_receta(client, medico, firmado, lab, interno, pac):
    lab_h, lab_id = lab
    h, dui = interno["h"], pac["dui"]
    at = abrir(client, medico, dui)
    bo = borrador_ol(client, h, at, lab_id).json()["id"]
    r = cofirmar(client, medico, bo, "corregir", comentario="Agrego glucosa", orden={"tipo": "LABORATORIO", "laboratorio_id": lab_id, "estudios": [HEMO, {"nombre": "Glucosa en ayunas"}]})
    assert r.status_code == 200, r.text
    assert len(client.get(f"/laboratorio/pendientes/{dui}", headers=lab_h).json()[0]["estudios"]) == 2
    br = borrador_rx(client, h, at, meds=[AMOX]).json()["id"]
    r = cofirmar(client, medico, br, "corregir", comentario="Cambio a paracetamol", pin=PIN, receta={"medicamentos": [PARA]})
    assert r.status_code == 200 and r.json()["token"], r.text
    assert sql("SELECT medicamento FROM receta_item WHERE receta_id = :r", r=r.json()["resultado_id"]) == [("Paracetamol",)]


def test_finalizar_asignacion_cancela_pendientes(client, medico, hospital, interno, pac):
    h, dui = interno["h"], pac["dui"]
    at = abrir(client, medico, dui)
    bid = borrador_diag(client, h, at).json()["id"]
    assert client.post(f"/practicas/{interno['asig']}/finalizar", headers=hospital, json={"motivo": "Termina la rotación"}).status_code == 200
    assert client.get("/practica/atenciones", headers=h).status_code == 403
    assert borrador_diag(client, h, at).status_code == 403
    v = client.get(f"/cofirma/borradores/{bid}", headers=medico).json()
    assert v["estado"] == "CANCELADO"
    assert cofirmar(client, medico, bid).status_code == 409
    assert tabla("diagnostico", paciente_id(dui)) == 0
    assert acciones_auditoria(bid) == ["BORRADOR_REDACTADO", "BORRADOR_CANCELADO"]


def test_dui_congelado_bloquea_borrador_y_cofirma(client, medico, interno, pac):
    h, dui = interno["h"], pac["dui"]
    at = abrir(client, medico, dui)
    bid = borrador_diag(client, h, at).json()["id"]
    r, _ = ml(client, dui)
    assert r.status_code in (200, 201), r.text
    assert borrador_diag(client, h, at, codigo_cie10="R51").status_code in (404, 423)
    assert cofirmar(client, medico, bid).status_code in (404, 409, 423)
    assert tabla("diagnostico", paciente_id(dui)) == 0


def test_tutor_deshabilitado_corta_el_acceso_del_estudiante(client, omega_headers, hospital, universidad, medico):
    otro = medico_nuevo(client, omega_headers)
    d, h = crear_estudiante(client, omega_headers, universidad)
    # busca el DUI del médico recién creado
    dui_otro = sql("SELECT p.dui FROM persona p JOIN perfil_profesional pf ON pf.persona_id = p.id WHERE pf.especialidad = 'Cardiología' ORDER BY p.creado_en DESC LIMIT 1")[0][0]
    assert asignar(client, hospital, d, tutor=dui_otro).status_code == 201
    assert client.get("/practica/mi-asignacion", headers=h).status_code == 200
    assert client.put("/portal/perfil/profesional/estado", headers=otro, json={"activo": False}).status_code == 200
    assert client.get("/practica/mi-asignacion", headers=h).status_code == 403


def test_endpoints_documentados(client):
    paths = client.get("/openapi.json").json()["paths"]
    for p in ("/practicas", "/practicas/{asignacion_id}/finalizar", "/practica/mi-asignacion", "/practica/atenciones", "/practica/atenciones/{atencion_id}/expediente/{seccion}",
              "/practica/atenciones/{atencion_id}/signos-vitales", "/practica/borradores/diagnostico", "/practica/borradores/receta", "/practica/borradores/orden-lab",
              "/practica/borradores", "/practica/borradores/{borrador_id}", "/cofirma/borradores", "/cofirma/borradores/{borrador_id}",
              "/cofirma/borradores/{borrador_id}/aprobar", "/cofirma/borradores/{borrador_id}/rechazar", "/cofirma/borradores/{borrador_id}/corregir"):
        assert p in paths, p
        assert all(op.get("summary") for op in paths[p].values()), p
