import json
from datetime import date, timedelta

import pytest
from sqlalchemy import text

from omega_core.database import SessionLocal
from omega_core.seed import DUI_MEDICO, PASSWORD_MEDICO

from .conftest import datos_persona, dui_nuevo
from .test_etapa2 import NAC, abrir, acciones_auditoria, auth, medico, ml, nota, paciente_id, sql  # noqa: F401
from .test_etapa2c import login
from .test_etapa3a import AMOX, canje, emitir, farmacia, firmado  # noqa: F401
from .test_etapa3c import HEMO, hb, lab, orden, registrar_lab, subir  # noqa: F401

P = "/portal"


@pytest.fixture
def pac(client):
    d = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=d).status_code == 201
    return d


@pytest.fixture
def pac_h(client, pac):
    return login(client, pac)


def vacuna(dui, **kw):
    return {"dui": dui, "vacuna": "Influenza", "dosis_numero": 1, "lote": "FLU-889", "fabricante": "Sanofi", "fecha_aplicacion": str(date.today() - timedelta(days=2)),
            "via_aplicacion": "intramuscular", "proxima_dosis": str(date.today() + timedelta(days=365))} | kw


def desbloquear(client, h, codigos):
    d = client.post(f"{P}/nivel4/desafio", headers=h)
    assert d.status_code == 200, d.text
    r = client.post(f"{P}/nivel4/desbloquear", headers=h, json={"desafio_id": d.json()["desafio_id"], "codigo": codigos[-1]})
    assert r.status_code == 200, r.text
    return r.json()["token_desbloqueo"]


# ------------------------------------------------------------------ Perfil
def test_perfil_editable_sin_tocar_datos_del_padron(client, pac, pac_h):
    r = client.get(f"{P}/perfil", headers=pac_h)
    assert r.status_code == 200 and r.json()["dui"] == pac["dui"] and r.json()["estudiante"]["registrado"] is False
    assert "password" not in json.dumps(r.json())
    nuevo = {"telefono": "7999-0000", "departamento": "Santa Ana", "municipio": "Santa Ana Centro", "direccion": "Col. Las Flores, pasaje 3, casa 12",
             "tipo_sangre": "O+", "contacto_emergencia_nombre": "María Prueba", "contacto_emergencia_telefono": "7123-0000"}
    r = client.patch(f"{P}/perfil", headers=pac_h, json=nuevo)
    assert r.status_code == 200, r.text
    p = r.json()
    assert p["direccion"] == nuevo["direccion"] and p["tipo_sangre"] == "O+" and p["contacto_emergencia_nombre"] == "María Prueba" and p["municipio"] == "Santa Ana Centro"
    assert client.get(f"{P}/perfil", headers=pac_h).json()["departamento"] == "Santa Ana"
    # actualización parcial: lo no enviado no se borra
    assert client.patch(f"{P}/perfil", headers=pac_h, json={"direccion": "Nueva dirección 45"}).json()["tipo_sangre"] == "O+"
    # DUI, nombres, fecha de nacimiento y roles no son editables
    for malo in ({"dui": dui_nuevo()}, {"nombres": "Otro"}, {"fecha_nacimiento": "1980-01-01"}, {"roles": ["OMEGA"]}, {"password": "x"}, {}, {"telefono": "abc"},
                 {"tipo_sangre": "Z"}, {"correo": "no-es-correo"}):
        assert client.patch(f"{P}/perfil", headers=pac_h, json=malo).status_code == 422, malo
    # correo ajeno: 409
    otro = datos_persona()
    client.post("/personas", json=otro)
    assert client.patch(f"{P}/perfil", headers=pac_h, json={"correo": otro["correo"]}).status_code == 409
    assert client.patch(f"{P}/perfil", headers=pac_h, json={"correo": f"Nuevo.{dui_nuevo()}@Example.SV"}).json()["correo"].startswith("nuevo.")
    det = sql("SELECT detalle FROM auditoria WHERE accion = 'PORTAL_PERFIL_ACTUALIZADO' AND recurso_id = :p ORDER BY id LIMIT 1", p=paciente_id(pac["dui"]))[0][0]
    assert "telefono" in det["campos"] and "7999-0000" not in json.dumps(det)  # se auditan los campos, no los valores
    assert client.get(f"{P}/perfil").status_code == 401


def test_activar_y_desactivar_perfiles_estudiante_y_profesional(client):
    d = datos_persona(estudiante={"carne": f"E{dui_nuevo()[:6]}", "universidad_nombre": "UES", "carrera": "Doctorado en Medicina", "ciclo": "Año 6",
                                  "correo_institucional": f"{dui_nuevo()[:8]}@ues.edu.sv"})
    client.post("/personas", json=d)
    h = login(client, d)
    p = client.get(f"{P}/perfil", headers=h).json()
    assert p["estudiante"]["registrado"] and p["estudiante"]["activo"] and "Medicina" in p["estudiante"]["detalle"] and p["profesional"]["registrado"] is False
    r = client.put(f"{P}/perfil/estudiante/estado", headers=h, json={"activo": False, "motivo": "Me gradué"})
    assert r.status_code == 200 and r.json()["estudiante"]["activo"] is False
    assert client.put(f"{P}/perfil/estudiante/estado", headers=h, json={"activo": True}).json()["estudiante"]["activo"] is True
    assert client.put(f"{P}/perfil/profesional/estado", headers=h, json={"activo": False}).status_code == 404  # no tiene ese perfil
    assert client.put(f"{P}/perfil/admin/estado", headers=h, json={"activo": False}).status_code == 422
    assert [x[0] for x in sql("SELECT detalle->>'despues' FROM auditoria WHERE accion = 'PORTAL_PERFIL_ESTADO' AND actor_id = :a ORDER BY id", a=paciente_id(d["dui"]))] == ["false", "true"]


def test_profesional_desactivado_deja_de_operar_y_conserva_su_verificacion(client, medico):
    h = lambda: auth(client.post("/auth/login/persona", json={"dui": DUI_MEDICO, "password": PASSWORD_MEDICO}).json()["tokens"]["access_token"])  # noqa: E731
    mh = h()
    assert client.get("/atenciones", headers=mh).status_code == 200
    try:
        r = client.put(f"{P}/perfil/profesional/estado", headers=mh, json={"activo": False, "motivo": "Licencia sin goce"})
        assert r.status_code == 200 and r.json()["profesional"]["activo"] is False and r.json()["profesional"]["verificado"] is True
        for resp in (client.get("/atenciones", headers=mh), client.get("/expediente/00000000-0", headers=mh), client.post("/atenciones", headers=mh, json={})):
            assert resp.status_code == 403, resp.text  # el cambio rige de inmediato, con el mismo token
        assert client.post("/vacunas", headers=mh, json=vacuna(dui_nuevo())).status_code == 403
    finally:
        client.put(f"{P}/perfil/profesional/estado", headers=mh, json={"activo": True})
    assert client.get("/atenciones", headers=mh).status_code == 200  # reactivado sin reverificar
    assert sql("SELECT verificado, activo FROM perfil_profesional WHERE persona_id = (SELECT id FROM persona WHERE dui = :d)", d=DUI_MEDICO) == [(True, True)]


# ------------------------------------------------------------------ Lectura de mi expediente
def test_lectura_propia_solo_lectura_y_aislamiento(client, medico, pac, pac_h):
    dui = pac["dui"]
    at = abrir(client, medico, dui)
    client.post(f"/atenciones/{at}/diagnosticos", headers=medico, json={"codigo_cie10": "J06.9", "descripcion": "Infección respiratoria aguda", "tipo": "DEFINITIVO", "principal": True})
    client.post(f"/atenciones/{at}/notas", headers=medico, json=nota(subjetivo="Nota SOAP confidencial del médico"))
    client.post(f"/atenciones/{at}/antecedentes", headers=medico, json={"tipo": "FAMILIAR", "descripcion": "Antecedente familiar X"})
    client.post("/vacunas", headers=medico, json=vacuna(dui))
    # otra persona con sus propios datos: no debe aparecer en mis lecturas
    otra = datos_persona()
    client.post("/personas", json=otra)
    at2 = abrir(client, medico, otra["dui"])
    client.post(f"/atenciones/{at2}/diagnosticos", headers=medico, json={"codigo_cie10": "K29.7", "descripcion": "Gastritis del otro paciente", "tipo": "DEFINITIVO", "principal": True})
    d = client.get(f"{P}/mi-expediente/diagnosticos", headers=pac_h)
    assert d.status_code == 200 and d.json()["devueltos"] == 1 and d.json()["items"][0]["datos"]["codigo_cie10"] == "J06.9"
    assert client.get(f"{P}/mi-expediente/vacunas", headers=pac_h).json()["items"][0]["datos"]["vacuna"] == "Influenza"
    assert client.get(f"{P}/mi-expediente/resultados", headers=pac_h).json()["devueltos"] == 0
    # secciones fuera del portal: notas SOAP y antecedentes no se exponen
    for sec in ("notas", "antecedentes", "alergias", "egresos"):
        assert client.get(f"{P}/mi-expediente/{sec}", headers=pac_h).status_code == 422
    # solo lectura
    for metodo in ("post", "put", "patch", "delete"):
        assert getattr(client, metodo)(f"{P}/mi-expediente/diagnosticos", headers=pac_h).status_code == 405
    # la otra persona ve únicamente lo suyo (nada del primer paciente) y sin DUI ajeno posible
    h2 = login(client, otra)
    d2 = client.get(f"{P}/mi-expediente/diagnosticos", headers=h2).json()
    assert [i["datos"]["codigo_cie10"] for i in d2["items"]] == ["K29.7"]
    for sec in ("vacunas", "resultados"):
        assert client.get(f"{P}/mi-expediente/{sec}", headers=h2).json()["devueltos"] == 0
    assert client.get(f"{P}/mi-expediente/recetas", headers=h2).json()["devueltos"] == 0
    assert client.get(f"{P}/mi-expediente/diagnosticos", params={"dui": dui}, headers=h2).json()["items"][0]["datos"]["codigo_cie10"] == "K29.7"  # un parámetro "dui" no cambia de titular
    # credenciales que no son de ciudadano
    assert client.get(f"{P}/mi-expediente/diagnosticos", headers=medico).status_code == 200  # el médico también es persona: ve SU propio (vacío) expediente
    assert client.get(f"{P}/mi-expediente/diagnosticos", headers=medico).json()["devueltos"] == 0
    assert client.get(f"{P}/mi-expediente/diagnosticos").status_code == 401
    assert "PORTAL_LECTURA_PROPIA" in acciones_auditoria(paciente_id(dui))


def test_recetas_propias_sin_token_ni_firma(client, medico, firmado, farmacia, pac, pac_h):
    abrir(client, medico, pac["dui"])
    rx = emitir(client, firmado, pac["dui"]).json()
    r = client.get(f"{P}/mi-expediente/recetas", headers=pac_h)
    assert r.status_code == 200 and r.json()["devueltos"] == 1
    item = r.json()["items"][0]
    assert item["folio"] == rx["folio"] and item["vigente"] is True and item["estado"] == "EMITIDA" and item["despachada_en"] is None
    assert item["medicamentos"][0]["medicamento"] == "Amoxicilina" and item["medico"] and item["establecimiento_emisor"]
    texto = json.dumps(r.json())
    assert rx["token"] not in texto and "firma" not in texto and "token" not in texto and "payload" not in texto and "clave_publica" not in texto
    assert client.post("/farmacia/recetas/despachar", headers=farmacia, json=canje(rx)).status_code == 201
    item = client.get(f"{P}/mi-expediente/recetas", headers=pac_h).json()["items"][0]
    assert item["estado"] == "DESPACHADA" and item["despachada_en"] and item["farmacia"] and item["vigente"] is False


def test_resultados_de_laboratorio_y_nivel4_con_2fa(client, medico, lab, pac, pac_h, codigos_2fa):
    lab_h, lab_id = lab
    dui = pac["dui"]
    at = abrir(client, medico, dui)
    client.post(f"/atenciones/{at}/diagnosticos", headers=medico, json={"codigo_cie10": "B20", "descripcion": "Enfermedad por VIH", "tipo": "DEFINITIVO"})
    client.post(f"/atenciones/{at}/diagnosticos", headers=medico, json={"codigo_cie10": "J06.9", "descripcion": "IVRA", "tipo": "DEFINITIVO", "principal": True})
    o1 = orden(client, medico, dui, lab_id).json()
    assert subir(client, lab_h, o1["folio"], [hb(14)]).status_code == 201
    o2 = orden(client, medico, dui, lab_id, estudios=[{"nombre": "Prueba de VIH 4ª generación"}]).json()
    assert subir(client, lab_h, o2["folio"], [{"estudio": 1, "parametro": "VIH Ag/Ac", "valor_texto": "REACTIVO", "bandera": "CRITICO"}]).status_code == 201
    # sin desbloqueo: lo estándar se ve; lo nivel 4 sale restringido
    d = client.get(f"{P}/mi-expediente/diagnosticos", headers=pac_h).json()
    assert d["devueltos"] == 2 and d["restringidos"] == 1 and "VIH" not in json.dumps(d) and "B20" not in json.dumps(d)
    r = client.get(f"{P}/mi-expediente/resultados", headers=pac_h).json()
    assert r["devueltos"] == 2 and r["restringidos"] == 1 and "REACTIVO" not in json.dumps(r)
    normal = [i for i in r["items"] if not i["restringido"]][0]["datos"]
    assert normal["orden_folio"] == o1["folio"] and normal["valores"][0]["bandera"] == "NORMAL"
    # 2FA: código incorrecto, desafío ajeno y luego correcto
    des = client.post(f"{P}/nivel4/desafio", headers=pac_h).json()
    assert client.post(f"{P}/nivel4/desbloquear", headers=pac_h, json={"desafio_id": des["desafio_id"], "codigo": "000000" if codigos_2fa[-1] != "000000" else "111111"}).status_code == 401
    otra = datos_persona()
    client.post("/personas", json=otra)
    h_otra = login(client, otra)
    assert client.post(f"{P}/nivel4/desbloquear", headers=h_otra, json={"desafio_id": des["desafio_id"], "codigo": codigos_2fa[-1]}).status_code == 401  # el desafío no es suyo
    tk = client.post(f"{P}/nivel4/desbloquear", headers=pac_h, json={"desafio_id": des["desafio_id"], "codigo": codigos_2fa[-1]})
    assert tk.status_code == 200, tk.text
    token = tk.json()["token_desbloqueo"]
    assert sql("SELECT count(*) FROM desbloqueo_nivel4 WHERE token_hash = :t", t=token)[0][0] == 0  # solo se guarda el hash
    h4 = pac_h | {"X-Desbloqueo-N4": token}
    d = client.get(f"{P}/mi-expediente/diagnosticos", headers=h4).json()
    assert d["restringidos"] == 0 and {i["datos"]["codigo_cie10"] for i in d["items"]} == {"B20", "J06.9"}
    r = client.get(f"{P}/mi-expediente/resultados", headers=h4).json()
    assert r["restringidos"] == 0 and "REACTIVO" in json.dumps(r)
    ac = sql("SELECT detalle FROM auditoria WHERE accion = 'PORTAL_LECTURA_PROPIA' AND recurso_id = :p ORDER BY id DESC LIMIT 1", p=paciente_id(dui))[0][0]
    assert ac["nivel4_abierto"] is True
    # el token solo sirve para su dueño y no sirve sin su sesión
    assert client.get(f"{P}/mi-expediente/diagnosticos", headers=h_otra | {"X-Desbloqueo-N4": token}).status_code == 403
    assert client.get(f"{P}/mi-expediente/diagnosticos", headers=pac_h | {"X-Desbloqueo-N4": "inventado"}).status_code == 403
    # vence a los 10 minutos
    with SessionLocal() as db:
        db.execute(text("UPDATE desbloqueo_nivel4 SET expira_en = now() - interval '1 minute' WHERE persona_id = :p"), {"p": paciente_id(dui)})
        db.commit()
    assert client.get(f"{P}/mi-expediente/diagnosticos", headers=h4).status_code == 403
    # re-desbloquear y volver a bloquear manualmente
    h4 = pac_h | {"X-Desbloqueo-N4": desbloquear(client, pac_h, codigos_2fa)}
    assert client.get(f"{P}/mi-expediente/diagnosticos", headers=h4).json()["restringidos"] == 0
    assert client.post(f"{P}/nivel4/bloquear", headers=pac_h).status_code == 204
    assert client.get(f"{P}/mi-expediente/diagnosticos", headers=h4).status_code == 403
    assert client.get(f"{P}/mi-expediente/diagnosticos", headers=pac_h).json()["restringidos"] == 1
    # bitácora de todo el proceso
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'PORTAL_NIVEL4_DESBLOQUEO' AND actor_id = :a", a=paciente_id(dui))[0][0] >= 3
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'PORTAL_NIVEL4_DESBLOQUEO' AND resultado = 'FALLO' AND actor_id = :a", a=paciente_id(dui))[0][0] == 1


# ------------------------------------------------------------------ Vacunas
def test_vacunas_carga_por_profesional_correccion_y_vista_ciudadana(client, medico, pac, pac_h):
    dui = pac["dui"]
    assert client.post("/vacunas", headers=medico, json=vacuna(dui)).status_code == 403  # sin atención ni consentimiento
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'VACUNA_DENEGADA' AND detalle->>'paciente_id' = :p", p=paciente_id(dui))[0][0] == 1
    abrir(client, medico, dui)
    assert client.post("/vacunas", headers=pac_h, json=vacuna(dui)).status_code == 403  # un ciudadano no carga vacunas
    assert client.post("/vacunas", json=vacuna(dui)).status_code == 401
    assert client.post("/vacunas", headers=medico, json=vacuna(dui, fecha_aplicacion=str(date.today() + timedelta(days=3)), proxima_dosis=None)).status_code == 422
    assert client.post("/vacunas", headers=medico, json=vacuna(dui, proxima_dosis=str(date.today() - timedelta(days=30)))).status_code == 422
    assert client.post("/vacunas", headers=medico, json=vacuna(dui, dosis_numero=0)).status_code == 422
    r = client.post("/vacunas", headers=medico, json=vacuna(dui))
    assert r.status_code == 201, r.text
    v1 = r.json()
    assert len(v1["hash_contenido"]) == 64
    assert client.post("/vacunas", headers=medico, json=vacuna(dui)).status_code == 409  # misma dosis duplicada
    # corrección: nueva versión que referencia la anterior
    assert client.post("/vacunas", headers=medico, json=vacuna(dui, lote="FLU-900", reemplaza_id=v1["id"])).status_code == 422  # falta motivo
    v2 = client.post("/vacunas", headers=medico, json=vacuna(dui, lote="FLU-900", reemplaza_id=v1["id"], motivo_correccion="Lote mal digitado"))
    assert v2.status_code == 201 and v2.json()["reemplaza_id"] == v1["id"]
    assert client.post("/vacunas", headers=medico, json=vacuna(dui, lote="OTRO", reemplaza_id=v1["id"], motivo_correccion="Otra vez")).status_code == 409
    # el ciudadano ve la versión vigente (y el historial si lo pide)
    vig = client.get(f"{P}/mi-expediente/vacunas", headers=pac_h).json()
    assert vig["devueltos"] == 1 and vig["items"][0]["datos"]["lote"] == "FLU-900" and vig["items"][0]["datos"]["establecimiento"]
    hist = client.get(f"{P}/mi-expediente/vacunas", params={"historial": True}, headers=pac_h).json()
    assert {i["id"] for i in hist["items"]} == {v1["id"], v2.json()["id"]}
    # el profesional con acceso la ve en el expediente y en el resumen
    assert client.get(f"/expediente/{dui}/vacunas", headers=medico).json()["items"][0]["datos"]["vacuna"] == "Influenza"
    assert client.get(f"/expediente/{dui}", headers=medico).json()["vacunas"]["devueltos"] == 1
    ac = acciones_auditoria(v2.json()["id"])
    assert "VACUNA_CORREGIDA" in ac and "VACUNA_REGISTRADA" in acciones_auditoria(v1["id"])
    # inmutable en la base
    for q in ("UPDATE vacuna SET lote = 'X' WHERE id = :i", "DELETE FROM vacuna WHERE id = :i"):
        with pytest.raises(Exception, match="inmutable"):
            with SessionLocal() as db:
                db.execute(text(q), {"i": v1["id"]})
                db.commit()


def test_vacuna_no_se_carga_a_un_dui_congelado(client, medico):
    d = datos_persona(fecha_nacimiento=NAC)
    client.post("/personas", json=d)
    abrir(client, medico, d["dui"])
    assert ml(client, d["dui"])[0].status_code == 200
    assert client.post("/vacunas", headers=medico, json=vacuna(d["dui"])).status_code in (403, 423)
    assert sql("SELECT count(*) FROM vacuna WHERE paciente_id = :p", p=paciente_id(d["dui"])) == [(0,)]


# ------------------------------------------------------------------ Quién consultó mi expediente
def test_el_ciudadano_ve_quien_consulto_su_expediente(client, medico, firmado, farmacia, lab, pac, pac_h, codigos_2fa):
    lab_h, lab_id = lab
    dui = pac["dui"]
    abrir(client, medico, dui)
    assert client.get(f"/expediente/{dui}", headers=medico, params={"justificacion": "Valoración confidencial de riesgo suicida"}).status_code == 200
    assert client.get(f"/expediente/{dui}/notas", headers=medico).status_code == 200
    rx = emitir(client, firmado, dui).json()
    assert client.post("/farmacia/recetas/consulta", headers=farmacia, json=canje(rx)).status_code == 200
    assert client.get(f"/laboratorio/pendientes/{dui}", headers=lab_h).status_code == 200
    # intentos denegados de otro profesional/DUI no aparecen; mis propias lecturas tampoco
    client.get(f"{P}/mi-expediente/diagnosticos", headers=pac_h)
    r = client.get(f"{P}/accesos", headers=pac_h)
    assert r.status_code == 200, r.text
    items = r.json()["items"]
    tipos = [i["tipo"] for i in items]
    assert tipos.count("PROFESIONAL") == 2 and "FARMACIA" in tipos and "LABORATORIO" in tipos
    prof = [i for i in items if i["tipo"] == "PROFESIONAL"]
    assert {i["que_consulto"] for i in prof} == {"resumen", "notas"} and all(i["via"] == "ATENCION_ACTIVA" for i in prof)
    assert prof[0]["accedio"].startswith("Médico") and "DOCTOR" in prof[0]["rol"] and prof[0]["establecimiento"]
    assert [i["accedio"] for i in items if i["tipo"] == "FARMACIA"][0] and [i for i in items if i["tipo"] == "LABORATORIO"][0]["que_consulto"].startswith("órdenes")
    assert all(i["abrio_nivel4"] is False for i in items)
    # solo lo necesario: sin IP, justificación, hashes, ids internos ni la propia lectura del ciudadano
    texto = json.dumps(r.json(), ensure_ascii=False)
    for prohibido in ("127.0.0.1", "testclient", "riesgo suicida", "justificacion", "hash", "actor_id", "detalle", "ip\"", "Persona", pac["nombres"] + " " + pac["apellidos"]):
        assert prohibido not in texto, prohibido
    assert set(items[0]) == {"fecha", "accedio", "tipo", "rol", "establecimiento", "via", "que_consulto", "abrio_nivel4"}
    assert "PORTAL_ACCESOS_CONSULTADOS" in acciones_auditoria(paciente_id(dui))
    # otra persona no ve los accesos de este paciente
    otra = datos_persona()
    client.post("/personas", json=otra)
    assert client.get(f"{P}/accesos", headers=login(client, otra)).json()["devueltos"] == 0
    # paginación y credenciales ajenas
    assert client.get(f"{P}/accesos", params={"limite": 2, "offset": 1}, headers=pac_h).json()["devueltos"] == 2
    assert client.get(f"{P}/accesos", params={"limite": 500}, headers=pac_h).status_code == 422
    assert client.get(f"{P}/accesos").status_code == 401
    assert client.get(f"{P}/accesos", headers=farmacia).status_code in (401, 403)
    assert client.get(f"{P}/accesos", headers=lab_h).status_code in (401, 403)


def test_acceso_con_nivel4_abierto_se_marca(client, medico, pac, pac_h):
    dui = pac["dui"]
    at = abrir(client, medico, dui)
    client.post(f"/atenciones/{at}/notas", headers=medico, json=nota(subjetivo="dato sensible", confidencial=True))
    # el médico responsable abre el nivel 4 con justificación
    assert client.get(f"/expediente/{dui}/notas", headers=medico, params={"justificacion": "Valoración clínica de seguimiento"}).status_code == 200
    items = client.get(f"{P}/accesos", headers=pac_h).json()["items"]
    assert items[0]["abrio_nivel4"] is True and items[0]["que_consulto"] == "notas"
    assert "Valoración clínica" not in json.dumps(items, ensure_ascii=False)
