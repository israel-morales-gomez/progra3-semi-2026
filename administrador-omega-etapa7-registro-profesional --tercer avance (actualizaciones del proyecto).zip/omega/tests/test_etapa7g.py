"""Etapa 7 · 2e · parte 1: autocompras declaradas por el paciente (portal /ciudadano, historial farmacológico)."""
import json
from datetime import date, timedelta

import pytest
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError

from omega_core.database import SessionLocal

from .conftest import datos_persona
from .test_etapa2 import NAC, acciones_auditoria, sql  # noqa: F401
from .test_etapa2c import login
from .test_etapa4a import pac, pac_h  # noqa: F401

A = "/portal/autocompras"


def compra(**kw):
    return {"medicamento": "Ibuprofeno", "dosis": "400 mg", "fecha_compra": str(date.today() - timedelta(days=1)), "farmacia": "Farmacia Central"} | kw


def test_humo_declarar_y_listar_con_etiqueta_de_declarada(client, pac_h):
    r = client.post(A, headers=pac_h, json=compra())
    assert r.status_code == 201, r.text
    a = r.json()
    assert a["origen"] == "DECLARADA_POR_PACIENTE" and a["etiqueta"] == "Declarada por el paciente" and a["oficial"] is False
    assert a["medicamento"] == "Ibuprofeno" and a["dosis"] == "400 mg" and a["farmacia"] == "Farmacia Central"
    sin_farmacia = client.post(A, headers=pac_h, json=compra(medicamento="Paracetamol", farmacia="  ", fecha_compra=str(date.today())))
    assert sin_farmacia.status_code == 201 and sin_farmacia.json()["farmacia"] is None
    lista = client.get(A, headers=pac_h)
    assert lista.status_code == 200 and lista.json()["devueltos"] == 2
    assert [i["medicamento"] for i in lista.json()["items"]] == ["Paracetamol", "Ibuprofeno"]  # más reciente primero


def test_validaciones_y_el_origen_no_se_puede_forzar(client, pac_h):
    assert client.post(A, headers=pac_h, json=compra(fecha_compra=str(date.today() + timedelta(days=1)))).status_code == 422
    assert client.post(A, headers=pac_h, json=compra(origen="RECETA_OFICIAL")).status_code == 422
    assert client.post(A, headers=pac_h, json=compra(paciente_id="00000000-0000-0000-0000-000000000000")).status_code == 422
    for campo in ("medicamento", "dosis", "fecha_compra"):
        d = compra()
        d.pop(campo)
        assert client.post(A, headers=pac_h, json=d).status_code == 422
    assert client.post(A, headers=pac_h, json=compra(medicamento=" ")).status_code == 422
    assert client.get(A, headers=pac_h).json()["devueltos"] == 0


def test_permisos_sin_sesion_y_aislamiento_entre_ciudadanos(client, pac_h):
    assert client.post(A, json=compra()).status_code == 401
    assert client.get(A).status_code == 401
    assert client.post(A, headers=pac_h, json=compra(medicamento="Naproxeno")).status_code == 201
    otro = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=otro).status_code == 201
    otro_h = login(client, otro)
    assert client.get(A, headers=otro_h).json() == {"devueltos": 0, "items": []}
    assert "Naproxeno" not in json.dumps(client.get(A, headers=otro_h).json())


def test_no_se_mezcla_con_las_recetas_oficiales_y_queda_auditada(client, pac, pac_h):
    a = client.post(A, headers=pac_h, json=compra(medicamento="Aspirina")).json()
    recetas = client.get("/portal/mi-expediente/recetas", headers=pac_h)
    assert recetas.status_code == 200 and recetas.json()["devueltos"] == 0 and "Aspirina" not in json.dumps(recetas.json())
    assert acciones_auditoria(a["id"]) == ["AUTOCOMPRA_REGISTRADA"]
    fila = sql("SELECT actor_tipo, recurso, detalle::text FROM auditoria WHERE recurso_id = :r", r=a["id"])[0]
    assert fila[0] == "persona" and fila[1] == "autocompra" and "Aspirina" not in fila[2]  # la bitácora no guarda el nombre del medicamento
    assert sql("SELECT count(*) FROM receta r JOIN persona p ON p.id = r.paciente_id WHERE p.dui = :d", d=pac["dui"])[0][0] == 0


def test_el_origen_esta_protegido_en_la_base_de_datos(client, pac_h):
    a = client.post(A, headers=pac_h, json=compra()).json()
    with SessionLocal() as db, pytest.raises(IntegrityError):
        db.execute(text("UPDATE autocompra SET origen = 'RECETA_OFICIAL' WHERE id = :i"), {"i": a["id"]})
        db.commit()
