import hashlib
import json
import uuid

import pytest
from sqlalchemy import event, text
from sqlalchemy.exc import DBAPIError, IntegrityError

from omega_core.database import SessionLocal, engine
from omega_core.seed import DUI_MEDICO

from .conftest import datos_persona, dui_nuevo, nit_nuevo
from .test_etapa2 import NAC, abrir, acciones_auditoria, auth, medico, paciente_id, sql  # noqa: F401
from .test_etapa2c import login
from .test_etapa3a import AMOX, PARA, PIN, farmacia, firmado  # noqa: F401
from .test_etapa3c import HEMO, lab, registrar_lab  # noqa: F401
from .test_etapa5a import (asignar, borrador_diag, borrador_ol, borrador_rx, cofirmar, crear_estudiante, hospital, medico_nuevo, pac, tabla)  # noqa: F401

CLAVE = "UniClave12345"


def datos_uni(**kw):
    return {"tipo": "UNIVERSIDAD", "nombre_legal": "Universidad Nacional de Prueba", "nit": nit_nuevo(), "credencial_autorizacion": f"MINED-{uuid.uuid4().hex[:6]}", "departamento": "San Salvador",
            "municipio": "San Salvador", "direccion": "Campus central", "telefono": "2200-0000", "correo": f"{uuid.uuid4().hex[:8]}@uni.edu.sv", "responsable_nombre": "Dra. Coordinadora",
            "responsable_cargo": "Coordinadora de prácticas clínicas", "responsable_dui": dui_nuevo(), "responsable_correo": "coordinacion@uni.edu.sv", "responsable_telefono": "7000-2222",
            "password": CLAVE} | kw


def login_uni(client, nit, codigos, clave=CLAVE):
    r = client.post("/auth/login/institucion", json={"identificador": nit, "password": clave})
    if r.status_code != 200:
        return r, None
    if r.json().get("requiere_2fa"):
        r = client.post("/auth/2fa/verificar", json={"desafio_id": r.json()["desafio_id"], "codigo": codigos[-1]})
        assert r.status_code == 200, r.text
    return r, auth(r.json()["tokens"]["access_token"])


def nueva_uni(client, omega_headers, codigos):
    d = datos_uni()
    r = client.post("/instituciones", json=d)
    assert r.status_code == 201, r.text
    uid = r.json()["id"]
    assert client.patch(f"/omega/instituciones/{uid}/estado", json={"estado": "ACTIVA", "motivo": "Credencial MINED verificada"}, headers=omega_headers).status_code == 200
    _, h = login_uni(client, d["nit"], codigos)
    return {"id": uid, "nit": d["nit"], "h": h, "datos": d}


@pytest.fixture
def uni(client, omega_headers, codigos_2fa):
    return nueva_uni(client, omega_headers, codigos_2fa)


def insertar_turno(est_dui, minutos, estado="CERRADA"):
    """Turno ya cerrado, creado directo en la BD (las horas reales no se pueden falsear con la API)."""
    with SessionLocal() as db:
        a = db.execute(text("SELECT id, tutor_id, universidad_id, institucion_id, estudiante_id FROM asignacion_practica WHERE estudiante_id = (SELECT id FROM persona WHERE dui = :d) AND activa"),
                       {"d": est_dui}).one()
        tid = uuid.uuid4()
        db.execute(text("INSERT INTO asistencia_practica (id, asignacion_id, estudiante_id, tutor_id, universidad_id, institucion_id, entrada, salida, minutos, estado) "
                        "VALUES (:i, :a, :e, :t, :u, :h, now() - interval '1 day', now() - interval '1 day' + (:m || ' minutes')::interval, :m, :s)"),
                   {"i": tid, "a": a.id, "e": a.estudiante_id, "t": a.tutor_id, "u": a.universidad_id, "h": a.institucion_id, "m": minutos, "s": estado})
        db.commit()
    return str(tid)


def estudiante_de(client, omega_headers, hospital, uni, nivel="INTERNADO"):
    d, h = crear_estudiante(client, omega_headers, uni["id"])
    r = asignar(client, hospital, d, nivel=nivel)
    assert r.status_code == 201, r.text
    return {"dui": d["dui"], "h": h, "id": paciente_id(d["dui"]), "datos": d}


# ------------------------------------------------------------------ Registro, verificación por Omega y login
def test_registro_verificacion_omega_y_login(client, omega_headers, codigos_2fa, hospital, medico, farmacia):
    # coordinador y credencial son obligatorios
    for falta in ("credencial_autorizacion", "responsable_cargo", "responsable_nombre", "responsable_correo", "responsable_telefono"):
        d = datos_uni()
        d.pop(falta)
        assert client.post("/instituciones", json=d).status_code == 422, falta
    d = datos_uni()
    r = client.post("/instituciones", json=d)
    assert r.status_code == 201 and r.json()["estado"] != "ACTIVA" and r.json()["tipo"] == "UNIVERSIDAD", r.text
    uid = r.json()["id"]
    assert client.post("/instituciones", json=datos_uni(nit=d["nit"])).status_code == 409
    # sin verificar por Omega no entra
    assert client.post("/auth/login/institucion", json={"identificador": d["nit"], "password": CLAVE}).status_code == 401
    # Omega la verifica y activa
    assert client.patch(f"/omega/instituciones/{uid}/estado", json={"estado": "ACTIVA", "motivo": "Credencial MINED verificada"}, headers=omega_headers).status_code == 200
    assert login_uni(client, d["nit"], codigos_2fa, clave="ClaveEquivocada1")[0].status_code == 401
    r, h = login_uni(client, d["nit"], codigos_2fa)
    assert r.status_code == 200
    p = client.get("/universidad/perfil", headers=h)
    assert p.status_code == 200, p.text
    p = p.json()
    assert p["nit"] == d["nit"] and p["credencial_autorizacion"] == d["credencial_autorizacion"] and p["estado"] == "ACTIVA"
    assert p["coordinador"] == {"nombre": "Dra. Coordinadora", "cargo": "Coordinadora de prácticas clínicas", "correo": "coordinacion@uni.edu.sv", "telefono": p["coordinador"]["telefono"]}
    # si Omega la suspende, pierde el acceso al instante
    assert client.patch(f"/omega/instituciones/{uid}/estado", json={"estado": "SUSPENDIDA", "motivo": "Revisión de credencial"}, headers=omega_headers).status_code == 200
    assert client.get("/universidad/perfil", headers=h).status_code == 401
    assert client.patch(f"/omega/instituciones/{uid}/estado", json={"estado": "ACTIVA", "motivo": "Revisión concluida"}, headers=omega_headers).status_code == 200
    assert client.get("/universidad/perfil", headers=h).status_code == 200
    # solo universidades: hospital, farmacia, médico y anónimo no
    for otro in (hospital, farmacia):
        assert client.get("/universidad/estudiantes", headers=otro).status_code == 403
    assert client.get("/universidad/estudiantes", headers=medico).status_code in (401, 403)
    assert client.get("/universidad/estudiantes").status_code == 401
    ac = acciones_auditoria(uid)
    assert "INSTITUCION_REGISTRADA" in ac and ac.count("INSTITUCION_ESTADO") == 3 and "UNIVERSIDAD_CONSULTA" in ac


# ------------------------------------------------------------------ Horas, asistencias y casos aprobados
def test_horas_asistencias_y_casos_aprobados(client, omega_headers, hospital, medico, firmado, lab, uni, pac):
    lab_h, lab_id = lab
    e = estudiante_de(client, omega_headers, hospital, uni)
    h = e["h"]
    # turno real: entrada/salida (un solo turno abierto a la vez)
    assert client.post("/practica/asistencias/salida", headers=h).status_code == 404
    a1 = client.post("/practica/asistencias/entrada", headers=h)
    assert a1.status_code == 201 and a1.json()["estado"] == "ABIERTA"
    assert client.post("/practica/asistencias/entrada", headers=h).status_code == 409
    c1 = client.post("/practica/asistencias/salida", headers=h)
    assert c1.status_code == 200 and c1.json()["estado"] == "CERRADA" and c1.json()["horas"] is not None
    # turnos "de verdad" (3 h y 2 h) sembrados en la BD
    t3, t2 = insertar_turno(e["dui"], 180), insertar_turno(e["dui"], 120)
    mis = client.get("/practica/asistencias", headers=h).json()
    assert len(mis) == 3
    # el tutor valida / rechaza; otro médico no puede
    otro = medico_nuevo(client, omega_headers)
    assert client.post(f"/cofirma/asistencias/{t3}/validar", headers=otro, json={"valida": True}).status_code == 403
    assert t3 in [a["id"] for a in client.get("/cofirma/asistencias", headers=medico).json()]
    assert client.get("/cofirma/asistencias", headers=otro).json() == []
    assert client.post(f"/cofirma/asistencias/{t2}/validar", headers=medico, json={"valida": False}).status_code == 422
    assert client.post(f"/cofirma/asistencias/{t3}/validar", headers=medico, json={"valida": True, "comentario": "Turno completo"}).json()["estado"] == "VALIDADA"
    assert client.post(f"/cofirma/asistencias/{t2}/validar", headers=medico, json={"valida": False, "comentario": "No asistió al turno completo"}).json()["estado"] == "RECHAZADA"
    assert client.post(f"/cofirma/asistencias/{t3}/validar", headers=medico, json={"valida": True}).status_code == 409
    assert client.post(f"/cofirma/asistencias/{c1.json()['id']}/validar", headers=e["h"], json={"valida": True}).status_code in (401, 403)  # no se autovalida
    assert acciones_auditoria(t3) == ["COFIRMA_DENEGADA", "ASISTENCIA_VALIDADA"]  # el intento de otro médico también queda registrado
    # la BD protege los turnos: horas, validación y borrado
    for q in ("UPDATE asistencia_practica SET minutos = 900 WHERE id = :i", "DELETE FROM asistencia_practica WHERE id = :i", "UPDATE asistencia_practica SET estado='RECHAZADA', comentario='x' WHERE id = :i",
              "UPDATE asistencia_practica SET entrada = entrada - interval '5 hours' WHERE id = :i", "TRUNCATE asistencia_practica"):
        with pytest.raises(DBAPIError, match="asistencia|inmutable"):
            with SessionLocal() as db:
                db.execute(text(q), {"i": t3})
                db.commit()
    # casos: 1 diagnóstico aprobado, 1 receta corregida, 1 orden aprobada, 1 rechazado y 1 pendiente (estos dos NO cuentan)
    at = abrir(client, medico, pac["dui"])
    bd, br, bo = (x.json()["id"] for x in (borrador_diag(client, h, at), borrador_rx(client, h, at), borrador_ol(client, h, at, lab_id)))
    rech = borrador_rx(client, h, at, meds=[PARA]).json()["id"]
    borrador_ol(client, h, at, lab_id)  # queda pendiente
    assert cofirmar(client, medico, bd).status_code == 200
    assert cofirmar(client, medico, br, "corregir", comentario="Cambio de fármaco", pin=PIN, receta={"medicamentos": [PARA]}).status_code == 200
    assert cofirmar(client, medico, bo).status_code == 200
    assert cofirmar(client, medico, rech, "rechazar", comentario="No corresponde al cuadro").status_code == 200
    # ---- lo que ve la universidad
    r = client.get("/universidad/estudiantes", headers=uni["h"])
    assert r.status_code == 200, r.text
    assert r.json()["total"] == 1
    it = r.json()["items"][0]
    assert it["id"] == e["id"] and it["carne"] == e["datos"]["estudiante"]["carne"] and it["asignacion_activa"]["nivel"] == "INTERNADO" and it["asignacion_activa"]["tutor"].startswith("Médico")
    assert it["horas_validadas"] == 3.0 and 3.0 <= it["horas_registradas"] <= 3.1  # 3 h validadas + el turno real; las 2 h rechazadas por el tutor no cuentan
    assert it["asistencias_validadas"] == 1
    assert it["casos"] == {"aprobados": 3, "de_ellos_corregidos": 1, "diagnosticos": 1, "recetas": 1, "ordenes": 1}
    d = client.get(f"/universidad/estudiantes/{e['id']}", headers=uni["h"]).json()
    assert len(d["asistencias"]) == 3 and {a["estado"] for a in d["asistencias"]} == {"CERRADA", "VALIDADA", "RECHAZADA"}
    assert sum(m["aprobados"] for m in d["casos_por_mes"]) == 3 and len(d["asignaciones"]) == 1 and d["asignaciones"][0]["activa"]
    s = client.get("/universidad/resumen", headers=uni["h"]).json()
    assert s["estudiantes"] == 1 and s["con_asignacion_activa"] == 1 and s["horas_validadas"] == 3.0 and s["casos"]["aprobados"] == 3
    # al finalizar la práctica, la historia se conserva
    client.post(f"/practicas/{sql('SELECT id FROM asignacion_practica WHERE estudiante_id = :e', e=e['id'])[0][0]}/finalizar", headers=hospital, json={"motivo": "Fin de rotación"})
    d = client.get(f"/universidad/estudiantes/{e['id']}", headers=uni["h"]).json()
    assert d["asignacion_activa"] is None and d["casos"]["aprobados"] == 3 and d["horas_validadas"] == 3.0
    ac = [a[0] for a in sql("SELECT accion FROM auditoria WHERE actor_id = :u", u=uni["id"])]
    assert ac.count("UNIVERSIDAD_CONSULTA") >= 4


# ------------------------------------------------------------------ Aislamiento entre universidades
def test_una_universidad_solo_ve_a_sus_estudiantes(client, omega_headers, codigos_2fa, hospital, uni):
    otra = nueva_uni(client, omega_headers, codigos_2fa)
    e1 = estudiante_de(client, omega_headers, hospital, uni)
    e2 = estudiante_de(client, omega_headers, hospital, otra)
    insertar_turno(e1["dui"], 60)
    insertar_turno(e2["dui"], 240)
    l1 = client.get("/universidad/estudiantes", headers=uni["h"]).json()["items"]
    l2 = client.get("/universidad/estudiantes", headers=otra["h"]).json()["items"]
    assert [x["id"] for x in l1] == [e1["id"]] and [x["id"] for x in l2] == [e2["id"]]
    assert client.get("/universidad/resumen", headers=uni["h"]).json()["horas_registradas" if False else "estudiantes"] == 1
    # el detalle de un estudiante ajeno es indistinguible de uno inexistente, y queda auditado
    ajeno = client.get(f"/universidad/estudiantes/{e2['id']}", headers=uni["h"])
    inex = client.get(f"/universidad/estudiantes/{uuid.uuid4()}", headers=uni["h"])
    assert ajeno.status_code == inex.status_code == 404 and ajeno.json() == inex.json()
    assert "UNIVERSIDAD_CONSULTA_DENEGADA" in [a[0] for a in sql("SELECT accion FROM auditoria WHERE actor_id = :u", u=uni["id"])]
    assert e2["dui"] not in json.dumps(l1) and e2["datos"]["estudiante"]["carne"] not in json.dumps(l1)
    # un estudiante no usa el portal de universidades
    assert client.get("/universidad/estudiantes", headers=e1["h"]).status_code in (401, 403)
    # tampoco cuentan las horas de una asignación hecha con otra universidad para el mismo estudiante
    assert client.get("/universidad/resumen", headers=otra["h"]).json()["estudiantes"] == 1


# ------------------------------------------------------------------ Ningún dato clínico ni de pacientes
def test_ningun_endpoint_de_universidad_devuelve_datos_clinicos(client, omega_headers, hospital, medico, firmado, lab, uni, pac):
    lab_h, lab_id = lab
    e = estudiante_de(client, omega_headers, hospital, uni)
    h = e["h"]
    at = abrir(client, medico, pac["dui"])
    unico = "Zzxqdiagnosticounico"
    bd = borrador_diag(client, h, at, descripcion=f"Neumonía {unico} lobar").json()["id"]
    br = borrador_rx(client, h, at, meds=[AMOX | {"medicamento": "Zzxqmedicamentounico"}]).json()["id"]
    bo = borrador_ol(client, h, at, lab_id, estudios=[{"nombre": "Zzxqestudiounico"}]).json()["id"]
    assert cofirmar(client, medico, bd).status_code == 200
    rx = cofirmar(client, medico, br, pin=PIN).json()
    ol = cofirmar(client, medico, bo).json()
    insertar_turno(e["dui"], 90)
    t = client.post("/universidad/lms/tokens", headers=uni["h"], json={"nombre": "Moodle de pruebas"})
    assert t.status_code == 201, t.text
    prohibidas = [unico, "Zzxqmedicamentounico", "Zzxqestudiounico", pac["dui"], pac["correo"], at, paciente_id(pac["dui"]), rx["folio"], ol["folio"],
                  str(rx["resultado_id"]), str(ol["resultado_id"]), bd, br, bo, "J06.9", "Amoxicilina", "Hemograma"]
    vistas = []
    fn = lambda conn, cur, stmt, *a: vistas.append(stmt.lower())  # noqa: E731
    event.listen(engine, "before_cursor_execute", fn)
    try:
        respuestas = [client.get(p, headers=uni["h"]) for p in ("/universidad/perfil", "/universidad/resumen", "/universidad/estudiantes", f"/universidad/estudiantes/{e['id']}", "/universidad/lms/tokens")]
        respuestas.append(client.get("/integraciones/lms/estudiantes", headers={"X-LMS-Token": t.json()["token"]}))
    finally:
        event.remove(engine, "before_cursor_execute", fn)
    llaves_prohibidas = {"paciente", "pacientes", "paciente_id", "atencion_id", "atencion", "folio", "diagnostico", "diagnosticos_detalle", "codigo_cie10", "descripcion", "observaciones", "medicamentos",
                         "medicamento", "estudios", "contenido", "contenido_final", "resultado_id", "resultado_tipo", "hash", "hash_contenido", "alergias", "resultados", "notas", "token_hash"}

    def llaves(o):
        if isinstance(o, dict):
            for k, v in o.items():
                yield k
                yield from llaves(v)
        elif isinstance(o, list):
            for v in o:
                yield from llaves(v)

    for r in respuestas:
        assert r.status_code == 200, (r.url, r.text)
        cuerpo = json.dumps(r.json(), ensure_ascii=False)
        for p in prohibidas:
            assert p not in cuerpo, (str(r.url), p)
        assert not (set(llaves(r.json())) & llaves_prohibidas), (str(r.url), set(llaves(r.json())) & llaves_prohibidas)
    # SQL espía: ninguna consulta de la universidad toca tablas clínicas, y de `borrador` nunca lee contenido ni paciente/atención
    todo = " ".join(vistas)
    for tbl in ("diagnostico", "nota_soap", "antecedente", "alergia", "signos_vitales", "egreso", "atencion", "receta", "orden_lab", "resultado_lab", "vacuna", "consentimiento", "defuncion"):
        assert f"from {tbl} " not in todo and f"join {tbl} " not in todo and f"from {tbl}\n" not in todo, f"la universidad leyó la tabla {tbl}"
    for st in vistas:
        if "borrador" in st:
            assert "contenido_cifrado" not in st and "borrador.paciente_id" not in st and "borrador.atencion_id" not in st and "contenido_final" not in st, st
        if "from persona" in st or "join persona" in st:
            assert "persona.password_hash" not in st and "totp" not in st


# ------------------------------------------------------------------ Token de lectura para LMS (solo estructura)
def test_token_lms_de_solo_lectura(client, omega_headers, codigos_2fa, hospital, medico, uni):
    otra = nueva_uni(client, omega_headers, codigos_2fa)
    e1, e2 = estudiante_de(client, omega_headers, hospital, uni), estudiante_de(client, omega_headers, hospital, otra)
    insertar_turno(e1["dui"], 120)
    # solo la universidad crea tokens
    for quien in (hospital, medico, e1["h"]):
        assert client.post("/universidad/lms/tokens", headers=quien, json={"nombre": "Moodle"}).status_code in (401, 403)
    assert client.post("/universidad/lms/tokens", headers=uni["h"], json={"nombre": "x"}).status_code == 422
    assert client.post("/universidad/lms/tokens", headers=uni["h"], json={"nombre": "Moodle", "dias": 999}).status_code == 422
    t = client.post("/universidad/lms/tokens", headers=uni["h"], json={"nombre": "Moodle producción", "dias": 30})
    assert t.status_code == 201, t.text
    tok, tid = t.json()["token"], t.json()["id"]
    assert tok.startswith("lms_") and t.json()["alcance"] == "lectura" and t.json()["prefijo"] == tok[:8]
    # solo se guarda el hash
    fila = sql("SELECT token_hash, prefijo FROM lms_token WHERE id = :i", i=tid)[0]
    assert fila[0] == hashlib.sha256(tok.encode()).hexdigest() and tok not in json.dumps(sql("SELECT * FROM lms_token WHERE id = :i", i=tid), default=str)
    assert "token" not in client.get("/universidad/lms/tokens", headers=uni["h"]).json()[0] and tid in [x["id"] for x in client.get("/universidad/lms/tokens", headers=uni["h"]).json()]
    assert tid not in [x["id"] for x in client.get("/universidad/lms/tokens", headers=otra["h"]).json()]
    # el endpoint de integración
    H = {"X-LMS-Token": tok}
    r = client.get("/integraciones/lms/estudiantes", headers=H)
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["lms_version"] == "1.0" and j["universidad"]["id"] == uni["id"] and [x["carne"] for x in j["estudiantes"]] == [e1["datos"]["estudiante"]["carne"]]
    assert e2["datos"]["estudiante"]["carne"] not in json.dumps(j)  # solo los de su universidad
    x = j["estudiantes"][0]
    assert x["horas_registradas"] == 2.0 and x["nivel_actual"] == "INTERNADO" and set(x) == {"carne", "nombre", "correo_institucional", "nivel_actual", "horas_registradas", "horas_validadas", "asistencias_validadas", "casos_aprobados", "casos_por_tipo"}
    # sin token / token ajeno / JWT / método de escritura: no
    assert client.get("/integraciones/lms/estudiantes").status_code == 401
    assert client.get("/integraciones/lms/estudiantes", headers={"X-LMS-Token": "lms_" + "a" * 43}).status_code == 401
    assert client.get("/integraciones/lms/estudiantes", headers={"X-LMS-Token": uni["h"]["Authorization"].split()[1]}).status_code == 401
    assert client.get("/integraciones/lms/estudiantes", headers=uni["h"]).status_code == 401  # el JWT no sirve aquí
    for m in ("post", "put", "patch", "delete"):
        assert getattr(client, m)("/integraciones/lms/estudiantes", headers=H).status_code == 405
    assert client.get("/universidad/estudiantes", headers=H).status_code == 401  # y el token LMS tampoco abre el portal
    # revocar (solo el dueño) y vencimiento
    assert client.delete(f"/universidad/lms/tokens/{tid}", headers=otra["h"]).status_code == 404
    assert client.delete(f"/universidad/lms/tokens/{tid}", headers=uni["h"]).json()["revocado_en"] is not None
    assert client.get("/integraciones/lms/estudiantes", headers=H).status_code == 401
    t2 = client.post("/universidad/lms/tokens", headers=uni["h"], json={"nombre": "Moodle 2"}).json()
    with SessionLocal() as db:
        db.execute(text("UPDATE lms_token SET expira_en = now() - interval '1 minute' WHERE id = :i"), {"i": t2["id"]})
        db.commit()
    assert client.get("/integraciones/lms/estudiantes", headers={"X-LMS-Token": t2["token"]}).status_code == 401
    # límite de tokens activos y restricción de solo lectura en la BD
    for k in range(5):
        assert client.post("/universidad/lms/tokens", headers=otra["h"], json={"nombre": f"Token {k}"}).status_code == 201
    assert client.post("/universidad/lms/tokens", headers=otra["h"], json={"nombre": "Token 6"}).status_code == 409
    with pytest.raises(IntegrityError, match="solo_lectura"):
        with SessionLocal() as db:
            db.execute(text("INSERT INTO lms_token (id, universidad_id, nombre, prefijo, token_hash, alcance, creado_en, expira_en) VALUES (gen_random_uuid(), :u, 'x', 'lms_xxxx', :h, 'escritura', now(), now() + interval '1 day')"),
                       {"u": uni["id"], "h": uuid.uuid4().hex * 2})
            db.commit()
    ac = acciones_auditoria(tid)
    assert ac[0] == "LMS_TOKEN_CREADO" and "LMS_TOKEN_REVOCADO" in ac and "LMS_TOKEN_RECHAZADO" in ac and ac.count("LMS_CONSULTA") == 1
    rec = sql("SELECT count(*) FROM auditoria WHERE accion = 'LMS_TOKEN_RECHAZADO' AND recurso_id = :i", i=tid)[0][0]
    assert rec >= 1
    assert "LMS_CONSULTA" in sql("SELECT array_agg(accion) FROM auditoria WHERE actor_id = :u", u=uni["id"])[0][0]


def test_endpoints_documentados(client):
    paths = client.get("/openapi.json").json()["paths"]
    for p in ("/universidad/perfil", "/universidad/resumen", "/universidad/estudiantes", "/universidad/estudiantes/{estudiante_id}", "/universidad/lms/tokens", "/universidad/lms/tokens/{token_id}",
              "/integraciones/lms/estudiantes", "/practica/asistencias/entrada", "/practica/asistencias/salida", "/practica/asistencias", "/cofirma/asistencias", "/cofirma/asistencias/{asistencia_id}/validar"):
        assert p in paths, p
        assert all(op.get("summary") for op in paths[p].values()), p
