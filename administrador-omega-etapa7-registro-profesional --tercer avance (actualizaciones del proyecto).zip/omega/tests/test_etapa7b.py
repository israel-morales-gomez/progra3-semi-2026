"""Etapa 7 · parte 1 (base común): dos portales FALSOS montados en una mini-app demuestran que la cookie de uno no abre el otro,
que sin sesión se redirige al login propio, la expiración propia por portal, CSRF, la guardia requiere_area y las páginas de error."""
import hashlib
import re
import uuid
from pathlib import Path

import pytest
from fastapi import APIRouter, Depends, FastAPI, HTTPException, Request
from fastapi.responses import RedirectResponse, Response
from fastapi.testclient import TestClient
from sqlalchemy import select, text
from sqlalchemy.orm import Session

from main import app as app_real
from omega_core.database import SessionLocal, get_db
from omega_core.models import Persona
from omega_core.seed import DUI_CIVIL
from web.comun import portales, sesion as ses
from web.comun.errores import instalar_errores
from web.comun.portales import Portal, _persona
from web.comun.sesion import Guardias, RedirigirALogin, Sesion, csrf_de, manejar_redireccion, requiere_area
from web.comun.vista import Vista

from .test_etapa2 import sql

# Dos portales de prueba; reutilizan dos slugs que la tabla sesion_web admite, pero con rutas y expiraciones propias.
A = Portal("laboratorio", "Prueba A", "Portal falso A", "persona", _persona, "Persona", ruta="/prueba-a", inactividad_min=30, absoluta_min=480)
B = Portal("universidad", "Prueba B", "Portal falso B", "persona", _persona, "Persona", ruta="/prueba-b", inactividad_min=5, absoluta_min=60)


def _hash(v: str) -> str:
    return hashlib.sha256(v.encode()).hexdigest()


def _crear_mini(carpeta: Path) -> FastAPI:
    (carpeta / "templates").mkdir()
    (carpeta / "templates" / "base.html").write_text(
        '{% extends "_documento.html" %}{% block cabecera %}<header class="cabecera"><a class="marca" href="{{ portal.base }}">{{ portal.nombre }}</a></header>{% endblock %}', encoding="utf-8")
    (carpeta / "templates" / "area.html").write_text(
        '{% extends "base.html" %}{% block contenido %}<h1>Área {{ portal.nombre }}</h1><form method="post" action="{{ portal.base }}/accion">'
        '<input type="hidden" name="csrf_token" value="{{ csrf_token }}"></form>{% endblock %}', encoding="utf-8")
    mini = FastAPI()
    mini.add_exception_handler(RedirigirALogin, manejar_redireccion)
    instalar_errores(mini)
    for portal in (A, B):
        mini.include_router(_rutas(portal, carpeta))
    return mini


def _rutas(portal: Portal, carpeta: Path) -> APIRouter:
    vista, csrf, area = Vista(portal, carpeta), csrf_de(portal), requiere_area(portal)
    solo_admin = requiere_area(portal, lambda s: False)  # un área que nadie puede ver: prueba el 403
    r = APIRouter(prefix=portal.base)

    @r.get("/ingresar")
    def pagina(request: Request):
        return vista.render(request, "area.html")

    @r.post("/entrar")
    def entrar(request: Request, campos: dict = Depends(csrf), db: Session = Depends(get_db)):
        pid = db.scalar(select(Persona.id).where(Persona.dui == campos.get("dui", "")))
        if pid is None:
            raise HTTPException(401)
        valor = ses.abrir_sesion(db, request, portal, "persona", pid)
        db.commit()
        resp = RedirectResponse(f"{portal.base}/area", 303)
        ses.poner_cookie(resp, portal, portal.cookie_sesion, valor)
        return resp

    @r.get("/area")
    def area_(request: Request, sesion: Sesion = Depends(area)):
        return vista.render(request, "area.html", sesion)

    @r.get("/admin")
    def admin(sesion: Sesion = Depends(solo_admin)):
        return {"ok": True}

    @r.post("/accion")
    def accion(sesion: Sesion = Depends(area), _: dict = Depends(csrf)):
        return Response(status_code=204)

    @r.get("/explota")
    def explota():
        raise RuntimeError("secreto-interno-123")

    return r


@pytest.fixture(scope="module")
def mini(tmp_path_factory, client):  # `client` siembra la base de datos
    return _crear_mini(tmp_path_factory.mktemp("portales_falsos"))


def nuevo(mini, **kw) -> TestClient:
    return TestClient(mini, follow_redirects=False, **kw)


def token_de(html: str) -> str:
    m = re.search(r'name="csrf_token" value="([0-9a-f]{64})"', html)
    assert m
    return m.group(1)


def entrar(c: TestClient, portal: Portal, dui: str = DUI_CIVIL):
    t = token_de(c.get(portal.base + "/ingresar").text)
    r = c.post(portal.base + "/entrar", data={"csrf_token": t, "dui": dui})
    assert r.status_code == 303, r.text
    return r


# ------------------------------------------------------------------ Cookie propia por portal
def test_cookie_con_nombre_path_y_atributos_propios(mini):
    c = nuevo(mini)
    sc = entrar(c, A).headers["set-cookie"].lower()
    assert A.cookie_sesion in sc and "httponly" in sc and "samesite=strict" in sc and "path=/prueba-a" in sc and "path=/;" not in sc
    assert ("secure" in sc) == ses.SEGURA  # Secure solo con ENTORNO=produccion
    assert A.cookie_sesion != B.cookie_sesion and A.cookie_csrf != B.cookie_csrf
    assert c.get("/prueba-a/area").status_code == 200


def test_secure_y_prefijo_en_produccion(monkeypatch):
    monkeypatch.setattr(portales, "SEGURA", True)
    monkeypatch.setattr(ses, "SEGURA", True)
    resp = Response()
    ses.poner_cookie(resp, A, A.cookie_sesion, "x")
    sc = resp.headers["set-cookie"].lower()
    assert A.cookie_sesion.startswith("__Secure-") and "secure" in sc and "httponly" in sc and "samesite=strict" in sc and "path=/prueba-a" in sc


def test_expiracion_propia_de_cada_portal(mini):
    c = nuevo(mini)
    entrar(c, A)
    entrar(c, B)
    va, vb = c.cookies.get(A.cookie_sesion), c.cookies.get(B.cookie_sesion)
    consulta = "SELECT extract(epoch FROM expira_en - creada_en) FROM sesion_web WHERE token_hash = :h"
    assert abs(float(sql(consulta, h=_hash(va))[0][0]) - 480 * 60) < 5  # A: 8 h
    assert abs(float(sql(consulta, h=_hash(vb))[0][0]) - 60 * 60) < 5  # B: 1 h
    with SessionLocal() as db:  # 6 minutos sin actividad: vence B (5 min) pero no A (30 min)
        db.execute(text("UPDATE sesion_web SET ultimo_uso = now() - interval '6 minutes' WHERE token_hash IN (:a, :b)"), {"a": _hash(va), "b": _hash(vb)})
        db.commit()
    assert c.get("/prueba-a/area").status_code == 200
    assert c.get("/prueba-b/area").status_code == 303


# ------------------------------------------------------------------ Aislamiento y redirección al login propio
def test_la_cookie_de_un_portal_no_abre_el_otro(mini):
    c = nuevo(mini)
    entrar(c, A)
    valor_a = c.cookies.get(A.cookie_sesion)
    r = c.get("/prueba-b/area")  # el navegador no manda la cookie de A a la ruta de B
    assert r.status_code == 303 and r.headers["location"].startswith("/prueba-b/ingresar")
    w = nuevo(mini)  # y aunque alguien copie el valor de A en la cookie de B, el servidor lo rechaza (la sesión es de UN portal)
    w.cookies.set(B.cookie_sesion, valor_a, path="/prueba-b")
    r = w.get("/prueba-b/area")
    assert r.status_code == 303 and r.headers["location"].startswith("/prueba-b/ingresar")
    c2 = nuevo(mini)
    entrar(c2, B)
    w2 = nuevo(mini)
    w2.cookies.set(A.cookie_sesion, c2.cookies.get(B.cookie_sesion), path="/prueba-a")
    assert w2.get("/prueba-a/area").status_code == 303


@pytest.mark.parametrize("portal", [A, B], ids=lambda p: p.base)
def test_sin_sesion_redirige_al_login_de_su_propio_portal(mini, portal):
    c = nuevo(mini)
    r = c.get(portal.base + "/area")
    assert r.status_code == 303 and r.headers["location"] == f"{portal.base}/ingresar?siguiente={portal.base}/area"
    assert portal.cookie_sesion in r.headers["set-cookie"] and f"path={portal.base}" in r.headers["set-cookie"].lower()  # borra la cookie vencida
    x = c.get(portal.base + "/area", headers={"HX-Request": "true"})  # HTMX: 401 + HX-Redirect, no un fragmento
    assert x.status_code == 401 and x.headers["hx-redirect"].startswith(f"{portal.base}/ingresar")
    assert not any(o.base in r.headers["location"] for o in (A, B) if o is not portal)


def test_requiere_area_responde_403_si_falta_el_permiso(mini):
    c = nuevo(mini)
    entrar(c, A)
    assert c.get("/prueba-a/admin").status_code == 403  # con sesión pero sin permiso: 403, no login
    h = c.get("/prueba-a/admin", headers={"Accept": "text/html"})
    assert h.status_code == 403 and "Acceso denegado" in h.text and "/prueba-a/admin" not in h.text
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'WEB_AREA_DENEGADA' AND detalle->>'portal' = 'laboratorio'")[0][0] >= 1
    assert nuevo(mini).get("/prueba-a/admin").status_code == 303  # sin sesión: al login


# ------------------------------------------------------------------ CSRF y cabecera sin enlaces a otros portales
def test_csrf_ligado_al_portal(mini):
    c = nuevo(mini)
    entrar(c, A)
    assert c.post("/prueba-a/accion").status_code == 403  # sin token
    bueno = token_de(c.get("/prueba-a/area").text)
    assert c.post("/prueba-a/accion", data={"csrf_token": bueno}).status_code == 204
    assert c.post("/prueba-a/accion", headers={"X-CSRF-Token": bueno}).status_code == 204  # HTMX
    de_b = token_de(c.get("/prueba-b/ingresar").text)  # el token de OTRO portal no vale aquí
    assert c.post("/prueba-a/accion", data={"csrf_token": de_b}).status_code == 403
    assert c.post("/prueba-a/accion", data={"csrf_token": bueno}, headers={"Origin": "https://sitio-malo.example"}).status_code == 403


@pytest.mark.parametrize("portal", [A, B], ids=lambda p: p.base)
def test_la_cabecera_no_enlaza_a_otros_portales(mini, portal):
    html = nuevo(mini).get(portal.base + "/ingresar").text
    enlaces = re.findall(r'(?:href|action)="([^"]+)"', html)
    assert enlaces and all(e.startswith((portal.base, "/static", "#")) for e in enlaces), enlaces
    otro = B if portal is A else A
    assert otro.base not in html and "hx-headers" in html


# ------------------------------------------------------------------ Páginas de error sin información interna
def test_paginas_de_error_html_en_la_app_real():
    c = TestClient(app_real, follow_redirects=False)
    html = {"Accept": "text/html"}
    r = c.get("/no-existe-" + uuid.uuid4().hex[:6], headers=html)
    assert r.status_code == 404 and "Página no encontrada" in r.text and r.headers["content-type"].startswith("text/html")
    assert "content-security-policy" in r.headers and "detail" not in r.text and "Traceback" not in r.text
    r = c.get("/ciudadano/salir", headers=html)  # método no permitido
    assert r.status_code == 405 and "Acción no disponible" in r.text
    r = c.post("/ciudadano/ingresar", data={"dui": "x", "password": "y"}, headers=html)  # CSRF rechazado: mensaje genérico
    assert r.status_code == 403 and "Acceso denegado" in r.text and "token" not in r.text.lower() and "csrf" not in r.text.lower()
    assert all(e in ("/", ) or e.startswith("/static") for e in re.findall(r'href="([^"]+)"', r.text))  # no enlaza a ningún portal
    j = c.get("/no-existe")  # sin Accept: html, la API conserva su JSON
    assert j.status_code == 404 and j.json() == {"detail": "Not Found"}


def test_error_500_no_revela_nada_interno(mini):
    c = nuevo(mini, raise_server_exceptions=False)
    r = c.get("/prueba-a/explota", headers={"Accept": "text/html"})
    assert r.status_code == 500 and "Error del sistema" in r.text
    assert "secreto-interno-123" not in r.text and "RuntimeError" not in r.text and "Traceback" not in r.text and "/prueba-a" not in r.text
    assert "content-security-policy" in r.headers and r.headers["cache-control"] == "no-store"
    j = c.get("/prueba-a/explota")
    assert j.status_code == 500 and j.json() == {"detail": "Error interno"} and "secreto" not in j.text
