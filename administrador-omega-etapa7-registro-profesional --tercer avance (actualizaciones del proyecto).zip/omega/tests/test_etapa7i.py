"""Etapa 7 · integración web del expediente civil · parte 1: pestaña «Medicamentos» (historial farmacológico) de /ciudadano.
Línea de tiempo (recetas + administraciones + autocompras), alta manual de autocompras con CSRF y alertas de interacciones.
Las pruebas no dependen de «la última fila» de tablas compartidas: todo se busca por persona, folio o nombre único."""
import re
import uuid
from datetime import date, timedelta

import pytest

from portal_civil import interacciones as I
from web.comun.portales import CIUDADANO

from .conftest import datos_persona
from .test_etapa2 import NAC, abrir, acciones_auditoria, medico, paciente_id, sql  # noqa: F401
from .test_etapa3a import AMOX, emitir, firmado  # noqa: F401
from .test_etapa4a import pac, pac_h  # noqa: F401
from .test_etapa7a import entrar_persona, nuevo, token_de, web  # noqa: F401  (web es un fixture)
from .test_etapa7d import _diag

EXP = "/ciudadano/expediente?seccion=medicamentos"
AUTO = "/ciudadano/medicamentos/autocompra"
HX = {"HX-Request": "true"}
WARFARINA = {"medicamento": "Warfarina", "presentacion": "tabletas 5 mg", "dosis": "5 mg", "via": "oral", "frecuencia": "cada 24 horas", "duracion_dias": 30, "cantidad": 30}


def _entrar(web, persona):
    assert entrar_persona(web, CIUDADANO, persona["dui"], persona["password"]).status_code == 303
    return web


def _declarar(web, **campos):
    """POST del formulario con el token CSRF de la propia pestaña."""
    datos = {"medicamento": "Ibuprofeno 400 mg", "dosis": "1 tableta cada 8 h", "fecha_compra": str(date.today() - timedelta(days=1)), "farmacia": "Farmacia Central"} | campos
    return web.post(AUTO, data={"csrf_token": token_de(web.get(EXP).text)} | datos)


def _tarjetas(html: str) -> int:
    return len(re.findall(r'class="registro canal-', html))


def _autocompras(persona_id: str) -> int:
    return sql("SELECT count(*) FROM autocompra WHERE paciente_id = :p", p=persona_id)[0][0]


# ------------------------------------------------------------------ catálogo de interacciones (sin base de datos)
@pytest.mark.parametrize("prescrito,autocompra,severidad", [
    ("Warfarina 5 mg", "Ibuprofeno 400 mg", "GRAVE"),
    ("Aspirina", "Acenocumarol", "GRAVE"),
    ("Tramadol", "Diazepam", "GRAVE"),
    ("Tadalafil", "Nitroglicerina", "GRAVE"),
    ("Losartán", "Naproxeno", "MODERADA"),
    ("Ciprofloxacino", "Carbonato de calcio", "MODERADA"),
    ("Amoxicilina 500 mg", "Amoxicilina", "MODERADA"),  # duplicidad: misma sustancia en ambos canales
])
def test_catalogo_detecta_interacciones_y_duplicidad(prescrito, autocompra, severidad):
    alertas = I.detectar([prescrito], [autocompra])
    assert len(alertas) == 1 and alertas[0].severidad == severidad
    assert alertas[0].prescrito == prescrito and alertas[0].autocompra == autocompra
    assert "médico o farmacéutico" in alertas[0].consejo and "No suspenda" in alertas[0].consejo  # nunca manda suspender


def test_catalogo_sin_falsos_positivos_ni_repetidos_y_ordena_por_gravedad():
    assert I.detectar(["Amoxicilina"], ["Paracetamol"]) == []
    assert I.detectar([], ["Ibuprofeno"]) == [] and I.detectar(["Warfarina"], []) == []
    assert I.detectar(["Warfarina", "Warfarina"], ["Ibuprofeno", "Ibuprofeno"]) and len(I.detectar(["Warfarina", "Warfarina"], ["Ibuprofeno", "Ibuprofeno"])) == 1
    mezcla = I.detectar(["Warfarina", "Losartán"], ["Ibuprofeno"])
    assert [a.severidad for a in mezcla] == ["GRAVE", "MODERADA"]


# ------------------------------------------------------------------ humo y permisos
def test_humo_la_pestana_responde_y_exige_sesion(web, pac):
    anonimo = nuevo(50201)
    assert anonimo.get(EXP).status_code == 303 and "/ciudadano/ingresar" in anonimo.get(EXP).headers["location"]
    assert anonimo.post(AUTO, data={}).status_code in (303, 403)  # sin sesión ni token no se declara nada
    _entrar(web, pac)
    r = web.get(EXP)
    assert r.status_code == 200 and "Medicamentos" in r.text and "Sin movimientos" in r.text
    assert "Sin alertas" in r.text and 'action="/ciudadano/medicamentos/autocompra"' in r.text
    frag = web.get("/ciudadano/expediente/medicamentos", headers=HX)  # fragmento HTMX de la pestaña
    assert frag.status_code == 200 and "Declarar un medicamento" in frag.text
    assert web.get("/ciudadano/expediente/medicamentos").status_code == 303  # sin HTMX vuelve a la página completa
    assert 'seccion=medicamentos' in web.get("/ciudadano/expediente/medicamentos").headers["location"]


def test_la_lectura_queda_en_la_bitacora(web, pac):
    _entrar(web, pac)
    assert web.get(EXP).status_code == 200
    n = sql("SELECT count(*) FROM auditoria WHERE accion = 'PORTAL_LECTURA_PROPIA' AND recurso_id = :p AND detalle->>'seccion' = 'medicamentos'", p=paciente_id(pac["dui"]))[0][0]
    assert n >= 1


def test_csrf_es_obligatorio_para_declarar(web, pac):
    _entrar(web, pac)
    datos = {"medicamento": "Ibuprofeno", "dosis": "400 mg", "fecha_compra": str(date.today()), "farmacia": ""}
    assert web.post(AUTO, data=datos).status_code == 403
    assert web.post(AUTO, data=datos | {"csrf_token": "0" * 64}).status_code == 403
    assert _autocompras(paciente_id(pac["dui"])) == 0


# ------------------------------------------------------------------ alta manual de autocompras
def test_alta_manual_aparece_en_la_linea_de_tiempo_con_su_etiqueta(web, pac):
    _entrar(web, pac)
    r = _declarar(web, medicamento="Ibuprofeno 400 mg")
    assert r.status_code == 303 and "seccion=medicamentos" in r.headers["location"] and "aviso=autocompra" in r.headers["location"]
    pagina = web.get(r.headers["location"])
    assert pagina.status_code == 200 and "quedó registrada" in pagina.text
    assert "Ibuprofeno 400 mg" in pagina.text and "Declarada por el paciente" in pagina.text and "no es una receta" in pagina.text
    assert _tarjetas(pagina.text) == 1 and "Sin movimientos" not in pagina.text
    pid = paciente_id(pac["dui"])
    assert _autocompras(pid) == 1
    assert sql("SELECT origen FROM autocompra WHERE paciente_id = :p", p=pid) == [("DECLARADA_POR_PACIENTE",)]
    aid = str(sql("SELECT id FROM autocompra WHERE paciente_id = :p", p=pid)[0][0])
    assert acciones_auditoria(aid) == ["AUTOCOMPRA_REGISTRADA"]
    assert "Ibuprofeno" not in str(sql("SELECT detalle::text FROM auditoria WHERE recurso_id = :r", r=aid))  # la bitácora no guarda el medicamento


def test_farmacia_es_opcional_y_el_html_se_escapa(web, pac):
    _entrar(web, pac)
    assert _declarar(web, medicamento="<b>Paracetamol</b>", farmacia="").status_code == 303
    pagina = web.get(EXP)
    assert "&lt;b&gt;Paracetamol&lt;/b&gt;" in pagina.text and "<b>Paracetamol</b>" not in pagina.text
    assert "Sin información" in pagina.text  # sin farmacia


@pytest.mark.parametrize("campos,mensaje", [
    ({"medicamento": ""}, "Escriba al menos 2 caracteres"),
    ({"dosis": ""}, "Escriba al menos 1 caracteres"),
    ({"fecha_compra": ""}, "fecha de compra válida"),
    ({"fecha_compra": "no-es-fecha"}, "fecha de compra válida"),
    ({"fecha_compra": str(date.today() + timedelta(days=2))}, "no puede ser futura"),
    ({"medicamento": "x" * 201}, "como máximo 200"),
])
def test_validaciones_conservan_lo_escrito_y_no_guardan(web, pac, campos, mensaje):
    _entrar(web, pac)
    r = _declarar(web, **({"farmacia": "Mi farmacia"} | campos))
    assert r.status_code == 422 and mensaje in r.text
    assert "Revise los campos marcados" in r.text or "no puede ser futura" in r.text
    assert "Mi farmacia" in r.text  # el resto del formulario se conserva
    assert _autocompras(paciente_id(pac["dui"])) == 0


# ------------------------------------------------------------------ alertas con recetas reales
def test_receta_vigente_mas_autocompra_genera_alerta_y_una_segura_no(web, client, medico, firmado, pac):
    abrir(client, medico, pac["dui"])
    rx = emitir(client, firmado, pac["dui"], meds=(WARFARINA,))
    assert rx.status_code == 201, rx.text
    _entrar(web, pac)
    base = web.get(EXP)
    assert rx.json()["folio"] in base.text and "Receta médica" in base.text and "Warfarina" in base.text
    assert "Sin alertas" in base.text  # recetada sola: nada que cruzar
    assert _declarar(web, medicamento="Paracetamol 500 mg").status_code == 303
    assert "Sin alertas" in web.get(EXP).text  # paracetamol no interactúa con warfarina en el catálogo
    assert _declarar(web, medicamento="Ibuprofeno 400 mg").status_code == 303
    pagina = web.get(EXP)
    assert "Alertas de interacciones (1)" in pagina.text and "Riesgo de sangrado" in pagina.text and "Grave" in pagina.text
    assert "Recetado: <strong>Warfarina</strong>" in pagina.text and "No suspenda ningún tratamiento" in pagina.text
    assert _declarar(web, medicamento="Warfarina").status_code == 303
    assert "Medicamento repetido" in web.get(EXP).text


def test_autocompra_antigua_sale_del_cruce_pero_sigue_en_la_linea_de_tiempo(web, client, medico, firmado, pac):
    abrir(client, medico, pac["dui"])
    assert emitir(client, firmado, pac["dui"], meds=(WARFARINA,)).status_code == 201
    _entrar(web, pac)
    assert _declarar(web, medicamento="Naproxeno 500 mg", fecha_compra=str(date.today() - timedelta(days=90))).status_code == 303
    pagina = web.get(EXP)
    assert "Sin alertas" in pagina.text and "Naproxeno 500 mg" in pagina.text


# ------------------------------------------------------------------ línea de tiempo: mezcla, orden y páginas
def test_linea_de_tiempo_ordena_por_fecha_y_pagina_de_a_diez(web, client, medico, firmado, pac):
    abrir(client, medico, pac["dui"])
    rx = emitir(client, firmado, pac["dui"], meds=(AMOX,)).json()
    _entrar(web, pac)
    for n in range(11):
        assert _declarar(web, medicamento=f"Vitamina-{n:02d}", fecha_compra=str(date.today() - timedelta(days=n))).status_code == 303
    p1, p2 = web.get(EXP), web.get(EXP + "&pagina=2")
    assert _tarjetas(p1.text) == 10 and _tarjetas(p2.text) == 2  # 12 movimientos: 11 autocompras + 1 receta
    assert p1.text.index("Vitamina-00") < p1.text.index("Vitamina-01") < p1.text.index("Vitamina-08")  # más reciente primero
    assert rx["folio"] in p1.text and "Vitamina-09" in p2.text and "Vitamina-10" in p2.text and "Vitamina-09" not in p1.text  # página 1: receta + 9 autocompras
    assert "Receta médica" in (p1.text + p2.text) and "Declarada por el paciente" in p1.text
    assert "No hay más registros" in web.get(EXP + "&pagina=3").text


# ------------------------------------------------------------------ aislamiento entre ciudadanos y nivel 4
def test_un_ciudadano_no_ve_ni_escribe_en_el_historial_de_otro(web, client, pac):
    otro = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=otro).status_code == 201
    unico = f"Zmed{uuid.uuid4().hex[:8]}"
    _entrar(web, pac)
    assert _declarar(web, medicamento=unico).status_code == 303
    b = _entrar(nuevo(50202), otro)
    assert unico not in b.get(EXP).text
    assert unico not in b.get(EXP + f"&dui={pac['dui']}").text  # ningún parámetro cambia de quién es el historial
    pid_a, pid_b = paciente_id(pac["dui"]), paciente_id(otro["dui"])
    # un formulario con ids o DUI ajenos no cambia a quién se guarda: siempre el titular de la sesión
    r = b.post(AUTO, data={"csrf_token": token_de(b.get(EXP).text), "medicamento": "Intruso", "dosis": "1", "fecha_compra": str(date.today()),
                           "dui": pac["dui"], "paciente_id": pid_a})
    assert r.status_code == 303
    assert _autocompras(pid_a) == 1 and _autocompras(pid_b) == 1
    assert sql("SELECT count(*) FROM autocompra WHERE paciente_id = :p AND medicamento = 'Intruso'", p=pid_a)[0][0] == 0


def test_la_pestana_no_filtra_datos_de_nivel_4(web, client, medico, pac):
    _diag(client, medico, abrir(client, medico, pac["dui"]), "B20", "Enfermedad por VIH")  # diagnóstico de nivel 4
    _entrar(web, pac)
    assert _declarar(web, medicamento="Vitamina C").status_code == 303
    pagina = web.get(EXP)
    assert pagina.status_code == 200 and "VIH" not in pagina.text and "B20" not in pagina.text
    protegido = web.get("/ciudadano/expediente?seccion=diagnosticos")
    assert "Protegido" in protegido.text and "VIH" not in protegido.text  # sin desbloqueo 2FA sigue oculto
