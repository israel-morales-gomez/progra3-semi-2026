"""Etapa 7 · portal /profesional: registro del profesional desde la web (con base de datos)."""
import re
import uuid

import pytest

from omega_core.roles_profesionales import ROLES
from omega_core.seed import DUI_MEDICO
from web.comun.portales import PROFESIONAL
from web.profesional import alta

from .conftest import datos_persona
from .test_etapa2 import sql
from .test_etapa7a import entrar_persona, enviar, token_de, web  # noqa: F401  (web es un fixture)

REGISTRO = "/profesional/registro"


def formulario(**extra) -> dict:
    """Campos del formulario web (todo texto, como llega del navegador)."""
    d = datos_persona()
    campos = {k: d[k] for k in ("dui", "nombres", "apellidos", "correo", "telefono")}
    campos |= {"password": d["password"], "password2": d["password"], "tipo": "DOCTOR", "rol_clave": "pediatra",
               "numero_junta": f"JVPM-{uuid.uuid4().hex[:8]}", "especialidad": "Pediatría", "departamento": "Usulután"}
    return campos | extra


def perfil(dui: str):
    return sql("SELECT p.tipo, p.rol_clave, p.especialidad, p.verificado, p.activo, p.numero_junta FROM perfil_profesional p JOIN persona x ON x.id = p.persona_id WHERE x.dui = :d", d=dui)


# ------------------------------------------------------------------ Página
def test_pagina_de_registro_es_publica_y_trae_los_65_ambitos(web):  # noqa: F811
    r = web.get(REGISTRO)
    assert r.status_code == 200
    assert len(re.findall(r'<option value="[a-z_]+" ', r.text)) >= len(ROLES)  # los 65 ámbitos (más los de otros selectores sin ese formato de clave)
    for clave in ("cardiologo", "enfermero_general", "medico_de_urgencias"):
        assert f'value="{clave}"' in r.text
    for nombre in ("tipo", "numero_junta", "rol_clave", "institucion_id", "password2", "csrf_token"):
        assert f'name="{nombre}"' in r.text


def test_el_login_y_la_navegacion_enlazan_al_registro(web):  # noqa: F811
    for url in ("/ciudadano/ingresar", "/ciudadano/ingresar?tipo=profesional"):  # el login único lo ofrece siempre
        assert 'href="/profesional/registro"' in web.get(url).text
    assert 'href="/profesional/registro"' in web.get(REGISTRO).text  # la cabecera sin sesión


def test_con_sesion_el_registro_redirige_al_panel(web):  # noqa: F811
    assert entrar_persona(web, PROFESIONAL).status_code == 303
    r = web.get(REGISTRO)
    assert r.status_code == 303 and r.headers["location"] == "/profesional/panel"


# ------------------------------------------------------------------ Alta
def test_registro_crea_persona_y_perfil_profesional_sin_verificar(web):  # noqa: F811
    campos = formulario()
    r = enviar(web, REGISTRO, campos)
    assert r.status_code == 303 and r.headers["location"] == "/ciudadano/ingresar?registrado=1&tipo=profesional"
    (tipo, rol, esp, verificado, activo, junta), = perfil(campos["dui"].replace("-", "")) or perfil(campos["dui"])
    assert (tipo, rol, esp) == ("DOCTOR", "pediatra", "Pediatría")
    assert verificado is False and activo is True and junta == campos["numero_junta"]
    # el aviso del login explica la verificación pendiente
    assert "pendiente de verificación" in web.get(r.headers["location"]).text
    # queda en la bitácora igual que en la API
    assert sql("SELECT 1 FROM auditoria WHERE accion = 'PERSONA_REGISTRADA' ORDER BY id DESC LIMIT 1")


def test_el_profesional_recien_registrado_entra_a_su_portal_pero_no_opera(web):  # noqa: F811
    campos = formulario(rol_clave="cardiologo", especialidad="Cardiología")
    assert enviar(web, REGISTRO, campos).status_code == 303
    r = entrar_persona(web, PROFESIONAL, dui=campos["dui"], password=campos["password"])
    assert r.status_code == 303 and r.headers["location"] == "/profesional/panel"
    panel = web.get("/profesional/panel")
    assert panel.status_code == 200 and "Cardiólogo" in panel.text
    assert "Abrir atención" not in panel.text  # sin verificar no hay tablero operativo (profesional_de lo impide)
    assert "verific" in web.get("/profesional/cuenta").text.lower()


def test_enfermeria_con_su_ambito(web):  # noqa: F811
    campos = formulario(tipo="ENFERMERA", rol_clave="enfermero_general", especialidad="")
    assert enviar(web, REGISTRO, campos).status_code == 303
    (tipo, rol, esp, *_), = perfil(campos["dui"].replace("-", "")) or perfil(campos["dui"])
    assert (tipo, rol, esp) == ("ENFERMERA", "enfermero_general", None)


# ------------------------------------------------------------------ Validaciones (las del esquema de la API)
def test_ambito_que_no_corresponde_al_tipo(web):  # noqa: F811
    r = enviar(web, REGISTRO, formulario(tipo="ENFERMERA", rol_clave="cardiologo"))
    assert r.status_code == 422 and "no corresponde al tipo de profesional" in r.text
    r = enviar(web, REGISTRO, formulario(tipo="DOCTOR", rol_clave="enfermero_general"))
    assert r.status_code == 422 and "no corresponde al tipo de profesional" in r.text


def test_faltan_tipo_o_ambito_y_se_muestran_con_los_demas_errores(web):  # noqa: F811
    r = enviar(web, REGISTRO, formulario(tipo="", rol_clave="", dui="123", correo="no-es-correo"))
    assert r.status_code == 422
    assert "Indique si es doctor o enfermero." in r.text and "Elija su ámbito laboral." in r.text
    assert "Revise los campos marcados." in r.text
    assert 'value="123"' in r.text  # conserva lo escrito


def test_ambito_inventado_se_rechaza(web):  # noqa: F811
    r = enviar(web, REGISTRO, formulario(rol_clave="mago_supremo"))
    assert r.status_code == 422 and "Elija un ámbito laboral de la lista." in r.text


def test_junta_obligatoria_y_contrasenas_distintas(web):  # noqa: F811
    r = enviar(web, REGISTRO, formulario(numero_junta=""))
    assert r.status_code == 422 and 'aria-invalid' in r.text
    r = enviar(web, REGISTRO, formulario(password2="OtraClave123"))
    assert r.status_code == 422 and "Las contraseñas no coinciden." in r.text


def test_contrasena_debil_la_rechaza_el_esquema(web):  # noqa: F811
    r = enviar(web, REGISTRO, formulario(password="corta", password2="corta"))
    assert r.status_code == 422 and 'aria-invalid' in r.text


def test_no_se_guarda_nada_si_hay_errores(web):  # noqa: F811
    campos = formulario(rol_clave="cardiologo", tipo="ENFERMERA")
    assert enviar(web, REGISTRO, campos).status_code == 422
    assert not sql("SELECT 1 FROM persona WHERE correo = :c", c=campos["correo"])


def test_duplicados_dui_y_junta(web):  # noqa: F811
    primero = formulario()
    assert enviar(web, REGISTRO, primero).status_code == 303
    r = enviar(web, REGISTRO, formulario(dui=primero["dui"]))  # mismo DUI
    assert r.status_code == 409 and "Dato ya registrado" in r.text
    r = enviar(web, REGISTRO, formulario(numero_junta=primero["numero_junta"]))  # misma junta
    assert r.status_code == 409 and "Dato ya registrado" in r.text
    r = enviar(web, REGISTRO, formulario(dui=DUI_MEDICO))  # el médico sembrado ya existe
    assert r.status_code == 409


def test_lugar_de_trabajo_valido_y_universidad_rechazada(web):  # noqa: F811
    filas = sql("SELECT id, tipo FROM institucion WHERE estado = 'ACTIVA' AND tipo <> 'UNIVERSIDAD' LIMIT 1")
    if filas:
        inst = str(filas[0][0])
        campos = formulario(institucion_id=inst)
        assert enviar(web, REGISTRO, campos).status_code == 303
        assert sql("SELECT p.institucion_id FROM perfil_profesional p WHERE p.numero_junta = :j", j=campos["numero_junta"])[0][0] == uuid.UUID(inst)
    r = enviar(web, REGISTRO, formulario(institucion_id="no-es-un-uuid"))
    assert r.status_code == 422
    r = enviar(web, REGISTRO, formulario(institucion_id=str(uuid.uuid4())))  # no existe
    assert r.status_code == 422 and "institucion_id" in r.text


def test_solo_se_listan_lugares_de_trabajo_activos_y_no_universidades(web):  # noqa: F811
    pagina = web.get(REGISTRO).text
    for (nombre,) in sql("SELECT nombre_legal FROM institucion WHERE estado <> 'ACTIVA' OR tipo = 'UNIVERSIDAD'"):
        assert nombre not in pagina


# ------------------------------------------------------------------ Seguridad
def test_sin_token_csrf_se_rechaza(web):  # noqa: F811
    web.get(REGISTRO)
    campos = formulario()
    r = web.post(REGISTRO, data=campos)
    assert r.status_code == 403
    assert not sql("SELECT 1 FROM persona WHERE correo = :c", c=campos["correo"])


def test_el_formulario_no_acepta_campos_de_privilegio(web):  # noqa: F811
    """`verificado` y `activo` no se leen del formulario: un registro web nunca nace verificado."""
    campos = formulario()
    assert enviar(web, REGISTRO, campos | {"verificado": "true", "es_omega": "true", "roles": "OMEGA"}).status_code == 303
    (_, _, _, verificado, _, _), = perfil(campos["dui"].replace("-", "")) or perfil(campos["dui"])
    assert verificado is False
    roles = {r[0] for r in sql("SELECT r.nombre FROM rol r JOIN persona_rol pr ON pr.rol_id = r.id JOIN persona x ON x.id = pr.persona_id WHERE x.correo = :c", c=campos["correo"])}
    assert roles == {"CIVIL", "PROFESIONAL"}  # nunca OMEGA, aunque el formulario lo pida


def test_limite_de_registros_por_ip(web):  # noqa: F811
    codigos = [enviar(web, REGISTRO, formulario()).status_code for _ in range(21)]
    assert codigos[:20] == [303] * 20 and codigos[20] == 429  # el mismo límite (20) que POST /personas


# ------------------------------------------------------------------ Módulo (sin base de datos)
def test_construir_devuelve_modelo_o_errores():
    v = alta.valores_de(formulario())
    modelo, errores = alta.construir(v, "ClaveSegura1", "ClaveSegura1")
    assert errores == {} and modelo.profesional.rol_clave == "pediatra" and modelo.profesional.tipo == "DOCTOR"
    modelo, errores = alta.construir(v | {"tipo": "ENFERMERA"}, "ClaveSegura1", "ClaveSegura1")
    assert modelo is None and "rol_clave" in errores
    assert modelo is None and alta.construir(v, "ClaveSegura1", "x")[1] == {"password2": "Las contraseñas no coinciden."}


def test_ambitos_agrupados_cubren_los_65():
    grupos = alta.ambitos()
    assert sum(len(roles) for _, roles in grupos) == 65 == len({c for _, roles in grupos for c, _ in roles})
