import json
import re
import uuid
from datetime import date, timedelta

import pytest
from sqlalchemy import text

from estadistica_epidemiologia import datos_ejemplo
from estadistica_epidemiologia.models import EpiEjemploVacuna
from omega_core.database import SessionLocal
from omega_core.seed import CODIGO_HOSPITAL, DUI_MEDICO, NIT_FARMACIA, PASSWORD_FARMACIA, PASSWORD_HOSPITAL, PASSWORD_MEDICO

from .conftest import datos_persona, dui_nuevo, nit_nuevo
from .test_etapa2 import NAC, abrir, auth, medico, sql  # noqa: F401
from .test_etapa2c import login
from .test_etapa3a import PIN, canje, emitir
from .test_etapa4a import vacuna
from .test_etapa6a import cama, ingresar
from .test_etapa6b import login_inst
from .test_etapa6c import salud  # noqa: F401
from .test_etapa6d import _claves, _hoy, get

HOY = _hoy()
RUTAS = ("/estadisticas/vacunacion/cobertura", "/estadisticas/poblacion-objetivo", "/estadisticas/recursos/insumos", "/estadisticas/recursos/consultas", "/estadisticas/recursos/camas")
PERMITIDAS = {"origen", "desde", "hasta", "min_dosis", "umbral_supresion", "celdas", "celdas_suprimidas", "nota", "vacuna", "departamento", "rango_edad", "personas_vacunadas", "poblacion_objetivo",
              "cobertura_pct", "anio", "poblacion", "medicamento", "farmacias", "existencias_vigentes", "umbral_total", "consumo_30d", "cobertura_dias", "por_vencer_90d", "estado", "motivo",
              "dias_minimos", "dias_exceso", "nivel", "periodo", "filas", "filas_suprimidas", "institucion", "tipo_institucion", "consultas", "hospitalizaciones_nuevas", "camas_totales",
              "camas_ocupadas", "porcentaje_ocupacion"}
EJ = {"origen": "EJEMPLO"}


def vac(n, vacuna="Influenza", edad=3, dep="Morazán", mun="Perquín", dosis=1, dias=20):
    return n, {"fecha": HOY - timedelta(days=dias), "edad": edad, "sexo": "F", "departamento": dep, "municipio": mun, "vacuna": vacuna, "dosis_total": dosis}


def poner_vac(*grupos):
    with SessionLocal() as db:
        datos_ejemplo.borrar(db)
        for n, f in grupos:
            db.add_all([EpiEjemploVacuna(**f) for _ in range(n)])
        db.commit()


def objetivo(client, h, dep, anio, vacuna, rango, n):
    r = client.put("/estadisticas/poblacion-objetivo", headers=h, json={"departamento": dep, "anio": anio, "vacuna": vacuna, "rango_edad": rango, "poblacion": n})
    assert r.status_code == 200, r.text
    return r.json()


@pytest.fixture(autouse=True)
def _limpio():
    yield
    with SessionLocal() as db:
        datos_ejemplo.borrar(db)
        db.execute(text("DELETE FROM poblacion_objetivo WHERE departamento LIKE 'Dep-Prueba%' OR departamento = 'Morazán'"))
        db.commit()


def por(r, *claves):
    assert r.status_code == 200, r.text
    return {tuple(c.get(k) for k in claves): c for c in r.json()["celdas"]}


# ------------------------------------------------------------------ Acceso y anonimización
def test_acceso_exclusivo_y_sin_identificadores(client, omega_headers, salud, medico, codigos_2fa):
    h_salud, d, pid = salud
    hospital = login_inst(client, CODIGO_HOSPITAL, PASSWORD_HOSPITAL, codigos_2fa)
    farmacia = login_inst(client, NIT_FARMACIA, PASSWORD_FARMACIA, codigos_2fa)
    civil = datos_persona()
    client.post("/personas", json=civil)
    h_civil = login(client, civil)
    for ruta in RUTAS:
        assert client.get(ruta).status_code == 401, ruta
        for quien in (medico, h_civil, hospital, farmacia):
            assert get(client, quien, ruta).status_code == 403, ruta
        assert get(client, h_salud, ruta).status_code == 200 and get(client, omega_headers, ruta).status_code == 200, ruta
    body = {"departamento": "Dep-Prueba", "anio": 2026, "vacuna": "Influenza", "rango_edad": "0-4", "poblacion": 10}
    assert client.put("/estadisticas/poblacion-objetivo", headers=h_salud, json=body).status_code == 403
    assert client.put("/estadisticas/poblacion-objetivo", headers=medico, json=body).status_code == 403
    with SessionLocal() as db:
        datos_ejemplo.generar(db, semilla=9, cantidad=1500)
    for ruta in RUTAS:
        for h in (omega_headers, h_salud):
            r = get(client, h, ruta, **(EJ if "cobertura" in ruta else {}))
            assert r.status_code == 200, ruta
            cuerpo = json.dumps(r.json(), ensure_ascii=False)
            assert _claves(r.json()) <= PERMITIDAS, (ruta, _claves(r.json()) - PERMITIDAS)
            assert not re.search(r"\d{8}-\d", cuerpo) and d["dui"] not in cuerpo and pid not in cuerpo and not re.search(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-", cuerpo), ruta
    r = get(client, omega_headers, RUTAS[0], **EJ)
    assert r.json()["celdas"] and all(c["personas_vacunadas"] >= 5 for c in r.json()["celdas"]) and r.json()["celdas_suprimidas"] >= 1
    cols = {c[0] for c in sql("SELECT column_name FROM information_schema.columns WHERE table_name IN ('v_epi_vacuna', 'epi_ejemplo_vacuna', 'poblacion_objetivo')")}
    assert not ({"dui", "nombres", "apellidos", "persona_id", "paciente_id", "correo", "lote", "fabricante"} & cols)
    assert {"ESTADISTICA_CONSULTADA"} <= {a[0] for a in sql("SELECT DISTINCT accion FROM auditoria WHERE detalle->>'consulta' LIKE 'recursos_%' OR detalle->>'consulta' = 'vacunacion_cobertura'")}


# ------------------------------------------------------------------ Vacunación y cobertura
def test_cobertura_por_region_y_edad(client, omega_headers, salud):
    poner_vac(vac(6, "Influenza", 3), vac(4, "Influenza", 3, dep="La Libertad", mun="Santa Tecla"), vac(5, "Influenza", 40), vac(8, "Influenza", 3, dosis=2),
              vac(5, "Sarampión, rubéola y paperas (SRP)", 1, dosis=2), vac(9, "Influenza", 3, dias=500))
    objetivo(client, omega_headers, "Morazán", HOY.year, "INFLUENZA", "0-4", 40)
    r = client.get("/estadisticas/vacunacion/cobertura", headers=salud[0], params={"origen": "EJEMPLO"})
    c = por(r, "vacuna", "departamento", "rango_edad")
    cel = c[("influenza", "Morazán", "0-4")]
    assert cel["personas_vacunadas"] == 14 and cel["poblacion_objetivo"] == 40 and cel["cobertura_pct"] == 35.0  # 6 + 8 (los de hace 500 días quedan fuera del periodo)
    assert c[("influenza", "Morazán", "30-44")]["poblacion_objetivo"] is None and c[("influenza", "Morazán", "30-44")]["cobertura_pct"] is None  # sin denominador: no se inventa
    assert ("influenza", "La Libertad", "0-4") not in c and r.json()["celdas_suprimidas"] == 1  # 4 personas: suprimido
    # al menos 2 dosis (esquema): solo 8 de los 14
    assert por(get(client, omega_headers, "/estadisticas/vacunacion/cobertura", min_dosis=2, vacuna="influenza", **EJ), "vacuna", "departamento", "rango_edad")[("influenza", "Morazán", "0-4")]["cobertura_pct"] == 20.0
    # filtros: vacuna con tildes/mayúsculas y departamento; el nombre se normaliza
    c = por(get(client, omega_headers, "/estadisticas/vacunacion/cobertura", vacuna="SARAMPIÓN, rubéola y paperas (srp)", departamento="morazán", **EJ), "vacuna", "rango_edad")
    assert list(c) == [("sarampion, rubeola y paperas (srp)", "0-4")]
    # periodo ampliado: entran los de hace 500 días; población del último año ≤ fin del periodo
    objetivo(client, omega_headers, "Morazán", HOY.year - 1, "Influenza", "0-4", 1)
    objetivo(client, omega_headers, "Morazán", HOY.year + 1, "Influenza", "0-4", 9999)
    r = get(client, omega_headers, "/estadisticas/vacunacion/cobertura", desde=str(HOY - timedelta(days=600)), vacuna="Influenza", departamento="Morazán", **EJ)
    cel = por(r, "vacuna", "rango_edad")[("influenza", "0-4")]
    assert cel["personas_vacunadas"] == 23 and cel["poblacion_objetivo"] == 40
    assert get(client, omega_headers, "/estadisticas/vacunacion/cobertura", desde="2026-05-01", hasta="2026-01-01").status_code == 422
    assert get(client, omega_headers, "/estadisticas/vacunacion/cobertura", min_dosis=0).status_code == 422
    # denominador: validación, normalización de la vacuna y bitácora
    assert client.put("/estadisticas/poblacion-objetivo", headers=omega_headers, json={"departamento": "Morazán", "anio": 2026, "vacuna": "X", "rango_edad": "0-4", "poblacion": 5}).status_code == 422
    assert client.put("/estadisticas/poblacion-objetivo", headers=omega_headers, json={"departamento": "Morazán", "anio": 2026, "vacuna": "Influenza", "rango_edad": "10-20", "poblacion": 5}).status_code == 422
    assert client.put("/estadisticas/poblacion-objetivo", headers=omega_headers, json={"departamento": "Morazán", "anio": 2026, "vacuna": "Influenza", "rango_edad": "0-4", "poblacion": 0}).status_code == 422
    assert {"departamento": "Morazán", "anio": HOY.year, "vacuna": "influenza", "rango_edad": "0-4", "poblacion": 40} in get(client, omega_headers, "/estadisticas/poblacion-objetivo").json()
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'ESTADISTICA_OBJETIVO_VACUNA_GUARDADO' AND detalle->>'vacuna' = 'influenza'")[0][0] >= 3


def test_vacunas_reales_una_persona_cuenta_una_vez(client, omega_headers):
    """Registros reales (portal civil): 5 personas distintas, una con dos dosis → 5 personas; sin DUI ni lote en la respuesta."""
    h = auth(client.post("/auth/login/persona", json={"dui": DUI_MEDICO, "password": PASSWORD_MEDICO}).json()["tokens"]["access_token"])
    nombre = f"Vacuna Prueba {uuid.uuid4().hex[:8]}"
    duis = []
    for i in range(5):
        d = datos_persona(fecha_nacimiento=str(HOY - timedelta(days=365 * 3 + 10)), sexo="M")
        assert client.post("/personas", json=d).status_code == 201
        abrir(client, h, d["dui"])
        assert client.post("/vacunas", headers=h, json=vacuna(d["dui"], vacuna=nombre, dosis_numero=1, lote=f"LOTE-{i}", proxima_dosis=None)).status_code == 201
        if i == 0:
            r = client.post("/vacunas", headers=h, json=vacuna(d["dui"], vacuna=nombre, dosis_numero=2, lote="LOTE-X", fecha_aplicacion=str(HOY - timedelta(days=1)), proxima_dosis=None))
            assert r.status_code == 201, r.text
        duis.append(d["dui"])
    r = get(client, omega_headers, "/estadisticas/vacunacion/cobertura", vacuna=nombre, origen="REAL")
    c = por(r, "vacuna", "rango_edad")
    assert list(c) == [(nombre.lower(), "0-4")] and c[(nombre.lower(), "0-4")]["personas_vacunadas"] == 5  # 6 dosis, 5 personas
    assert not any(x in r.text for x in duis) and "LOTE-" not in r.text
    assert get(client, omega_headers, "/estadisticas/vacunacion/cobertura", vacuna=nombre, min_dosis=2, origen="REAL").json()["celdas"] == []  # 1 persona con 2 dosis: suprimido


# ------------------------------------------------------------------ Insumos (inventario de farmacia)
def test_insumos_que_faltan_o_sobran(client, omega_headers, codigos_2fa):
    f = login_inst(client, NIT_FARMACIA, PASSWORD_FARMACIA, codigos_2fa)
    sufijo = uuid.uuid4().hex[:8]
    nombres = {k: f"zmed{k}{sufijo}" for k in "abcde"}

    def lote(med, cant, dias=400):
        r = client.post("/farmacia/inventario/lotes", headers=f, json={"medicamento": med, "numero_lote": f"L-{uuid.uuid4().hex[:8]}", "fecha_vencimiento": str(HOY + timedelta(days=dias)), "cantidad": cant})
        assert r.status_code == 201, r.text
    lote(nombres["a"], 100)
    assert client.put(f"/farmacia/inventario/umbrales/{nombres['a']}", headers=f, json={"umbral": 150}).status_code == 200      # a: bajo su umbral → FALTA
    lote(nombres["b"], 500, dias=30)                                                                                           # b: 500 uds. por vencer sin consumo → SOBRA
    lote(nombres["d"], 1000)
    assert client.put(f"/farmacia/inventario/umbrales/{nombres['d']}", headers=f, json={"umbral": 10}).status_code == 200      # d: normal → ADECUADO
    # c: 30 unidades y se despachan 21 → consumo de 21 en el mes, quedan 9 → cobertura 12.9 días → FALTA
    lote(nombres["c"], 30)
    mh = auth(client.post("/auth/login/persona", json={"dui": DUI_MEDICO, "password": PASSWORD_MEDICO}).json()["tokens"]["access_token"])
    client.post("/farmacia/firma/enrolar", json={"pin": PIN}, headers=mh)
    pac = datos_persona(fecha_nacimiento=NAC)
    client.post("/personas", json=pac)
    abrir(client, mh, pac["dui"])
    rx = emitir(client, mh, pac["dui"], meds=[{"medicamento": nombres["c"], "dosis": "1 tableta", "frecuencia": "cada 8 horas", "duracion_dias": 7, "cantidad": 21}])
    assert rx.status_code == 201, rx.text
    assert client.post("/farmacia/recetas/despachar", json=canje(rx.json(), responsable="Lic. Prueba"), headers=f).status_code == 201

    def ins(med, **p):
        r = get(client, omega_headers, "/estadisticas/recursos/insumos", medicamento=med, **p)
        assert r.status_code == 200, r.text
        return r.json()
    a, b, c = (ins(nombres[k])["celdas"] for k in "abc")
    assert a[0]["estado"] == "FALTA" and a[0]["existencias_vigentes"] == 100 and a[0]["umbral_total"] == 150 and a[0]["farmacias"] == 1 and "umbral" in a[0]["motivo"]
    assert b[0]["estado"] == "SOBRA" and b[0]["por_vencer_90d"] == 500
    assert c[0]["estado"] == "FALTA" and c[0]["consumo_30d"] == 21 and c[0]["existencias_vigentes"] == 9 and c[0]["cobertura_dias"] == 12.9
    assert ins(nombres["d"])["celdas"] == []  # lo adecuado no se lista por defecto
    d = ins(nombres["d"], estado="TODOS")["celdas"]
    assert d[0]["estado"] == "ADECUADO" and d[0]["cobertura_dias"] is None
    assert [x["medicamento"] for x in ins(None, estado="FALTA", departamento="San Salvador")["celdas"] if x["medicamento"].endswith(sufijo)] == sorted([nombres["a"], nombres["c"]])
    assert all(x["estado"] == "SOBRA" for x in ins(None, estado="SOBRA")["celdas"])
    # los umbrales de días cambian el diagnóstico
    assert ins(nombres["c"], dias_minimos=5)["celdas"] == []
    assert ins(nombres["a"], dias_exceso=30)["celdas"][0]["estado"] == "FALTA"
    # agregado por región: ni la farmacia, ni su NIT, ni ids ni pacientes
    cuerpo = json.dumps(ins(None, estado="TODOS"), ensure_ascii=False)
    assert "Farmacia Demo" not in cuerpo and NIT_FARMACIA not in cuerpo and pac["dui"] not in cuerpo and not re.search(r"[0-9a-f]{8}-[0-9a-f]{4}-", cuerpo)
    assert get(client, omega_headers, "/estadisticas/recursos/insumos", estado="OTRO").status_code == 422


# ------------------------------------------------------------------ Consultas, hospitalizaciones y camas
def hospital_nuevo(client, omega_headers, dep="Usulután"):
    nombre = f"Hospital Prueba 6E {uuid.uuid4().hex[:8]}"
    d = {"tipo": "HOSPITAL", "nombre_legal": nombre, "nit": nit_nuevo(), "codigo_minsal": f"H-{uuid.uuid4().hex[:8]}", "departamento": dep, "municipio": dep, "direccion": dep,
         "telefono": "2400-0000", "correo": f"{uuid.uuid4().hex[:8]}@hosp.sv", "responsable_nombre": "Dr. Director", "responsable_dui": dui_nuevo(), "documento_permiso_ref": "up://permiso.pdf",
         "horario": "24 horas", "password": "HospClave12345"}
    r = client.post("/instituciones", json=d)
    assert r.status_code == 201, r.text
    hid = r.json()["id"]
    assert client.patch(f"/omega/instituciones/{hid}/estado", json={"estado": "ACTIVA", "motivo": "Permiso verificado"}, headers=omega_headers).status_code == 200
    p = datos_persona(fecha_nacimiento=NAC, profesional={"tipo": "DOCTOR", "especialidad": "Medicina Interna", "numero_junta": f"J{uuid.uuid4().hex[:7]}", "institucion_id": hid})
    r = client.post("/personas", json=p)
    assert r.status_code == 201, r.text
    assert client.patch(f"/omega/personas/{r.json()['id']}/verificacion", headers=omega_headers, json={"perfil": "profesional", "verificado": True, "motivo": "JVPM verificada"}).status_code == 200
    return login(client, p), nombre


def atender(client, h, n, **extra):
    ats = []
    for _ in range(n):
        d = datos_persona(fecha_nacimiento=NAC)
        assert client.post("/personas", json=d).status_code == 201
        ats.append(abrir(client, h, d["dui"], **extra))
    return ats


def test_consultas_hospitalizaciones_y_camas_por_institucion_y_region(client, omega_headers):
    h, nombre = hospital_nuevo(client, omega_headers)
    h2, nombre2 = hospital_nuevo(client, omega_headers)
    ambulatorias = atender(client, h, 5)
    atender(client, h, 2, tipo_atencion="HOSPITALIZACION", fase3=False)
    atender(client, h2, 3)  # solo 3 consultas: su fila se suprime

    def filas(**p):
        r = get(client, omega_headers, "/estadisticas/recursos/consultas", **p)
        assert r.status_code == 200, r.text
        return r.json()
    r = filas(departamento="Usulután")
    mia = [x for x in r["filas"] if x["institucion"] == nombre]
    assert len(mia) == 1 and mia[0]["consultas"] == 7 and mia[0]["tipo_institucion"] == "HOSPITAL" and mia[0]["periodo"] == HOY.strftime("%Y-%m")
    assert mia[0]["hospitalizaciones_nuevas"] is None  # 2 hospitalizaciones: ocultas
    assert not any(x["institucion"] == nombre2 for x in r["filas"]) and r["filas_suprimidas"] >= 1  # 3 consultas: suprimida
    atender(client, h, 3, tipo_atencion="HOSPITALIZACION", fase3=False)
    mia = [x for x in filas(departamento="Usulután")["filas"] if x["institucion"] == nombre][0]
    assert mia["consultas"] == 10 and mia["hospitalizaciones_nuevas"] == 5
    # por región: agrega a todos los hospitales del departamento y no nombra instituciones
    reg = filas(nivel="region", departamento="usulután", periodo="anio")
    assert reg["nivel"] == "region" and reg["filas"][0]["institucion"] is None and reg["filas"][0]["consultas"] >= 10 and reg["filas"][0]["periodo"] == str(HOY.year)
    assert nombre not in json.dumps(reg) and filas(departamento="Usulután", tipo="FARMACIA")["filas"] == []
    # periodo fuera de rango: nada
    assert filas(desde=str(HOY - timedelta(days=900)), hasta=str(HOY - timedelta(days=800)), departamento="Usulután")["filas"] == []
    # --- camas: 6 camas activas; 2 ocupadas (oculto), luego 5 ocupadas (visible)
    servicio = f"Servicio {uuid.uuid4().hex[:6]}"
    camas = [cama(client, h, servicio, f"B-0{i}").json() for i in range(6)]

    def mi_fila(**p):
        r = get(client, omega_headers, "/estadisticas/recursos/camas", departamento="Usulután", **p)
        assert r.status_code == 200, r.text
        return [x for x in r.json()["filas"] if x["institucion"] == nombre]
    assert mi_fila()[0]["camas_totales"] == 6 and mi_fila()[0]["camas_ocupadas"] == 0 and mi_fila()[0]["porcentaje_ocupacion"] == 0.0
    for c, at in zip(camas[:2], ambulatorias[:2]):
        assert ingresar(client, h, c["id"], at).status_code == 201
    f = mi_fila()[0]
    assert f["camas_ocupadas"] is None and f["porcentaje_ocupacion"] is None and f["camas_totales"] == 6  # 2 ocupadas: oculto
    for c, at in zip(camas[2:5], ambulatorias[2:5]):
        assert ingresar(client, h, c["id"], at).status_code == 201
    f = mi_fila()[0]
    assert f["camas_ocupadas"] == 5 and f["porcentaje_ocupacion"] == 83.3 and f["tipo_institucion"] == "HOSPITAL"
    reg = get(client, omega_headers, "/estadisticas/recursos/camas", nivel="region", departamento="Usulután").json()["filas"]
    assert len(reg) == 1 and reg[0]["institucion"] is None and reg[0]["camas_totales"] >= 6
    assert nombre not in json.dumps(reg) and get(client, omega_headers, "/estadisticas/recursos/camas", nivel="otro").status_code == 422
    # una cama retirada no cuenta
    assert client.put(f"/camas/{camas[5]['id']}/activa", headers=h, json={"activa": False, "motivo": "Mantenimiento"}).status_code == 200
    assert mi_fila()[0]["camas_totales"] == 5 and mi_fila()[0]["porcentaje_ocupacion"] == 100.0
    # nada de pacientes ni identificadores
    cuerpo = json.dumps(get(client, omega_headers, "/estadisticas/recursos/camas").json()) + json.dumps(filas())
    assert not re.search(r"\d{8}-\d", cuerpo) and not re.search(r"[0-9a-f]{8}-[0-9a-f]{4}-", cuerpo)


def test_bitacora_y_documentacion(client, omega_headers, salud):
    h_salud, _, pid = salud
    antes = sql("SELECT count(*) FROM auditoria WHERE accion = 'ESTADISTICA_CONSULTADA' AND actor_id::text = :p", p=pid)[0][0]
    for ruta in RUTAS:
        assert get(client, h_salud, ruta).status_code == 200
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'ESTADISTICA_CONSULTADA' AND actor_id::text = :p", p=pid)[0][0] == antes + len(RUTAS)
    d = sql("SELECT detalle FROM auditoria WHERE accion = 'ESTADISTICA_CONSULTADA' AND actor_id::text = :p AND detalle->>'consulta' = 'recursos_camas'", p=pid)[0][0]
    assert d["consulta"] == "recursos_camas" and "celdas" in d
    paths = client.get("/openapi.json").json()["paths"]
    for p in RUTAS:
        op = paths[p]["get"]
        assert op["summary"] and {"401", "403"} <= set(op["responses"]), p
    assert paths["/estadisticas/vacunacion/cobertura"]["get"]["description"] and "cobertura" in paths["/estadisticas/vacunacion/cobertura"]["get"]["description"]
    assert "put" in paths["/estadisticas/poblacion-objetivo"] and paths["/estadisticas/poblacion-objetivo"]["put"]["summary"]
