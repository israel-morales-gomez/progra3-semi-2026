import hashlib
import re
import uuid
from pathlib import Path

import pyotp
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text, update

from main import app
from omega_core.database import SessionLocal
from omega_core.models import Persona
from omega_core.models.identidad import PerfilEstudiante
from omega_core.seed import (CODIGO_HOSPITAL, DUI_CIVIL, DUI_MEDICO, DUI_OMEGA, NIT_FARMACIA, PASSWORD_CIVIL, PASSWORD_FARMACIA, PASSWORD_HOSPITAL,
                             PASSWORD_MEDICO, PASSWORD_OMEGA, TOTP_OMEGA)
from web.comun import sesion as ses
from web.comun.portales import (CIUDADANO, FARMACIA, INSTITUCION, LABORATORIO, OMEGA, PORTALES, PROFESIONAL, PUBLICOS, UNIVERSIDAD)

from .conftest import datos_persona, dui_nuevo, nit_nuevo
from .test_etapa2 import sql

RAIZ = Path(__file__).resolve().parent.parent / "web"
LOGINS = [p.base + "/ingresar" for p in PORTALES]
CON_LOGIN = [p for p in PORTALES if p.ingreso_en is None]  # profesional entra por el login único de /ciudadano


@pytest.fixture
def web():
    """Navegador nuevo por prueba (su propio jar de cookies); no sigue redirecciones para poder verlas."""
    with TestClient(app, client=("127.0.0.1", 50077), follow_redirects=False) as c:
        yield c


def nuevo(puerto: int) -> TestClient:
    return TestClient(app, client=("127.0.0.1", puerto), follow_redirects=False)


def token_de(html: str) -> str:
    m = re.search(r'name="csrf_token" value="([0-9a-f]{64})"', html)
    assert m, "la página no trae el token CSRF"
    return m.group(1)


def enviar(web, ruta, campos=None, pagina=None, **kw):
    """GET de la página del formulario (para obtener cookie y token) y POST con el token."""
    r = web.get(pagina or ruta)
    assert r.status_code == 200, r.text
    return web.post(ruta, data={"csrf_token": token_de(r.text)} | (campos or {}), **kw)


def entrar_persona(web, portal=CIUDADANO, dui=DUI_MEDICO, password=PASSWORD_MEDICO, **extra):
    """Login único de personas (/ciudadano/ingresar). Entrar «en» PROFESIONAL = elegir la opción profesional; para estudiante pasar tipo="estudiante"."""
    tipo = "profesional" if portal is PROFESIONAL else "ciudadano"
    return enviar(web, "/ciudadano/ingresar", {"dui": dui, "password": password, "tipo": tipo} | extra)


def entrar_inst(web, portal, ident, clave, codigos):
    """Login institucional completo (con 2FA si lo pide). Devuelve la última respuesta."""
    from omega_core.security.ratelimit import limitador
    limitador.reset()  # esta prueba hace muchos logins desde la misma IP; los límites se prueban aparte
    r = enviar(web, f"{portal.base}/ingresar", {"identificador": ident, "password": clave})
    if r.status_code == 200 and "Verificación en dos pasos" in r.text:
        desafio = re.search(r'name="desafio_id" value="([0-9a-f-]{36})"', r.text).group(1)
        r = web.post(f"{portal.base}/ingresar/2fa", data={"csrf_token": token_de(r.text), "desafio_id": desafio, "codigo": codigos[-1]})
    return r


def sesion_cookie(web, portal=CIUDADANO) -> str | None:
    return web.cookies.get(portal.cookie_sesion)


def h(valor: str) -> str:
    return hashlib.sha256(valor.encode()).hexdigest()


def crear_institucion(client, omega_headers, tipo: str) -> tuple[str, str]:
    """Registra y activa una institución del tipo dado (misma API de siempre). Devuelve (NIT, contraseña)."""
    nit, clave = nit_nuevo(), "InstClave12345"
    d = {"tipo": tipo, "nombre_legal": f"{tipo.capitalize()} de Prueba", "nit": nit, "codigo_minsal": f"T-{uuid.uuid4().hex[:8]}", "departamento": "San Miguel",
         "municipio": "San Miguel", "direccion": "San Miguel", "telefono": "2600-0000", "correo": f"{uuid.uuid4().hex[:8]}@inst.sv", "responsable_nombre": "Responsable Prueba",
         "responsable_dui": dui_nuevo(), "responsable_junta": "JV-777", "documento_permiso_ref": "up://permiso.pdf", "password": clave,
         "horario": "L-V 8:00-16:00", "credencial_autorizacion": "MINEDUCYT-123", "responsable_cargo": "Decano", "responsable_correo": "decano@uni.sv", "responsable_telefono": "2200-0000"}
    r = client.post("/instituciones", json=d)
    assert r.status_code == 201, r.text
    ok = client.patch(f"/omega/instituciones/{r.json()['id']}/estado", json={"estado": "ACTIVA", "motivo": "Documentos verificados"}, headers=omega_headers)
    assert ok.status_code == 200, ok.text
    return nit, clave


# ------------------------------------------------------------------ Humo: páginas, rutas protegidas e índice
@pytest.mark.parametrize("portal", CON_LOGIN, ids=lambda p: p.slug)
def test_cada_portal_carga_con_su_propia_cabecera_y_cookie(web, portal):
    r = web.get(portal.base + "/ingresar")
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/html")
    assert '<html lang="es">' in r.text and "<h1>" in r.text and "csrf_token" in r.text and "hx-headers" in r.text
    assert f"/static/css/comun.css" in r.text and portal.css in r.text and f'class="portal-{portal.slug}"' in r.text
    assert f"<strong>{portal.nombre}</strong>" in r.text  # su propia cabecera
    sc = r.headers["set-cookie"].lower()  # cookie CSRF propia: HttpOnly, SameSite=Strict y Path = solo este portal
    assert portal.cookie_csrf in sc and "httponly" in sc and "samesite=strict" in sc and f"path={portal.base}" in sc
    # ningún portal enlaza a otro
    otros = [p.base for p in PORTALES if p is not portal and p.base != portal.base]
    enlaces = re.findall(r'(?:href|action)="([^"]+)"', r.text)
    permitidos = ("/profesional/registro",) if portal is CIUDADANO else ()  # el login único de personas ofrece el registro del profesional
    assert all(e.startswith((portal.base, "/static", "#")) or e in permitidos for e in enlaces), enlaces
    if portal is not OMEGA:
        assert OMEGA.base not in r.text and "/omega" not in r.text  # el portal de Omega no se menciona en ninguna página pública
    assert not any(e.startswith(o + "/") or e == o for e in enlaces for o in otros if e not in permitidos)
    assert web.get(portal.base).status_code == 303


def test_profesional_no_tiene_login_propio_usa_el_unico(web):
    for ruta in ("/profesional", "/profesional/ingresar"):
        r = web.get(ruta)
        assert r.status_code == 303 and r.headers["location"] == "/ciudadano/ingresar?tipo=profesional"
    assert web.post("/profesional/ingresar").status_code in (404, 405)
    html = web.get("/ciudadano/ingresar?tipo=profesional").text  # login único con las tres opciones y «profesional» preseleccionado
    assert all(f'name="tipo" value="{v}"' in html for v in ("ciudadano", "profesional", "estudiante")) and re.search(r'value="profesional" checked', html)
    assert re.search(r'value="ciudadano" checked', web.get("/ciudadano/ingresar").text)


def test_omega_vive_en_ruta_secreta_y_no_se_publica(web):
    assert OMEGA.base != "/omega" and OMEGA.base.startswith("/")
    assert web.get("/omega/ingresar").status_code == 404 and web.get("/omega/panel").status_code == 404 and web.get("/static/omega/portal.css").status_code == 404
    assert web.get(OMEGA.base + "/ingresar").status_code == 200 and web.get(OMEGA.css).status_code == 200
    indice = web.get("/").text
    assert OMEGA.base not in indice and "Omega" not in indice.split("<h1>")[1] and all(p.base in indice for p in PUBLICOS if p.ingreso_en is None)
    assert OMEGA.base not in web.get("/ciudadano/ingresar").text and OMEGA.base not in web.get("/openapi.json").text


def test_registro_solo_en_ciudadano(web):
    assert web.get("/ciudadano/registro").status_code == 200
    assert web.get("/profesional/registro").status_code == 200  # el profesional tiene su propio registro (tests/test_etapa7p.py)
    for p in PORTALES[1:]:
        if p is not PROFESIONAL:
            assert web.get(p.base + "/registro").status_code == 404


@pytest.mark.parametrize("portal", PORTALES, ids=lambda p: p.slug)
def test_rutas_protegidas_redirigen_al_login_de_su_portal(web, portal):
    login = portal.ingreso_en or portal.base + "/ingresar"
    for ruta in ("/panel", "/cuenta"):
        r = web.get(portal.base + ruta)
        assert r.status_code == 303 and r.headers["location"].startswith(login)
        x = web.get(portal.base + ruta, headers={"HX-Request": "true"})  # HTMX: 401 + HX-Redirect, no un fragmento con el login
        assert x.status_code == 401 and x.headers["hx-redirect"].startswith(login)
    assert web.get(portal.base + "/cuenta").headers["location"] == portal.url_ingreso(f"{portal.base}/cuenta")
    assert web.get(portal.base).headers["location"] == portal.url_ingreso()
    assert web.post(portal.base + "/salir").status_code == 303


def test_indice_neutro_y_metodos(web):
    r = web.get("/")
    assert r.status_code == 200 and all(p.base in r.text for p in PUBLICOS if p.ingreso_en is None) and OMEGA.base not in r.text and "csrf" not in r.text and "<script" not in r.text
    assert web.get("/favicon.ico").status_code == 204 and web.get("/ciudadano/salir").status_code == 405 and web.get("/no-existe").status_code == 404
    assert web.get("/panel").status_code == 404 and web.get("/ingresar").status_code == 404  # ya no hay un login único


# ------------------------------------------------------------------ Cabeceras, CSP y recursos propios
def test_cabeceras_de_seguridad_y_csp(web):
    r = web.get("/ciudadano/ingresar")
    csp = r.headers["content-security-policy"]
    assert "script-src 'self'" in csp and "style-src 'self'" in csp and "default-src 'none'" in csp and "frame-ancestors 'none'" in csp and "form-action 'self'" in csp
    assert "unsafe-inline" not in csp and "unsafe-eval" not in csp and "http" not in csp and "*" not in csp
    assert r.headers["x-frame-options"] == "DENY" and r.headers["x-content-type-options"] == "nosniff" and r.headers["cache-control"] == "no-store"
    assert r.headers["cross-origin-opener-policy"] == "same-origin"
    # la API JSON conserva su CSP; /docs sigue funcionando; /static se puede cachear
    assert web.get("/health").headers["content-security-policy"] == "default-src 'none'; frame-ancestors 'none'"
    assert "content-security-policy" not in web.get("/docs").headers
    for ruta in ("/static/css/comun.css", "/static/ciudadano/portal.css"):
        s = web.get(ruta)
        assert s.status_code == 200 and "max-age" in s.headers["cache-control"], ruta
    assert web.get(OMEGA.css).status_code == 200 and web.get(OMEGA.css).headers["cache-control"] == "no-store"  # el CSS de Omega, bajo su ruta secreta, no se cachea
    assert web.get("/static/../main.py").status_code in (400, 404)


@pytest.mark.parametrize("portal", CON_LOGIN, ids=lambda p: p.slug)
def test_sin_cdn_ni_scripts_inline_ni_jwt_en_el_navegador(web, portal):
    html = web.get(portal.base + "/ingresar").text
    assert not re.search(r"(src|href|action)=[\"']https?://", html) and "//cdn" not in html
    assert not re.search(r"<script(?![^>]*\ssrc=)", html)  # ni un <script> en línea
    assert not re.search(r"\son[a-z]+=|\sstyle=|javascript:", html)  # ni manejadores ni estilos en línea
    assert set(re.findall(r'<script[^>]*src="([^"]+)"', html)) == {"/static/vendor/htmx.min.js", "/static/js/app.js", "/static/vendor/alpine.csp.min.js"}


def test_vendor_de_npm_y_ningun_almacenamiento_en_el_navegador(web):
    for linea in (RAIZ / "comun/static/vendor/SHA256SUMS").read_text(encoding="utf-8").splitlines():
        hh, ruta = linea.split("  ")
        assert hashlib.sha256((RAIZ / "comun/static" / ruta).read_bytes()).hexdigest() == hh
    pkg = (RAIZ / "package.json").read_text(encoding="utf-8")
    assert "htmx.org" in pkg and "@alpinejs/csp" in pkg
    js = (RAIZ / "comun/static/js/app.js").read_text(encoding="utf-8")
    assert "localStorage" not in js and "sessionStorage" not in js and "eval(" not in js
    for t in RAIZ.glob("**/templates/*.html"):
        texto = t.read_text(encoding="utf-8")
        assert "localStorage" not in texto and "cdn" not in texto.lower(), t
    paginas = ("/ingresar", "/panel", "/cuenta", "/salir", "/registro")
    assert not any(p == q.base or p.startswith(tuple(q.base + x for x in paginas)) for p in web.get("/openapi.json").json()["paths"] for q in PORTALES) and "/static" not in "".join(web.get("/openapi.json").json()["paths"])


# ------------------------------------------------------------------ CSRF
def test_csrf_rechaza_peticiones_sin_token_valido(web):
    ruta = "/ciudadano/ingresar"
    web.get(ruta)
    datos = {"dui": DUI_CIVIL, "password": PASSWORD_CIVIL}
    assert web.post(ruta, data=datos).status_code == 403                                     # sin token
    assert web.post(ruta, data=datos | {"csrf_token": "0" * 64}).status_code == 403          # token falso
    ajeno = token_de(nuevo(50078).get(ruta).text)
    assert web.post(ruta, data=datos | {"csrf_token": ajeno}).status_code == 403             # token de otra sesión/cookie
    # el token de OTRO portal tampoco vale aunque sea de este mismo navegador
    otro_portal = token_de(web.get("/farmacia/ingresar").text)
    assert web.post(ruta, data=datos | {"csrf_token": otro_portal}).status_code == 403
    bueno = token_de(web.get(ruta).text)
    assert web.post(ruta, data=datos | {"csrf_token": bueno}, headers={"Origin": "https://sitio-malo.example"}).status_code == 403  # origen ajeno
    assert web.post(ruta, data=datos | {"csrf_token": bueno}, headers={"Origin": "http://testserver"}).status_code == 303
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'WEB_CSRF_RECHAZADO' AND detalle->>'motivo' = 'ORIGEN_DISTINTO'")[0][0] >= 1
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'WEB_CSRF_RECHAZADO' AND detalle->>'motivo' = 'TOKEN_AUSENTE_O_INVALIDO'")[0][0] >= 4


def test_csrf_tambien_se_acepta_por_cabecera_de_htmx(web):
    ruta = "/ciudadano/ingresar"
    r = web.get(ruta)
    token = token_de(r.text)
    assert f'hx-headers=\'{{"X-CSRF-Token": "{token}"}}\'' in r.text  # el contenedor lo manda en toda petición HTMX
    datos = {"dui": DUI_CIVIL, "password": "ClaveIncorrecta1"}
    assert web.post(ruta, data=datos, headers={"X-CSRF-Token": token, "HX-Request": "true"}).status_code == 401  # pasó el CSRF; falla la contraseña
    assert web.post(ruta, data=datos, headers={"HX-Request": "true"}).status_code == 403
    assert web.post(ruta, data=datos | {"csrf_token": token}, headers={"X-CSRF-Token": "0" * 64}).status_code == 401
    assert web.post(ruta, data=datos, headers={"X-CSRF-Token": "0" * 64}).status_code == 403


# ------------------------------------------------------------------ Login de ciudadano y sesión
def test_login_ciudadano_sesion_cookie_y_cierre(web):
    web.get("/ciudadano/ingresar")
    csrf_previo = web.cookies.get(CIUDADANO.cookie_csrf)
    r = entrar_persona(web, CIUDADANO, DUI_CIVIL, PASSWORD_CIVIL)
    assert r.status_code == 303 and r.headers["location"] == "/ciudadano/panel"
    sc = r.headers["set-cookie"].lower()
    assert CIUDADANO.cookie_sesion in sc and "httponly" in sc and "samesite=strict" in sc and "path=/ciudadano" in sc and "path=/;" not in sc
    valor = sesion_cookie(web)
    assert valor and valor != csrf_previo and not valor.startswith("eyJ") and valor.count(".") == 0  # cookie opaca: no es un JWT
    fila = sql("SELECT portal, sujeto_tipo, revocada, refresh_jti FROM sesion_web WHERE token_hash = :h", h=h(valor))
    assert fila and fila[0][:3] == ("ciudadano", "persona", False) and fila[0][3] is not None
    assert not sql("SELECT 1 FROM sesion_web WHERE token_hash = :v", v=valor)  # solo se guarda el hash
    p = web.get("/ciudadano/panel")
    assert p.status_code == 200 and "Ciudadano Demo" in p.text and ">Salir<" in p.text
    assert "eyJ" not in p.text and "eyJ" not in "".join(f"{k}={v}" for k, v in web.cookies.items())  # ningún JWT llega al navegador
    assert "civil@example.sv" in web.get("/ciudadano/cuenta").text and web.get("/ciudadano/ingresar").headers["location"] == "/ciudadano/panel"
    assert web.get("/ciudadano/panel").headers["cache-control"] == "no-store"
    # cierre de sesión: exige CSRF; sin token la sesión sigue viva
    assert web.post("/ciudadano/salir").status_code == 403 and web.get("/ciudadano/panel").status_code == 200
    r = web.post("/ciudadano/salir", data={"csrf_token": token_de(web.get("/ciudadano/panel").text)})
    assert r.status_code == 303 and r.headers["location"].startswith("/ciudadano/ingresar")
    assert "omega_ciudadano=" in r.headers["set-cookie"] and "path=/ciudadano" in r.headers["set-cookie"].lower()  # la cookie se invalida
    assert sql("SELECT revocada FROM sesion_web WHERE token_hash = :h", h=h(valor)) == [(True,)]
    assert sql("SELECT revocado FROM refresh_token WHERE jti = :j", j=fila[0][3]) == [(True,)]  # el refresh del login también se revoca
    web.cookies.set(CIUDADANO.cookie_sesion, valor, path="/ciudadano")  # reutilizar la cookie vieja no sirve
    assert web.get("/ciudadano/panel").status_code == 303
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'WEB_SESION_CERRADA' AND detalle->>'portal' = 'ciudadano'")[0][0] >= 1


def test_login_errores_y_redireccion_segura(web):
    for dui, pw in ((DUI_CIVIL, "Equivocada123"), (dui_nuevo(), "Equivocada123"), ("no-es-un-dui", "x")):
        r = entrar_persona(web, CIUDADANO, dui, pw)
        assert r.status_code == 401 and "Credenciales inválidas" in r.text and (len(pw) < 5 or pw not in r.text)
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'LOGIN_PERSONA' AND resultado = 'FALLO'")[0][0] >= 2  # la bitácora es la de omega_core
    assert entrar_persona(web, CIUDADANO, DUI_CIVIL, PASSWORD_CIVIL, siguiente="/ciudadano/cuenta").headers["location"] == "/ciudadano/cuenta"
    for i, malo in enumerate(("https://sitio-malo.example", "//sitio-malo.example", "/\\sitio-malo.example", "javascript:alert(1)", "/profesional/panel", "/ciudadano//x.example")):
        w = nuevo(50100 + i)
        assert entrar_persona(w, CIUDADANO, DUI_CIVIL, PASSWORD_CIVIL, siguiente=malo).headers["location"] == "/ciudadano/panel", malo


def test_limite_de_intentos_se_hereda_de_omega_core(web):
    from omega_core.security.ratelimit import limitador
    dui = dui_nuevo()
    codigos = [entrar_persona(web, CIUDADANO, dui, "Equivocada123").status_code for _ in range(10)]
    assert codigos[0] == 401 and (429 in codigos or 401 in codigos[-1:])  # bloqueo por identificador o por IP (reglas existentes)
    limitador.reset()


def test_la_sesion_caduca_por_inactividad_vencimiento_o_cuenta_desactivada(web, client):
    d = datos_persona()
    assert client.post("/personas", json=d).status_code == 201  # la API sigue funcionando junto al frontend
    entrar_persona(web, CIUDADANO, d["dui"], d["password"])
    assert web.get("/ciudadano/panel").status_code == 200
    valor = sesion_cookie(web)

    def actualizar(sql_set):
        with SessionLocal() as db:
            db.execute(text(f"UPDATE sesion_web SET {sql_set} WHERE token_hash = :h"), {"h": h(valor)})
            db.commit()
        web.cookies.set(CIUDADANO.cookie_sesion, valor, path="/ciudadano")

    actualizar("ultimo_uso = now() - interval '31 minutes'")
    assert web.get("/ciudadano/panel").status_code == 303  # inactividad (30 min)
    actualizar("ultimo_uso = now()")
    assert web.get("/ciudadano/panel").status_code == 200
    actualizar("ultimo_uso = now(), expira_en = now() - interval '1 minute'")
    assert web.get("/ciudadano/panel").status_code == 303  # vencimiento absoluto
    actualizar("expira_en = now() + interval '1 hour', ultimo_uso = now()")
    assert web.get("/ciudadano/panel").status_code == 200
    with SessionLocal() as db:
        db.execute(update(Persona).where(Persona.dui == d["dui"]).values(activo=False))
        db.commit()
    assert web.get("/ciudadano/panel").status_code == 303  # cuenta desactivada: la sesión deja de valer en el acto


# ------------------------------------------------------------------ Aislamiento entre portales
def test_una_sesion_no_abre_las_urls_de_otro_portal(web):
    assert entrar_persona(web, CIUDADANO, DUI_MEDICO, PASSWORD_MEDICO).status_code == 303  # el médico también es persona
    assert web.get("/ciudadano/panel").status_code == 200
    valor = sesion_cookie(web)
    for p in PORTALES[1:]:  # el navegador no envía la cookie del ciudadano a otro Path: cada uno lo manda a SU login
        for ruta in ("/panel", "/cuenta"):
            r = web.get(p.base + ruta)
            assert r.status_code == 303 and r.headers["location"].startswith(p.ingreso_en or p.base + "/ingresar"), p.slug
    # aunque alguien inyecte el valor de la cookie del ciudadano en la cookie de otro portal, el servidor la rechaza (la sesión es de UN portal)
    for p in PORTALES[1:]:
        w = nuevo(50120)
        w.cookies.set(p.cookie_sesion, valor, path=p.base)
        r = w.get(p.base + "/panel")
        assert r.status_code == 303 and r.headers["location"].startswith(p.ingreso_en or p.base + "/ingresar"), p.slug
    # y el POST de cierre de sesión de otro portal tampoco la reconoce
    w = nuevo(50121)
    w.cookies.set(PROFESIONAL.cookie_sesion, valor, path=PROFESIONAL.base)
    assert w.post("/profesional/salir").status_code in (303, 403)
    assert sql("SELECT revocada FROM sesion_web WHERE token_hash = :h", h=h(valor)) == [(False,)]
    assert web.get("/ciudadano/panel").status_code == 200  # la sesión original sigue viva


def test_cada_portal_acepta_solo_su_tipo_de_cuenta_de_persona(web, codigos_2fa):
    # una persona sin perfil profesional ni estudiantil entra como ciudadano, no como profesional
    w = nuevo(50130)
    r = entrar_persona(w, PROFESIONAL, DUI_CIVIL, PASSWORD_CIVIL)
    assert r.status_code == 403 and "no está registrada como profesional de salud" in r.text and sesion_cookie(w, PROFESIONAL) is None and sesion_cookie(w, CIUDADANO) is None
    assert 'value="profesional" checked' in r.text  # conserva la opción elegida
    assert w.get("/profesional/panel").status_code == 303
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'WEB_ACCESO_DENEGADO' AND detalle->>'portal' = 'profesional'")[0][0] >= 1
    assert sql("SELECT count(*) FROM sesion_web WHERE portal = 'profesional' AND sujeto_id = (SELECT id FROM persona WHERE dui = :d)", d=DUI_CIVIL) == [(0,)]
    assert sql("SELECT revocado FROM refresh_token WHERE sujeto_id = (SELECT id FROM persona WHERE dui = :d) ORDER BY creado_en DESC LIMIT 1", d=DUI_CIVIL) == [(True,)]  # el refresh emitido se revoca
    # el médico entra como profesional y ve su perfil
    assert entrar_persona(w, PROFESIONAL, DUI_MEDICO, PASSWORD_MEDICO).status_code == 303
    c = w.get("/profesional/cuenta")
    assert c.status_code == 200 and "Doctor" in c.text and "Junta" in c.text
    assert entrar_persona(nuevo(50132), PROFESIONAL, DUI_MEDICO, PASSWORD_MEDICO, tipo="estudiante").status_code == 403  # el médico no es estudiante
    assert entrar_persona(nuevo(50133), PROFESIONAL, DUI_MEDICO, PASSWORD_MEDICO, tipo="otro").status_code == 422  # opción inválida
    assert entrar_persona(nuevo(50134), CIUDADANO, DUI_MEDICO, PASSWORD_MEDICO).headers["location"] == "/ciudadano/panel"  # y como ciudadano sigue entrando
    # un estudiante activo también entra como profesional
    d = datos_persona()
    assert web.post("/ciudadano/registro", data={"csrf_token": token_de(web.get("/ciudadano/registro").text), **{k: d[k] for k in ("dui", "nombres", "apellidos", "correo", "telefono")}, "password": d["password"], "password2": d["password"]}).status_code == 303
    with SessionLocal() as db:
        pid = db.scalar(text("SELECT id FROM persona WHERE dui = :d"), {"d": d["dui"]})
        db.add(PerfilEstudiante(persona_id=pid, carne=uuid.uuid4().hex[:12], universidad_nombre="UES", facultad="Medicina", carrera="Doctorado en Medicina", ciclo="Internado", correo_institucional="x@ues.edu.sv"))
        db.commit()
    w2 = nuevo(50131)
    r2 = entrar_persona(w2, PROFESIONAL, d["dui"], d["password"], tipo="estudiante")  # confirmado el perfil, el proceso termina en el panel profesional
    assert r2.status_code == 303 and r2.headers["location"] == "/profesional/panel" and "Estudiante en práctica" in w2.get("/profesional/cuenta").text
    assert entrar_persona(nuevo(50135), PROFESIONAL, d["dui"], d["password"]).status_code == 403  # tiene perfil de estudiante, no de profesional
    with SessionLocal() as db:  # si desactiva el perfil de estudiante, la sesión deja de valer en el acto
        db.execute(update(PerfilEstudiante).where(PerfilEstudiante.persona_id == pid).values(activo=False))
        db.commit()
    assert w2.get("/profesional/panel").status_code == 303


def test_cada_portal_institucional_acepta_solo_su_tipo(web, client, omega_headers, codigos_2fa):
    # hospital semilla (con 2FA): entra en /institucion; en /farmacia, /laboratorio y /universidad recibe 403 tras verificar
    w = nuevo(50140)
    r = entrar_inst(w, INSTITUCION, CODIGO_HOSPITAL, PASSWORD_HOSPITAL, codigos_2fa)
    assert r.status_code == 303 and r.headers["location"] == "/institucion/panel" and "Hospital" in w.get("/institucion/panel").text
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'LOGIN_INSTITUCION' AND detalle->>'segundo_factor' = 'true'")[0][0] >= 1
    for i, p in enumerate((FARMACIA, LABORATORIO, UNIVERSIDAD)):
        x = entrar_inst(nuevo(50141 + i), p, CODIGO_HOSPITAL, PASSWORD_HOSPITAL, codigos_2fa)
        assert x.status_code == 403 and "no tiene acceso a este portal" in x.text, p.slug
    # farmacia semilla (sin 2FA)
    f = nuevo(50150)
    assert enviar(f, "/farmacia/ingresar", {"identificador": NIT_FARMACIA, "password": "Mala12345678"}).status_code == 401
    assert entrar_inst(f, FARMACIA, NIT_FARMACIA, PASSWORD_FARMACIA, codigos_2fa).status_code == 303 and "Farmacia Demo" in f.get("/farmacia/panel").text
    assert entrar_inst(nuevo(50151), INSTITUCION, NIT_FARMACIA, PASSWORD_FARMACIA, codigos_2fa).status_code == 403
    # clínica → /institucion; laboratorio → /laboratorio (con 2FA); universidad → /universidad
    for i, (tipo, portal) in enumerate((("CLINICA", INSTITUCION), ("LABORATORIO", LABORATORIO), ("UNIVERSIDAD", UNIVERSIDAD))):
        nit, clave = crear_institucion(client, omega_headers, tipo)
        w = nuevo(50160 + i)
        assert entrar_inst(w, portal, nit, clave, codigos_2fa).status_code == 303, tipo
        assert w.get(portal.base + "/panel").status_code == 200 and tipo.capitalize() in w.get(portal.base + "/cuenta").text
        assert entrar_inst(nuevo(50170 + i), FARMACIA, nit, clave, codigos_2fa).status_code == 403
    # una institución no entra por un portal de personas y viceversa
    assert enviar(nuevo(50180), "/ciudadano/ingresar", {"dui": CODIGO_HOSPITAL, "password": PASSWORD_HOSPITAL}).status_code == 401
    assert enviar(nuevo(50181), "/farmacia/ingresar", {"identificador": DUI_CIVIL, "password": PASSWORD_CIVIL}).status_code == 401
    # 2FA: código malo y desafío mal formado no rompen la página ni abren sesión
    w = nuevo(50182)
    r = enviar(w, "/institucion/ingresar", {"identificador": CODIGO_HOSPITAL, "password": PASSWORD_HOSPITAL})
    assert "Verificación en dos pasos" in r.text
    desafio = re.search(r'name="desafio_id" value="([0-9a-f-]{36})"', r.text).group(1)
    mal = w.post("/institucion/ingresar/2fa", data={"csrf_token": token_de(r.text), "desafio_id": desafio, "codigo": "000000" if codigos_2fa[-1] != "000000" else "111111"})
    assert mal.status_code == 401 and "Código inválido" in mal.text and sesion_cookie(w, INSTITUCION) is None
    w3 = nuevo(50183)
    r = enviar(w3, "/institucion/ingresar/2fa", {"desafio_id": "no-es-uuid", "codigo": "12"}, pagina="/institucion/ingresar")
    assert r.status_code == 401 and sesion_cookie(w3, INSTITUCION) is None
    assert web.get("/farmacia/ingresar/2fa").status_code == 405 and web.post("/ciudadano/ingresar/2fa").status_code == 404  # solo existe en portales institucionales


# ------------------------------------------------------------------ Omega (TOTP)
def _totp_nuevo():
    with SessionLocal() as db:  # evita el anti-replay entre pruebas consecutivas
        db.execute(update(Persona).where(Persona.dui == DUI_OMEGA).values(totp_ultimo_paso=None))
        db.commit()
    return pyotp.TOTP(TOTP_OMEGA).now()


def test_login_omega_con_totp_y_revalidacion_de_ip(web, monkeypatch):
    ruta = OMEGA.base + "/ingresar"
    mal = enviar(web, ruta, {"dui": DUI_OMEGA, "password": PASSWORD_OMEGA, "totp": "000000"})
    assert mal.status_code == 401 and sesion_cookie(web, OMEGA) is None
    r = enviar(web, ruta, {"dui": DUI_OMEGA, "password": PASSWORD_OMEGA, "totp": _totp_nuevo()})
    assert r.status_code == 303 and sesion_cookie(web, OMEGA) and f"path={OMEGA.base}" in r.headers["set-cookie"].lower()
    assert "Administrador Omega" in web.get(OMEGA.base + "/panel").text and sql("SELECT portal, sujeto_tipo, refresh_jti FROM sesion_web ORDER BY creada_en DESC LIMIT 1") == [("omega", "omega", None)]
    for p in PORTALES[:-1]:  # la sesión de Omega no abre ningún otro portal
        assert web.get(p.base + "/panel").status_code == 303
    monkeypatch.setattr(ses, "ip_permitida_omega", lambda ip: False)  # la IP se revalida en cada petición
    assert web.get(OMEGA.base + "/panel").status_code == 303
    monkeypatch.undo()
    # Omega no entra por los portales de personas ni viceversa
    assert entrar_persona(nuevo(50190), CIUDADANO, DUI_OMEGA, PASSWORD_OMEGA).status_code == 401
    assert entrar_persona(nuevo(50191), PROFESIONAL, DUI_OMEGA, PASSWORD_OMEGA).status_code == 401
    assert enviar(nuevo(50192), ruta, {"dui": DUI_MEDICO, "password": PASSWORD_MEDICO, "totp": "123456"}).status_code == 401


# ------------------------------------------------------------------ Registro (solo ciudadano)
def test_registro_de_personas_usa_las_reglas_existentes(web):
    d = datos_persona(sexo="F", municipio="Santa Tecla", departamento="La Libertad", fecha_nacimiento="1990-05-17")
    campos = {k: d[k] for k in ("dui", "nombres", "apellidos", "correo", "telefono", "departamento", "municipio", "fecha_nacimiento", "sexo")} | {"password": d["password"], "password2": d["password"]}
    r = enviar(web, "/ciudadano/registro", campos)
    assert r.status_code == 303 and r.headers["location"] == "/ciudadano/ingresar?registrado=1"
    assert sql("SELECT sexo, municipio, fecha_nacimiento::text FROM persona WHERE dui = :d", d=d["dui"]) == [("F", "Santa Tecla", "1990-05-17")]
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'PERSONA_REGISTRADA' AND detalle->>'perfiles' LIKE '%civil%'")[0][0] >= 1  # misma bitácora que POST /personas
    assert "Registro completado" in web.get("/ciudadano/ingresar?registrado=1").text
    assert entrar_persona(web, CIUDADANO, d["dui"], d["password"]).status_code == 303  # y ya puede ingresar
    dup = enviar(nuevo(50200), "/ciudadano/registro", campos | {"correo": f"otro-{dui_nuevo()}@example.sv"})
    assert dup.status_code == 409 and "ya registrado" in dup.text
    assert entrar_persona(nuevo(50201), PROFESIONAL, d["dui"], d["password"]).status_code == 403  # recién registrado: ciudadano, no profesional


def test_registro_validaciones_y_escape_de_html(web):
    base = datos_persona()
    campos = {k: base[k] for k in ("dui", "nombres", "apellidos", "correo", "telefono")} | {"password": base["password"], "password2": base["password"], "departamento": "", "municipio": "", "fecha_nacimiento": "", "sexo": ""}
    pagina = "/ciudadano/registro"
    r = enviar(web, pagina, campos | {"password": "corta", "password2": "corta"})
    assert r.status_code == 422 and 'class="campo con-error"' in r.text and "Revise los campos" in r.text
    r = enviar(web, pagina, campos | {"password2": "Distinta12345"})
    assert r.status_code == 422 and "no coinciden" in r.text
    r = enviar(web, pagina, campos | {"dui": '"><script>alert(1)</script>'})
    assert r.status_code == 422 and "<script>alert" not in r.text and "&lt;script&gt;alert" in r.text  # lo escrito se escapa al volver a mostrarse
    assert enviar(web, pagina, campos | {"correo": "no-es-correo"}).status_code == 422
    assert enviar(web, pagina, campos | {"sexo": "X"}).status_code == 422
    assert sql("SELECT count(*) FROM persona WHERE correo = :c", c=base["correo"].lower()) == [(0,)]
    assert web.post(pagina, data=campos).status_code == 403  # y sin CSRF no se registra nada
