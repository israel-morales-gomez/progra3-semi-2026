import json
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError, IntegrityError

from main import app
from nodo_edge_sync.cliente import ColaNodo, NodoNoAutorizado, SinConexion
from omega_core.database import SessionLocal
from omega_core.seed import CODIGO_HOSPITAL, NIT_FARMACIA, PASSWORD_FARMACIA, PASSWORD_HOSPITAL

from .conftest import datos_persona, dui_nuevo, nit_nuevo
from .test_etapa2 import NAC, abrir, acciones_auditoria, auth, medico, sql  # noqa: F401
from .test_etapa5a import universidad
from .test_etapa6a import cama, egresar, ingresar, medico_otra_institucion, paciente_con_atencion, servicio  # noqa: F401


def ahora():
    return datetime.now(timezone.utc)


def uid():
    return uuid.uuid4().hex[:12]


def ev(tipo="NODO_ESTADO", payload=None, ts=None, clave=None, **extra):
    return {"clave": clave or f"ev-{uuid.uuid4()}", "tipo": tipo, "ts": (ts or ahora()).isoformat(), "payload": payload if payload is not None else {}} | extra


def estado_ev(k, valor, ts=None, **kw):
    return ev("NODO_ESTADO", {"clave": k, "valor": valor}, ts, **kw)


def enviar(client, token, eventos, **kw):
    return client.post("/sync/lotes", headers={"X-Nodo-Token": token}, json={"eventos": eventos} | kw)


def login_inst(client, ident, pw, codigos_2fa):
    r = client.post("/auth/login/institucion", json={"identificador": ident, "password": pw})
    assert r.status_code == 200, r.text
    if not r.json().get("requiere_2fa"):
        return auth(r.json()["tokens"]["access_token"])
    r = client.post("/auth/2fa/verificar", json={"desafio_id": r.json()["desafio_id"], "codigo": codigos_2fa[-1]})
    assert r.status_code == 200, r.text
    return auth(r.json()["tokens"]["access_token"])


def crear_nodo(client, h, nombre="Nodo de prueba"):
    r = client.post("/sync/nodos", headers=h, json={"nombre": nombre})
    assert r.status_code == 201, r.text
    return r.json()


@pytest.fixture
def hospital(client, codigos_2fa):
    return login_inst(client, CODIGO_HOSPITAL, PASSWORD_HOSPITAL, codigos_2fa)


@pytest.fixture
def nodo(client, hospital):
    """Nodo del hospital semilla; se revoca al terminar para no acumular nodos activos."""
    n = crear_nodo(client, hospital)
    yield n
    client.delete(f"/sync/nodos/{n['id']}", headers=hospital)


@pytest.fixture
def lab_nodo(client, codigos_2fa):
    """Nodo de la farmacia semilla (otra institución y otro tipo que el hospital). Se revoca al terminar."""
    h = login_inst(client, NIT_FARMACIA, PASSWORD_FARMACIA, codigos_2fa)
    n = crear_nodo(client, h, "Nodo farmacia")
    yield h, n, None
    client.delete(f"/sync/nodos/{n['id']}", headers=h)


def estado_de(client, h, k):
    r = client.get("/sync/estado", params={"clave": k}, headers=h)
    assert r.status_code == 200
    return r.json()[0]["valor"]["valor"] if r.json() else None


def conflictos_de(client, h, entidad):
    return client.get("/sync/conflictos", params={"entidad": entidad}, headers=h).json()


# ------------------------------------------------------------------ Autenticación y autorización del nodo
def test_registro_revocacion_y_autenticacion_del_nodo(client, hospital, medico, universidad, codigos_2fa):
    n = crear_nodo(client, hospital)
    assert n["token"].startswith("nodo_") and n["revocado_en"] is None
    assert "token" not in json.dumps(client.get("/sync/nodos", headers=hospital).json())  # el token se muestra una sola vez
    assert sql("SELECT token_hash FROM nodo_edge WHERE id = :i", i=n["id"])[0][0] != n["token"]  # solo se guarda el hash
    assert enviar(client, n["token"], [estado_ev(f"k{uid()}", 1)]).status_code == 200
    assert "SYNC_NODO_CREADO" in acciones_auditoria(n["id"])
    # sin token, token inventado, o un token de persona o de institución: 401
    assert client.post("/sync/lotes", json={"eventos": [estado_ev("x1", 1)]}).status_code == 401
    assert enviar(client, "nodo_inventado", [estado_ev("x1", 1)]).status_code == 401
    assert client.post("/sync/lotes", headers=hospital, json={"eventos": [estado_ev("x1", 1)]}).status_code == 401
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'SYNC_NODO_RECHAZADO' AND detalle->>'motivo' = 'TOKEN_DESCONOCIDO'")[0][0] >= 2
    # solo una institución (no una persona) registra nodos; y solo hospital/clínica/laboratorio/farmacia
    assert client.post("/sync/nodos", headers=medico, json={"nombre": "Nodo de médico"}).status_code in (401, 403)
    assert client.post("/sync/nodos", headers={}, json={"nombre": "Nodo anónimo"}).status_code in (401, 403)
    uni = universidad
    uni_h = login_inst(client, sql("SELECT nit FROM institucion WHERE id = :i", i=uni)[0][0], "UniClave12345", codigos_2fa)
    assert client.post("/sync/nodos", headers=uni_h, json={"nombre": "Nodo universidad"}).status_code == 403
    # revocar: efecto inmediato, auditado y solo por la institución dueña
    assert client.delete(f"/sync/nodos/{uuid.uuid4()}", headers=hospital).status_code == 404
    assert client.delete(f"/sync/nodos/{n['id']}", headers=hospital).json()["revocado_en"] is not None
    assert enviar(client, n["token"], [estado_ev("x1", 1)]).status_code == 401
    assert "SYNC_NODO_REVOCADO" in acciones_auditoria(n["id"])
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'SYNC_NODO_RECHAZADO' AND recurso_id = :r", r=n["id"])[0][0] >= 1


def test_un_nodo_de_otra_institucion_no_toca_lo_ajeno(client, hospital, nodo, lab_nodo):
    lab_h, lab_n, _ = lab_nodo
    assert client.delete(f"/sync/nodos/{nodo['id']}", headers=lab_h).status_code == 404  # no puede revocar el nodo de otro
    assert nodo["id"] not in json.dumps(client.get("/sync/nodos", headers=lab_h).json())
    # la institución del nodo es siempre la del token: la misma clave se puede usar en dos instituciones sin chocar
    k, clave = f"k{uid()}", f"misma-clave-{uid()}"
    assert enviar(client, nodo["token"], [estado_ev(k, "hospital", clave=clave)]).json()["aplicados"] == 1
    assert enviar(client, lab_n["token"], [estado_ev(k, "laboratorio", clave=clave)]).json()["aplicados"] == 1
    assert estado_de(client, hospital, k) == "hospital" and estado_de(client, lab_h, k) == "laboratorio"
    assert sql("SELECT count(DISTINCT institucion_id) FROM sync_evento WHERE clave = :c", c=clave) == [(2,)]
    # un evento no puede declarar institución ajena: se rechaza (no se ignora el campo)
    r = enviar(client, lab_n["token"], [estado_ev(k, "x", institucion_id=str(uuid.uuid4())), ev("NODO_ESTADO", {"clave": k, "valor": 1, "institucion_id": "x"})]).json()
    assert [x["estado"] for x in r["resultados"]] == ["ERROR", "ERROR"]
    assert estado_de(client, hospital, k) == "hospital"
    # los conflictos solo se ven en la propia institución
    k2 = f"k{uid()}"
    enviar(client, lab_n["token"], [estado_ev(k2, 1, ts=ahora()), estado_ev(k2, 2, ts=ahora() - timedelta(minutes=5))])
    assert len(conflictos_de(client, lab_h, f"estado:{k2}")) == 1 and conflictos_de(client, hospital, f"estado:{k2}") == []


# ------------------------------------------------------------------ Lotes e idempotencia
def test_lote_responde_por_evento_y_el_mismo_lote_dos_veces_no_duplica(client, hospital, nodo):
    tok, a, b, c = nodo["token"], f"k{uid()}", f"k{uid()}", f"k{uid()}"
    t0 = ahora() - timedelta(minutes=10)
    e1, e2 = estado_ev(a, "A1", t0), estado_ev(b, "B1", t0)
    r1 = enviar(client, tok, [e1, e2]).json()
    assert (r1["recibidos"], r1["aplicados"], r1["duplicados"], r1["conflictos"], r1["errores"]) == (2, 2, 0, 0, 0)
    # segundo lote: un duplicado, un conflicto (más viejo que lo guardado), un aplicado nuevo y un error
    lote2 = [e1, estado_ev(a, "A-viejo", t0 - timedelta(minutes=5)), estado_ev(c, "C1", t0), ev("TIPO_RARO", {})]
    r2 = enviar(client, tok, lote2).json()
    assert [x["estado"] for x in r2["resultados"]] == ["DUPLICADO", "CONFLICTO", "APLICADO", "ERROR"] and [x["indice"] for x in r2["resultados"]] == [0, 1, 2, 3]
    assert (r2["recibidos"], r2["aplicados"], r2["duplicados"], r2["conflictos"], r2["errores"]) == (4, 1, 1, 1, 1)
    assert r2["resultados"][0]["resultado_original"] == "APLICADO" and r2["resultados"][0]["payload_coincide"] is True
    assert r2["resultados"][1]["conflicto_id"] and "Tipo de evento desconocido" in r2["resultados"][3]["detalle"]
    filas = sql("SELECT count(*) FROM sync_evento WHERE clave = ANY(:c)", c=[e1["clave"], e2["clave"], lote2[1]["clave"], lote2[2]["clave"]])[0][0]
    conf = len(conflictos_de(client, hospital, f"estado:{a}"))
    # --- el MISMO lote otra vez: todo lo ya procesado es DUPLICADO, sin error y sin efectos nuevos
    r3 = enviar(client, tok, lote2).json()
    assert [x["estado"] for x in r3["resultados"]] == ["DUPLICADO", "DUPLICADO", "DUPLICADO", "ERROR"]
    assert (r3["aplicados"], r3["duplicados"], r3["conflictos"], r3["errores"]) == (0, 3, 0, 1)
    assert [x.get("resultado_original") for x in r3["resultados"][:3]] == ["APLICADO", "CONFLICTO", "APLICADO"]
    assert sql("SELECT count(*) FROM sync_evento WHERE clave = ANY(:c)", c=[e1["clave"], e2["clave"], lote2[1]["clave"], lote2[2]["clave"]])[0][0] == filas == 4
    assert len(conflictos_de(client, hospital, f"estado:{a}")) == conf == 1  # no se registra el conflicto dos veces
    assert estado_de(client, hospital, a) == "A1" and estado_de(client, hospital, c) == "C1"
    # el primer lote completo, reenviado, también es todo duplicado
    r4 = enviar(client, tok, [e1, e2]).json()
    assert (r4["aplicados"], r4["duplicados"]) == (0, 2)


def test_la_base_de_datos_garantiza_la_unicidad_de_la_clave(client, nodo):
    e = estado_ev(f"k{uid()}", 1)
    assert enviar(client, nodo["token"], [e]).json()["aplicados"] == 1
    with pytest.raises(IntegrityError, match="uq_sync_evento_institucion_clave"):
        with SessionLocal() as db:
            db.execute(text("""INSERT INTO sync_evento (id, institucion_id, nodo_id, clave, tipo, ts_evento, recibido_en, lote_id, payload, hash_payload, resultado)
                               SELECT gen_random_uuid(), institucion_id, nodo_id, clave, tipo, ts_evento, recibido_en, lote_id, payload, hash_payload, resultado
                               FROM sync_evento WHERE clave = :c"""), {"c": e["clave"]})
            db.commit()


def test_el_mismo_lote_desde_varios_hilos_se_aplica_una_sola_vez(client, nodo):
    k = f"k{uid()}"
    t0 = ahora() - timedelta(minutes=3)
    lote = [estado_ev(k, i, t0 + timedelta(seconds=i)) for i in range(5)] + [estado_ev(f"o{uid()}", 1, t0)]

    def intento(_):
        with TestClient(app, client=("127.0.0.1", 50003)) as cl:
            r = enviar(cl, nodo["token"], lote)
            assert r.status_code == 200, r.text
            return r.json()

    with ThreadPoolExecutor(6) as ex:
        res = list(ex.map(intento, range(6)))
    assert sum(r["aplicados"] + r["conflictos"] for r in res) == 6  # cada evento se procesó exactamente una vez en total
    assert sum(r["duplicados"] for r in res) == 6 * 5 and all(r["errores"] == 0 for r in res)
    assert sql("SELECT count(*) FROM sync_evento WHERE clave = ANY(:c)", c=[e["clave"] for e in lote])[0][0] == 6


def test_evento_invalido_no_frena_al_resto_ni_consume_su_clave(client, nodo):
    k = f"k{uid()}"
    malo_ts = ev("NODO_ESTADO", {"clave": k, "valor": 1}, ahora() + timedelta(hours=1))                 # reloj adelantado
    viejo = ev("NODO_ESTADO", {"clave": k, "valor": 1}, ahora() - timedelta(days=40))                  # demasiado antiguo
    sin_zona = {"clave": f"ev-{uuid.uuid4()}", "tipo": "NODO_ESTADO", "ts": "2026-10-10T09:00:00", "payload": {"clave": k, "valor": 1}}
    sin_clave = {"tipo": "NODO_ESTADO", "ts": ahora().isoformat(), "payload": {}}
    payload_malo = ev("NODO_ESTADO", {"clave": k, "valor": 1, "extra": True})
    bueno = estado_ev(k, "ok")
    r = enviar(client, nodo["token"], [malo_ts, viejo, sin_zona, sin_clave, payload_malo, bueno]).json()
    assert [x["estado"] for x in r["resultados"]] == ["ERROR"] * 5 + ["APLICADO"] and (r["errores"], r["aplicados"]) == (5, 1)
    assert "futuro" in r["resultados"][0]["detalle"] and "30 días" in r["resultados"][1]["detalle"]
    # el error no consume la clave: se reenvía corregido con la MISMA clave y se aplica
    corregido = estado_ev(k, "corregido", clave=payload_malo["clave"])
    assert enviar(client, nodo["token"], [corregido]).json()["aplicados"] == 1
    assert sql("SELECT count(*) FROM sync_evento WHERE clave = :c", c=payload_malo["clave"]) == [(1,)]
    # lote vacío o demasiado grande: rechazado entero
    assert enviar(client, nodo["token"], []).status_code == 422
    assert enviar(client, nodo["token"], [5]).status_code == 422  # un elemento que no es objeto
    assert enviar(client, nodo["token"], [estado_ev(k, 1)] * 201).status_code == 422


# ------------------------------------------------------------------ Conflictos: gana el más reciente
def test_conflictos_gana_el_evento_mas_reciente_y_se_registran(client, hospital, nodo):
    k, ent = f"k{uid()}", None
    ent = f"estado:{k}"
    t0 = ahora() - timedelta(minutes=30)
    assert enviar(client, nodo["token"], [estado_ev(k, "v1", t0)]).json()["aplicados"] == 1
    # más reciente: gana y pisa; queda registrado lo que se sobrescribió
    r = enviar(client, nodo["token"], [estado_ev(k, "v2", t0 + timedelta(minutes=5))]).json()["resultados"][0]
    assert r["estado"] == "APLICADO" and r["conflicto_id"] and estado_de(client, hospital, k) == "v2"
    # más viejo: pierde (CONFLICTO) y el valor guardado no cambia
    r = enviar(client, nodo["token"], [estado_ev(k, "v0", t0 - timedelta(minutes=5))]).json()["resultados"][0]
    assert r["estado"] == "CONFLICTO" and r["conflicto_id"] and estado_de(client, hospital, k) == "v2"
    # empate de marca de tiempo: con valor distinto es conflicto (se conserva lo guardado); con el mismo valor no hay nada que resolver
    assert enviar(client, nodo["token"], [estado_ev(k, "otro", t0 + timedelta(minutes=5))]).json()["resultados"][0]["estado"] == "CONFLICTO"
    r = enviar(client, nodo["token"], [estado_ev(k, "v2", t0 + timedelta(minutes=5))]).json()["resultados"][0]
    assert r["estado"] == "APLICADO" and r["conflicto_id"] is None
    cs = {c["resolucion"]: c for c in conflictos_de(client, hospital, ent)}
    assert len(conflictos_de(client, hospital, ent)) == 3
    assert cs["EVENTO_GANA"]["valor_servidor"]["valor"] == "v1" and cs["EVENTO_GANA"]["valor_evento"]["valor"] == "v2"
    assert cs["SERVIDOR_GANA"]["entidad"] == ent and cs["SERVIDOR_GANA"]["ts_evento"] and cs["SERVIDOR_GANA"]["ts_servidor"]
    # el orden de llegada dentro del lote da igual: se procesa por marca de tiempo
    k2 = f"k{uid()}"
    nuevo, viejo = estado_ev(k2, "nuevo", t0 + timedelta(minutes=2)), estado_ev(k2, "viejo", t0)
    r = enviar(client, nodo["token"], [nuevo, viejo]).json()
    assert [x["estado"] for x in r["resultados"]] == ["APLICADO", "APLICADO"] and estado_de(client, hospital, k2) == "nuevo"
    # lo registrado es inmutable
    with pytest.raises(DBAPIError, match="inmutable|no se permite|prohibid"):
        with SessionLocal() as db:
            db.execute(text("UPDATE sync_conflicto SET motivo = 'x' WHERE entidad = :e"), {"e": ent})
            db.commit()


def test_limpieza_de_cama_terminada_con_nodo(client, medico, hospital, nodo, servicio, omega_headers):
    c = cama(client, medico, servicio, "N-01").json()
    _, at = paciente_con_atencion(client, medico)
    assert ingresar(client, medico, c["id"], at).status_code == 201
    pedido = lambda cid, ts=None: ev("CAMA_LIMPIEZA_TERMINADA", {"cama_id": cid}, ts)  # noqa: E731
    # cama ocupada: la limpieza no aplica (conflicto, gana el servidor)
    r = enviar(client, nodo["token"], [pedido(c["id"], ahora() + timedelta(seconds=1))]).json()["resultados"][0]
    assert r["estado"] == "CONFLICTO" and sql("SELECT estado FROM cama WHERE id = :i", i=c["id"]) == [("OCUPADA",)]
    assert egresar(client, medico, c["id"]).status_code == 200
    assert sql("SELECT estado FROM cama WHERE id = :i", i=c["id"]) == [("LIMPIEZA",)]
    # evento anterior al último cambio de la cama: pierde
    r = enviar(client, nodo["token"], [pedido(c["id"], ahora() - timedelta(hours=1))]).json()["resultados"][0]
    assert r["estado"] == "CONFLICTO" and sql("SELECT estado FROM cama WHERE id = :i", i=c["id"]) == [("LIMPIEZA",)]
    # evento posterior: se aplica, la cama queda libre y se audita
    e = pedido(c["id"], ahora() + timedelta(seconds=2))
    r = enviar(client, nodo["token"], [e]).json()["resultados"][0]
    assert r["estado"] == "APLICADO" and sql("SELECT estado FROM cama WHERE id = :i", i=c["id"]) == [("LIBRE",)]
    assert "CAMA_LIMPIEZA_TERMINADA" in acciones_auditoria(c["id"])
    assert sql("SELECT detalle->>'via' FROM auditoria WHERE accion = 'CAMA_LIMPIEZA_TERMINADA' AND recurso_id = :r", r=c["id"]) == [("SYNC_NODO",)]
    assert enviar(client, nodo["token"], [e]).json()["resultados"][0]["estado"] == "DUPLICADO"
    # cama de OTRA institución o inexistente: mismo error (no revela que existe) y no se toca
    otro_h, _ = medico_otra_institucion(client, omega_headers)
    ajena = cama(client, otro_h, servicio, "AJ-01").json()
    ra = enviar(client, nodo["token"], [pedido(ajena["id"]), pedido(str(uuid.uuid4()))]).json()["resultados"]
    assert [x["estado"] for x in ra] == ["ERROR", "ERROR"] and ra[0]["detalle"] == ra[1]["detalle"]


def test_tipos_de_evento_autorizados_segun_el_tipo_de_institucion(client, lab_nodo):
    _, n, _ = lab_nodo
    r = enviar(client, n["token"], [ev("CAMA_LIMPIEZA_TERMINADA", {"cama_id": str(uuid.uuid4())}), estado_ev(f"k{uid()}", 1)]).json()["resultados"]
    assert r[0]["estado"] == "ERROR" and "no está autorizado" in r[0]["detalle"] and r[1]["estado"] == "APLICADO"


# ------------------------------------------------------------------ Bitácora e inmutabilidad
def test_todo_queda_en_la_bitacora(client, hospital, nodo):
    k, lote_id = f"k{uid()}", str(uuid.uuid4())
    t0 = ahora() - timedelta(minutes=10)
    e1 = estado_ev(k, "A", t0)
    assert enviar(client, nodo["token"], [e1]).json()["aplicados"] == 1
    lote = [estado_ev(k, "viejo", t0 - timedelta(minutes=1)), ev("TIPO_RARO", {}), estado_ev(f"k{uid()}", "otro", t0)]
    r = enviar(client, nodo["token"], lote, lote_id=lote_id).json()
    assert r["lote_id"] == lote_id
    det = sql("SELECT detalle, actor_tipo, actor_id FROM auditoria WHERE accion = 'SYNC_LOTE_RECIBIDO' AND recurso_id = :r", r=lote_id)
    assert len(det) == 1 and det[0][1] == "nodo" and str(det[0][2]) == nodo["id"]
    assert (det[0][0]["recibidos"], det[0][0]["aplicados"], det[0][0]["conflictos"], det[0][0]["errores"]) == (3, 1, 1, 1)
    assert "SYNC_EVENTO_APLICADO" in acciones_auditoria(sql("SELECT id FROM sync_evento WHERE clave = :c", c=e1["clave"])[0][0].__str__())
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'SYNC_EVENTO_CONFLICTO' AND detalle->>'clave' = :c", c=lote[0]["clave"]) == [(1,)]
    # clave reutilizada con contenido distinto: se ignora como duplicado, pero queda registrada la anomalía
    r = enviar(client, nodo["token"], [estado_ev(k, "OTRO-CONTENIDO", t0, clave=e1["clave"])]).json()["resultados"][0]
    assert r["estado"] == "DUPLICADO" and r["payload_coincide"] is False
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'SYNC_CLAVE_REUTILIZADA' AND detalle->>'clave' = :c", c=e1["clave"]) == [(1,)]
    assert estado_de(client, hospital, k) == "A"


def test_eventos_y_conflictos_son_inmutables_en_la_base(client, nodo):
    k = f"k{uid()}"
    e = estado_ev(k, 1)
    enviar(client, nodo["token"], [e, estado_ev(k, 2, ahora() - timedelta(hours=1))])
    for sentencia in ("UPDATE sync_evento SET payload = '{}'::jsonb WHERE clave = :c", "UPDATE sync_evento SET resultado = 'PENDIENTE' WHERE clave = :c",
                      "UPDATE sync_evento SET resultado = 'CONFLICTO' WHERE clave = :c", "DELETE FROM sync_evento WHERE clave = :c", "TRUNCATE sync_evento",
                      "DELETE FROM sync_conflicto WHERE entidad = :e", "TRUNCATE sync_conflicto"):
        with pytest.raises(DBAPIError):
            with SessionLocal() as db:
                db.execute(text(sentencia), {"c": e["clave"], "e": f"estado:{k}"})
                db.commit()
    assert sql("SELECT resultado FROM sync_evento WHERE clave = :c", c=e["clave"]) == [("APLICADO",)]


# ------------------------------------------------------------------ Cliente del nodo (cola SQLite)
def transporte_de(client, token, registro=None):
    def t(lote):
        if registro is not None:
            registro.append(lote)
        r = enviar(client, token, lote["eventos"], lote_id=lote["lote_id"])
        return r.status_code, r.json()
    return t


def test_cliente_encola_sin_red_y_envia_en_lotes_al_reconectar(client, nodo, tmp_path):
    ruta, lotes, red = str(tmp_path / "cola.sqlite"), [], {"arriba": False}
    k = f"k{uid()}"

    def transporte(lote):
        if not red["arriba"]:
            raise SinConexion("sin red")
        return transporte_de(client, nodo["token"], lotes)(lote)

    cola = ColaNodo(ruta, transporte)
    claves = [cola.encolar("NODO_ESTADO", {"clave": k, "valor": i}, ts=ahora() - timedelta(minutes=10 - i)) for i in range(5)]
    assert cola.pendientes() == 5
    with pytest.raises(SinConexion):
        cola.sincronizar(tam_lote=2)
    assert cola.pendientes() == 5 and sql("SELECT count(*) FROM sync_evento WHERE clave = ANY(:c)", c=claves) == [(0,)]
    # el archivo sobrevive a un reinicio del nodo
    cola = ColaNodo(ruta, transporte)
    assert cola.pendientes() == 5
    red["arriba"] = True
    r = cola.sincronizar(tam_lote=2)
    assert (r["lotes"], r["enviados"], r["aplicados"]) == (3, 5, 5) and [len(x["eventos"]) for x in lotes] == [2, 2, 1]
    assert cola.pendientes() == 0 and cola.estados() == {"APLICADO": 5}
    assert cola.sincronizar()["enviados"] == 0  # nada más que enviar
    assert sql("SELECT valor->>'valor' FROM sync_estado_nodo WHERE clave = :k AND institucion_id = (SELECT institucion_id FROM nodo_edge WHERE id = :n)", k=k, n=nodo["id"]) == [("4",)]


def test_cliente_reenvio_tras_caida_es_seguro(client, nodo, tmp_path):
    """El servidor procesa el lote pero la respuesta se pierde: el nodo no sabe que llegó y lo reenvía; el servidor lo reconoce."""
    cola = ColaNodo(str(tmp_path / "c.sqlite"), None)
    k = f"k{uid()}"
    claves = [cola.encolar("NODO_ESTADO", {"clave": k, "valor": i}, ts=ahora() - timedelta(minutes=5 - i)) for i in range(3)]

    def respuesta_perdida(lote):
        transporte_de(client, nodo["token"])(lote)
        raise SinConexion("se cortó la respuesta")

    cola.transporte = respuesta_perdida
    with pytest.raises(SinConexion):
        cola.sincronizar()
    assert cola.pendientes() == 3
    cola.transporte = transporte_de(client, nodo["token"])
    r = cola.sincronizar()
    assert (r["duplicados"], r["aplicados"]) == (3, 0) and cola.pendientes() == 0
    assert sql("SELECT count(*) FROM sync_evento WHERE clave = ANY(:c)", c=claves) == [(3,)]


def test_cliente_token_rechazado_y_eventos_con_error(client, hospital, nodo, tmp_path):
    cola = ColaNodo(str(tmp_path / "c.sqlite"), transporte_de(client, "nodo_falso"))
    cola.encolar("NODO_ESTADO", {"clave": "xx", "valor": 1})
    with pytest.raises(NodoNoAutorizado):
        cola.sincronizar()
    assert cola.pendientes() == 1  # no se pierde nada
    cola.transporte = transporte_de(client, nodo["token"])
    cola.encolar("TIPO_RARO", {})  # el servidor lo rechaza: queda FALLIDO y no se reintenta solo
    r = cola.sincronizar()
    assert (r["aplicados"], r["fallidos"]) == (1, 1) and cola.pendientes() == 0 and cola.estados() == {"APLICADO": 1, "FALLIDO": 1}
    # el servidor caído (5xx) deja los eventos pendientes
    cola.encolar("NODO_ESTADO", {"clave": "yy", "valor": 1})
    cola.transporte = lambda lote: (503, {})
    with pytest.raises(SinConexion):
        cola.sincronizar()
    assert cola.pendientes() == 1


# ------------------------------------------------------------------ Documentación
def test_endpoints_documentados(client):
    doc = client.get("/openapi.json").json()
    paths = doc["paths"]
    for p, ms in (("/sync/nodos", {"get", "post"}), ("/sync/nodos/{nodo_id}", {"delete"}), ("/sync/lotes", {"post"}), ("/sync/conflictos", {"get"}), ("/sync/estado", {"get"})):
        assert ms <= set(paths[p]), p
        assert all(op.get("summary") and op.get("responses") for op in paths[p].values()), p
    lotes = paths["/sync/lotes"]["post"]
    assert any(x["name"] == "X-Nodo-Token" and x["in"] == "header" for x in lotes["parameters"]) and "401" in lotes["responses"]
    assert "DUPLICADO" in lotes["description"] and "más reciente" in lotes["description"]
    assert next(v for k, v in doc["components"]["schemas"].items() if k.startswith("nodo_edge_sync") and k.endswith("LoteIn")).get("example")
    assert "DUPLICADO" in json.dumps(doc["components"]["schemas"]["ResultadoEventoOut"])
