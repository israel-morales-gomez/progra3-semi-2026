import json
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError, IntegrityError

from main import app
from omega_core.database import SessionLocal
from omega_core.seed import DUI_MEDICO

from .conftest import datos_persona
from .test_etapa2 import NAC, acciones_auditoria, auth, medico, ml, paciente_id, sql  # noqa: F401
from .test_etapa2c import login
from .test_etapa4a import pac, pac_h  # noqa: F401

SV = timezone(timedelta(hours=-6))


def prox_fecha(dias=4) -> date:
    return datetime.now(SV).date() + timedelta(days=dias)


@pytest.fixture
def agenda(client, medico):
    """Bloque 08:00-10:00 (4 citas de 30 min) en un día futuro; al terminar se retira el bloque y se cancelan las citas de prueba."""
    f = prox_fecha()
    r = client.post("/agenda", headers=medico, json={"dia_semana": f.weekday(), "hora_inicio": "08:00", "hora_fin": "10:00", "duracion_min": 30})
    assert r.status_code == 201, r.text
    bloque = r.json()
    yield {"fecha": str(f), "bloque": bloque, "medico_id": str(sql("SELECT id FROM persona WHERE dui = :d", d=DUI_MEDICO)[0][0])}
    with SessionLocal() as db:
        db.execute(text("UPDATE cita SET estado='CANCELADA' WHERE medico_id = :m AND estado='PROGRAMADA'"), {"m": bloque["id"] and sql("SELECT medico_id FROM agenda_disponibilidad WHERE id = :i", i=bloque["id"])[0][0]})
        db.execute(text("UPDATE agenda_disponibilidad SET activo=false WHERE id = :i"), {"i": bloque["id"]})
        db.commit()


def reservar(client, h, ag, hora="08:00", **kw):
    return client.post("/citas", headers=h, json={"medico_id": ag["medico_id"], "fecha": ag["fecha"], "hora": hora} | kw)


# ------------------------------------------------------------------ Cascada + reserva
def test_cascada_y_reserva(client, medico, agenda, pac, pac_h):
    esp = client.get("/citas/especialidades", headers=pac_h).json()
    assert {"especialidad": "Medicina Interna", "medicos": 1} in esp
    ce = client.get("/citas/centros", params={"especialidad": "medicina interna"}, headers=pac_h).json()
    assert len(ce) == 1 and ce[0]["medicos"] == 1
    dr = client.get("/citas/doctores", params={"especialidad": "Medicina Interna", "institucion_id": ce[0]["institucion_id"]}, headers=pac_h).json()
    assert [d["medico_id"] for d in dr] == [agenda["medico_id"]]
    assert agenda["fecha"] in client.get("/citas/fechas", params={"medico_id": agenda["medico_id"]}, headers=pac_h).json()["fechas"]
    h = client.get("/citas/horas", params={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"]}, headers=pac_h).json()
    assert h["horas"] == ["08:00:00", "08:30:00", "09:00:00", "09:30:00"] and h["duracion_min"] == 30
    r = reservar(client, pac_h, agenda, "08:30", motivo="Control de presión")
    assert r.status_code == 201, r.text
    c = r.json()
    assert c["estado"] == "PROGRAMADA" and c["hora"] == "08:30:00" and c["fin"] == "09:00:00" and c["especialidad"] == "Medicina Interna"
    # ya no aparece como libre
    h = client.get("/citas/horas", params={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"]}, headers=pac_h).json()
    assert "08:30:00" not in h["horas"] and len(h["horas"]) == 3
    # otra persona no puede tomar el mismo horario
    otra = datos_persona(fecha_nacimiento=NAC)
    client.post("/personas", json=otra)
    h2 = login(client, otra)
    assert reservar(client, h2, agenda, "08:30").status_code == 409
    # mis citas: solo las mías
    assert [x["id"] for x in client.get("/citas", headers=pac_h).json()["items"]] == [c["id"]]
    assert client.get("/citas", headers=h2).json()["total"] == 0
    # el médico ve su agenda con solo el nombre del paciente
    ag = client.get("/agenda/citas", params={"desde": agenda["fecha"], "hasta": agenda["fecha"]}, headers=medico).json()
    assert ag["total"] == 1 and ag["items"][0]["paciente"].startswith(pac["nombres"]) and set(ag["items"][0]) == {"id", "fecha", "hora", "estado", "paciente", "motivo"}
    ac = acciones_auditoria(c["id"])
    assert ac == ["CITA_RESERVADA"]
    assert "CITA_DENEGADA" in [a[0] for a in sql("SELECT accion FROM auditoria WHERE accion='CITA_DENEGADA' AND detalle->>'motivo'='HORARIO_OCUPADO'")]


def test_validaciones_de_horario(client, medico, agenda, pac, pac_h):
    assert reservar(client, pac_h, agenda, "08:15").status_code == 422          # no cae en la grilla de la agenda
    assert reservar(client, pac_h, agenda, "10:00").status_code == 422          # fuera del bloque
    assert reservar(client, pac_h, agenda, "08:00:30").status_code == 422       # formato
    assert client.post("/citas", headers=pac_h, json={"medico_id": agenda["medico_id"], "fecha": str(prox_fecha(200)), "hora": "08:00"}).status_code == 422
    # día sin agenda (otro día de la semana)
    otro = prox_fecha(5)
    assert client.post("/citas", headers=pac_h, json={"medico_id": agenda["medico_id"], "fecha": str(otro), "hora": "08:00"}).status_code == 422
    # pasado
    assert client.post("/citas", headers=pac_h, json={"medico_id": agenda["medico_id"], "fecha": str(date.today() - timedelta(days=7)), "hora": "08:00"}).status_code == 422
    # doctor inexistente / persona que no es doctor
    assert client.post("/citas", headers=pac_h, json={"medico_id": "00000000-0000-0000-0000-000000000000", "fecha": agenda["fecha"], "hora": "08:00"}).status_code == 404
    assert client.get("/citas/horas", params={"medico_id": paciente_id(pac["dui"]), "fecha": agenda["fecha"]}, headers=pac_h).status_code == 404
    # sin sesión
    assert client.get("/citas/especialidades").status_code == 401 and client.post("/citas", json={}).status_code in (401, 422)
    assert client.post("/citas", headers=pac_h, json={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"], "hora": "08:00", "extra": 1}).status_code == 422


def test_dui_congelado_no_reserva(client, medico, agenda):
    p = datos_persona(fecha_nacimiento=NAC)
    client.post("/personas", json=p)
    h = login(client, p)
    r, _ = ml(client, p["dui"])
    assert r.status_code in (200, 201), r.text
    # la sesión de un fallecido deja de valer (401); y aunque se saltara ese filtro, la regla de negocio responde 423
    assert reservar(client, h, agenda).status_code == 401
    from fastapi import HTTPException
    from core_expediente.service import asegurar_no_congelado
    with SessionLocal() as db, pytest.raises(HTTPException) as ex:
        asegurar_no_congelado(db, paciente_id(p["dui"]) if False else __import__("uuid").UUID(paciente_id(p["dui"])))
    assert ex.value.status_code == 423
    # reserva a nombre de un DUI congelado forzando el filtro de sesión: el endpoint debe devolver 423
    from omega_core.deps import persona_actual
    from omega_core.models import Persona
    def _forzada():
        with SessionLocal() as db:
            return db.get(Persona, __import__("uuid").UUID(paciente_id(p["dui"])))
    app.dependency_overrides[persona_actual] = _forzada
    try:
        assert reservar(client, h, agenda).status_code == 423
    finally:
        app.dependency_overrides.pop(persona_actual, None)
    assert sql("SELECT count(*) FROM cita WHERE paciente_id = :p", p=paciente_id(p["dui"]))[0][0] == 0
    assert any(a == "CITA_DENEGADA" for (a,) in sql("SELECT accion FROM auditoria WHERE actor_id = :p", p=paciente_id(p["dui"])))


def test_doble_reserva_bloqueada_por_la_base_de_datos(client, medico, agenda):
    pers = []
    for _ in range(6):
        p = datos_persona(fecha_nacimiento=NAC)
        client.post("/personas", json=p)
        pers.append(login(client, p))

    def intento(h):
        with TestClient(app, client=("127.0.0.1", 50001)) as c:
            return reservar(c, h, agenda, "09:00").status_code

    with ThreadPoolExecutor(6) as ex:
        codigos = list(ex.map(intento, pers))
    assert sorted(codigos) == [201] + [409] * 5, codigos
    # aun saltándose la API, la BD lo rechaza
    with SessionLocal() as db:
        c = db.execute(text("SELECT medico_id, institucion_id, especialidad, inicio, fin FROM cita WHERE medico_id = :m AND estado='PROGRAMADA'"), {"m": agenda["medico_id"]}).first()
        otro = db.execute(text("SELECT id FROM persona WHERE id <> :m LIMIT 1"), {"m": agenda["medico_id"]}).scalar()
        with pytest.raises(IntegrityError, match="uq_cita_medico_inicio"):
            db.execute(text("INSERT INTO cita (id, paciente_id, medico_id, institucion_id, especialidad, inicio, fin, estado, creado_en) "
                            "VALUES (gen_random_uuid(), :p, :m, :i, :e, :a, :b, 'PROGRAMADA', now())"), {"p": otro, "m": c[0], "i": c[1], "e": c[2], "a": c[3], "b": c[4]})
        db.rollback()


def test_paciente_no_tiene_dos_citas_a_la_misma_hora(client, medico, agenda, pac_h):
    assert reservar(client, pac_h, agenda, "08:00").status_code == 201
    r = reservar(client, pac_h, agenda, "08:00")
    assert r.status_code == 409


# ------------------------------------------------------------------ Cancelar / reprogramar
def test_cancelar_libera_y_es_solo_del_titular(client, medico, agenda, pac_h):
    cid = reservar(client, pac_h, agenda, "08:00").json()["id"]
    intruso = datos_persona(fecha_nacimiento=NAC)
    client.post("/personas", json=intruso)
    hi = login(client, intruso)
    assert client.post(f"/citas/{cid}/cancelar", headers=hi).status_code == 404
    assert client.post(f"/citas/{cid}/reprogramar", headers=hi, json={"fecha": agenda["fecha"], "hora": "09:00"}).status_code == 404
    r = client.post(f"/citas/{cid}/cancelar", headers=pac_h, json={"motivo": "Ya no puedo asistir"})
    assert r.status_code == 200 and r.json()["estado"] == "CANCELADA"
    assert client.post(f"/citas/{cid}/cancelar", headers=pac_h).status_code == 409
    assert "08:00:00" in client.get("/citas/horas", params={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"]}, headers=pac_h).json()["horas"]
    assert reservar(client, hi, agenda, "08:00").status_code == 201  # otro ciudadano ya puede tomarlo
    assert client.get("/citas", params={"estado": "CANCELADA"}, headers=pac_h).json()["total"] == 1
    assert acciones_auditoria(cid) == ["CITA_RESERVADA", "CITA_CANCELADA"]


def test_reprogramar_atomico(client, medico, agenda, pac_h):
    c1 = reservar(client, pac_h, agenda, "08:00").json()
    otro = datos_persona(fecha_nacimiento=NAC)
    client.post("/personas", json=otro)
    ho = login(client, otro)
    assert reservar(client, ho, agenda, "09:30").status_code == 201
    # nuevo horario ocupado: la cita original queda intacta
    assert client.post(f"/citas/{c1['id']}/reprogramar", headers=pac_h, json={"fecha": agenda["fecha"], "hora": "09:30"}).status_code == 409
    assert client.get("/citas", params={"estado": "PROGRAMADA"}, headers=pac_h).json()["items"][0]["id"] == c1["id"]
    # mismo horario: 422
    assert client.post(f"/citas/{c1['id']}/reprogramar", headers=pac_h, json={"fecha": agenda["fecha"], "hora": "08:00"}).status_code == 422
    r = client.post(f"/citas/{c1['id']}/reprogramar", headers=pac_h, json={"fecha": agenda["fecha"], "hora": "09:00", "motivo": "Cambio de turno laboral"})
    assert r.status_code == 200, r.text
    n = r.json()
    assert n["hora"] == "09:00:00" and n["reprogramada_de_id"] == c1["id"] and n["estado"] == "PROGRAMADA"
    est = {x["id"]: x["estado"] for x in client.get("/citas", headers=pac_h).json()["items"]}
    assert est == {c1["id"]: "REPROGRAMADA", n["id"]: "PROGRAMADA"}
    assert "08:00:00" in client.get("/citas/horas", params={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"]}, headers=pac_h).json()["horas"]
    assert client.post(f"/citas/{c1['id']}/cancelar", headers=pac_h).status_code == 409
    assert acciones_auditoria(n["id"]) == ["CITA_REPROGRAMADA"]


def test_citas_inmutables_en_la_bd(client, medico, agenda, pac_h):
    c = reservar(client, pac_h, agenda, "08:00").json()
    for q in ("UPDATE cita SET inicio = inicio + interval '1 hour' WHERE id = :i", "DELETE FROM cita WHERE id = :i", "TRUNCATE cita"):
        with pytest.raises(DBAPIError, match="cita"):
            with SessionLocal() as db:
                db.execute(text(q), {"i": c["id"]} if ":i" in q else {})
                db.commit()
    client.post(f"/citas/{c['id']}/cancelar", headers=pac_h)
    with pytest.raises(DBAPIError, match="CANCELADA"):
        with SessionLocal() as db:
            db.execute(text("UPDATE cita SET estado='PROGRAMADA' WHERE id = :i"), {"i": c["id"]})
            db.commit()


# ------------------------------------------------------------------ Agenda del profesional
def test_agenda_del_medico(client, medico, agenda, pac_h):
    f = agenda["bloque"]
    # traslape
    assert client.post("/agenda", headers=medico, json={"dia_semana": f["dia_semana"], "hora_inicio": "09:00", "hora_fin": "11:00", "duracion_min": 30}).status_code == 409
    # validaciones
    for malo in ({"dia_semana": 7, "hora_inicio": "08:00", "hora_fin": "09:00"}, {"dia_semana": 1, "hora_inicio": "09:00", "hora_fin": "08:00"},
                 {"dia_semana": 1, "hora_inicio": "08:00", "hora_fin": "08:20", "duracion_min": 30}, {"dia_semana": 1, "hora_inicio": "08:00", "hora_fin": "09:00", "duracion_min": 5}):
        assert client.post("/agenda", headers=medico, json=malo).status_code == 422, malo
    # un ciudadano no define agenda
    assert client.post("/agenda", headers=pac_h, json={"dia_semana": 1, "hora_inicio": "08:00", "hora_fin": "09:00"}).status_code == 403
    assert client.get("/agenda", headers=pac_h).status_code == 403
    assert f["id"] in [b["id"] for b in client.get("/agenda", headers=medico).json()]
    # retirar el bloque: deja de ofrecerse, la cita ya reservada se conserva
    cid = reservar(client, pac_h, agenda, "08:00").json()["id"]
    assert client.delete(f"/agenda/{f['id']}", headers=medico).json()["activo"] is False
    assert client.get("/citas/especialidades", headers=pac_h).json() == [] or all(e["especialidad"] != "Medicina Interna" for e in client.get("/citas/especialidades", headers=pac_h).json())
    assert client.get("/citas/horas", params={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"]}, headers=pac_h).status_code == 404
    assert client.get("/citas", params={"estado": "PROGRAMADA"}, headers=pac_h).json()["items"][0]["id"] == cid
    assert client.delete(f"/agenda/{f['id']}", headers=pac_h).status_code == 403
    assert acciones_auditoria(f["id"]) == ["AGENDA_BLOQUE_CREADO", "AGENDA_BLOQUE_RETIRADO"]


def test_profesional_desactivado_no_ofrece_citas(client, medico, agenda, pac_h):
    sql_ = lambda v: SessionLocal().execute(text(f"UPDATE perfil_profesional SET activo = {v} WHERE persona_id = :m"), {"m": agenda["medico_id"]})
    with SessionLocal() as db:
        db.execute(text("UPDATE perfil_profesional SET activo = false WHERE persona_id = :m"), {"m": agenda["medico_id"]})
        db.commit()
    try:
        assert reservar(client, pac_h, agenda).status_code == 404
    finally:
        with SessionLocal() as db:
            db.execute(text("UPDATE perfil_profesional SET activo = true WHERE persona_id = :m"), {"m": agenda["medico_id"]})
            db.commit()
    assert reservar(client, pac_h, agenda).status_code == 201


# ------------------------------------------------------------------ Chatbot
def msg(client, h, t):
    r = client.post("/chatbot/mensaje", headers=h, json={"mensaje": t})
    assert r.status_code == 200, r.text
    return r.json()


def test_chatbot_consultivo(client, pac_h, pac):
    a = msg(client, pac_h, "¿Cómo puedo AGENDAR una cita?")
    assert a["intencion"] == "agendar" and "no agendo" in a["respuesta"].lower() and a["acciones"][0]["ruta"] == "/citas/especialidades"
    assert msg(client, pac_h, "quiero cambiar mi cita")["intencion"] == "reprogramar"
    assert msg(client, pac_h, "necesito cancelar la cita")["intencion"] == "cancelar"
    d = msg(client, pac_h, "Tengo fiebre y tos, ¿qué medicamento puedo tomar? ¿qué enfermedad es?")
    assert d["intencion"] == "diagnostico" and "no puedo diagnosticar" in d["respuesta"].lower() and d["acciones"][0]["ruta"] == "/citas/especialidades"
    e = msg(client, pac_h, "tengo dolor de pecho y no puedo respirar")
    assert e["intencion"] == "emergencia" and "911" in e["respuesta"] and e["acciones"] == []
    assert msg(client, pac_h, "quién vio mi expediente")["acciones"][0]["ruta"] == "/portal/accesos"
    assert msg(client, pac_h, "mis vacunas")["intencion"] == "expediente"
    assert msg(client, pac_h, "xyzzy")["intencion"] == "no_entendido"
    assert msg(client, pac_h, "Hola")["intencion"] == "saludo"
    # nunca agenda ni diagnostica: ninguna cita creada, ninguna acción es de escritura sobre citas
    assert sql("SELECT count(*) FROM cita WHERE paciente_id = :p", p=paciente_id(pac["dui"]))[0][0] == 0
    for texto in ("agéndame una cita mañana a las 8 con el doctor", "dame un diagnóstico", "reserva por mí"):
        r = msg(client, pac_h, texto)
        assert all(x["metodo"] == "GET" for x in r["acciones"]) and "diagnóstico" not in r["respuesta"].lower().replace("no puedo diagnosticar", "")
    assert sql("SELECT count(*) FROM cita WHERE paciente_id = :p", p=paciente_id(pac["dui"]))[0][0] == 0
    # validación y autenticación
    assert client.post("/chatbot/mensaje", headers=pac_h, json={"mensaje": ""}).status_code == 422
    assert client.post("/chatbot/mensaje", headers=pac_h, json={"mensaje": "x" * 501}).status_code == 422
    assert client.post("/chatbot/mensaje", json={"mensaje": "hola"}).status_code == 401
    # auditoría: intención sí, texto jamás
    filas = sql("SELECT detalle FROM auditoria WHERE accion='CHATBOT_CONSULTA' AND actor_id = :p", p=paciente_id(pac["dui"]))
    assert len(filas) >= 10 and all(set(f[0]) == {"intencion", "largo", "llm"} and f[0]["llm"] is False for f in filas)
    assert "fiebre" not in json.dumps([f[0] for f in filas])


def test_chatbot_llm_opcional_desconectado_y_conectable(client, pac_h, monkeypatch):
    from portal_civil import chatbot
    assert chatbot.proveedor_llm is None

    class Falso:
        def redactar(self, intencion, base, mensaje):
            return "[LLM] " + base

    monkeypatch.setattr(chatbot, "proveedor_llm", Falso())
    assert msg(client, pac_h, "cómo agendar una cita")["respuesta"].startswith("[LLM] ")
    # emergencias y diagnóstico nunca pasan por el LLM
    assert not msg(client, pac_h, "tengo una emergencia")["respuesta"].startswith("[LLM]")
    assert not msg(client, pac_h, "dame un diagnóstico")["respuesta"].startswith("[LLM]")
