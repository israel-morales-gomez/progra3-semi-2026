import json
import re
from datetime import date, timedelta

import pytest

from estadistica_epidemiologia import datos_ejemplo
from estadistica_epidemiologia.models import EpiEjemplo, EpiEjemploReceta
from omega_core.database import SessionLocal
from omega_core.seed import CODIGO_HOSPITAL, PASSWORD_HOSPITAL

from .conftest import datos_persona
from .test_etapa2 import auth, medico, sql  # noqa: F401
from .test_etapa2c import login
from .test_etapa6b import login_inst
from .test_etapa6c import PERMITIDAS as _P6C, salud  # noqa: F401

def _hoy():
    with SessionLocal() as db:
        return db.execute(__import__("sqlalchemy").text("SELECT current_date")).scalar_one()


HOY = _hoy()
EJ = {"origen": "EJEMPLO"}
RUTAS = ("/estadisticas/indicadores/incidencia", "/estadisticas/indicadores/prevalencia", "/estadisticas/indicadores/mortalidad", "/estadisticas/brotes",
         "/estadisticas/medicamentos/mas-prescritos", "/estadisticas/medicamentos/antibioticos", "/estadisticas/poblacion")
PERMITIDAS = _P6C | {"indicador", "desde", "hasta", "departamento", "poblacion", "tasa_por_100000", "municipio", "casos_ventana", "promedio_base", "razon", "base_insuficiente", "alerta",
                     "ventana_dias", "periodos_base", "factor", "periodo", "medicamento", "prescripciones", "unidades", "prescripciones_totales", "proporcion_antibioticos"}


def caso(n, tipo="DIAGNOSTICO", codigo="J06", dep="Morazán", mun="Perquín", dias=10, estatus="ACTIVA", **kw):
    return n, {"tipo": tipo, "fecha": HOY - timedelta(days=dias), "edad": 30, "sexo": "F", "departamento": dep, "municipio": mun, "codigo_cie10": codigo, "estatus": estatus, **kw}


def rx(n, med="Paracetamol 500 mg", dep="Morazán", dias=10, cant=10):
    return n, {"fecha": HOY - timedelta(days=dias), "departamento": dep, "municipio": "Perquín", "medicamento": med, "cantidad": cant}


def poner(*grupos):
    with SessionLocal() as db:
        datos_ejemplo.borrar(db)
        for n, f in grupos:
            db.add_all([(EpiEjemploReceta if "medicamento" in f else EpiEjemplo)(**f) for _ in range(n)])
        db.commit()


def poblacion(client, omega_headers, dep, anio, n):
    r = client.put("/estadisticas/poblacion", headers=omega_headers, json={"departamento": dep, "anio": anio, "poblacion": n})
    assert r.status_code == 200, r.text


@pytest.fixture(autouse=True)
def _limpio():
    yield
    with SessionLocal() as db:
        datos_ejemplo.borrar(db)
        db.execute(__import__("sqlalchemy").text("DELETE FROM poblacion_region WHERE departamento LIKE 'Dep-Prueba%'"))
        db.commit()


def get(client, h, ruta, **p):
    return client.get(ruta, headers=h, params=p)


def por(r, *claves):
    assert r.status_code == 200, r.text
    return {tuple(c.get(k) for k in claves): c for c in r.json()["celdas"]}


# ------------------------------------------------------------------ Mismas reglas de acceso y anonimización
def test_acceso_exclusivo_y_sin_identificadores(client, omega_headers, salud, medico, codigos_2fa):
    h_salud, d, pid = salud
    hospital = login_inst(client, CODIGO_HOSPITAL, PASSWORD_HOSPITAL, codigos_2fa)
    civil = datos_persona()
    client.post("/personas", json=civil)
    for ruta in RUTAS:
        assert client.get(ruta).status_code == 401, ruta
        for quien in (medico, login(client, civil), hospital):
            assert get(client, quien, ruta).status_code == 403, ruta
        assert get(client, h_salud, ruta).status_code == 200 and get(client, omega_headers, ruta).status_code == 200, ruta
    assert client.put("/estadisticas/poblacion", headers=h_salud, json={"departamento": "Dep-Prueba", "anio": 2026, "poblacion": 10}).status_code == 403
    assert client.put("/estadisticas/poblacion", headers=medico, json={"departamento": "Dep-Prueba", "anio": 2026, "poblacion": 10}).status_code == 403
    with SessionLocal() as db:
        datos_ejemplo.generar(db, semilla=5, cantidad=1500)
    for ruta in RUTAS[:6]:
        for h in (omega_headers, h_salud):
            r = get(client, h, ruta, **EJ)
            assert r.status_code == 200 and r.json()["celdas"], ruta
            cuerpo = json.dumps(r.json(), ensure_ascii=False)
            assert _claves(r.json()) <= PERMITIDAS, (ruta, _claves(r.json()) - PERMITIDAS)
            assert not re.search(r"\d{8}-\d", cuerpo) and d["dui"] not in cuerpo and pid not in cuerpo and not re.search(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-", cuerpo), ruta
            assert all(c.get("casos", c.get("casos_ventana", c.get("prescripciones"))) >= 5 for c in r.json()["celdas"]), ruta  # nada menor al umbral
    cols = {c[0] for c in sql("SELECT column_name FROM information_schema.columns WHERE table_name IN ('v_epi_evento', 'v_epi_receta', 'epi_ejemplo_receta')")}
    assert not ({"dui", "nombres", "apellidos", "persona_id", "paciente_id", "medico_id", "receta_id", "correo", "folio"} & cols)


def _claves(x, acc=None):
    acc = set() if acc is None else acc
    if isinstance(x, dict):
        for k, v in x.items():
            acc.add(k)
            _claves(v, acc)
    elif isinstance(x, list):
        for v in x:
            _claves(v, acc)
    return acc


# ------------------------------------------------------------------ Incidencia, prevalencia y mortalidad
def test_incidencia_prevalencia_y_mortalidad_con_tasas(client, omega_headers):
    poner(caso(8, dias=10), caso(6, dias=100), caso(5, dias=10, mun="Cacaopera", estatus="CURADA"), caso(7, dias=200, estatus="EN_REMISION"),
          caso(5, dep="La Libertad", mun="Santa Tecla", dias=10), caso(4, codigo="A09", dias=10),
          caso(6, "FALLECIDO", "I21", dias=20), caso(5, "FALLECIDO", "I21", dep="La Libertad", mun="Santa Tecla", dias=20))
    poblacion(client, omega_headers, "Morazán", HOY.year, 200_000)
    # incidencia: últimos 30 días → J06 en Morazán = 8 + 5 (CURADA también es un caso nuevo); la de hace 100 días queda fuera
    r = get(client, omega_headers, "/estadisticas/indicadores/incidencia", desde=str(HOY - timedelta(days=30)), hasta=str(HOY), **EJ)
    c = por(r, "causa", "departamento")
    assert c[("J06", "Morazán")]["casos"] == 13 and c[("J06", "Morazán")]["poblacion"] == 200_000 and c[("J06", "Morazán")]["tasa_por_100000"] == 6.5
    assert c[("J06", "La Libertad")]["casos"] == 5 and c[("J06", "La Libertad")]["tasa_por_100000"] is None  # sin población cargada: no se inventa
    assert ("A09", "Morazán") not in c and r.json()["celdas_suprimidas"] == 1 and ("I21", "Morazán") not in c  # 4 casos suprimidos; las muertes no son incidencia
    # periodo ampliado: entra lo de hace 100 días
    r = get(client, omega_headers, "/estadisticas/indicadores/incidencia", desde=str(HOY - timedelta(days=150)), causa="j06", departamento="morazán", **EJ)
    assert por(r, "causa", "departamento")[("J06", "Morazán")]["casos"] == 19
    # prevalencia: solo ACTIVA / EN_REMISION hasta el corte (8 + 6 + 7 = 21; los 5 CURADA no cuentan)
    r = get(client, omega_headers, "/estadisticas/indicadores/prevalencia", causa="J06", departamento="Morazán", **EJ)
    p = por(r, "causa", "departamento")[("J06", "Morazán")]
    assert p["casos"] == 21 and p["tasa_por_100000"] == 10.5 and r.json()["desde"] is None
    assert por(get(client, omega_headers, "/estadisticas/indicadores/prevalencia", hasta=str(HOY - timedelta(days=150)), causa="J06", **EJ), "causa")[("J06",)]["casos"] == 7
    # mortalidad
    r = get(client, omega_headers, "/estadisticas/indicadores/mortalidad", **EJ)
    c = por(r, "causa", "departamento")
    assert c[("I21", "Morazán")]["casos"] == 6 and c[("I21", "Morazán")]["tasa_por_100000"] == 3.0 and c[("I21", "La Libertad")]["casos"] == 5
    assert all(k[0] == "I21" for k in c)
    # la población usada es la del último año ≤ fin del periodo
    poblacion(client, omega_headers, "Morazán", HOY.year - 1, 100_000)
    poblacion(client, omega_headers, "Morazán", HOY.year + 1, 50_000)
    assert por(get(client, omega_headers, "/estadisticas/indicadores/mortalidad", **EJ), "causa", "departamento")[("I21", "Morazán")]["poblacion"] == 200_000
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'ESTADISTICA_POBLACION_GUARDADA' AND detalle->>'departamento' = 'Morazán'")[0][0] >= 3
    with SessionLocal() as db:
        db.execute(__import__("sqlalchemy").text("DELETE FROM poblacion_region WHERE departamento = 'Morazán'"))
        db.commit()


def test_parametros_de_periodo_invalidos(client, omega_headers):
    assert get(client, omega_headers, "/estadisticas/indicadores/incidencia", desde="2026-05-01", hasta="2026-01-01").status_code == 422
    assert get(client, omega_headers, "/estadisticas/indicadores/incidencia", desde="1990-01-01", hasta="2026-01-01").status_code == 422
    assert get(client, omega_headers, "/estadisticas/indicadores/incidencia", causa="J06.9").status_code == 422
    assert get(client, omega_headers, "/estadisticas/indicadores/incidencia", desde="no-es-fecha").status_code == 422
    assert get(client, omega_headers, "/estadisticas/brotes", factor=0.5).status_code == 422


# ------------------------------------------------------------------ Brotes
def test_deteccion_de_brotes_por_municipio(client, omega_headers):
    # Perquín: base de 8 semanas ≈ 1/semana (8 casos) y 9 en la última semana → alerta (9 ≥ 2 × 1). Cacaopera: 6 ahora y 6 por semana antes → sin alerta.
    base_perquin = [caso(1, dias=7 * k + 3) for k in range(1, 9)]
    base_cacaopera = [caso(6, mun="Cacaopera", dias=7 * k + 3) for k in range(1, 9)]
    poner(caso(9, dias=2), *base_perquin, caso(6, mun="Cacaopera", dias=2), *base_cacaopera, caso(4, mun="Arambala", dias=2), caso(5, codigo="A09", mun="Perquín", dias=2))
    r = get(client, omega_headers, "/estadisticas/brotes", **EJ)
    b = por(r, "causa", "municipio")
    assert b[("J06", "Perquín")]["alerta"] is True and b[("J06", "Perquín")]["casos_ventana"] == 9 and b[("J06", "Perquín")]["base_insuficiente"] is False
    assert b[("J06", "Perquín")]["promedio_base"] == 1.0 and b[("J06", "Perquín")]["razon"] == 9.0
    assert b[("J06", "Cacaopera")]["alerta"] is False and b[("J06", "Cacaopera")]["promedio_base"] == 6.0 and b[("J06", "Cacaopera")]["razon"] == 1.0
    # sin base previa suficiente: alerta si hay ≥ 5 casos, pero el promedio no se revela
    a09 = b[("A09", "Perquín")]
    assert a09["alerta"] is True and a09["base_insuficiente"] is True and a09["promedio_base"] is None and a09["razon"] is None
    assert ("J06", "Arambala") not in b and r.json()["celdas_suprimidas"] == 1  # 4 casos: suprimido
    assert [x["alerta"] for x in r.json()["celdas"]] == sorted((x["alerta"] for x in r.json()["celdas"]), reverse=True)  # primero las alertas
    # parámetros: factor más exigente, ventana, municipio y enfermedad
    assert por(get(client, omega_headers, "/estadisticas/brotes", factor=10, causa="J06", **EJ), "causa", "municipio")[("J06", "Perquín")]["alerta"] is False
    assert list(por(get(client, omega_headers, "/estadisticas/brotes", causa="A09", **EJ), "causa", "municipio")) == [("A09", "Perquín")]
    # un corte muy anterior: aún no había casos
    assert por(get(client, omega_headers, "/estadisticas/brotes", hasta=str(HOY - timedelta(days=400)), **EJ), "causa", "municipio") == {}
    # los fallecidos no son casos de brote
    poner(caso(9, "FALLECIDO", "J06", dias=2))
    assert por(get(client, omega_headers, "/estadisticas/brotes", **EJ), "causa", "municipio") == {}


# ------------------------------------------------------------------ Medicamentos
def test_medicamentos_mas_prescritos_por_periodo_y_region(client, omega_headers):
    mes_actual, mes_ant = HOY.strftime("%Y-%m"), (HOY - timedelta(days=45)).strftime("%Y-%m")
    poner(rx(9, "Paracetamol 500 mg", dias=1, cant=10), rx(6, "AMOXICILINA 500 mg", dias=1, cant=7), rx(5, "Paracetamol 500 mg", dep="La Libertad", dias=1), rx(5, "Paracetamol 500 mg", dias=45),
          rx(4, "Metformina", dias=1))
    r = get(client, omega_headers, "/estadisticas/medicamentos/mas-prescritos", **EJ, desde=str(HOY - timedelta(days=60)))
    c = por(r, "periodo", "departamento", "medicamento")
    assert c[(mes_actual, "Morazán", "paracetamol 500 mg")]["prescripciones"] == 9 and c[(mes_actual, "Morazán", "paracetamol 500 mg")]["unidades"] == 90
    assert c[(mes_actual, "Morazán", "amoxicilina 500 mg")]["unidades"] == 42  # nombre normalizado
    assert c[(mes_actual, "La Libertad", "paracetamol 500 mg")]["prescripciones"] == 5 and (mes_ant, "Morazán", "paracetamol 500 mg") in c or mes_ant == mes_actual
    assert not any(k[2] == "metformina" for k in c) and r.json()["celdas_suprimidas"] == 1  # 4 prescripciones: suprimido
    assert [x["prescripciones"] for x in r.json()["celdas"]] == sorted((x["prescripciones"] for x in r.json()["celdas"]), reverse=True)
    # región y agrupación anual
    r = get(client, omega_headers, "/estadisticas/medicamentos/mas-prescritos", periodo="anio", departamento="morazán", desde=str(HOY - timedelta(days=60)), **EJ)
    assert all(x["departamento"] == "Morazán" and re.fullmatch(r"\d{4}", x["periodo"]) for x in r.json()["celdas"])
    assert por(r, "periodo", "medicamento")[(str(HOY.year), "paracetamol 500 mg")]["prescripciones"] >= 9
    assert get(client, omega_headers, "/estadisticas/medicamentos/mas-prescritos", periodo="semana").status_code == 422


def test_consumo_de_antibioticos(client, omega_headers):
    mes = HOY.strftime("%Y-%m")
    poner(rx(6, "Amoxicilina 500 mg", dias=1, cant=20), rx(5, "Azitromicina 500 mg", dias=1, cant=3), rx(14, "Paracetamol 500 mg", dias=1),
          rx(3, "Ciprofloxacino 500 mg", dep="La Libertad", dias=1), rx(10, "Ibuprofeno", dep="La Libertad", dias=1))
    r = get(client, omega_headers, "/estadisticas/medicamentos/antibioticos", **EJ, desde=str(HOY - timedelta(days=20)))
    c = por(r, "periodo", "departamento")
    m = c[(mes, "Morazán")] if (mes, "Morazán") in c else None
    assert m and m["prescripciones"] == 11 and m["unidades"] == 135 and m["prescripciones_totales"] == 25 and m["proporcion_antibioticos"] == 0.44 and m["medicamento"] is None
    assert ("%s" % mes, "La Libertad") not in c and r.json()["celdas_suprimidas"] == 1  # solo 3 antibióticos: suprimido
    # el catálogo decide qué es antibiótico
    assert sql("SELECT count(*) FROM antibiotico_catalogo WHERE nombre IN ('amoxicilina', 'azitromicina', 'ciprofloxacino')") == [(3,)]
    assert por(get(client, omega_headers, "/estadisticas/medicamentos/antibioticos", periodo="anio", **EJ), "periodo", "departamento")[(str(HOY.year), "Morazán")]["prescripciones"] == 11


def test_recetas_reales_entran_sin_identificadores(client, omega_headers):
    """Recetas reales (módulo farmacia) cuentan como prescripciones; las anuladas no; ni folio ni DUI salen."""
    from .test_etapa3a import emitir, firmado, medico as _m  # noqa: F401
    from .test_etapa2 import NAC, abrir
    med_h = client.post("/auth/login/persona", json={"dui": __import__("omega_core.seed", fromlist=["x"]).DUI_MEDICO, "password": __import__("omega_core.seed", fromlist=["x"]).PASSWORD_MEDICO}).json()["tokens"]["access_token"]
    h = auth(med_h)
    client.post("/farmacia/firma/enrolar", json={"pin": "PinMedico#2026"}, headers=h)
    nombre, folios, duis = f"Claritromicina Z{re.sub('[^a-z0-9]', '', __import__('uuid').uuid4().hex[:8])}", [], []
    for _ in range(6):
        d = datos_persona(fecha_nacimiento=NAC)
        assert client.post("/personas", json=d).status_code == 201
        abrir(client, h, d["dui"])
        r = emitir(client, h, d["dui"], meds=[{"medicamento": nombre, "dosis": "500 mg", "frecuencia": "cada 12 horas", "duracion_dias": 7, "cantidad": 14}])
        assert r.status_code == 201, r.text
        folios.append(r.json()["folio"]); duis.append(d["dui"])

    def celda():
        r = get(client, omega_headers, "/estadisticas/medicamentos/mas-prescritos", limite=500)
        assert r.status_code == 200
        assert not any(f in r.text or x in r.text for f in folios for x in duis)
        return [c for c in r.json()["celdas"] if c["medicamento"] == nombre.lower()]
    assert celda()[0]["prescripciones"] == 6 and celda()[0]["unidades"] == 84 and celda()[0]["departamento"] == "SIN_DATO"
    assert get(client, omega_headers, "/estadisticas/medicamentos/antibioticos").json()["celdas"]  # el catálogo reconoce la claritromicina
    def anular(folio):
        with SessionLocal() as db:
            db.execute(__import__("sqlalchemy").text("UPDATE receta SET estado = 'ANULADA' WHERE folio = :f"), {"f": folio})
            db.commit()
    anular(folios[0])
    assert celda()[0]["prescripciones"] == 5  # la anulada no cuenta
    anular(folios[1])
    assert celda() == []  # quedan 4: la celda se suprime
