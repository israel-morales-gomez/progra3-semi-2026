"""Etapa 7 · 3b: directorio de clínicas y hospitales (sector y red de seguros), búsqueda de medicamentos en farmacias y chatbot «¿dónde hay X?»."""
import json
import secrets
import uuid
from datetime import date, timedelta
from decimal import Decimal

from .conftest import datos_persona, dui_nuevo, nit_nuevo
from .test_etapa2 import NAC, acciones_auditoria, sql  # noqa: F401
from .test_etapa2c import login
from .test_etapa3b import INV, hoy_mas, vencer
from .test_etapa4a import pac, pac_h  # noqa: F401
from .test_etapa6b import login_inst
from .test_etapa6e import hospital_nuevo

DIR, BUSCAR = "/directorio/instituciones", "/farmacias/buscar"
CLAVE = "FarmaClave123"


def med_unico() -> str:
    # Solo consonantes: el chatbot exige 3 letras seguidas para aceptar un medicamento, y así el nombre
    # nunca forma palabras que descarta (cita, centro, recet...). Un hex al azar fallaba cerca de la mitad de las veces.
    return "xq" + "".join(secrets.choice("bcdfghjklmnpqrstvwxz") for _ in range(10))


def hospital(client, oh, **cob):
    """Hospital activo con un doctor verificado. Devuelve (headers del doctor, nombre, id)."""
    h, nombre = hospital_nuevo(client, oh)
    iid = sql("SELECT id FROM institucion WHERE nombre_legal = :n", n=nombre)[0][0]
    if cob:
        assert cobertura(client, oh, iid, **cob).status_code == 200
    return h, nombre, str(iid)


def cobertura(client, oh, iid, **kw):
    return client.patch(f"/omega/instituciones/{iid}/cobertura", headers=oh, json={"motivo": "Clasificación de Omega"} | kw)


def farmacia_en(client, oh, dep="Usulután", mun="Santa Elena"):
    nit, nombre = nit_nuevo(), f"Farmacia 7H {uuid.uuid4().hex[:8]}"
    d = {"tipo": "FARMACIA", "nombre_legal": nombre, "nit": nit, "numero_registro": f"FARM-{uuid.uuid4().hex[:8]}", "departamento": dep, "municipio": mun,
         "direccion": f"Centro de {mun}", "telefono": "2600-0000", "correo": f"{uuid.uuid4().hex[:8]}@farmacia.sv", "responsable_nombre": "Lic. Prueba", "responsable_dui": dui_nuevo(),
         "responsable_junta": "JVQF-555", "documento_junta_ref": "up://junta.pdf", "documento_permiso_ref": "up://permiso.pdf", "password": CLAVE}
    r = client.post("/instituciones", json=d)
    assert r.status_code == 201, r.text
    fid = r.json()["id"]
    assert client.patch(f"/omega/instituciones/{fid}/estado", json={"estado": "ACTIVA", "motivo": "Documentos verificados"}, headers=oh).status_code == 200
    h = login_inst(client, nit, CLAVE, [])
    return h, nombre, fid


def poner_lote(client, h, med, cantidad=100, dias=365, **extra):
    r = client.post(f"{INV}/lotes", headers=h, json={"medicamento": med, "numero_lote": f"L-{uuid.uuid4().hex[:6]}", "fecha_vencimiento": hoy_mas(dias), "cantidad": cantidad} | extra)
    assert r.status_code == 201, r.text
    return r.json()


# ------------------------------------------------------------------ Directorio
def test_directorio_filtra_por_sector_y_red_de_seguros(client, omega_headers, pac_h):
    _, a, ia = hospital(client, omega_headers, sector="PUBLICO", red_seguros="PUBLICA")
    _, b, ib = hospital(client, omega_headers, sector="PRIVADO", red_seguros="POLIZA_PRIVADA")
    _, c, ic = hospital(client, omega_headers, sector="PRIVADO", red_seguros="AMBAS")
    _, s, _ = hospital(client, omega_headers)  # sin clasificar

    def ver(nombre, **f):
        r = client.get(DIR, params={"q": nombre} | f, headers=pac_h)
        assert r.status_code == 200, r.text
        return r.json()["items"]

    assert [i["institucion_id"] for i in ver(a, sector="PUBLICO")] == [ia] and ver(a, sector="PRIVADO") == []
    assert [i["institucion_id"] for i in ver(b, sector="PRIVADO")] == [ib] and ver(b, sector="PUBLICO") == []
    assert [i["institucion_id"] for i in ver(a, red_seguros="PUBLICA")] == [ia] and ver(a, red_seguros="POLIZA_PRIVADA") == []
    assert ver(b, red_seguros="PUBLICA") == [] and [i["institucion_id"] for i in ver(b, red_seguros="POLIZA_PRIVADA")] == [ib]
    # un centro de red AMBAS aparece en los dos filtros; combinar filtros los intersecta
    assert len(ver(c, red_seguros="PUBLICA")) == 1 and len(ver(c, red_seguros="POLIZA_PRIVADA")) == 1
    assert len(ver(c, sector="PRIVADO", red_seguros="PUBLICA")) == 1 and ver(c, sector="PUBLICO", red_seguros="PUBLICA") == []
    # sin clasificar: se lista sin filtros, no con filtros
    assert len(ver(s)) == 1 and ver(s)[0]["sector"] is None and ver(s, sector="PUBLICO") == [] and ver(s, red_seguros="PUBLICA") == []
    item = ver(a)[0]
    assert item["tipo"] == "HOSPITAL" and item["sector"] == "PUBLICO" and item["red_seguros"] == "PUBLICA" and item["departamento"] == "Usulután"
    # solo lo público: sin datos del responsable ni de acceso
    assert not ({"nit", "correo", "responsable_dui", "responsable_nombre", "password_hash", "requiere_2fa"} & set(item))
    # un centro suspendido deja de aparecer
    assert client.patch(f"/omega/instituciones/{ic}/estado", headers=omega_headers, json={"estado": "SUSPENDIDA", "motivo": "Prueba de suspensión"}).status_code == 200
    assert ver(c) == []
    # filtros inválidos
    assert client.get(DIR, params={"sector": "MIXTO"}, headers=pac_h).status_code == 422
    assert client.get(DIR, params={"red_seguros": "AMBAS"}, headers=pac_h).status_code == 422


def test_omega_gestiona_sector_y_red_con_permisos_y_auditoria(client, omega_headers, pac_h):
    _, _, iid = hospital(client, omega_headers)
    url = f"/omega/instituciones/{iid}/cobertura"
    cuerpo = {"sector": "PUBLICO", "motivo": "Hospital nacional"}
    assert client.patch(url, json=cuerpo).status_code == 401
    assert client.patch(url, headers=pac_h, json=cuerpo).status_code in (401, 403)  # un ciudadano no clasifica centros
    r = cobertura(client, omega_headers, iid, sector="PUBLICO")
    assert r.status_code == 200 and r.json()["sector"] == "PUBLICO" and r.json()["red_seguros"] is None
    r = cobertura(client, omega_headers, iid, red_seguros="AMBAS")
    assert r.json()["sector"] == "PUBLICO" and r.json()["red_seguros"] == "AMBAS"  # lo no enviado se conserva
    assert client.patch(url, headers=omega_headers, json={"motivo": "Sin cambios"}).status_code == 422
    assert cobertura(client, omega_headers, iid, sector="MIXTO").status_code == 422
    assert cobertura(client, omega_headers, str(uuid.uuid4()), sector="PUBLICO").status_code == 404
    assert acciones_auditoria(iid).count("INSTITUCION_COBERTURA") == 2
    _, _, fid = farmacia_en(client, omega_headers)
    assert cobertura(client, omega_headers, fid, sector="PRIVADO").status_code == 422  # solo hospitales y clínicas


def test_la_cascada_de_citas_usa_los_mismos_filtros(client, omega_headers, pac_h):
    f = date.today() + timedelta(days=4)
    ha, _, ia = hospital(client, omega_headers, sector="PUBLICO", red_seguros="PUBLICA")
    hb, _, ib = hospital(client, omega_headers, sector="PRIVADO", red_seguros="POLIZA_PRIVADA")
    bloques = []
    try:
        for h in (ha, hb):
            r = client.post("/agenda", headers=h, json={"dia_semana": f.weekday(), "hora_inicio": "08:00", "hora_fin": "10:00", "duracion_min": 30})
            assert r.status_code == 201, r.text
            bloques.append((h, r.json()["id"]))
        P = {"especialidad": "Medicina Interna"}

        def ids(**filtro):
            r = client.get("/citas/centros", params=P | filtro, headers=pac_h)
            assert r.status_code == 200, r.text
            return {c["institucion_id"]: c for c in r.json()}

        todos = ids()
        assert ia in todos and ib in todos and todos[ia]["sector"] == "PUBLICO" and todos[ib]["red_seguros"] == "POLIZA_PRIVADA"
        pub = ids(sector="PUBLICO")
        assert ia in pub and ib not in pub
        priv = ids(sector="PRIVADO", red_seguros="POLIZA_PRIVADA")
        assert ib in priv and ia not in priv
        assert ia in ids(red_seguros="PUBLICA") and ib not in ids(red_seguros="PUBLICA")
        # los pasos 1 y 3 respetan el mismo filtro
        sin = {e["especialidad"]: e["medicos"] for e in client.get("/citas/especialidades", headers=pac_h).json()}
        solo_pub = {e["especialidad"]: e["medicos"] for e in client.get("/citas/especialidades", params={"sector": "PUBLICO"}, headers=pac_h).json()}
        assert solo_pub["Medicina Interna"] < sin["Medicina Interna"]
        d = {"especialidad": "Medicina Interna", "institucion_id": ia}
        assert len(client.get("/citas/doctores", params=d, headers=pac_h).json()) == 1
        assert client.get("/citas/doctores", params=d | {"sector": "PRIVADO"}, headers=pac_h).json() == []
        assert client.get("/citas/centros", params=P | {"sector": "MIXTO"}, headers=pac_h).status_code == 422
    finally:  # no dejar agendas activas que alteren otras pruebas de la cascada
        for h, bid in bloques:
            client.delete(f"/agenda/{bid}", headers=h)


# ------------------------------------------------------------------ Farmacias
def test_busqueda_por_zona_disponibilidad_aproximada_y_comparacion_de_precios(client, omega_headers, pac_h):
    h1, n1, f1 = farmacia_en(client, omega_headers, "Usulután", "Santa Elena")
    h2, n2, f2 = farmacia_en(client, omega_headers, "Usulután", "Santa Elena")
    h3, n3, f3 = farmacia_en(client, omega_headers, "Santa Ana", "Metapán")
    med = med_unico()
    poner_lote(client, h1, med, cantidad=5, precio_unitario=1.50)
    poner_lote(client, h2, med, cantidad=80, precio_unitario=1.20)
    poner_lote(client, h3, med, cantidad=20)

    def buscar(**f):
        r = client.get(BUSCAR, params={"medicamento": med} | f, headers=pac_h)
        assert r.status_code == 200, r.text
        return r.json()

    zona = buscar(departamento="Usulután", municipio="Santa Elena")
    por = {x["farmacia_id"]: x for x in zona["resultados"]}
    assert set(por) == {f1, f2} and zona["total"] == 2
    assert por[f1]["disponibilidad"] == "BAJA" and por[f2]["disponibilidad"] == "ALTA"
    assert [x["farmacia_id"] for x in zona["resultados"]] == [f2, f1]  # más disponible primero
    assert Decimal(por[f1]["precio_unitario"]) == Decimal("1.50") and Decimal(por[f2]["precio_unitario"]) == Decimal("1.20")
    # solo farmacias y disponibilidad aproximada: nunca la cantidad exacta ni datos de pacientes
    assert set(por[f1]) == {"farmacia_id", "farmacia", "departamento", "municipio", "direccion", "telefono", "horario", "atiende_domicilio", "medicamento", "disponibilidad", "precio_unitario"}
    assert "aproximada" in zona["aviso"] and "no sustituye" in zona["aviso"]
    comp = zona["comparacion_precios"]
    assert len(comp) == 1 and comp[0]["mas_barata_id"] == f2 and Decimal(comp[0]["precio_minimo"]) == Decimal("1.20") and Decimal(comp[0]["precio_maximo"]) == Decimal("1.50")
    # sin tildes ni mayúsculas, y sin filtro de zona entra la tercera farmacia
    assert {x["farmacia_id"] for x in buscar(departamento="usulutan", municipio="SANTA ELENA")["resultados"]} == {f1, f2}
    assert {x["farmacia_id"] for x in buscar(departamento="Santa Ana")["resultados"]} == {f3}
    assert {x["farmacia_id"] for x in buscar()["resultados"]} == {f1, f2, f3}
    assert [x["farmacia_id"] for x in buscar(orden="precio")["resultados"]] == [f2, f1, f3]  # sin precio al final


def test_sin_precios_no_hay_comparacion_y_el_precio_es_opcional(client, omega_headers, pac_h):
    h1, _, f1 = farmacia_en(client, omega_headers)
    h2, _, f2 = farmacia_en(client, omega_headers)
    sin_precio, un_precio = med_unico(), med_unico()
    poner_lote(client, h1, sin_precio, 30)
    poner_lote(client, h2, sin_precio, 30)
    poner_lote(client, h1, un_precio, 30, precio_unitario=2.00)
    poner_lote(client, h2, un_precio, 30)
    a = client.get(BUSCAR, params={"medicamento": sin_precio}, headers=pac_h).json()
    assert a["total"] == 2 and a["comparacion_precios"] == [] and all(x["precio_unitario"] is None for x in a["resultados"])
    b = client.get(BUSCAR, params={"medicamento": un_precio}, headers=pac_h).json()
    assert b["total"] == 2 and b["comparacion_precios"] == []  # con una sola farmacia con precio no hay con qué comparar
    for malo in (0, -1, 1_000_000):  # el precio, si se informa, debe ser razonable
        r = client.post(f"{INV}/lotes", headers=h1, json={"medicamento": med_unico(), "numero_lote": "L-1", "fecha_vencimiento": hoy_mas(30), "cantidad": 5, "precio_unitario": malo})
        assert r.status_code == 422


def test_la_busqueda_ignora_lotes_vencidos_agotados_y_farmacias_inactivas(client, omega_headers, pac_h):
    h, _, fid = farmacia_en(client, omega_headers)
    viejo, agotado = med_unico(), med_unico()
    vencer(poner_lote(client, h, viejo)["id"])
    lote = poner_lote(client, h, agotado, cantidad=3)
    assert client.post(f"{INV}/lotes/{lote['id']}/ajustes", headers=h, json={"tipo": "MERMA", "cantidad": 3, "motivo": "Se terminó el stock"}).status_code == 200
    for m in (viejo, agotado):
        assert client.get(BUSCAR, params={"medicamento": m}, headers=pac_h).json()["total"] == 0
    vivo = med_unico()
    poner_lote(client, h, vivo)
    assert client.get(BUSCAR, params={"medicamento": vivo}, headers=pac_h).json()["total"] == 1
    assert client.patch(f"/omega/instituciones/{fid}/estado", headers=omega_headers, json={"estado": "SUSPENDIDA", "motivo": "Prueba de suspensión"}).status_code == 200
    assert client.get(BUSCAR, params={"medicamento": vivo}, headers=pac_h).json()["total"] == 0


def test_permisos_del_directorio_y_de_la_busqueda(client, omega_headers, pac_h):
    fh, _, _ = farmacia_en(client, omega_headers)
    for url, params in ((DIR, {}), (BUSCAR, {"medicamento": "amoxicilina"})):
        assert client.get(url, params=params).status_code == 401
        assert client.get(url, params=params, headers=fh).status_code in (401, 403)  # una farmacia no usa el portal del ciudadano
        assert client.get(url, params=params, headers=omega_headers).status_code in (401, 403)
    assert client.get(BUSCAR, params={"medicamento": "ab"}, headers=pac_h).status_code == 422
    assert client.get(BUSCAR, headers=pac_h).status_code == 422
    # `%` y `_` se buscan como texto, no como comodines
    assert client.get(BUSCAR, params={"medicamento": "%%%"}, headers=pac_h).json()["total"] == 0
    assert client.get(BUSCAR, params={"medicamento": "ααα"}, headers=pac_h).status_code == 422  # normaliza a vacío: no devuelve todo el inventario


# ------------------------------------------------------------------ Chatbot
def test_chatbot_responde_donde_hay_x_con_la_busqueda_y_sigue_sin_agendar(client, omega_headers, pac, pac_h):
    assert client.patch("/portal/perfil", headers=pac_h, json={"departamento": "Usulután", "municipio": "Santa Elena"}).status_code == 200
    h, nombre, fid = farmacia_en(client, omega_headers, "Usulután", "Santa Elena")
    med = med_unico()
    poner_lote(client, h, med, cantidad=40, precio_unitario=3.25)
    r = client.post("/chatbot/mensaje", headers=pac_h, json={"mensaje": f"¿Dónde hay {med}?"})
    assert r.status_code == 200, r.text
    b = r.json()
    assert b["intencion"] == "disponibilidad" and nombre in b["respuesta"] and "media" in b["respuesta"] and "$3.25" in b["respuesta"]
    assert "aproximada" in b["respuesta"] and "no sustituye" in b["respuesta"] and "no agendo" in b["respuesta"].lower()
    rutas = [a["ruta"] for a in b["acciones"]]
    assert any(x.startswith("/farmacias/buscar?") and med in x for x in rutas) and "/citas/especialidades" in rutas  # sigue redirigiendo a citas
    assert client.get("/citas", headers=pac_h).json()["total"] == 0  # no agendó nada
    # sin resultados
    nada = client.post("/chatbot/mensaje", headers=pac_h, json={"mensaje": f"donde puedo comprar {med_unico()}"}).json()
    assert nada["intencion"] == "disponibilidad" and "No encontré" in nada["respuesta"]
    # lo clínico sigue yendo a diagnóstico, la emergencia a emergencia, y agendar sigue redirigiendo
    assert client.post("/chatbot/mensaje", headers=pac_h, json={"mensaje": f"dónde hay {med}, qué dosis tomo"}).json()["intencion"] == "diagnostico"
    assert client.post("/chatbot/mensaje", headers=pac_h, json={"mensaje": f"tengo dolor de pecho, donde hay {med}"}).json()["intencion"] == "emergencia"
    ag = client.post("/chatbot/mensaje", headers=pac_h, json={"mensaje": "quiero agendar una cita"}).json()
    assert ag["intencion"] == "agendar" and "no agendo" in ag["respuesta"].lower() and client.get("/citas", headers=pac_h).json()["total"] == 0
    # una pregunta por un centro no es una búsqueda de medicamentos
    assert client.post("/chatbot/mensaje", headers=pac_h, json={"mensaje": "dónde hay una clínica cerca"}).json()["intencion"] == "horarios"
    # la bitácora guarda la intención y los resultados, nunca el texto ni el medicamento
    pid = str(sql("SELECT id FROM persona WHERE dui = :d", d=pac["dui"])[0][0])
    filas = sql("SELECT detalle::text FROM auditoria WHERE accion = 'CHATBOT_CONSULTA' AND actor_id = :a", a=pid)
    assert filas and all(med not in f[0] for f in filas) and any('"disponibilidad"' in f[0] and '"resultados"' in f[0] for f in filas)


def test_chatbot_sin_sesion_sigue_protegido(client):
    assert client.post("/chatbot/mensaje", json={"mensaje": "dónde hay amoxicilina"}).status_code == 401
