import threading
import uuid
from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text

from main import app
from omega_core.database import SessionLocal

from .conftest import datos_persona, dui_nuevo, nit_nuevo
from .test_etapa2 import abrir, acciones_auditoria, auth, medico, sql  # noqa: F401
from .test_etapa3a import PARA, canje, emitir, firmado, paciente  # noqa: F401

INV = "/farmacia/inventario"


def hoy_mas(dias: int) -> str:
    return str(date.today() + timedelta(days=dias))


def registrar_farmacia(client, omega_headers) -> tuple[dict, str]:
    nit, clave = nit_nuevo(), "FarmaClave123"
    d = {"tipo": "FARMACIA", "nombre_legal": "Farmacia de Prueba", "nit": nit, "numero_registro": f"FARM-{uuid.uuid4().hex[:8]}", "direccion": "Santa Ana",
         "telefono": "2400-0000", "correo": f"{uuid.uuid4().hex[:8]}@farmacia.sv", "responsable_nombre": "Lic. Prueba", "responsable_dui": dui_nuevo(),
         "responsable_junta": "JVQF-555", "documento_junta_ref": "up://junta.pdf", "documento_permiso_ref": "up://permiso.pdf", "password": clave}
    r = client.post("/instituciones", json=d)
    assert r.status_code == 201, r.text
    assert client.patch(f"/omega/instituciones/{r.json()['id']}/estado", json={"estado": "ACTIVA", "motivo": "Documentos verificados"}, headers=omega_headers).status_code == 200
    r = client.post("/auth/login/institucion", json={"identificador": nit, "password": clave})
    assert r.status_code == 200, r.text
    return auth(r.json()["tokens"]["access_token"]), r.json().get("institucion_id") or nit


@pytest.fixture
def farm(client, omega_headers):
    return registrar_farmacia(client, omega_headers)[0]


def lote(client, h, med="paracetamol", dias=365, cantidad=100, numero=None):
    r = client.post(f"{INV}/lotes", headers=h, json={"medicamento": med, "numero_lote": numero or f"L-{uuid.uuid4().hex[:6]}",
                                                      "fecha_vencimiento": hoy_mas(dias), "cantidad": cantidad})
    assert r.status_code == 201, r.text
    return r.json()


def vencer(lote_id: str, dias_atras: int = 2):
    """Envejece un lote saltando los triggers (solo superusuario; solo en pruebas)."""
    with SessionLocal() as db:
        db.execute(text("SET LOCAL session_replication_role = replica"))
        db.execute(text("UPDATE lote SET fecha_vencimiento = current_date - :d WHERE id = :i"), {"d": dias_atras, "i": lote_id})
        db.commit()


def receta(client, firmado, cantidad: int, med=PARA):
    d = datos_persona()
    client.post("/personas", json=d)
    abrir(client, firmado, d["dui"])
    r = emitir(client, firmado, d["dui"], meds=[med | {"cantidad": cantidad}])
    assert r.status_code == 201, r.text
    return r.json()


def stock(lote_id: str) -> int:
    return sql("SELECT cantidad_actual FROM lote WHERE id = :i", i=lote_id)[0][0]


def test_registro_ajustes_y_libro_de_movimientos(client, farm):
    assert client.post(f"{INV}/lotes", headers=farm, json={"medicamento": "x", "numero_lote": "L", "fecha_vencimiento": hoy_mas(5), "cantidad": 1}).status_code == 422
    assert client.post(f"{INV}/lotes", headers=farm, json={"medicamento": "Ibuprofeno", "numero_lote": "L1", "fecha_vencimiento": hoy_mas(-1), "cantidad": 5}).status_code == 422
    assert client.post(f"{INV}/lotes", headers=farm, json={"medicamento": "Ibuprofeno", "numero_lote": "L1", "fecha_vencimiento": hoy_mas(30), "cantidad": 0}).status_code == 422
    l = lote(client, farm, med="Ibuprofeno 400", numero="L1", dias=40, cantidad=50)
    assert l["medicamento"] == "ibuprofeno 400" and l["cantidad_actual"] == 50 and l["estado"] == "VIGENTE"
    assert client.post(f"{INV}/lotes", headers=farm, json={"medicamento": "IBUPROFENO 400", "numero_lote": "L1", "fecha_vencimiento": hoy_mas(30), "cantidad": 5}).status_code == 409
    aj = lambda **kw: client.post(f"{INV}/lotes/{l['id']}/ajustes", headers=farm, json=kw)  # noqa: E731
    assert aj(tipo="MERMA", cantidad=60, motivo="Caja dañada por humedad").status_code == 409  # dejaría negativo
    assert aj(tipo="MERMA", cantidad=5, motivo="x").status_code == 422  # motivo obligatorio
    assert aj(tipo="MERMA", cantidad=0, motivo="Sin unidades").status_code == 422
    assert aj(tipo="MERMA", cantidad=10, motivo="Caja dañada por humedad").json()["cantidad_actual"] == 40
    assert aj(tipo="ENTRADA", cantidad=25, motivo="Reposición proveedor").json()["cantidad_actual"] == 65
    assert aj(tipo="CORRECCION", cantidad=60, motivo="Conteo físico mensual").json()["cantidad_actual"] == 60
    assert aj(tipo="CORRECCION", cantidad=60, motivo="Conteo físico mensual").status_code == 422
    mov = client.get(f"{INV}/lotes/{l['id']}/movimientos", headers=farm).json()
    assert [(m["tipo"], m["delta"], m["saldo"]) for m in mov] == [("ENTRADA", 50, 50), ("MERMA", -10, 40), ("ENTRADA", 25, 65), ("CORRECCION", -5, 60)]
    ac = acciones_auditoria(l["id"])
    assert ac.count("INVENTARIO_AJUSTE") == 3 and "INVENTARIO_LOTE_REGISTRADO" in ac
    det = sql("SELECT detalle FROM auditoria WHERE recurso_id = :r AND accion = 'INVENTARIO_AJUSTE' ORDER BY id LIMIT 1", r=l["id"])[0][0]
    assert det["antes"] == 50 and det["despues"] == 40 and det["motivo"] == "Caja dañada por humedad"
    # el libro y los lotes no se alteran desde SQL
    for q in ("UPDATE movimiento_inventario SET delta = 999 WHERE lote_id = :i", "DELETE FROM movimiento_inventario WHERE lote_id = :i",
              "DELETE FROM lote WHERE id = :i", "UPDATE lote SET fecha_vencimiento = fecha_vencimiento + 400 WHERE id = :i"):
        with pytest.raises(Exception, match="inmutable|no se eliminan|solo cantidad_actual"):
            with SessionLocal() as db:
                db.execute(text(q), {"i": l["id"]})
                db.commit()
    with pytest.raises(Exception, match="stock_no_negativo"):
        with SessionLocal() as db:
            db.execute(text("UPDATE lote SET cantidad_actual = -1 WHERE id = :i"), {"i": l["id"]})
            db.commit()


def test_despacho_descuenta_fefo(client, farm, firmado):
    l10 = lote(client, farm, dias=10, cantidad=5, numero="V10")
    l5 = lote(client, farm, dias=5, cantidad=5, numero="V5")
    l60 = lote(client, farm, dias=60, cantidad=20, numero="V60")
    rx = receta(client, firmado, 8)
    v = client.post("/farmacia/recetas/consulta", headers=farm, json=canje(rx)).json()
    assert v["apto_para_despacho"] is True and v["stock_faltante"] == []
    d = client.post("/farmacia/recetas/despachar", headers=farm, json=canje(rx))
    assert d.status_code == 201, d.text
    assert [(x["numero_lote"], x["cantidad"]) for x in d.json()["lotes_descontados"]] == [("V5", 5), ("V10", 3)]  # el que vence primero sale primero
    assert (stock(l5["id"]), stock(l10["id"]), stock(l60["id"])) == (0, 2, 20)
    mov = sql("SELECT tipo, delta, saldo, despacho_id IS NOT NULL FROM movimiento_inventario WHERE lote_id = :i ORDER BY creado_en", i=l5["id"])
    assert mov == [("ENTRADA", 5, 5, False), ("DESPACHO", -5, 0, True)]
    desc = sql("SELECT detalle FROM auditoria WHERE accion = 'INVENTARIO_DESCUENTO_DESPACHO' AND detalle->>'folio' = :f", f=rx["folio"])
    assert desc and [x["numero_lote"] for x in desc[0][0]["lotes"]] == ["V5", "V10"]
    # un segundo canje no vuelve a descontar
    assert client.post("/farmacia/recetas/despachar", headers=farm, json=canje(rx)).status_code == 409
    assert (stock(l5["id"]), stock(l10["id"]), stock(l60["id"])) == (0, 2, 20)


def test_no_despacha_lotes_vencidos_ni_stock_insuficiente(client, farm, firmado):
    # solo hay un lote vencido
    viejo = lote(client, farm, dias=30, cantidad=50, numero="VIEJO")
    vencer(viejo["id"])
    assert client.get(f"{INV}/lotes/{viejo['id']}", headers=farm).json()["estado"] == "VENCIDO"
    rx = receta(client, firmado, 5)
    v = client.post("/farmacia/recetas/consulta", headers=farm, json=canje(rx)).json()
    assert v["apto_para_despacho"] is False and {"STOCK_INSUFICIENTE", "LOTE_VENCIDO"} <= set(v["motivos_bloqueo"])
    r = client.post("/farmacia/recetas/despachar", headers=farm, json=canje(rx))
    assert r.status_code == 409 and r.json()["detail"]["stock_faltante"][0]["disponible"] == 0 and r.json()["detail"]["stock_faltante"][0]["vencido_no_utilizable"] == 50
    assert stock(viejo["id"]) == 50 and sql("SELECT estado FROM receta WHERE folio = :f", f=rx["folio"]) == [("EMITIDA",)]
    # stock vigente insuficiente (3 < 5): no se despacha parcialmente
    corto = lote(client, farm, dias=90, cantidad=3, numero="CORTO")
    r = client.post("/farmacia/recetas/despachar", headers=farm, json=canje(rx))
    assert r.status_code == 409 and "STOCK_INSUFICIENTE" in r.json()["detail"]["motivos"]
    assert r.json()["detail"]["stock_faltante"][0]["requerido"] == 5 and r.json()["detail"]["stock_faltante"][0]["disponible"] == 3
    assert stock(corto["id"]) == 3
    assert "STOCK_INSUFICIENTE" in sql("SELECT detalle FROM auditoria WHERE accion = 'RECETA_DESPACHO_BLOQUEADO' AND detalle->>'folio' = :f ORDER BY id DESC LIMIT 1",
                                      f=rx["folio"])[0][0]["motivos"]
    # con reposición vigente, se despacha y NUNCA toca el lote vencido
    ok = lote(client, farm, dias=120, cantidad=10, numero="NUEVO")
    d = client.post("/farmacia/recetas/despachar", headers=farm, json=canje(rx))
    assert d.status_code == 201, d.text
    assert [(x["numero_lote"], x["cantidad"]) for x in d.json()["lotes_descontados"]] == [("CORTO", 3), ("NUEVO", 2)]
    assert stock(viejo["id"]) == 50
    # defensa en la base de datos: ni siquiera con SQL directo se descuenta un lote vencido
    vencer(ok["id"])
    despacho_id = sql("SELECT id FROM despacho d WHERE receta_id = (SELECT id FROM receta WHERE folio = :f)", f=rx["folio"])[0][0]
    with pytest.raises(Exception, match="lote vencido"):
        with SessionLocal() as db:
            db.execute(text("INSERT INTO movimiento_inventario (id, farmacia_id, lote_id, tipo, delta, saldo, despacho_id, creado_en) "
                            "SELECT gen_random_uuid(), farmacia_id, id, 'DESPACHO', -1, 7, :d, now() FROM lote WHERE id = :i"), {"d": despacho_id, "i": ok["id"]})
            db.commit()


def test_alertas_de_stock_bajo_y_vencimiento(client, farm):
    lote(client, farm, med="Paracetamol", dias=10, cantidad=6, numero="P-10")
    lote(client, farm, med="Paracetamol", dias=60, cantidad=2, numero="P-60")
    lote(client, farm, med="Loratadina", dias=200, cantidad=500)
    viejo = lote(client, farm, med="Paracetamol", dias=20, cantidad=40, numero="P-VIEJO")
    vencer(viejo["id"])
    assert client.put(f"{INV}/umbrales/paracetamol", headers=farm, json={"umbral": -1}).status_code == 422
    u = client.put(f"{INV}/umbrales/Paracetamol", headers=farm, json={"umbral": 10})
    assert u.status_code == 200 and u.json()["stock_vigente"] == 8 and u.json()["stock_vencido"] == 40 and u.json()["stock_bajo"] is True  # el vencido no cuenta
    assert client.put(f"{INV}/umbrales/amoxicilina", headers=farm, json={"umbral": 0}).json()["stock_bajo"] is True  # sin lotes: agotado
    a = client.get(f"{INV}/alertas", params={"dias": 30}, headers=farm).json()
    assert sorted(e["medicamento"] for e in a["stock_bajo"]) == ["amoxicilina", "paracetamol"]  # loratadina sin umbral: sin alerta
    assert [l["numero_lote"] for l in a["lotes_por_vencer"]] == ["P-10"]  # el de 60 días aún no
    assert [l["numero_lote"] for l in a["lotes_vencidos_con_stock"]] == ["P-VIEJO"]
    a60 = client.get(f"{INV}/alertas", params={"dias": 90}, headers=farm).json()
    assert [l["numero_lote"] for l in a60["lotes_por_vencer"]] == ["P-10", "P-60"]
    # umbral configurable: sube el stock por encima y la alerta desaparece
    p10 = client.get(f"{INV}/lotes", params={"medicamento": "paracetamol", "estado": "POR_VENCER"}, headers=farm).json()[0]
    client.post(f"{INV}/lotes/{p10['id']}/ajustes", headers=farm, json={"tipo": "ENTRADA", "cantidad": 20, "motivo": "Reposición proveedor"})
    ex = {e["medicamento"]: e for e in client.get(f"{INV}/existencias", headers=farm).json()}
    assert ex["paracetamol"]["stock_vigente"] == 28 and ex["paracetamol"]["stock_bajo"] is False and ex["paracetamol"]["umbral"] == 10
    assert ex["loratadina"]["umbral"] is None and ex["loratadina"]["stock_bajo"] is False
    assert [e["medicamento"] for e in client.get(f"{INV}/alertas", headers=farm).json()["stock_bajo"]] == ["amoxicilina"]
    d = sql("SELECT detalle FROM auditoria WHERE accion = 'INVENTARIO_UMBRAL_CONFIGURADO' AND recurso_id = 'paracetamol' ORDER BY id DESC LIMIT 1")[0][0]
    assert d["despues"] == 10


def test_una_farmacia_solo_ve_y_modifica_su_inventario(client, farm, omega_headers, firmado):
    otra, _ = registrar_farmacia(client, omega_headers)
    mio = lote(client, farm, med="Metformina", numero="COMUN", cantidad=30)
    ajeno = lote(client, otra, med="Metformina", numero="COMUN", cantidad=7)  # mismo número de lote en otra farmacia: permitido
    assert [l["id"] for l in client.get(f"{INV}/lotes", headers=farm).json()] == [mio["id"]]
    assert [l["id"] for l in client.get(f"{INV}/lotes", headers=otra).json()] == [ajeno["id"]]
    for r in (client.get(f"{INV}/lotes/{ajeno['id']}", headers=farm), client.get(f"{INV}/lotes/{ajeno['id']}/movimientos", headers=farm),
              client.post(f"{INV}/lotes/{ajeno['id']}/ajustes", headers=farm, json={"tipo": "MERMA", "cantidad": 1, "motivo": "intento ajeno"}),
              client.get(f"{INV}/lotes/{uuid.uuid4()}", headers=farm)):
        assert r.status_code == 404 and r.json() == {"detail": "Lote no encontrado en su inventario"}  # igual que si no existiera
    assert stock(ajeno["id"]) == 7
    # umbrales y existencias son por farmacia
    client.put(f"{INV}/umbrales/metformina", headers=farm, json={"umbral": 50})
    assert client.get(f"{INV}/existencias", headers=otra).json()[0]["umbral"] is None
    assert client.get(f"{INV}/alertas", headers=otra).json()["stock_bajo"] == []
    assert len(client.get(f"{INV}/alertas", headers=farm).json()["stock_bajo"]) == 1
    # el despacho de una farmacia no consume el stock de otra
    rx = receta(client, firmado, 5, med=PARA | {"medicamento": "Metformina"})
    r = client.post("/farmacia/recetas/despachar", headers=otra, json=canje(rx))
    assert r.status_code == 201 and r.json()["lotes_descontados"][0]["cantidad"] == 5 and stock(ajeno["id"]) == 2 and stock(mio["id"]) == 30
    # roles ajenos: un médico no accede al inventario; sin token tampoco
    assert client.get(f"{INV}/lotes", headers=firmado).status_code in (401, 403)
    assert client.get(f"{INV}/lotes").status_code == 401


def test_despachos_simultaneos_nunca_dejan_stock_negativo(client, farm, firmado):
    l = lote(client, farm, med="Paracetamol", cantidad=20, numero="CARRERA")
    recetas = [receta(client, firmado, 8) for _ in range(5)]  # piden 40 en total; hay 20
    barrera, codigos = threading.Barrier(5), []

    def intento(rx):
        with TestClient(app, client=("127.0.0.1", 50002)) as c:
            barrera.wait()
            codigos.append(c.post("/farmacia/recetas/despachar", json=canje(rx), headers=farm).status_code)

    hilos = [threading.Thread(target=intento, args=(rx,)) for rx in recetas]
    [h.start() for h in hilos]
    [h.join() for h in hilos]
    assert sorted(codigos) == [201, 201, 409, 409, 409], codigos  # 2 × 8 = 16 ≤ 20; el tercero (24) no cabe
    assert stock(l["id"]) == 4
    assert sql("SELECT sum(delta), count(*) FILTER (WHERE tipo = 'DESPACHO') FROM movimiento_inventario WHERE lote_id = :i", i=l["id"]) == [(4, 2)]
