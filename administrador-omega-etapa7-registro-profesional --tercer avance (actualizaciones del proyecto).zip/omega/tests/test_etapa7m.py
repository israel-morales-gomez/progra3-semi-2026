"""Etapa 7 · portal profesional: registro de los 65 ámbitos del documento y plantillas por rol (no requiere base de datos)."""
from collections import Counter
from types import SimpleNamespace as NS

import pytest
from pydantic import ValidationError

from omega_core.roles_profesionales import ALIAS_ESPECIALIDAD, ENFERMERIA, LAYOUTS, POR_CLAVE, ROLES
from omega_core.schemas import PerfilProfesionalIn
from web.profesional.roles import LAYOUTS as PLANTILLAS
from web.profesional.roles import plantilla_de


def _persona(tipo="DOCTOR", esp=None, rol=None, activo=True):
    return NS(profesional=NS(activo=activo, tipo=tipo, especialidad=esp, rol_clave=rol))


def test_registro_cumple_el_documento():
    assert [r.n for r in ROLES] == list(range(1, 66))  # 57 originales + 8 agregados (v1.1)
    assert [r.n for r in ROLES if r.agregado] == list(range(58, 66))
    assert set(LAYOUTS) == set(PLANTILLAS)  # cada layout de la matriz tiene su plantilla
    assert Counter(r.layout for r in ROLES) == {"clinico_general": 30, "quirurgico": 15, "apoyo_gerencial": 7, "apoyo_lis": 5, "urgencias": 4, "apoyo_enfermeria": 4}
    assert {r.n for r in ROLES if r.layout_alt} == {39, 60}  # los dos híbridos
    assert all(r.fases and all(1 <= f <= 5 for f in r.fases) and r.widget and r.envia and r.recibe for r in ROLES)
    assert all(v in POR_CLAVE for v in ALIAS_ESPECIALIDAD.values())


def test_plantilla_por_rol_y_permisos():
    assert plantilla_de(_persona(rol="medico_de_urgencias")).layout.clave == "urgencias"
    cirujano = plantilla_de(_persona(rol="cirujano_general"))
    assert cirujano.permite("abrir") and cirujano.permite("cerrar") and cirujano.foco == (2, 3)
    enfermero = plantilla_de(_persona("ENFERMERA", rol="enfermero_general"))
    assert enfermero.permite("avanzar") and not enfermero.permite("cerrar") and not enfermero.permite("asumir")
    for clave in ("radiologo_pacs", "analista_de_laboratorio", "administrador_hospitalario", "epidemiologo"):
        assert not plantilla_de(_persona(rol=clave)).acciones  # apoyo LIS y gerencial: consulta
    assert plantilla_de(_persona(rol="gineco_obstetra")).permite("abrir")  # híbrido: suma acciones de ambos layouts
    assert plantilla_de(_persona(rol="psiquiatra")).area_fija == "Psiquiatría"  # salud mental: nivel 4 siempre cifrado


def test_rol_inferido_y_respaldo():
    p = plantilla_de(_persona(esp="Cardiología"))
    assert p.rol.clave == "cardiologo" and p.inferido
    assert plantilla_de(_persona(esp="Especialidad rara")).rol.clave == "medico_internista"
    assert plantilla_de(_persona("ENFERMERA")).rol.clave == "enfermero_general"
    assert plantilla_de(_persona(activo=False)) is None
    assert plantilla_de(NS(profesional=None)) is None  # solo estudiante


@pytest.mark.parametrize("tipo,rol,valido", [("DOCTOR", "cardiologo", True), ("ENFERMERA", "enfermero_de_uci", True), ("DOCTOR", "enfermero_general", False),
                                            ("ENFERMERA", "cardiologo", False), ("DOCTOR", "no_existe", False), ("DOCTOR", None, True)])
def test_esquema_valida_rol_clave(tipo, rol, valido):
    datos = dict(tipo=tipo, numero_junta="123", rol_clave=rol)
    if valido:
        assert PerfilProfesionalIn(**datos).rol_clave == rol
    else:
        with pytest.raises(ValidationError):
            PerfilProfesionalIn(**datos)


def test_enfermeria_son_los_cuatro_roles_del_documento():
    assert ENFERMERIA == {r.clave for r in ROLES if r.n in (46, 59, 60, 61)}
