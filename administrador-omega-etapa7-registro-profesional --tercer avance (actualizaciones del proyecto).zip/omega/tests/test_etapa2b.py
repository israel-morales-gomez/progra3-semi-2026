import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from omega_core.database import SessionLocal

from .conftest import datos_persona
from .test_etapa2 import abrir, medico, nota, sql  # noqa: F401  (fixture `medico` reutilizada)

EGRESO = {"tipo_egreso": "ALTA_MEDICA", "condicion_egreso": "Estable", "resumen_egreso": "Paciente evoluciona favorablemente.",
          "plan_seguimiento": "Control en 7 días"}


@pytest.fixture
def pac(client):
    d = datos_persona()
    assert client.post("/personas", json=d).status_code == 201
    return d["dui"]


def acciones(at):
    return [r[0] for r in sql("SELECT accion FROM auditoria WHERE recurso_id = :r ORDER BY id", r=at)]


def trans(client, h, at, a, **kw):
    return client.post(f"/atenciones/{at}/transicion", headers=h, json={"a_fase": a, **kw})


def test_no_se_salta_de_fase_y_cada_transicion_se_audita(client, medico, pac):
    at = abrir(client, medico, pac, fase3=False)
    for destino in (3, 4, 5):
        assert trans(client, medico, at, destino).status_code in (409, 422), destino
    # prerrequisitos de la fase 1 -> 2
    r = trans(client, medico, at, 2)
    assert r.status_code == 409 and "Admisión incompleta" in r.json()["detail"]
    assert trans(client, medico, at, 2, identidad_verificada=True, antecedentes_revisados=True).json()["fase"] == 2
    # fase 2 -> 3 exige triaje y médico responsable
    r = trans(client, medico, at, 3)
    assert r.status_code == 409 and "triaje" in r.json()["detail"]
    assert client.post(f"/atenciones/{at}/triaje", headers=medico, json={"nivel": "AMARILLO", "discriminador": "Dolor moderado"}).status_code == 200
    assert trans(client, medico, at, 3).json()["fase"] == 3
    assert trans(client, medico, at, 5).status_code == 409  # 3 -> 5 no existe
    assert trans(client, medico, at, 4).json()["fase"] == 4
    assert trans(client, medico, at, 3).json()["fase"] == 3  # 4 -> 3 permitido (reingreso a ejecución)
    assert trans(client, medico, at, 4).json()["fase"] == 4
    # cierre: exige egreso, nota SOAP y diagnóstico principal
    assert trans(client, medico, at, 5).status_code == 422
    assert trans(client, medico, at, 5, egreso=EGRESO).status_code == 409  # faltan nota y diagnóstico
    assert trans(client, medico, at, 3).json()["fase"] == 3
    assert client.post(f"/atenciones/{at}/notas", headers=medico, json=nota()).status_code == 201
    assert client.post(f"/atenciones/{at}/diagnosticos", headers=medico,
                       json={"codigo_cie10": "J06.9", "descripcion": "IVRA", "tipo": "DEFINITIVO", "principal": True}).status_code == 201
    assert trans(client, medico, at, 4).status_code == 200
    r = trans(client, medico, at, 5, egreso=EGRESO)
    assert r.status_code == 200, r.text
    assert r.json()["fase"] == 5 and r.json()["estado"] == "CERRADA"
    # cerrada: no admite más
    assert trans(client, medico, at, 4).status_code == 409
    assert client.post(f"/atenciones/{at}/notas", headers=medico, json=nota()).status_code == 409
    # bitácora: una entrada por transición + apertura + cierre; historial en el detalle
    ac = acciones(at)
    assert ac.count("TRANSICION_FASE") == 8 and "ATENCION_ABIERTA" in ac and "ATENCION_CERRADA" in ac
    det = client.get(f"/atenciones/{at}", headers=medico).json()
    assert [(t["de_fase"], t["a_fase"]) for t in det["transiciones"]][:3] == [(None, 1), (1, 2), (2, 3)]
    # egreso con plan de seguimiento guardado
    assert sql("SELECT plan_seguimiento FROM egreso WHERE atencion_id = :a", a=at) == [("Control en 7 días",)]


def test_transaccionalidad_y_trigger_de_fases_en_postgres(client, medico, pac):
    at = abrir(client, medico, pac, fase3=False)
    # el trigger rechaza saltos aunque se omita la API
    with pytest.raises(DBAPIError, match="transicion de fase invalida"):
        with SessionLocal() as db:
            db.execute(text("UPDATE atencion SET fase = 4 WHERE id = :i"), {"i": at})
            db.commit()
    with pytest.raises(DBAPIError):  # 1 -> 3 sin Código Rojo
        with SessionLocal() as db:
            db.execute(text("UPDATE atencion SET fase = 3 WHERE id = :i"), {"i": at})
            db.commit()
    # una transición fallida no deja rastro parcial (ni fase cambiada ni transición registrada)
    assert trans(client, medico, at, 2).status_code == 409
    assert sql("SELECT fase FROM atencion WHERE id = :i", i=at) == [(1,)]
    assert sql("SELECT count(*) FROM atencion_transicion WHERE atencion_id = :i", i=at) == [(1,)]  # solo la apertura
    # una sola atención abierta por paciente e institución
    r = client.post("/atenciones", headers=medico, json={"dui": pac, "tipo_atencion": "AMBULATORIA", "area": "Medicina General", "motivo_consulta": "otra"})
    assert r.status_code == 409


def test_triaje_niveles_y_reevaluacion(client, medico, pac):
    at = abrir(client, medico, pac, fase3=False)
    assert client.post(f"/atenciones/{at}/triaje", headers=medico, json={"nivel": "VERDE", "discriminador": "x" * 5}).status_code == 409  # fase 1
    trans(client, medico, at, 2, identidad_verificada=True, antecedentes_revisados=True)
    assert client.post(f"/atenciones/{at}/triaje", headers=medico, json={"nivel": "URGENTE", "discriminador": "algo"}).status_code == 422
    for nivel in ("AZUL", "VERDE", "AMARILLO", "NARANJA"):
        r = client.post(f"/atenciones/{at}/triaje", headers=medico, json={"nivel": nivel, "discriminador": "Valoración clínica"})
        assert r.status_code == 200 and r.json()["nivel_triaje"] == nivel and r.json()["codigo_rojo"] is False
    assert sql("SELECT count(*) FROM triaje WHERE atencion_id = :i", i=at) == [(4,)]  # historial de reevaluaciones
    assert acciones(at).count("TRIAJE_REGISTRADO") == 4


def test_codigo_rojo_al_ingreso_bypass_con_motivo_auditado(client, medico, pac):
    base = {"dui": pac, "tipo_atencion": "URGENCIAS", "area": "Emergencias", "motivo_consulta": "Paro cardiorrespiratorio"}
    assert client.post("/atenciones", headers=medico, json=base | {"codigo_rojo": True}).status_code == 422  # sin motivo
    assert client.post("/atenciones", headers=medico, json=base | {"codigo_rojo": True, "motivo_codigo_rojo": "corto"}).status_code == 422
    assert client.post("/atenciones", headers=medico, json=base | {"motivo_codigo_rojo": "motivo sin rojo activo"}).status_code == 422
    motivo = "Paro cardiorrespiratorio en sala de espera"
    r = client.post("/atenciones", headers=medico, json=base | {"codigo_rojo": True, "motivo_codigo_rojo": motivo})
    assert r.status_code == 201, r.text
    a = r.json()
    assert a["fase"] == 3 and a["codigo_rojo"] is True and a["nivel_triaje"] == "ROJO"  # sin identidad, antecedentes ni triaje previos
    det = sql("SELECT detalle FROM auditoria WHERE recurso_id = :r AND accion = 'CODIGO_ROJO_ACTIVADO'", r=a["id"])
    assert det and det[0][0]["motivo"] == motivo
    assert sql("SELECT count(*) FROM revision_bypass WHERE atencion_id = :a", a=a["id"]) == [(1,)]  # queda pendiente de revisión
    # se puede registrar clínica de inmediato y cerrar el flujo normal desde 3
    assert client.post(f"/atenciones/{a['id']}/signos-vitales", headers=medico, json={"fc": 0, "spo2": 40}).status_code in (201, 422)
    assert trans(client, medico, a["id"], 4).status_code == 200


def test_triaje_rojo_exige_motivo_y_activa_codigo_rojo(client, medico, pac):
    at = abrir(client, medico, pac, fase3=False)
    trans(client, medico, at, 2, identidad_verificada=True, antecedentes_revisados=True)
    ficha = {"nivel": "ROJO", "discriminador": "Inconsciente"}
    assert client.post(f"/atenciones/{at}/triaje", headers=medico, json=ficha).status_code == 422  # motivo obligatorio
    motivo = "Paciente inconsciente, via aerea comprometida"
    r = client.post(f"/atenciones/{at}/triaje", headers=medico, json=ficha | {"motivo": motivo})
    assert r.status_code == 200, r.text
    assert r.json()["codigo_rojo"] is True and r.json()["nivel_triaje"] == "ROJO"
    d = sql("SELECT detalle FROM auditoria WHERE recurso_id = :r AND accion = 'CODIGO_ROJO_ACTIVADO'", r=at)
    assert d and d[0][0]["motivo"] == motivo and d[0][0]["origen"] == "triaje"
    assert sql("SELECT count(*) FROM revision_bypass WHERE atencion_id = :a", a=at) == [(1,)]
    assert trans(client, medico, at, 3).json()["fase"] == 3
