import random
import uuid

import pyotp
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import update

from main import app
from omega_core.database import SessionLocal
from omega_core.models import Persona
from omega_core.security import twofa
from omega_core.security.ratelimit import limitador
from omega_core.seed import DUI_OMEGA, PASSWORD_OMEGA, TOTP_OMEGA, sembrar
from omega_core.validadores import digito_dui


@pytest.fixture(scope="session")
def client():
    sembrar()
    with TestClient(app, client=("127.0.0.1", 50000)) as c:
        yield c


@pytest.fixture(autouse=True)
def _reset_limitador():
    limitador.reset()


@pytest.fixture
def codigos_2fa(monkeypatch):
    enviados = []
    monkeypatch.setattr(twofa, "enviar_codigo", lambda destino, codigo, sujeto: enviados.append(codigo))
    return enviados


def dui_nuevo() -> str:
    ocho = f"{random.randint(10_000_000, 99_999_999)}"
    return f"{ocho}-{digito_dui(ocho)}"


def nit_nuevo() -> str:
    n = f"{random.randint(0, 10**14 - 1):014d}"
    return f"{n[:4]}-{n[4:10]}-{n[10:13]}-{n[13]}"


def datos_persona(**extra) -> dict:
    d = {
        "dui": dui_nuevo(), "nombres": "Ana", "apellidos": "Prueba", "correo": f"{uuid.uuid4().hex[:10]}@example.sv",
        "telefono": "7123-4567", "password": "ClaveSegura1",
    }
    d.update(extra)
    return d


def login_omega(client) -> str:
    with SessionLocal() as db:  # evita el anti-replay entre pruebas consecutivas dentro de la misma ventana de 30 s
        db.execute(update(Persona).where(Persona.dui == DUI_OMEGA).values(totp_ultimo_paso=None))
        db.commit()
    r = client.post("/omega/login", json={"dui": DUI_OMEGA, "password": PASSWORD_OMEGA, "totp": pyotp.TOTP(TOTP_OMEGA).now()})
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


@pytest.fixture
def omega_headers(client):
    return {"Authorization": f"Bearer {login_omega(client)}"}
