"""Etapa 7 · instrumentos de los widgets del portal profesional (calculadoras y escalas sin estado)."""
import html
import re
from datetime import date

import pytest
from sqlalchemy import text

from omega_core.database import SessionLocal
from omega_core.roles_profesionales import POR_CLAVE
from omega_core.seed import DUI_MEDICO
from web.comun.portales import PROFESIONAL
from web.profesional import instrumentos as ins

from .test_etapa2 import sql  # noqa: F401
from .test_etapa7a import entrar_persona, token_de, web  # noqa: F401  (web es un fixture)


def calc(clave, **crudos):
    i = ins.POR_CLAVE[clave]
    return i.calcular(ins.validar(i, {k: str(v) for k, v in crudos.items()}))


def lineas(r):
    return dict(r.lineas)


# ------------------------------------------------------------------ Registro
def test_cada_rol_apunta_a_roles_e_instrumentos_existentes():
    assert set(ins.ROLES) <= set(POR_CLAVE)
    assert all(c in ins.POR_CLAVE for claves in ins.ROLES.values() for c in claves)
    assert {c for claves in ins.ROLES.values() for c in claves} == set(ins.POR_CLAVE)  # ningún instrumento queda huérfano
    for i in ins.INSTRUMENTOS:  # cada campo de opción trae opciones y cada numérico sus límites
        assert i.campos and len({c.nombre for c in i.campos}) == len(i.campos)
        for c in i.campos:
            assert (c.tipo != "opcion" or c.opciones) and (c.tipo not in ("numero", "entero") or (c.minimo is not None and c.maximo is not None))


# ------------------------------------------------------------------ Cálculos con valores conocidos
def test_glasgow():
    r = calc("glasgow", ocular=4, verbal=5, motora=6)
    assert "15/15" in r.titulo and r.nivel == "ok"
    r = calc("glasgow", ocular=1, verbal=1, motora=1)
    assert "3/15" in r.titulo and r.nivel == "alerta"
    assert "Moderado" in calc("glasgow", ocular=3, verbal=3, motora=4).titulo  # 10


def test_phq9_y_alerta_del_item_9():
    todos = {f"p{i}": 1 for i in range(1, 10)}
    r = calc("phq9", **todos)
    assert "9/27" in r.titulo and "Leve" in r.titulo and r.nivel == "alerta"  # el ítem 9 positivo eleva la alerta aunque la gravedad sea leve
    r = calc("phq9", **(todos | {"p9": 0, "p1": 0}))
    assert "7/27" in r.titulo and r.nivel == "info"
    assert calc("phq9", **{k: 3 for k in todos}).titulo.startswith("PHQ-9: 27/27")
    r = calc("phq9", **(todos | {"p1": 0, "p2": 0, "p3": 0, "p4": 0, "p5": 0, "p6": 0, "p7": 0, "p8": 0}))  # solo el ítem 9
    assert r.nivel == "alerta" and "ÍTEM 9 POSITIVO" in r.notas[0]


def test_child_pugh():
    r = calc("child_pugh", bilirrubina=2.5, albumina=3.0, inr=1.5, ascitis=2, encefalopatia=1)
    assert "clase B (8" in r.titulo
    assert "clase A (5" in calc("child_pugh", bilirrubina=1.0, albumina=4.0, inr=1.1, ascitis=1, encefalopatia=1).titulo
    assert "clase C (15" in calc("child_pugh", bilirrubina=5, albumina=2.0, inr=3, ascitis=3, encefalopatia=3).titulo
    # límites inclusivos de los rangos intermedios
    r = calc("child_pugh", bilirrubina=3, albumina=3.5, inr=2.3, ascitis=1, encefalopatia=1)
    assert [lineas(r)[k] for k in ("Bilirrubina", "Albúmina", "INR")] == ["2 pt"] * 3


def test_das28():
    r = calc("das28", dolorosas=4, inflamadas=2, vsg=30, **{"global": 50})
    assert "4.60" in r.titulo and "moderada" in r.titulo
    assert "Remisión" in calc("das28", dolorosas=0, inflamadas=0, vsg=5, **{"global": 10}).titulo
    assert "alta" in calc("das28", dolorosas=20, inflamadas=15, vsg=80, **{"global": 90}).titulo


def test_regla_de_los_nueve_y_parkland():
    r = calc("nueve", cabeza=100, tronco_a=100, peso=70)
    assert "27.0 %" in r.titulo and r.nivel == "alerta"
    assert lineas(r)["Parkland (24 h)"].startswith("7,560 mL") and "3,780 mL (473 mL/h)" in lineas(r)["Primeras 8 h desde la quemadura"].replace("472", "473")
    r = calc("nueve", msd=50)  # sin peso no hay Parkland
    assert "4.5 %" in r.titulo and "Parkland (24 h)" not in lineas(r) and r.nivel == "info"
    assert "0.0 %" in calc("nueve").titulo


def test_superficie_corporal():
    r = calc("bsa", peso=70, talla=175)
    assert lineas(r)["Mosteller"] == "1.84 m²" and lineas(r)["DuBois"] == "1.85 m²"


def test_calculadora_gestacional():
    r = calc("gestacional", fum="2026-01-01", referencia="2026-04-01")
    assert "12 semanas + 6 días" in r.titulo and "Primer trimestre" in r.titulo
    assert lineas(r)["Fecha probable de parto (Naegele)"].startswith("2026-10-08")
    assert "28 semanas + 0 días" in calc("gestacional", fum="2026-01-01", referencia="2026-07-16").titulo and "Tercer" in calc("gestacional", fum="2026-01-01", referencia="2026-07-16").titulo
    with pytest.raises(ValueError, match="anterior a la FUM"):
        calc("gestacional", fum="2026-04-01", referencia="2026-01-01")
    with pytest.raises(ValueError, match="43 semanas"):
        calc("gestacional", fum="2025-01-01", referencia="2026-01-01")
    assert "semanas" in calc("gestacional", fum=date.today().isoformat()).titulo  # sin fecha de referencia usa hoy


def test_harris_benedict_e_imc():
    r = calc("harris", sexo="M", edad=30, peso=70, talla=175, actividad="1.2")
    assert "2,035 kcal" in r.titulo and lineas(r)["Tasa metabólica basal"] == "1,696 kcal/día" and "22.9" in lineas(r)["IMC"] and "Normopeso" in lineas(r)["IMC"]
    mujer = calc("harris", sexo="F", edad=30, peso=60, talla=165, actividad="1.55")
    assert lineas(mujer)["Tasa metabólica basal"] == "1,384 kcal/día"  # 447.593 + 554.82 + 511.17 - 129.9


def test_funcion_renal():
    r = calc("renal", sexo="M", edad=60, peso=80, creatinina=1.0)
    assert lineas(r)["Cockcroft-Gault"] == "88.9 mL/min" and abs(float(lineas(r)["CKD-EPI 2021"].split()[0]) - 86.2) < 0.3 and "G2" in r.titulo
    mujer = calc("renal", sexo="F", edad=60, peso=80, creatinina=1.0)
    assert lineas(mujer)["Cockcroft-Gault"] == "75.6 mL/min"
    assert "G5" in calc("renal", sexo="M", edad=70, peso=60, creatinina=8).titulo and calc("renal", sexo="M", edad=70, peso=60, creatinina=8).nivel == "alerta"


def test_hba1c():
    r = calc("hba1c", hba1c=7)
    assert "154 mg/dL" in r.titulo and "Rango diabético" in lineas(r)["Categoría ADA"] and r.nivel == "alerta"
    assert "prediabetes" in lineas(calc("hba1c", hba1c=6.0))["Categoría ADA"]


def test_morse_eva_rass_y_fim():
    base = dict(caidas=0, secundario=0, ayuda=0, iv=0, marcha=0, mental=0)
    assert "Morse 0" in calc("morse", **base).titulo and calc("morse", **base).nivel == "ok"
    assert "Morse 25 · Riesgo moderado" in calc("morse", **(base | {"caidas": 25})).titulo
    r = calc("morse", caidas=25, secundario=15, ayuda=30, iv=20, marcha=20, mental=15)
    assert "Morse 125" in r.titulo and r.nivel == "alerta"
    assert "moderado" in calc("eva", eva=5).titulo and calc("eva", eva=0).nivel == "ok" and calc("eva", eva=9).nivel == "alerta"
    assert calc("rass", rass=-3).titulo.startswith("RASS -3 · Sedación moderada") and calc("rass", rass=0).titulo.startswith("RASS 0 ") and calc("rass", rass=4).nivel == "alerta"
    assert calc("rass", rass=1).titulo.startswith("RASS +1")
    campos_fim = {c.nombre: 7 for c in ins.FIM.campos}
    assert len(campos_fim) == 18 and "126/126" in calc("fim", **campos_fim).titulo
    assert "18/126" in calc("fim", **{k: 1 for k in campos_fim}).titulo
    assert lineas(calc("fim", **campos_fim))["Motora (13 ítems)"] == "91/91"


# ------------------------------------------------------------------ Validación en el servidor
@pytest.mark.parametrize("clave,crudos,mensaje", [
    ("glasgow", {"ocular": "4", "verbal": "5"}, "Respuesta motora: es obligatorio"),
    ("glasgow", {"ocular": "9", "verbal": "5", "motora": "6"}, "opción no válida"),
    ("bsa", {"peso": "abc", "talla": "170"}, "debe ser un número"),
    ("bsa", {"peso": "nan", "talla": "170"}, "debe ser un número"),
    ("bsa", {"peso": "inf", "talla": "170"}, "debe ser un número"),
    ("bsa", {"peso": "0", "talla": "170"}, "debe estar entre"),
    ("bsa", {"peso": "70", "talla": "1700"}, "debe estar entre"),
    ("das28", {"dolorosas": "3.5", "inflamadas": "1", "vsg": "20", "global": "50"}, "número entero"),
    ("das28", {"dolorosas": "29", "inflamadas": "1", "vsg": "20", "global": "50"}, "entre 0 y 28"),
    ("gestacional", {"fum": "31-02-2026"}, "fecha no válida"),
    ("eva", {"eva": "11"}, "entre 0 y 10"),
])
def test_validacion_de_servidor(clave, crudos, mensaje):
    i = ins.POR_CLAVE[clave]
    with pytest.raises(ValueError, match=mensaje):
        i.calcular(ins.validar(i, crudos))


def test_coma_decimal_y_espacios():
    assert calc("hba1c", hba1c=" 7,0 ").titulo.startswith("Glucosa media estimada 154")


# ------------------------------------------------------------------ Web
P = "/profesional"


def _rol(valor):
    with SessionLocal() as db:
        db.execute(text("UPDATE perfil_profesional SET rol_clave = :r WHERE persona_id = (SELECT id FROM persona WHERE dui = :d)"), {"r": valor, "d": DUI_MEDICO})
        db.commit()


def _enviar(web, clave, campos):
    pagina = web.get(f"{P}/panel")
    assert pagina.status_code == 200, pagina.text
    return web.post(f"{P}/instrumentos/{clave}", data={"csrf_token": token_de(pagina.text)} | campos, headers={"HX-Request": "true"})


def test_el_widget_muestra_y_calcula_los_instrumentos_de_su_rol(web):  # noqa: F811
    try:
        _rol("neurologo")
        assert entrar_persona(web, PROFESIONAL).status_code == 303
        panel = web.get(f"{P}/panel")
        assert "Escala de coma de Glasgow" in panel.text and f'hx-post="{P}/instrumentos/glasgow"' in panel.text and "no se guardan en el expediente" in panel.text
        assert "PHQ-9" not in panel.text  # solo los de su rol
        r = _enviar(web, "glasgow", {"ocular": "3", "verbal": "4", "motora": "5"})
        assert r.status_code == 200 and "Glasgow 12/15" in r.text and "E3 V4 M5" in r.text
        r = _enviar(web, "glasgow", {"ocular": "3"})
        assert r.status_code == 422 and "Respuesta verbal: es obligatorio" in r.text
    finally:
        _rol(None)


def test_un_instrumento_ajeno_al_rol_se_rechaza_y_se_audita(web):  # noqa: F811
    try:
        _rol("neurologo")
        assert entrar_persona(web, PROFESIONAL).status_code == 303
        antes = sql("SELECT count(*) FROM auditoria WHERE accion = 'WEB_AREA_DENEGADA'")[0][0]
        assert _enviar(web, "phq9", {}).status_code == 403
        assert _enviar(web, "no_existe", {}).status_code == 403
        assert sql("SELECT count(*) FROM auditoria WHERE accion = 'WEB_AREA_DENEGADA'")[0][0] == antes + 2
    finally:
        _rol(None)


def test_sin_csrf_o_sin_sesion_no_calcula(web):  # noqa: F811
    assert web.post(f"{P}/instrumentos/glasgow", data={"ocular": "4"}).status_code in (303, 401, 403)
    try:
        _rol("neurologo")
        assert entrar_persona(web, PROFESIONAL).status_code == 303
        assert web.post(f"{P}/instrumentos/glasgow", data={"ocular": "4", "verbal": "5", "motora": "6"}).status_code == 403
    finally:
        _rol(None)


def test_rol_sin_instrumento_conserva_la_tarjeta_informativa(web):  # noqa: F811
    try:
        _rol("cardiologo")  # EKG y Score de Riesgo: aún sin instrumento
        assert entrar_persona(web, PROFESIONAL).status_code == 303
        panel = web.get(f"{P}/panel")
        assert "EKG y Score de Riesgo" in panel.text and "se conecta en una parte posterior" in panel.text and "Instrumentos de este widget" not in panel.text
    finally:
        _rol(None)


def test_el_resultado_se_escapa_y_el_formulario_trae_todos_los_campos(web):  # noqa: F811
    try:
        _rol("fisiatra")
        assert entrar_persona(web, PROFESIONAL).status_code == 303
        panel = web.get(f"{P}/panel")
        assert len(re.findall(r'<select id="i-fim-', panel.text)) == 18 and "Locomoción" in panel.text
        _rol("gineco_obstetra")
        r = _enviar(web, "gestacional", {"fum": "<script>"})
        assert r.status_code == 422 and "<script>" not in r.text
    finally:
        _rol(None)
