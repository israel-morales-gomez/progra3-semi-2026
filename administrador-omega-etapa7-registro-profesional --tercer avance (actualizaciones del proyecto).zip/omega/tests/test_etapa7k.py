"""Etapa 7 · integración web del expediente civil · parte 3: estado vital y datos civiles en el panel de /ciudadano."""
import uuid
from datetime import datetime, timezone

from core_expediente import service as servicio_vital
from core_expediente.schemas import EstadoVitalOut
from omega_core.database import SessionLocal
from web.ciudadano.servicios import tarjeta_vital
from web.comun.portales import CIUDADANO

from omega_core.validadores import normalizar_telefono

from .conftest import datos_persona
from .test_etapa2 import NAC, ml, paciente_id, sql  # noqa: F401
from .test_etapa4a import pac, pac_h  # noqa: F401
from .test_etapa7a import entrar_persona, nuevo, web  # noqa: F401

PANEL = "/ciudadano/panel"


def _entrar(web, persona):
    assert entrar_persona(web, CIUDADANO, persona["dui"], persona["password"]).status_code == 303
    return web


def test_panel_muestra_estado_activo_y_datos_civiles_con_sin_informacion(web, pac):
    _entrar(web, pac)
    r = web.get(PANEL)
    assert r.status_code == 200 and "Estado vital" in r.text and "Activo" in r.text and "Cuenta congelada" not in r.text
    assert "Mis datos" in r.text and pac["dui"] in r.text and pac["correo"] in r.text and normalizar_telefono(pac["telefono"]) in r.text
    assert "NIT" in r.text and "Tipo de sangre" in r.text and "Contacto de emergencia" in r.text
    assert r.text.count("Sin información") >= 3  # NIT, sangre, dirección y contacto: aún vacíos
    assert 'href="/ciudadano/perfil"' in r.text


def test_panel_muestra_lo_que_el_ciudadano_ya_guardo(web, pac, pac_h, client):
    unico = f"Contacto {uuid.uuid4().hex[:6]}"
    assert client.patch("/portal/perfil", headers=pac_h, json={"tipo_sangre": "O+", "contacto_emergencia_nombre": unico, "contacto_emergencia_telefono": "7000-1111",
                                                              "direccion": "Colonia Los Pinos, casa 4"}).status_code == 200
    _entrar(web, pac)
    r = web.get(PANEL)
    assert "O+" in r.text and unico in r.text and normalizar_telefono("7000-1111") in r.text and "Colonia Los Pinos, casa 4" in r.text


def test_la_lectura_del_estado_vital_queda_en_la_bitacora_sin_datos_de_salud(web, pac):
    _entrar(web, pac)
    assert web.get(PANEL).status_code == 200
    filas = sql("SELECT detalle::text FROM auditoria WHERE accion = 'PORTAL_LECTURA_PROPIA' AND recurso_id = :p AND detalle->>'seccion' = 'estado_vital'", p=paciente_id(pac["dui"]))
    assert len(filas) >= 1 and all("causa" not in f[0].lower() for f in filas)


def test_un_ciudadano_no_ve_los_datos_de_otro(web, client, pac, pac_h):
    unico = f"Contacto {uuid.uuid4().hex[:6]}"
    assert client.patch("/portal/perfil", headers=pac_h, json={"contacto_emergencia_nombre": unico, "contacto_emergencia_telefono": "7000-2222"}).status_code == 200
    otro = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=otro).status_code == 201
    r = _entrar(nuevo(50302), otro).get(PANEL)
    assert unico not in r.text and pac["dui"] not in r.text and otro["dui"] in r.text
    assert nuevo(50303).get(PANEL).status_code == 303  # sin sesión


# ------------------------------------------------------------------ fallecido: tarjeta y reglas de nivel 4 (sin depender de que la sesión web sobreviva a la baja)
def _fallecido():
    return EstadoVitalOut(estado="FALLECIDO", congelado=True, fallecido_en=datetime(2026, 10, 1, 9, 30, tzinfo=timezone.utc),
                          causa_oficial="Infarto agudo de miocardio", causa_cie10="I21.9", entidad_certificadora="Instituto de Medicina Legal")


def test_tarjeta_de_fallecido_oculta_la_causa_sin_desbloqueo():
    assert tarjeta_vital(EstadoVitalOut(estado="VIVO", congelado=False), False) == {"vivo": True}
    oculta = tarjeta_vital(_fallecido(), causa_visible=False)
    assert oculta["vivo"] is False and oculta["causa"] is None and oculta["cie10"] is None and oculta["causa_visible"] is False
    assert oculta["entidad"] == "Instituto de Medicina Legal" and oculta["fallecido_en"].hour == 3  # hora de El Salvador (UTC-6)
    visible = tarjeta_vital(_fallecido(), causa_visible=True)
    assert visible["causa"] == "Infarto agudo de miocardio" and visible["cie10"] == "I21.9"


def test_medicina_legal_congela_y_el_servicio_alimenta_la_tarjeta(client):
    d = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=d).status_code == 201
    r, _ = ml(client, d["dui"])
    assert r.status_code == 200, r.text
    with SessionLocal() as db:
        estado = servicio_vital.estado_vital(db, paciente_id(d["dui"]))
    assert estado.estado == "FALLECIDO" and estado.congelado
    t = tarjeta_vital(estado, causa_visible=False)
    assert t["vivo"] is False and t["causa"] is None and t["entidad"] == "Instituto de Medicina Legal"
