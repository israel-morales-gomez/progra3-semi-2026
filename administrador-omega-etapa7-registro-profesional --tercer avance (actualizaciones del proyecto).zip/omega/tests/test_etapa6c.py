import json
import re
import subprocess
import sys
from datetime import date

import pytest
from sqlalchemy import text

from estadistica_epidemiologia import datos_ejemplo
from estadistica_epidemiologia.models import EpiEjemplo
from omega_core.database import SessionLocal
from omega_core.seed import CODIGO_HOSPITAL, NIT_FARMACIA, PASSWORD_FARMACIA, PASSWORD_HOSPITAL

from .conftest import datos_persona
from .test_etapa2 import auth, medico, sql  # noqa: F401
from .test_etapa2c import alta_completa, login
from .test_etapa6b import login_inst

RUTAS = ("/estadisticas/fallecidos", "/estadisticas/enfermedades-comunes", "/estadisticas/enfermedades-graves", "/estadisticas/municipios")
PERMITIDAS = {"consulta", "origen", "umbral_supresion", "celdas", "celdas_suprimidas", "nota", "causa", "rango_edad", "sexo", "zona", "casos"}
EJ = {"origen": "EJEMPLO"}


def fila(tipo="DIAGNOSTICO", codigo="I21", edad=65, sexo="F", mun="San Salvador", dep="San Salvador", fecha=date(2026, 3, 1)):
    return {"tipo": tipo, "fecha": fecha, "edad": edad, "sexo": sexo, "departamento": dep, "municipio": mun, "codigo_cie10": codigo}


def poner(*grupos):
    """Deja SOLO estos casos de ejemplo (n copias de cada fila)."""
    with SessionLocal() as db:
        datos_ejemplo.borrar(db)
        for n, f in grupos:
            db.add_all([EpiEjemplo(**f) for _ in range(n)])
        db.commit()


@pytest.fixture(autouse=True)
def _sin_ejemplo_ajeno():
    yield
    with SessionLocal() as db:
        datos_ejemplo.borrar(db)


@pytest.fixture
def salud(client, omega_headers):
    d = datos_persona()
    r = client.post("/personas", json=d)
    assert r.status_code == 201, r.text
    r2 = client.put(f"/omega/personas/{r.json()['id']}/salud-publica", headers=omega_headers, json={"activo": True, "motivo": "Analista de epidemiología MINSAL"})
    assert r2.status_code == 200, r2.text
    return login(client, d), d, r.json()["id"]


def get(client, h, ruta, **p):
    return client.get(ruta, headers=h, params=p)


def celdas(r):
    assert r.status_code == 200, r.text
    return {tuple(c.get(k) for k in ("causa", "rango_edad", "sexo", "zona")): c["casos"] for c in r.json()["celdas"]}


# ------------------------------------------------------------------ Acceso exclusivo
def test_solo_omega_y_salud_publica(client, omega_headers, salud, medico, codigos_2fa):
    h_salud, _, pid = salud
    civil = datos_persona()
    client.post("/personas", json=civil)
    h_civil = login(client, civil)
    hospital = login_inst(client, CODIGO_HOSPITAL, PASSWORD_HOSPITAL, codigos_2fa)
    farmacia = login_inst(client, NIT_FARMACIA, PASSWORD_FARMACIA, codigos_2fa)
    for ruta in RUTAS:
        assert client.get(ruta).status_code == 401, ruta
        assert get(client, h_salud, ruta).status_code == 200, ruta
        assert get(client, omega_headers, ruta).status_code == 200, ruta
        for quien in (medico, h_civil, hospital, farmacia):  # ningún otro rol
            assert get(client, quien, ruta).status_code == 403, ruta
    assert client.get("/estadisticas/fallecidos", headers={"Authorization": "Bearer basura"}).status_code == 401
    # cada intento denegado queda en la bitácora, con su motivo
    motivos = {m[0] for m in sql("SELECT detalle->>'motivo' FROM auditoria WHERE accion = 'ESTADISTICA_ACCESO_DENEGADO' AND resultado = 'FALLO'")}
    assert {"ROL_NO_AUTORIZADO", "TIPO_CREDENCIAL_NO_PERMITIDO", "SIN_TOKEN"} <= motivos
    # el rol de salud pública NO abre nada más: ni datos clínicos, ni la administración de Omega
    assert client.get("/expediente/" + datos_persona()["dui"], headers=h_salud).status_code in (403, 404)
    assert client.get("/omega/me", headers=h_salud).status_code == 403
    assert client.put("/estadisticas/municipios", headers=h_salud, json={"departamento": "Morazán", "nombre": "Perquín", "zona": "URBANA"}).status_code == 403
    assert client.put(f"/omega/personas/{pid}/salud-publica", headers=h_salud, json={"activo": True, "motivo": "me lo doy yo mismo"}).status_code == 403
    assert client.put(f"/omega/personas/{pid}/salud-publica", headers=medico, json={"activo": True, "motivo": "intento de un médico"}).status_code == 403
    # Omega retira el rol: efecto inmediato y auditado
    assert client.put(f"/omega/personas/{pid}/salud-publica", headers=omega_headers, json={"activo": False, "motivo": "Fin de la asignación"}).json()["activo"] is False
    assert get(client, h_salud, "/estadisticas/fallecidos").status_code == 403
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'ESTADISTICA_ROL_SALUD_PUBLICA' AND recurso_id = :p", p=pid) == [(2,)]


# ------------------------------------------------------------------ Anonimización y supresión
def _claves(x, acc):
    if isinstance(x, dict):
        for k, v in x.items():
            acc.add(k)
            _claves(v, acc)
    elif isinstance(x, list):
        for v in x:
            _claves(v, acc)
    return acc


def test_ningun_endpoint_devuelve_identificadores(client, omega_headers, salud):
    h_salud, d, pid = salud
    with SessionLocal() as db:
        datos_ejemplo.generar(db, semilla=7, cantidad=1500)
    for h in (omega_headers, h_salud):
        for ruta in RUTAS[:3]:
            r = get(client, h, ruta, **EJ)
            assert r.status_code == 200 and r.json()["celdas"]
            assert _claves(r.json(), set()) <= PERMITIDAS, ruta
            cuerpo = json.dumps(r.json(), ensure_ascii=False)
            assert not re.search(r"\d{8}-\d", cuerpo) and d["dui"] not in cuerpo and d["nombres"] not in cuerpo and d["correo"] not in cuerpo and pid not in cuerpo
            assert not re.search(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-", cuerpo)  # ningún UUID
    # ni la vista ni la tabla de ejemplo tienen columnas de identidad
    cols = {c[0] for c in sql("SELECT column_name FROM information_schema.columns WHERE table_name IN ('v_epi_evento', 'epi_ejemplo')")}
    assert not ({"dui", "nombres", "apellidos", "persona_id", "paciente_id", "correo", "telefono", "direccion"} & cols)


def test_celdas_con_menos_de_5_casos_se_suprimen(client, omega_headers):
    poner((5, fila(codigo="I21", sexo="F")), (4, fila(codigo="I21", sexo="M")), (1, fila(codigo="C50", sexo="F")))
    r = get(client, omega_headers, "/estadisticas/enfermedades-graves", **EJ)
    c = celdas(r)
    assert c == {("I21", "60-74", "F", None): 5}  # exactamente 5 se muestra; 4 y 1 no
    assert r.json()["celdas_suprimidas"] == 2 and r.json()["umbral_supresion"] == 5 and "totales" in r.json()["nota"]
    assert "M" not in json.dumps(r.json()["celdas"]) and "C50" not in json.dumps(r.json()["celdas"])
    # no hay forma de bajar el umbral por parámetro
    r = get(client, omega_headers, "/estadisticas/enfermedades-graves", umbral=1, minimo=1, **EJ)
    assert celdas(r) == c
    # con datos generados, jamás aparece una celda menor al umbral y las celdas "raras" a propósito quedan ocultas
    with SessionLocal() as db:
        datos_ejemplo.generar(db, semilla=3, cantidad=800)
    for ruta in RUTAS[:3]:
        r = get(client, omega_headers, ruta, **EJ)
        assert all(x["casos"] >= 5 for x in r.json()["celdas"]) and r.json()["celdas_suprimidas"] >= 0
    assert not any(k[0] == "A15" for k in celdas(get(client, omega_headers, "/estadisticas/fallecidos", **EJ)))
    assert not any(k[0] == "K72" for k in celdas(get(client, omega_headers, "/estadisticas/enfermedades-graves", **EJ)))
    assert get(client, omega_headers, "/estadisticas/fallecidos", **EJ).json()["celdas_suprimidas"] >= 1


# ------------------------------------------------------------------ Consultas
def test_fallecidos_por_causa_edad_y_genero(client, omega_headers):
    poner((5, fila("FALLECIDO", "I21", 4, "F")), (5, fila("FALLECIDO", "I21", 5, "F")), (6, fila("FALLECIDO", "I21", 74, "M")), (7, fila("FALLECIDO", "J18", 75, "M")),
          (9, fila("DIAGNOSTICO", "J06", 30, "F")))  # un diagnóstico no cuenta como fallecido
    c = celdas(get(client, omega_headers, "/estadisticas/fallecidos", **EJ))
    assert c == {("I21", "0-4", "F", None): 5, ("I21", "5-14", "F", None): 5, ("I21", "60-74", "M", None): 6, ("J18", "75+", "M", None): 7}
    assert list(c.values()) == [7, 6, 5, 5]  # de mayor a menor
    assert celdas(get(client, omega_headers, "/estadisticas/fallecidos", anio_desde=2027, **EJ)) == {}
    assert len(celdas(get(client, omega_headers, "/estadisticas/fallecidos", anio_desde=2026, anio_hasta=2026, **EJ))) == 4


def test_enfermedades_comunes_por_edad_y_zona_rural_urbana(client, omega_headers):
    poner((6, fila(codigo="J06", edad=3, mun="Perquín", dep="Morazán")), (5, fila(codigo="J06", edad=3, mun="Santa Tecla", dep="La Libertad")),
          (5, fila(codigo="A09", edad=3, mun="Lugar Inventado", dep="Morazán")), (9, fila("FALLECIDO", "J06", 3, "F", "Perquín", "Morazán")))
    c = celdas(get(client, omega_headers, "/estadisticas/enfermedades-comunes", **EJ))
    assert c == {("J06", "0-4", None, "RURAL"): 6, ("J06", "0-4", None, "URBANA"): 5, ("A09", "0-4", None, "SIN_DATO"): 5}
    assert celdas(get(client, omega_headers, "/estadisticas/enfermedades-comunes", zona="RURAL", **EJ)) == {("J06", "0-4", None, "RURAL"): 6}
    assert get(client, omega_headers, "/estadisticas/enfermedades-comunes", zona="OTRA", **EJ).status_code == 422
    assert len(get(client, omega_headers, "/estadisticas/enfermedades-comunes", limite=1, **EJ).json()["celdas"]) == 1
    # Omega reclasifica un municipio: el cambio se refleja y queda auditado
    r = client.put("/estadisticas/municipios", headers=omega_headers, json={"departamento": "Morazán", "nombre": "Lugar Inventado", "zona": "RURAL"})
    assert r.status_code == 200 and r.json()["zona"] == "RURAL"
    assert celdas(get(client, omega_headers, "/estadisticas/enfermedades-comunes", zona="RURAL", **EJ))[("A09", "0-4", None, "RURAL")] == 5
    r = client.put("/estadisticas/municipios", headers=omega_headers, json={"departamento": "Morazán", "nombre": "Lugar Inventado", "zona": "URBANA"})
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'ESTADISTICA_MUNICIPIO_GUARDADO' AND detalle->>'nombre' = 'Lugar Inventado'")[0][0] >= 2
    cat = get(client, omega_headers, "/estadisticas/municipios").json()
    assert {"departamento": "Morazán", "nombre": "Perquín", "zona": "RURAL"} in cat and {"departamento": "San Salvador", "nombre": "San Salvador", "zona": "URBANA"} in cat
    with SessionLocal() as db:  # limpia el municipio de la prueba
        db.execute(text("DELETE FROM municipio_catalogo WHERE nombre = 'Lugar Inventado'"))
        db.commit()


def test_enfermedades_graves_por_genero_y_edad(client, omega_headers):
    poner((5, fila(codigo="I21", edad=50, sexo="M")), (5, fila(codigo="I21", edad=50, sexo="F")), (5, fila(codigo="C50", edad=40, sexo="F")), (20, fila(codigo="J06", edad=50, sexo="M")),
          (5, fila(codigo="I21", edad=50, sexo="M", fecha=date(2025, 1, 1))))
    c = celdas(get(client, omega_headers, "/estadisticas/enfermedades-graves", **EJ))
    assert c == {("I21", "45-59", "M", None): 10, ("I21", "45-59", "F", None): 5, ("C50", "30-44", "F", None): 5}  # J06 no es grave
    assert celdas(get(client, omega_headers, "/estadisticas/enfermedades-graves", anio_desde=2026, **EJ))[("I21", "45-59", "M", None)] == 5


def test_por_defecto_solo_datos_reales_y_el_ejemplo_se_pide_aparte(client, omega_headers):
    poner((8, fila(codigo="Z99")))
    assert ("Z99", "60-74", None, "URBANA") not in celdas(get(client, omega_headers, "/estadisticas/enfermedades-comunes", limite=200))
    assert ("Z99", "60-74", None, "URBANA") in celdas(get(client, omega_headers, "/estadisticas/enfermedades-comunes", origen="TODOS", limite=200))
    assert get(client, omega_headers, "/estadisticas/enfermedades-comunes", origen="EJEMPLO").json()["origen"] == "EJEMPLO"


def test_datos_reales_sin_nivel4_ni_identificadores(client, omega_headers, medico):
    pacientes = []
    for _ in range(5):
        d = datos_persona(sexo="F")
        assert client.post("/personas", json=d).status_code == 201
        alta_completa(client, medico, d)  # diagnóstico J06.9 (nivel 2) y B20 (nivel 4, cifrado)
        pacientes.append(d)
    assert sql("SELECT sexo FROM persona WHERE dui = :d", d=pacientes[0]["dui"]) == [("F",)]
    r = get(client, omega_headers, "/estadisticas/enfermedades-comunes", limite=200)
    assert sum(c["casos"] for c in r.json()["celdas"] if c["causa"] == "J06") >= 5
    assert all(c["causa"] != "B20" for c in r.json()["celdas"])  # el nivel 4 jamás entra en las estadísticas
    cuerpo = json.dumps([get(client, omega_headers, ru, origen="TODOS").json() for ru in RUTAS[:3]], ensure_ascii=False)
    assert not any(d["dui"] in cuerpo or d["correo"] in cuerpo for d in pacientes) and "B20" not in cuerpo
    assert client.post("/personas", json=datos_persona(sexo="X")).status_code == 422


# ------------------------------------------------------------------ Datos de ejemplo
def test_script_de_ejemplo_repetible_y_no_toca_datos_reales(client):
    antes = {t: sql(f"SELECT count(*) FROM {t}")[0][0] for t in ("persona", "diagnostico", "defuncion", "atencion", "municipio_catalogo")}
    hoy = date(2026, 10, 1)
    with SessionLocal() as db:
        n1 = datos_ejemplo.generar(db, semilla=11, cantidad=500, hoy=hoy)
        a = sql("SELECT tipo, fecha, edad, sexo, municipio, codigo_cie10 FROM epi_ejemplo ORDER BY id")
        n2 = datos_ejemplo.generar(db, semilla=11, cantidad=500, hoy=hoy)  # repetible: borra y regenera igual, sin acumular
        b = sql("SELECT tipo, fecha, edad, sexo, municipio, codigo_cie10 FROM epi_ejemplo ORDER BY id")
    assert n1 == n2 == 1522 and a == b and len(a) == 517  # 517 casos + 503 prescripciones + 502 vacunados
    assert {t: sql(f"SELECT count(*) FROM {t}")[0][0] for t in antes} == antes
    r = subprocess.run([sys.executable, "-m", "estadistica_epidemiologia.datos_ejemplo", "--borrar"], capture_output=True, text=True, timeout=60)
    assert r.returncode == 0 and "Borrados 1522" in r.stdout, r.stdout + r.stderr
    assert sql("SELECT count(*) FROM epi_ejemplo") == [(0,)]
    assert {t: sql(f"SELECT count(*) FROM {t}")[0][0] for t in antes} == antes  # borrar no toca lo real


# ------------------------------------------------------------------ Bitácora y documentación
def test_todo_acceso_queda_en_la_bitacora(client, omega_headers, salud):
    h_salud, _, pid = salud
    poner((5, fila()))
    def n(accion, actor, consulta):
        return sql("SELECT count(*) FROM auditoria WHERE accion = :a AND actor_id::text = :x AND detalle->>'consulta' = :c", a=accion, x=actor, c=consulta)[0][0]
    omega_id = sql("SELECT id FROM persona WHERE dui = '00000001-8'")[0][0].__str__()
    antes = (n("ESTADISTICA_CONSULTADA", pid, "enfermedades_graves_por_genero_edad"), n("ESTADISTICA_CONSULTADA", omega_id, "fallecidos_por_causa_edad_genero"), n("ESTADISTICA_CONSULTADA", pid, "catalogo_municipios"))
    get(client, h_salud, "/estadisticas/enfermedades-graves", **EJ)
    get(client, omega_headers, "/estadisticas/fallecidos", **EJ)
    get(client, h_salud, "/estadisticas/municipios")
    assert (n("ESTADISTICA_CONSULTADA", pid, "enfermedades_graves_por_genero_edad"), n("ESTADISTICA_CONSULTADA", omega_id, "fallecidos_por_causa_edad_genero"),
            n("ESTADISTICA_CONSULTADA", pid, "catalogo_municipios")) == tuple(x + 1 for x in antes)
    d = sql("SELECT detalle, actor_tipo FROM auditoria WHERE accion = 'ESTADISTICA_CONSULTADA' AND actor_id::text = :p ORDER BY id DESC LIMIT 2", p=pid)
    assert d[1][1] == "salud_publica" and any(x[0].get("origen") == "EJEMPLO" and x[0].get("celdas") == 1 for x in d)


def test_endpoints_documentados(client):
    paths = client.get("/openapi.json").json()["paths"]
    for p in RUTAS:
        op = paths[p]["get"]
        assert op["summary"] and op["description"] and {"401", "403"} <= set(op["responses"]), p
    assert "5 casos" in paths["/estadisticas/fallecidos"]["get"]["description"]
    assert {"put"} <= set(paths["/estadisticas/municipios"]) and {"put"} <= set(paths["/omega/personas/{persona_id}/salud-publica"])
    assert all(paths[p]["put"]["summary"] for p in ("/estadisticas/municipios", "/omega/personas/{persona_id}/salud-publica"))
