"""Etapa 7 · parte 2b: /ciudadano/expediente (solo lectura, pestañas HTMX, paginación, nivel 4 oculto).
Pruebas de humo y de permisos: sin sesión → login; el sujeto sale siempre de la sesión, aunque se manipulen ids en la URL."""
import json
import re
from datetime import date, timedelta

from web.ciudadano.formato import fecha
from web.comun.portales import CIUDADANO

from .conftest import datos_persona
from .test_etapa2 import NAC, abrir, medico, paciente_id, sql  # noqa: F401
from .test_etapa3a import AMOX, canje, emitir, farmacia, firmado  # noqa: F401
from .test_etapa3c import hb, lab, orden, subir  # noqa: F401
from .test_etapa4a import desbloquear, pac, pac_h, vacuna  # noqa: F401
from .test_etapa7a import entrar_persona, nuevo, web  # noqa: F401  (web es un fixture)

EXP = "/ciudadano/expediente"
HX = {"HX-Request": "true"}
PESTANAS = ("diagnosticos", "recetas", "resultados", "vacunas")


def _entrar(web, persona):
    assert entrar_persona(web, CIUDADANO, persona["dui"], persona["password"]).status_code == 303
    return web


def _registros(html: str) -> int:
    return html.count('<li class="registro">')


def _persona_nueva(client):
    d = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=d).status_code == 201
    return d


def _diag(client, medico, at, codigo, texto, **kw):
    r = client.post(f"/atenciones/{at}/diagnosticos", headers=medico, json={"codigo_cie10": codigo, "descripcion": texto, "tipo": "DEFINITIVO", "principal": True} | kw)
    assert r.status_code == 201, r.text


# ------------------------------------------------------------------ Sin sesión
def test_sin_sesion_el_expediente_redirige_al_login_de_ciudadano(web):
    for ruta in (EXP, f"{EXP}?seccion=vacunas&pagina=2", *(f"{EXP}/{p}" for p in PESTANAS)):
        r = web.get(ruta)
        assert r.status_code == 303 and r.headers["location"].startswith("/ciudadano/ingresar"), ruta
    r = web.get(f"{EXP}/recetas", headers=HX)  # una petición HTMX recibe 401 + HX-Redirect, no un fragmento
    assert r.status_code == 401 and r.headers["hx-redirect"].startswith("/ciudadano/ingresar")


# ------------------------------------------------------------------ Humo: las cuatro pestañas con datos reales
def test_pestanas_muestran_el_expediente_propio_con_fechas_legibles_y_nivel4_oculto(web, client, medico, firmado, farmacia, lab, pac, pac_h):  # noqa: F811
    lab_h, lab_id = lab
    dui = pac["dui"]
    at = abrir(client, medico, dui)
    _diag(client, medico, at, "J06.9", "Infección respiratoria aguda")
    _diag(client, medico, at, "B20", "Enfermedad por VIH", principal=False)  # nivel 4
    aplicada = date.today() - timedelta(days=2)
    assert client.post("/vacunas", headers=medico, json=vacuna(dui)).status_code == 201
    assert subir(client, lab_h, orden(client, medico, dui, lab_id).json()["folio"], [hb(14)]).status_code == 201
    o2 = orden(client, medico, dui, lab_id, estudios=[{"nombre": "Prueba de VIH 4ª generación"}]).json()
    assert subir(client, lab_h, o2["folio"], [{"estudio": 1, "parametro": "VIH Ag/Ac", "valor_texto": "REACTIVO", "bandera": "CRITICO"}]).status_code == 201
    rx = emitir(client, firmado, dui)
    assert rx.status_code == 201
    token_receta = rx.json()["token"]
    _entrar(web, pac)
    antes = sql("SELECT count(*) FROM auditoria WHERE accion = 'PORTAL_LECTURA_PROPIA' AND actor_id = :p", p=paciente_id(dui))[0][0]

    pagina = web.get(EXP)  # página completa: pestaña inicial = diagnósticos
    assert pagina.status_code == 200 and 'id="expediente"' in pagina.text and "Infección respiratoria aguda" in pagina.text
    assert re.search(r'<a [^>]*aria-current="page"[^>]*>Diagnósticos</a>', pagina.text, re.S)
    assert "Protegido" in pagina.text and "1 registro protegido" in pagina.text
    assert "VIH" not in pagina.text and "B20" not in pagina.text  # el contenido de nivel 4 jamás llega al navegador

    dx = web.get(f"{EXP}/diagnosticos", headers=HX)  # fragmento HTMX: solo el bloque, no la página
    assert dx.status_code == 200 and "<html" not in dx.text and "J06.9" in dx.text and "VIH" not in dx.text
    va = web.get(f"{EXP}/vacunas", headers=HX).text
    assert "Influenza" in va and fecha(aplicada) in va and str(aplicada) not in va  # fecha legible, no ISO
    assert re.search(r"Dosis\s+1", va)
    re_ = web.get(f"{EXP}/resultados", headers=HX).text
    assert "Hemoglobina" in re_ and "g/dL" in re_ and "Normal" in re_ and "Protegido" in re_ and "REACTIVO" not in re_ and "VIH" not in re_
    rc = web.get(f"{EXP}/recetas", headers=HX).text
    assert "Amoxicilina" in rc and "Vigente" in rc and "21 unidades" in rc
    for texto in (dx.text, va, re_, rc, pagina.text):
        assert token_receta not in texto  # nunca el token de canje de la receta
    assert web.get(f"{EXP}?seccion=vacunas").text.count("Influenza") >= 1  # respaldo sin JavaScript
    assert web.get(f"{EXP}/vacunas").status_code == 303 and web.get(f"{EXP}/vacunas").headers["location"] == f"{EXP}?seccion=vacunas&pagina=1"
    despues = sql("SELECT count(*) FROM auditoria WHERE accion = 'PORTAL_LECTURA_PROPIA' AND actor_id = :p", p=paciente_id(dui))[0][0]
    assert despues > antes  # cada lectura queda en la bitácora (la registra el servicio de portal_civil)


# ------------------------------------------------------------------ Paginación
def test_paginacion_de_cada_pestana(web, client, medico, pac):
    dui = pac["dui"]
    abrir(client, medico, dui)
    for i in range(12):
        assert client.post("/vacunas", headers=medico, json=vacuna(dui, vacuna=f"Vacuna {i:02d}")).status_code == 201
    _entrar(web, pac)
    p1 = web.get(f"{EXP}/vacunas", headers=HX).text
    assert _registros(p1) == 10 and "Siguiente" in p1 and "Anterior" not in p1 and "Página 1" in p1
    p2 = web.get(f"{EXP}/vacunas?pagina=2", headers=HX).text
    assert _registros(p2) == 2 and "Anterior" in p2 and "Siguiente" not in p2 and "Página 2" in p2
    vistas = set(re.findall(r"Vacuna \d\d", p1)) | set(re.findall(r"Vacuna \d\d", p2))
    assert len(vistas) == 12 and not set(re.findall(r"Vacuna \d\d", p1)) & set(re.findall(r"Vacuna \d\d", p2))  # sin repetidos ni faltantes
    p3 = web.get(f"{EXP}/vacunas?pagina=3", headers=HX)
    assert p3.status_code == 200 and _registros(p3.text) == 0 and "No hay más registros" in p3.text
    assert web.get(f"{EXP}?seccion=vacunas&pagina=2").status_code == 200
    for malo in ("0", "-1", "abc", "99999"):
        assert web.get(f"{EXP}/vacunas?pagina={malo}", headers=HX).status_code == 422, malo
    assert "Aún no hay" in web.get(f"{EXP}/diagnosticos", headers=HX).text  # pestaña vacía: invitación, no error


# ------------------------------------------------------------------ Permisos: nunca datos ajenos
def test_un_ciudadano_no_ve_datos_ajenos_aunque_manipule_ids(web, client, medico, pac, pac_h, codigos_2fa):  # noqa: F811
    a, b = pac, _persona_nueva(client)
    _diag(client, medico, abrir(client, medico, a["dui"]), "J06.9", "Infección respiratoria de la persona A")
    _diag(client, medico, abrir(client, medico, b["dui"]), "K29.7", "Gastritis de la persona B")
    assert client.post("/vacunas", headers=medico, json=vacuna(a["dui"], lote="LOTE-DE-A")).status_code == 201
    id_a, id_b = paciente_id(a["dui"]), paciente_id(b["dui"])
    token_a = desbloquear(client, pac_h, codigos_2fa)  # desbloqueo válido de A: tampoco debe abrir nada en la web

    nav_b = _entrar(web, b)
    manipulados = {"dui": a["dui"], "paciente_id": id_a, "persona_id": id_a, "id": id_a, "sujeto": id_a, "historial": "true", "justificacion": "quiero ver"}
    for pestana in PESTANAS:
        for params in ({}, manipulados):
            t = nav_b.get(f"{EXP}/{pestana}", params=params, headers=HX | {"X-Desbloqueo-N4": token_a}).text
            assert "persona A" not in t and "LOTE-DE-A" not in t and "Influenza" not in t and a["dui"] not in t, (pestana, params)
    assert "Gastritis de la persona B" in nav_b.get(f"{EXP}/diagnosticos", params=manipulados, headers=HX).text  # siempre el expediente de la sesión
    assert "persona A" not in nav_b.get(EXP, params=manipulados).text
    # el id o el DUI de otra persona en la ruta no es una sección válida; no hay rutas por id
    for ruta in (f"{EXP}/{id_a}", f"{EXP}/{a['dui']}", f"{EXP}/vacunas/{id_a}", f"{EXP}/{id_a}/vacunas"):
        assert nav_b.get(ruta, headers=HX).status_code == 404, ruta
    # solo lectura
    for metodo in ("post", "put", "patch", "delete"):
        assert getattr(nav_b, metodo)(f"{EXP}/vacunas").status_code in (403, 405), metodo
    assert sql("SELECT count(*) FROM vacuna WHERE paciente_id = :p", p=id_b)[0][0] == 0

    nav_a = _entrar(nuevo(50078), a)
    ta = nav_a.get(f"{EXP}/diagnosticos", params={"dui": b["dui"], "persona_id": id_b}, headers=HX | {"X-Desbloqueo-N4": token_a}).text
    assert "persona A" in ta and "Gastritis" not in ta  # A ve lo suyo y nada de B
    assert "LOTE-DE-A" in nav_a.get(f"{EXP}/vacunas", headers=HX).text


def test_el_nivel4_sigue_oculto_incluso_con_un_desbloqueo_valido_de_la_api(web, client, medico, pac, pac_h, codigos_2fa):  # noqa: F811
    _diag(client, medico, abrir(client, medico, pac["dui"]), "B20", "Enfermedad por VIH")
    token = desbloquear(client, pac_h, codigos_2fa)
    abierto = client.get("/portal/mi-expediente/diagnosticos", headers=pac_h | {"X-Desbloqueo-N4": token}).json()
    assert abierto["restringidos"] == 0 and "B20" in json.dumps(abierto)  # la API sí lo abre con el token (parte 2c lo hará en la web)
    t = _entrar(web, pac).get(f"{EXP}/diagnosticos", headers=HX | {"X-Desbloqueo-N4": token}).text
    assert "Protegido" in t and "B20" not in t and "VIH" not in t
