"""Etapa 7 · integración web del expediente civil · parte 2: agendamiento manual de citas y directorio de centros en /ciudadano.
Las pruebas buscan por persona, cita o nombre único (nunca «la última fila» de tablas compartidas)."""
import re
from datetime import date

from web.comun.portales import CIUDADANO

from .conftest import datos_persona
from .test_etapa2 import NAC, acciones_auditoria, medico, paciente_id, sql  # noqa: F401
from .test_etapa4a import pac  # noqa: F401
from .test_etapa4b import agenda  # noqa: F401  (doctor con bloque 08:00-10:00 de 30 min en un día futuro)
from .test_etapa7a import entrar_persona, nuevo, token_de, web  # noqa: F401
from .test_etapa7h import hospital

CITAS, MIS, RESERVAR, DIR = "/ciudadano/citas", "/ciudadano/citas/mis", "/ciudadano/citas/reservar", "/ciudadano/directorio"


def _entrar(web, persona):
    assert entrar_persona(web, CIUDADANO, persona["dui"], persona["password"]).status_code == 303
    return web


def _texto(iso: str) -> str:
    return date.fromisoformat(iso).strftime("%d/%m/%Y")


def _reservar(w, ag, hora, **extra):
    """Pasa por la página de confirmación (de ahí sale el token CSRF) y envía el formulario."""
    pag = w.get(CITAS, params={"medico_id": ag["medico_id"], "fecha": ag["fecha"], "hora": hora})
    datos = {"csrf_token": token_de(pag.text), "medico_id": ag["medico_id"], "fecha": ag["fecha"], "hora": hora} | extra
    return w.post(RESERVAR, data=datos)


def _cita_id(persona, estado="PROGRAMADA", hora=None):
    q, p = "SELECT id FROM cita WHERE paciente_id = :p AND estado = :e", {"p": paciente_id(persona["dui"]), "e": estado}
    if hora:
        q, p = q + " AND to_char(inicio AT TIME ZONE 'America/El_Salvador', 'HH24:MI') = :h", p | {"h": hora}
    return str(sql(q + " ORDER BY inicio LIMIT 1", **p)[0][0])


def test_flujo_completo_por_la_web_hasta_reservar(web, agenda, pac):
    _entrar(web, pac)
    r = web.get(CITAS)
    assert r.status_code == 200 and "Elija la especialidad" in r.text and "Medicina Interna" in r.text
    centros = web.get(CITAS, params={"especialidad": "Medicina Interna"}).text
    assert "Elija el centro médico" in centros
    inst = re.search(r"institucion_id=([0-9a-f-]{36})", centros).group(1)
    doctores = web.get(CITAS, params={"especialidad": "Medicina Interna", "institucion_id": inst})
    assert "Elija el doctor" in doctores.text and f"medico_id={agenda['medico_id']}" in doctores.text
    fechas = web.get(CITAS, params={"medico_id": agenda["medico_id"]})
    assert "Elija la fecha" in fechas.text and _texto(agenda["fecha"]) in fechas.text
    horas = web.get(CITAS, params={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"]})
    assert "Elija la hora" in horas.text and all(h in horas.text for h in ("08:00", "08:30", "09:00", "09:30"))
    conf = web.get(CITAS, params={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"], "hora": "08:30"})
    assert "Confirme su cita" in conf.text and "Confirmar cita" in conf.text and 'action="/ciudadano/citas/reservar"' in conf.text
    r = _reservar(web, agenda, "08:30", motivo="Control de presión")
    assert r.status_code == 303 and "/ciudadano/citas/mis" in r.headers["location"] and "aviso=reservada" in r.headers["location"]
    mis = web.get(r.headers["location"])
    assert mis.status_code == 200 and "Su cita quedó reservada" in mis.text
    assert "Medicina Interna" in mis.text and "08:30" in mis.text and "Programada" in mis.text and "Control de presión" in mis.text
    assert "CITA_RESERVADA" in acciones_auditoria(_cita_id(pac))
    assert "Medicina Interna" in web.get("/ciudadano/expediente?seccion=seguimiento").text  # aparece sola en «Seguimiento»
    assert "08:30" not in web.get(CITAS, params={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"]}).text  # la hora tomada ya no se ofrece
    desde_dir = web.get(CITAS, params={"institucion_id": inst})  # desde el directorio: el centro llega elegido
    assert "Elija la especialidad en" in desde_dir.text and "Medicina Interna" in desde_dir.text


def test_los_filtros_de_sector_y_red_se_aplican_al_recorrido(web, agenda, pac):
    _entrar(web, pac)
    assert "Medicina Interna" in web.get(CITAS).text
    assert "Medicina Interna" not in web.get(CITAS, params={"sector": "PUBLICO"}).text  # el centro semilla no está clasificado
    assert web.get(CITAS, params={"sector": "MIXTO", "red_seguros": "X"}).status_code == 200  # un filtro inválido se ignora


def test_parametros_invalidos_no_rompen_el_recorrido(web, agenda, pac):
    _entrar(web, pac)
    for p in ({"medico_id": "no-es-uuid"}, {"institucion_id": "x"}, {"medico_id": agenda["medico_id"], "fecha": "32/13/2026"},
              {"medico_id": agenda["medico_id"], "fecha": agenda["fecha"], "hora": "99:99"}, {"especialidad": "x" * 500}):
        assert web.get(CITAS, params=p).status_code == 200


def test_doble_reserva_da_conflicto_claro_y_vuelve_a_las_horas(web, client, agenda, pac):
    otra = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=otra).status_code == 201
    a, b = _entrar(web, pac), _entrar(nuevo(50212), otra)
    assert _reservar(a, agenda, "09:00").status_code == 303
    r = b.get(CITAS, params={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"], "hora": "09:00"})
    assert "Ese horario ya no está libre" in r.text  # la página ya no ofrece la hora ocupada
    r = b.post(RESERVAR, data={"csrf_token": token_de(r.text), "medico_id": agenda["medico_id"], "fecha": agenda["fecha"], "hora": "09:00"})
    assert r.status_code == 409 and 'role="alert"' in r.text and "Elija la hora" in r.text
    assert sql("SELECT count(*) FROM cita WHERE paciente_id = :p", p=paciente_id(otra["dui"]))[0][0] == 0


def test_cancelar_libera_el_horario_y_reprogramar_conserva_la_historia(web, agenda, pac):
    a = _entrar(web, pac)
    assert _reservar(a, agenda, "08:00").status_code == 303
    cid = _cita_id(pac)
    base = f"/ciudadano/citas/{cid}/reprogramar"
    assert _texto(agenda["fecha"]) in a.get(base).text  # paso de fechas
    horas = a.get(base, params={"fecha": agenda["fecha"]})
    assert "09:30" in horas.text and 'href="/ciudadano/citas/mis"' in horas.text
    conf = a.get(base, params={"fecha": agenda["fecha"], "hora": "09:30"})
    assert "Confirmar nuevo horario" in conf.text
    r = a.post(base, data={"csrf_token": token_de(conf.text), "fecha": agenda["fecha"], "hora": "09:30"})
    assert r.status_code == 303 and "aviso=reprogramada" in r.headers["location"]
    assert sql("SELECT estado FROM cita WHERE paciente_id = :p ORDER BY inicio", p=paciente_id(pac["dui"])) == [("REPROGRAMADA",), ("PROGRAMADA",)]
    mis = a.get(MIS)
    assert "Reprogramada" in mis.text and "Programada" in mis.text
    nueva = _cita_id(pac, hora="09:30")  # cancelar: queda con su estado y el horario vuelve a estar libre
    r = a.post(f"/ciudadano/citas/{nueva}/cancelar", data={"csrf_token": token_de(mis.text)})
    assert r.status_code == 303 and "aviso=cancelada" in r.headers["location"]
    assert "Cancelada" in a.get(MIS).text and "CITA_CANCELADA" in acciones_auditoria(nueva)
    assert "09:30" in a.get(CITAS, params={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"]}).text
    assert a.post(f"/ciudadano/citas/{nueva}/cancelar", data={"csrf_token": token_de(mis.text)}).status_code == 409  # ya cancelada
    assert a.get(f"/ciudadano/citas/{nueva}/reprogramar").status_code == 404


def test_una_cita_ajena_responde_404_y_el_csrf_es_obligatorio(web, client, agenda, pac):
    otra = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=otra).status_code == 201
    a, b = _entrar(web, pac), _entrar(nuevo(50222), otra)
    assert _reservar(a, agenda, "08:30").status_code == 303
    cid = _cita_id(pac)
    token_b = token_de(b.get(MIS).text)
    r = b.post(f"/ciudadano/citas/{cid}/cancelar", data={"csrf_token": token_b})
    assert r.status_code == 404 and "Cita no encontrada" in r.text
    assert b.get(f"/ciudadano/citas/{cid}/reprogramar").status_code == 404
    assert b.post(f"/ciudadano/citas/{cid}/reprogramar", data={"csrf_token": token_b, "fecha": agenda["fecha"], "hora": "09:00"}).status_code == 404
    assert sql("SELECT estado FROM cita WHERE id = :c", c=cid) == [("PROGRAMADA",)]
    assert a.post(f"/ciudadano/citas/{cid}/cancelar", data={}).status_code == 403  # sin token
    assert a.post(RESERVAR, data={"medico_id": agenda["medico_id"], "fecha": agenda["fecha"], "hora": "09:00"}).status_code == 403
    assert "08:30" not in b.get(MIS).text  # su lista de citas no incluye la ajena
    assert nuevo(50223).get(MIS).status_code == 303  # sin sesión


def test_reserva_con_datos_malos_se_rechaza_sin_guardar(web, agenda, pac):
    a = _entrar(web, pac)
    token = token_de(a.get(CITAS).text)
    for datos in ({"medico_id": "x", "fecha": agenda["fecha"], "hora": "08:00"}, {"medico_id": agenda["medico_id"], "fecha": "no", "hora": "08:00"},
                  {"medico_id": agenda["medico_id"], "fecha": agenda["fecha"], "hora": "08:07"},  # no es un horario de la agenda
                  {"medico_id": agenda["medico_id"], "fecha": agenda["fecha"], "hora": "08:00", "motivo": "x"}):  # motivo muy corto
        r = a.post(RESERVAR, data={"csrf_token": token} | datos)
        assert r.status_code in (409, 422), (datos, r.status_code)
        if "motivo" in datos:
            assert "El motivo debe tener entre 3 y 300 caracteres" in r.text
    assert sql("SELECT count(*) FROM cita WHERE paciente_id = :p", p=paciente_id(pac["dui"]))[0][0] == 0


# ------------------------------------------------------------------ directorio
def test_directorio_filtra_pagina_y_enlaza_al_agendamiento(web, client, omega_headers, pac):
    _, nombre, iid = hospital(client, omega_headers, sector="PRIVADO", red_seguros="POLIZA_PRIVADA")
    _entrar(web, pac)
    r = web.get(DIR, params={"q": nombre})
    assert r.status_code == 200 and nombre in r.text and "Privado" in r.text and "Póliza privada" in r.text
    assert f"institucion_id={iid}" in r.text and "Agendar aquí" in r.text and "Hospital" in r.text
    publico = web.get(DIR, params={"q": nombre, "sector": "PUBLICO"})  # el cuadro de búsqueda repite el nombre: se verifica por el id del centro
    assert f"institucion_id={iid}" not in publico.text and "No hay centros con esos filtros" in publico.text
    assert nombre in web.get(DIR, params={"q": nombre, "red_seguros": "POLIZA_PRIVADA", "tipo": "HOSPITAL"}).text
    assert "al menos 2 letras" in web.get(DIR, params={"q": "a"}).text
    assert web.get(DIR, params={"sector": "MIXTO", "tipo": "OTRO"}).status_code == 200  # filtros inválidos se ignoran
    assert "No hay más centros" in web.get(DIR, params={"pagina": 2, "q": nombre}).text
    assert web.get(DIR, params={"pagina": 0}).status_code == 422
    citas = web.get(CITAS, params={"institucion_id": iid})  # «Agendar aquí»: la página de citas llega con ese centro elegido
    assert citas.status_code == 200 and nombre in citas.text and "Elija la especialidad en" in citas.text
    assert "Dr. Director" not in r.text and "HospClave" not in r.text  # sin datos del responsable ni de acceso
    assert nuevo(50232).get(DIR).status_code == 303  # sin sesión
