import json
import threading
import time
import uuid
from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import event, text
from sqlalchemy.exc import IntegrityError

from farmacia import firma as fx
from farmacia.alergias import choca
from main import app
from omega_core.database import SessionLocal, engine
from omega_core.seed import NIT_FARMACIA, NIT_HOSPITAL, PASSWORD_FARMACIA, PASSWORD_HOSPITAL

from .conftest import datos_persona
from .test_etapa2 import NAC, abrir, acciones_auditoria, auth, medico, ml, nota, paciente_id, sql  # noqa: F401

PIN = "PinMedico#2026"
AMOX = {"medicamento": "Amoxicilina", "presentacion": "cápsulas 500 mg", "dosis": "500 mg", "via": "oral", "frecuencia": "cada 8 horas",
        "duracion_dias": 7, "cantidad": 21}
PARA = {"medicamento": "Paracetamol", "dosis": "500 mg", "frecuencia": "cada 6 horas", "duracion_dias": 3, "cantidad": 12}


@pytest.fixture
def firmado(client, medico):
    r = client.post("/farmacia/firma/enrolar", json={"pin": PIN}, headers=medico)
    assert r.status_code in (201, 409), r.text
    return medico


@pytest.fixture
def farmacia(client):
    r = client.post("/auth/login/institucion", json={"identificador": NIT_FARMACIA, "password": PASSWORD_FARMACIA})
    assert r.status_code == 200, r.text
    h = auth(r.json()["tokens"]["access_token"])
    for med in ("amoxicilina", "paracetamol"):  # desde la parte B el despacho exige existencias
        for _ in range(3):
            lote = {"medicamento": med, "numero_lote": f"A3-{uuid.uuid4().hex[:8]}", "fecha_vencimiento": str(date.today() + timedelta(days=365)), "cantidad": 10_000}
            if client.post("/farmacia/inventario/lotes", json=lote, headers=h).status_code == 201:
                break
    return h


@pytest.fixture
def paciente(client):
    d = datos_persona(fecha_nacimiento=NAC)
    assert client.post("/personas", json=d).status_code == 201
    return d


def emitir(client, h, dui, meds=(AMOX,), **kw):
    return client.post("/recetas", headers=h, json={"dui": dui, "pin": PIN, "medicamentos": list(meds)} | kw)


def canje(rx, **extra):
    return {"folio": rx["folio"], "token": rx["token"]} | extra


def test_emision_firma_y_validaciones(client, firmado, paciente):
    dui = paciente["dui"]
    assert emitir(client, firmado, dui).status_code == 403  # sin atención abierta
    abrir(client, firmado, dui, fase3=False)
    assert emitir(client, firmado, dui).status_code == 409  # fase 1: aún no es ejecución
    d2 = datos_persona()
    client.post("/personas", json=d2)
    abrir(client, firmado, d2["dui"])
    assert client.post("/recetas", headers=firmado, json={"dui": d2["dui"], "pin": "PinIncorrecto", "medicamentos": [AMOX]}).status_code == 401
    assert emitir(client, firmado, d2["dui"], meds=[]).status_code == 422
    assert emitir(client, firmado, d2["dui"], meds=[AMOX | {"cantidad": 0}]).status_code == 422
    assert emitir(client, firmado, d2["dui"], vigencia_dias=500).status_code == 422
    r = emitir(client, firmado, d2["dui"], meds=[AMOX, PARA], vigencia_dias=10)
    assert r.status_code == 201, r.text
    rx = r.json()
    assert rx["folio"].startswith("RX-") and len(rx["token"].replace("-", "")) == 16 and len(rx["medicamentos"]) == 2
    # el token no se guarda en claro; la firma verifica con la clave pública del médico
    fila = sql("SELECT token_hash, payload, firma, clave_publica, estado FROM receta WHERE folio = :f", f=rx["folio"])[0]
    assert rx["token"] not in fila[0] and fila[4] == "EMITIDA"
    assert fx.verificar(fila[3], fila[1].encode(), fila[2]) and not fx.verificar(fila[3], fila[1].encode() + b" ", fila[2])
    assert "RECETA_EMITIDA" in acciones_auditoria(str(sql("SELECT id FROM receta WHERE folio = :f", f=rx["folio"])[0][0]))
    # la receta es inmutable en la base (solo cambia estado)
    for q in ("UPDATE receta SET vigente_hasta = vigente_hasta + interval '1 year' WHERE folio = :f", "DELETE FROM receta WHERE folio = :f",
              "UPDATE receta SET payload = 'x' WHERE folio = :f", "UPDATE receta_item SET dosis = '9 g' WHERE receta_id = (SELECT id FROM receta WHERE folio = :f)"):
        with pytest.raises(Exception, match="inmutable|no se eliminan"):
            with SessionLocal() as db:
                db.execute(text(q), {"f": rx["folio"]})
                db.commit()


def test_farmacia_ve_solo_lo_necesario_y_despacho_unico(client, firmado, farmacia, paciente):
    dui = paciente["dui"]
    at = abrir(client, firmado, dui)
    # datos clínicos que la farmacia NO debe ver
    client.post(f"/atenciones/{at}/diagnosticos", headers=firmado, json={"codigo_cie10": "J01.9", "descripcion": "Sinusitis aguda", "tipo": "DEFINITIVO", "principal": True})
    client.post(f"/atenciones/{at}/notas", headers=firmado, json=nota(subjetivo="Congestión nasal persistente"))
    client.post(f"/atenciones/{at}/antecedentes", headers=firmado, json={"tipo": "PERSONAL_PATOLOGICO", "descripcion": "Asma bronquial"})
    client.post(f"/atenciones/{at}/alergias", headers=firmado, json={"sustancia": "látex", "severidad": "LEVE"})
    rx = emitir(client, firmado, dui, meds=[PARA]).json()
    # consulta: mismo 404 con token malo y con folio inexistente; el hospital no puede usar el portal
    malo = client.post("/farmacia/recetas/consulta", headers=farmacia, json={"folio": rx["folio"], "token": "AAAA-BBBB-CCCC-DDDD"})
    inex = client.post("/farmacia/recetas/consulta", headers=farmacia, json={"folio": "RX-NOEXISTE", "token": "AAAA-BBBB-CCCC-DDDD"})
    assert malo.status_code == inex.status_code == 404 and malo.json() == inex.json()
    hosp = client.post("/auth/login/institucion", json={"identificador": NIT_HOSPITAL, "password": PASSWORD_HOSPITAL})
    assert hosp.status_code == 200  # el hospital (2FA) no llega a tener token sin código; si lo tuviera, tampoco es farmacia
    assert client.post("/farmacia/recetas/consulta", json=canje(rx), headers=farmacia).status_code == 200
    assert client.post("/farmacia/recetas/consulta", json=canje(rx), headers=firmado).status_code in (401, 403)  # un médico no es farmacia
    # --- SQL espía: ninguna consulta de farmacia toca tablas clínicas ni columnas sobrantes de persona
    vistas = []
    fn = lambda conn, cur, stmt, *a: vistas.append(stmt.lower())  # noqa: E731
    event.listen(engine, "before_cursor_execute", fn)
    try:
        r = client.post("/farmacia/recetas/consulta", json=canje(rx), headers=farmacia)
        assert r.status_code == 200, r.text
        v = r.json()
        d = client.post("/farmacia/recetas/despachar", json=canje(rx, responsable="Lic. Pérez"), headers=farmacia)
        assert d.status_code == 201, d.text
    finally:
        event.remove(engine, "before_cursor_execute", fn)
    todo = " ".join(vistas)
    for tabla in ("diagnostico", "nota_soap", "antecedente", "signos_vitales", "egreso", "atencion"):
        assert f"from {tabla}" not in todo and f"join {tabla}" not in todo, tabla
    for st in vistas:  # de la persona solo se leen nombre y DUI (la entidad institucional propia de la farmacia no cuenta)
        if "from persona" in st:
            assert not any(c in st for c in ("password_hash", "correo", "telefono", "fecha_nacimiento", "totp")), st
    # --- y la respuesta tampoco los contiene
    texto = json.dumps(v, ensure_ascii=False).lower()
    for prohibido in ("sinusitis", "j01", "congesti", "asma", "diagnos", "soap", "antecedente", "signos"):
        assert prohibido not in texto, prohibido
    assert v["alergias_relevantes"] == [] and v["apto_para_despacho"] is True and v["firma"]["valida"] is True
    assert v["paciente_dui_parcial"].startswith("****") and paciente["dui"] not in texto and v["paciente_iniciales"] == "A.P."
    assert v["medicamentos"][0]["medicamento"] == "Paracetamol"
    # --- anti doble canje
    r2 = client.post("/farmacia/recetas/despachar", json=canje(rx), headers=farmacia)
    assert r2.status_code == 409 and "RECETA_YA_DESPACHADA" in r2.json()["detail"]["motivos"]
    assert sql("SELECT count(*) FROM despacho d JOIN receta r ON r.id = d.receta_id WHERE r.folio = :f", f=rx["folio"]) == [(1,)]
    assert sql("SELECT estado FROM receta WHERE folio = :f", f=rx["folio"]) == [("DESPACHADA",)]
    rid = str(sql("SELECT id FROM receta WHERE folio = :f", f=rx["folio"])[0][0])
    ac = acciones_auditoria(rid)
    assert "RECETA_CONSULTADA" in ac and "RECETA_DESPACHADA" in ac and "RECETA_DESPACHO_BLOQUEADO" in ac


def test_bloqueo_por_alergias(client, firmado, farmacia, paciente):
    dui = paciente["dui"]
    at = abrir(client, firmado, dui)
    a1 = client.post(f"/atenciones/{at}/alergias", headers=firmado, json={"sustancia": "Penicilina", "severidad": "GRAVE", "reaccion": "urticaria"}).json()
    client.post(f"/atenciones/{at}/alergias", headers=firmado, json={"sustancia": "látex", "severidad": "LEVE"})
    rx = emitir(client, firmado, dui, meds=[AMOX, PARA]).json()
    v = client.post("/farmacia/recetas/consulta", json=canje(rx), headers=farmacia).json()
    assert v["apto_para_despacho"] is False and "ALERGIA_CONFLICTO" in v["motivos_bloqueo"]
    assert [(a["sustancia"], a["medicamentos_afectados"]) for a in v["alergias_relevantes"]] == [("penicilina", ["Amoxicilina"])]  # látex no se revela
    r = client.post("/farmacia/recetas/despachar", json=canje(rx), headers=farmacia)
    assert r.status_code == 409 and r.json()["detail"]["motivos"] == ["ALERGIA_CONFLICTO"]
    assert sql("SELECT estado FROM receta WHERE folio = :f", f=rx["folio"]) == [("EMITIDA",)]
    assert sql("SELECT count(*) FROM despacho d JOIN receta r ON r.id = d.receta_id WHERE r.folio = :f", f=rx["folio"]) == [(0,)]
    rid = str(sql("SELECT id FROM receta WHERE folio = :f", f=rx["folio"])[0][0])
    det = sql("SELECT detalle FROM auditoria WHERE recurso_id = :r AND accion = 'RECETA_DESPACHO_BLOQUEADO'", r=rid)[0][0]
    assert "ALERGIA_CONFLICTO" in det["motivos"]
    # el médico descarta la alergia con una nueva versión (el original no se edita) y el bloqueo desaparece
    r = client.post(f"/atenciones/{at}/alergias", headers=firmado, json={
        "sustancia": "Penicilina", "severidad": "GRAVE", "estado": "DESCARTADA", "reemplaza_id": a1["id"], "motivo_correccion": "Prueba cutánea negativa"})
    assert r.status_code == 201, r.text
    assert client.post("/farmacia/recetas/despachar", json=canje(rx), headers=farmacia).status_code == 201


@pytest.mark.parametrize("med,alergia,esperado", [
    ("Amoxicilina", "penicilina", True), ("amoxicilina + ácido clavulánico", "Penicilinas", True), ("Ceftriaxona", "betalactámicos", True),
    ("Ibuprofeno", "AINE", True), ("Diclofenaco sódico", "antiinflamatorios", True), ("Sulfametoxazol/Trimetoprima", "sulfas", True),
    ("Paracetamol", "AINE", False), ("Azitromicina", "penicilina", False), ("Paracetamol", "látex", False), ("Aspirina", "ASPIRINA", True),
])
def test_diccionario_de_choques(med, alergia, esperado):
    assert choca(med, alergia) is esperado


def test_dui_congelado_no_emite_ni_despacha(client, firmado, farmacia, paciente):
    dui = paciente["dui"]
    abrir(client, firmado, dui)
    rx = emitir(client, firmado, dui).json()
    r, _ = ml(client, dui)  # Medicina Legal registra el fallecimiento
    assert r.status_code == 200, r.text
    r = emitir(client, firmado, dui)
    assert r.status_code == 423
    assert "RECETA_EMISION_DENEGADA" in acciones_auditoria(paciente_id(dui)) or sql(
        "SELECT 1 FROM auditoria WHERE accion = 'RECETA_EMISION_DENEGADA' AND detalle->>'paciente_id' = :p", p=paciente_id(dui))
    # una receta emitida antes de la muerte tampoco se despacha
    assert client.post("/farmacia/recetas/despachar", json=canje(rx), headers=farmacia).status_code == 423
    assert sql("SELECT estado FROM receta WHERE folio = :f", f=rx["folio"]) == [("EMITIDA",)]
    # ni siquiera saltando la API: el trigger de PostgreSQL lo impide
    with pytest.raises(IntegrityError, match="fallecido"):
        with SessionLocal() as db:
            db.execute(text("INSERT INTO despacho (id, receta_id, farmacia_id, despachado_en, hash_receta) "
                            "SELECT gen_random_uuid(), r.id, (SELECT id FROM institucion WHERE nit = :n), now(), r.hash_payload FROM receta r WHERE r.folio = :f"),
                       {"n": NIT_FARMACIA, "f": rx["folio"]})
            db.commit()


def test_receta_vencida_se_bloquea(client, firmado, farmacia, paciente):
    abrir(client, firmado, paciente["dui"])
    rx = emitir(client, firmado, paciente["dui"], vigencia_dias=1).json()
    with SessionLocal() as db:  # envejece la receta saltando los triggers (solo superusuario, solo en la prueba)
        db.execute(text("SET LOCAL session_replication_role = replica"))
        db.execute(text("UPDATE receta SET emitida_en = now() - interval '3 days', vigente_hasta = now() - interval '2 days' WHERE folio = :f"), {"f": rx["folio"]})
        db.commit()
    v = client.post("/farmacia/recetas/consulta", json=canje(rx), headers=farmacia).json()
    assert v["vigente"] is False and "RECETA_VENCIDA" in v["motivos_bloqueo"]
    r = client.post("/farmacia/recetas/despachar", json=canje(rx), headers=farmacia)
    assert r.status_code == 409 and "RECETA_VENCIDA" in r.json()["detail"]["motivos"]


def test_despacho_simultaneo_solo_uno_gana(client, firmado, farmacia, paciente):
    abrir(client, firmado, paciente["dui"])
    rx = emitir(client, firmado, paciente["dui"]).json()
    n, barrera, codigos = 8, threading.Barrier(8), []

    def intento():
        with TestClient(app, client=("127.0.0.1", 50001)) as c:
            barrera.wait()
            codigos.append(c.post("/farmacia/recetas/despachar", json=canje(rx), headers=farmacia).status_code)

    hilos = [threading.Thread(target=intento) for _ in range(n)]
    [h.start() for h in hilos]
    [h.join() for h in hilos]
    assert sorted(codigos) == [201] + [409] * (n - 1), codigos
    assert sql("SELECT count(*) FROM despacho d JOIN receta r ON r.id = d.receta_id WHERE r.folio = :f", f=rx["folio"]) == [(1,)]
    assert sql("SELECT count(*) FROM auditoria WHERE accion = 'RECETA_DESPACHADA' AND detalle->>'folio' = :f", f=rx["folio"]) == [(1,)]


def test_bloqueo_en_base_de_datos_sin_pasar_por_la_api(client, firmado, farmacia, paciente):
    """Dos conexiones insertan un despacho a la vez: la segunda espera el bloqueo de fila del trigger y luego es rechazada."""
    abrir(client, firmado, paciente["dui"])
    rx = emitir(client, firmado, paciente["dui"]).json()
    ins = text("INSERT INTO despacho (id, receta_id, farmacia_id, despachado_en, hash_receta) "
               "SELECT gen_random_uuid(), r.id, (SELECT id FROM institucion WHERE nit = :n), now(), r.hash_payload FROM receta r WHERE r.folio = :f")
    p = {"n": NIT_FARMACIA, "f": rx["folio"]}
    resultado = {}

    def segunda():
        try:
            with SessionLocal() as db:
                db.execute(ins, p)
                db.commit()
            resultado["b"] = "OK"
        except IntegrityError as e:
            resultado["b"] = "RECHAZADO"
            resultado["msg"] = str(e.orig)

    a = SessionLocal()
    a.execute(ins, p)  # A inserta sin confirmar: retiene el bloqueo de la fila de la receta
    t = threading.Thread(target=segunda)
    t.start()
    time.sleep(0.7)
    assert t.is_alive(), "B debía quedar esperando el bloqueo de A"
    a.commit()
    a.close()
    t.join(5)
    assert resultado["b"] == "RECHAZADO" and ("no disponible" in resultado["msg"] or "uq_despacho" in resultado["msg"])
    assert sql("SELECT count(*) FROM despacho d JOIN receta r ON r.id = d.receta_id WHERE r.folio = :f", f=rx["folio"]) == [(1,)]
    with pytest.raises(Exception, match="inmutable"):  # el despacho tampoco se altera ni se borra
        with SessionLocal() as db:
            db.execute(text("DELETE FROM despacho WHERE receta_id = (SELECT id FROM receta WHERE folio = :f)"), {"f": rx["folio"]})
            db.commit()
