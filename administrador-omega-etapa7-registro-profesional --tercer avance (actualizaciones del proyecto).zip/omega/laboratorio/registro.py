"""Inyecta la sección `resultados` en el expediente sin que core_expediente dependa de este módulo."""
from core_expediente import service as expediente

from .models import ResultadoLab

expediente.MODELOS["resultados"] = ResultadoLab
expediente.PLANOS["resultados"] = ("orden_folio", "tipo_estudio", "responsable", "hay_critico", "valores", "observaciones")
if "resultados" not in expediente.SECCIONES_RESUMEN:
    expediente.SECCIONES_RESUMEN.append("resultados")
