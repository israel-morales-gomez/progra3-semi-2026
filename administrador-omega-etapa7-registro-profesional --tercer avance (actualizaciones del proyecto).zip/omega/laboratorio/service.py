import hashlib
import json
import secrets
from datetime import date

from core_expediente.constantes import normalizar_texto

from .schemas import ValorIn, ValorOut

# Estudios cuyo resultado es de nivel 4 (se guarda cifrado). Ampliable.
ESTUDIOS_N4 = ("vih", "hiv", "carga viral", "cd4", "genetic", "adn", "cariotipo", "toxicolog", "psicotr", "embarazo")


def nuevo_folio_orden() -> str:
    return f"OL-{secrets.token_hex(5).upper()}"


def nivel_orden(nombres: list[str], confidencial: bool) -> int:
    return 4 if confidencial or any(k in normalizar_texto(n) for n in nombres for k in ESTUDIOS_N4) else 2


def calcular_bandera(v: ValorIn) -> tuple[str, bool]:
    """Numéricos: la bandera sale de los rangos (el laboratorio no puede 'esconder' un crítico con una bandera manual). Texto: la indica el laboratorio."""
    if v.valor_numerico is not None:
        x = v.valor_numerico
        if v.critico_min is not None and x < v.critico_min:
            return "CRITICO_BAJO", True
        if v.critico_max is not None and x > v.critico_max:
            return "CRITICO_ALTO", True
        if v.ref_min is not None and x < v.ref_min:
            return "BAJO", False
        if v.ref_max is not None and x > v.ref_max:
            return "ALTO", False
        return "NORMAL", False
    b = v.bandera or "NORMAL"
    return b, b == "CRITICO"


def valores_con_bandera(valores: list[ValorIn]) -> list[dict]:
    out = []
    for v in valores:
        bandera, critico = calcular_bandera(v)
        out.append({**v.model_dump(exclude={"bandera"}), "bandera": bandera, "critico": critico})
    return out


def hash_contenido(contenido: dict | str) -> str:
    base = contenido if isinstance(contenido, str) else json.dumps(contenido, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
    return hashlib.sha256(base.encode()).hexdigest()


def edad(nacimiento: date | None, hoy: date) -> int | None:
    if nacimiento is None:
        return None
    return hoy.year - nacimiento.year - ((hoy.month, hoy.day) < (nacimiento.month, nacimiento.day))


def a_valor_out(d: dict) -> ValorOut:
    return ValorOut(**d)
