from fastapi import Depends, HTTPException

from omega_core.deps import institucion_actual
from omega_core.models import Institucion


def laboratorio_actual(inst: Institucion = Depends(institucion_actual)) -> Institucion:
    if inst.tipo != "LABORATORIO":
        raise HTTPException(403, "Solo laboratorios autorizados")
    return inst
