import uuid
from datetime import datetime

from sqlalchemy import Boolean, CheckConstraint, DateTime, ForeignKey, Index, Integer, SmallInteger, String, Text, Uuid
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from core_expediente.models import _NIVEL_OK, RegistroBase, _coherencia
from omega_core.constantes import en_lista
from omega_core.models.base import Base, ahora

TIPOS_ORDEN = ("LABORATORIO", "IMAGENOLOGIA")
ESTADOS_ORDEN = ("PENDIENTE", "COMPLETADA", "CANCELADA")
PRIORIDADES = ("RUTINA", "URGENTE")
MODALIDADES = ("RX", "US", "TC", "RM", "MAMOGRAFIA", "OTRO")


def _fk(tabla: str, **kw):
    return mapped_column(Uuid, ForeignKey(f"{tabla}.id", ondelete="RESTRICT"), **kw)


class OrdenLab(Base):
    """Orden de laboratorio o imagenología. Inmutable salvo `estado` (PENDIENTE → COMPLETADA | CANCELADA), controlado por trigger."""

    __tablename__ = "orden_lab"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    folio: Mapped[str] = mapped_column(String(20), unique=True)
    tipo: Mapped[str] = mapped_column(String(12))
    paciente_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    medico_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    institucion_emisora_id: Mapped[uuid.UUID] = _fk("institucion")
    laboratorio_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    atencion_id: Mapped[uuid.UUID] = _fk("atencion")
    prioridad: Mapped[str] = mapped_column(String(10), default="RUTINA")
    nivel_sensibilidad: Mapped[int] = mapped_column(SmallInteger, default=2)  # 4 = el resultado se guarda cifrado
    estado: Mapped[str] = mapped_column(String(12), default="PENDIENTE")
    creada_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    completada_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        CheckConstraint(en_lista("tipo", TIPOS_ORDEN), name="tipo_valido"),
        CheckConstraint(en_lista("estado", ESTADOS_ORDEN), name="estado_valido"),
        CheckConstraint(en_lista("prioridad", PRIORIDADES), name="prioridad_valida"),
        CheckConstraint("nivel_sensibilidad IN (2, 4)", name="nivel_valido"),
        Index("ix_orden_lab_pendientes", "laboratorio_id", "paciente_id", "estado"),
    )


class OrdenLabItem(Base):
    __tablename__ = "orden_lab_item"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    orden_id: Mapped[uuid.UUID] = _fk("orden_lab", index=True)
    n: Mapped[int] = mapped_column(SmallInteger)
    nombre: Mapped[str] = mapped_column(String(120))
    codigo: Mapped[str | None] = mapped_column(String(20))
    modalidad: Mapped[str | None] = mapped_column(String(12))
    __table_args__ = (
        Index("uq_orden_lab_item_n", "orden_id", "n", unique=True),
        CheckConstraint("modalidad IS NULL OR " + en_lista("modalidad", MODALIDADES), name="modalidad_valida"),
    )


class ResultadoLab(RegistroBase, Base):
    """Resultado estructurado INYECTADO al expediente (misma mecánica que los demás registros: nivel 4 cifrado con Fernet).
    Quien lo sube es una institución (laboratorio), no una persona: `institucion_id` = laboratorio y `registrado_por` queda NULL."""

    __tablename__ = "resultado_lab"
    registrado_por: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"), nullable=True)
    orden_id: Mapped[uuid.UUID] = _fk("orden_lab", unique=True)  # una orden, un solo resultado
    orden_folio: Mapped[str] = mapped_column(String(20))
    tipo_estudio: Mapped[str] = mapped_column(String(12))
    responsable: Mapped[str] = mapped_column(String(150))
    hay_critico: Mapped[bool] = mapped_column(Boolean, default=False)
    valores: Mapped[list | None] = mapped_column(JSONB(none_as_null=True))  # NULL cuando es nivel 4 (viaja en contenido_cifrado)
    observaciones: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (_NIVEL_OK, _coherencia("cifrado_coherente", ["valores", "observaciones"]))


class AlertaCritica(Base):
    """Alerta para el médico que pidió la orden cuando un resultado trae valores críticos."""

    __tablename__ = "alerta_critica"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    resultado_id: Mapped[uuid.UUID] = _fk("resultado_lab", unique=True)
    orden_id: Mapped[uuid.UUID] = _fk("orden_lab")
    orden_folio: Mapped[str] = mapped_column(String(20))
    tipo_estudio: Mapped[str] = mapped_column(String(12))
    medico_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    paciente_id: Mapped[uuid.UUID] = _fk("persona")
    nivel_sensibilidad: Mapped[int] = mapped_column(SmallInteger)
    n_criticos: Mapped[int] = mapped_column(Integer)
    detalle: Mapped[list | None] = mapped_column(JSONB(none_as_null=True))  # valores críticos; NULL si la orden es nivel 4 (se abre el resultado con justificación)
    estado: Mapped[str] = mapped_column(String(12), default="PENDIENTE")
    creada_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    reconocida_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    comentario: Mapped[str | None] = mapped_column(String(500))
    __table_args__ = (
        CheckConstraint("estado IN ('PENDIENTE', 'RECONOCIDA')", name="estado_valido"),
        CheckConstraint("nivel_sensibilidad < 4 OR detalle IS NULL", name="n4_sin_detalle"),
        Index("ix_alerta_critica_medico_estado", "medico_id", "estado"),
    )
