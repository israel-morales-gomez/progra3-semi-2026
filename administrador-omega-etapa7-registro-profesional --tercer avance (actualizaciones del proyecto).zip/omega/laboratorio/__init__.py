"""Módulo laboratorio e imagenología: órdenes del médico, consulta restringida del laboratorio y resultados estructurados inyectados al expediente."""
