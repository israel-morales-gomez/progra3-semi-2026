import uuid
from datetime import timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import exists, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from core_expediente.deps import Profesional, medico_activo
from core_expediente.models import Atencion, Defuncion
from core_expediente.service import dui_o_422, esta_congelado, identidad_minima
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Institucion, Persona
from omega_core.models.base import ahora
from omega_core.security.campos import cifrar_json
from omega_core.security.ratelimit import ip_cliente, limitador, limitar_ip

from . import registro  # noqa: F401  (inyecta la sección `resultados` en el expediente)
from . import service
from .deps import laboratorio_actual
from .models import AlertaCritica, OrdenLab, OrdenLabItem, ResultadoLab
from .schemas import (
    AlertaCriticaOut, CrearOrdenIn, EstudioOut, LabDirectorioOut, OrdenOut, OrdenPendienteOut, PacienteLabOut, ReconocerIn, ResultadoOut,
    SubirResultadoIn,
)

medico_router = APIRouter(prefix="/laboratorio", tags=["laboratorio · órdenes y alertas críticas (médico)"])
lab_router = APIRouter(prefix="/laboratorio", tags=["laboratorio · consulta de pendientes y resultados (laboratorio)"])
ERR_M = {401: {"description": "No autenticado"}, 403: {"description": "No es médico verificado / sin atención activa del paciente"},
         404: {"description": "Laboratorio destino no válido"}, 409: {"description": "Atención fuera de fase 3/4"}, 423: {"description": "DUI congelado por fallecimiento"}}
ERR_L = {401: {"description": "No autenticado"}, 403: {"description": "Solo laboratorios activos"}, 404: {"description": "Orden no encontrada (también si es de otro laboratorio)"},
         409: {"description": "Orden ya completada/cancelada o resultado incompleto"}, 423: {"description": "Paciente fallecido"}, 429: {"description": "Demasiadas consultas"}}


def _estudios(db: Session, orden_id: uuid.UUID) -> list[OrdenLabItem]:
    return list(db.scalars(select(OrdenLabItem).where(OrdenLabItem.orden_id == orden_id).order_by(OrdenLabItem.n)))


def _est_out(items) -> list[EstudioOut]:
    return [EstudioOut(n=i.n, nombre=i.nombre, codigo=i.codigo, modalidad=i.modalidad) for i in items]


# ------------------------------------------------------------------ Médico
@medico_router.get("/directorio", response_model=list[LabDirectorioOut], responses=ERR_M, summary="Laboratorios y centros de imagen activos",
                   description="Para elegir el destino de una orden. Solo datos públicos del establecimiento.")
def directorio(med: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    filas = db.execute(select(Institucion.id, Institucion.nombre_legal, Institucion.departamento, Institucion.municipio)
                       .where(Institucion.tipo == "LABORATORIO", Institucion.estado == "ACTIVA").order_by(Institucion.nombre_legal).limit(200)).all()
    return [LabDirectorioOut(id=f.id, nombre=f.nombre_legal, departamento=f.departamento, municipio=f.municipio) for f in filas]


@medico_router.post("/ordenes", response_model=OrdenOut, status_code=201, responses=ERR_M, summary="Crear una orden de laboratorio o imagenología",
                    description="Solo médicos verificados, con **atención abierta (fase 3 o 4)** del paciente en su institución. **No se crean órdenes para un DUI congelado por fallecimiento (423).** "
                                "La orden contiene únicamente los estudios solicitados (sin diagnóstico ni indicación clínica) y queda en la bitácora.")
def crear_orden(datos: CrearOrdenIn, request: Request, med: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    return crear_orden_lab(db, med, datos, ip_cliente(request))


def crear_orden_lab(db: Session, med: Profesional, datos: CrearOrdenIn, ip: str, *, antes_commit=None, auditoria_extra: dict | None = None) -> OrdenOut:
    """Crea la orden a nombre de `med`. `antes_commit(db, orden)` corre en la MISMA transacción (lo usa la co-firma de borradores de estudiantes)."""
    yo = med.persona.id

    def denegar(codigo: int, msg: str, motivo: str, pid=None):
        auditar("ORDEN_LAB_DENEGADA", actor_tipo="persona", actor_id=yo, recurso="orden_lab", resultado="FALLO", ip=ip, detalle={"motivo": motivo, "paciente_id": pid})
        raise HTTPException(codigo, msg)

    ident = identidad_minima(db, dui_o_422(datos.dui))
    if ident is None:
        denegar(403, "Sin acceso a este paciente", "PACIENTE_NO_ACCESIBLE")
    if esta_congelado(db, ident.id):
        denegar(423, "Expediente congelado: el paciente figura como fallecido. No se pueden crear órdenes.", "DUI_CONGELADO", ident.id)
    at = db.execute(select(Atencion.id, Atencion.fase).where(Atencion.paciente_id == ident.id, Atencion.institucion_id == med.institucion_id,
                                                             Atencion.estado == "ABIERTA")).first()
    if at is None:
        denegar(403, "Sin acceso a este paciente: requiere atención activa en su institución", "SIN_ATENCION_ACTIVA", ident.id)
    if at.fase not in (3, 4):
        denegar(409, "Las órdenes se crean durante la ejecución o la trazabilidad de la atención (fase 3 o 4)", "FASE_INVALIDA", ident.id)
    lab = db.execute(select(Institucion.id, Institucion.nombre_legal, Institucion.departamento, Institucion.municipio)
                     .where(Institucion.id == datos.laboratorio_id, Institucion.tipo == "LABORATORIO", Institucion.estado == "ACTIVA")).first()
    if lab is None:
        raise HTTPException(404, "Laboratorio destino no encontrado o inactivo")
    nivel = service.nivel_orden([e.nombre for e in datos.estudios], datos.confidencial)
    o = OrdenLab(folio=service.nuevo_folio_orden(), tipo=datos.tipo, paciente_id=ident.id, medico_id=yo, institucion_emisora_id=med.institucion_id,
                 laboratorio_id=lab.id, atencion_id=at.id, prioridad=datos.prioridad, nivel_sensibilidad=nivel)
    db.add(o)
    db.flush()
    for n, e in enumerate(datos.estudios, 1):
        db.add(OrdenLabItem(orden_id=o.id, n=n, nombre=e.nombre, codigo=e.codigo, modalidad=e.modalidad))
    if antes_commit is not None:
        antes_commit(db, o)
    try:
        db.commit()
    except IntegrityError:  # el trigger de PostgreSQL también impide órdenes para DUI congelado
        db.rollback()
        denegar(423, "Expediente congelado: el paciente figura como fallecido. No se pueden crear órdenes.", "DUI_CONGELADO", ident.id)
    auditar("ORDEN_LAB_CREADA", actor_tipo="persona", actor_id=yo, recurso="orden_lab", recurso_id=o.id, ip=ip,
            detalle={"folio": o.folio, "tipo": o.tipo, "paciente_id": ident.id, "laboratorio_id": lab.id, "estudios": len(datos.estudios),
                     "prioridad": o.prioridad, "nivel": nivel, **(auditoria_extra or {})})
    return OrdenOut(id=o.id, folio=o.folio, tipo=o.tipo, estado=o.estado, prioridad=o.prioridad, nivel_sensibilidad=nivel, creada_en=o.creada_en,
                    laboratorio=LabDirectorioOut(id=lab.id, nombre=lab.nombre_legal, departamento=lab.departamento, municipio=lab.municipio),
                    estudios=[EstudioOut(n=n, **e.model_dump()) for n, e in enumerate(datos.estudios, 1)])


@medico_router.get("/ordenes", response_model=list[OrdenOut], responses=ERR_M, summary="Las órdenes que yo creé",
                   description="Solo las órdenes creadas por el médico autenticado, con su estado (PENDIENTE / COMPLETADA / CANCELADA).")
def mis_ordenes(estado: str | None = Query(None, pattern="^(PENDIENTE|COMPLETADA|CANCELADA)$"), limite: int = Query(50, ge=1, le=200),
                med: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    q = select(OrdenLab).where(OrdenLab.medico_id == med.persona.id).order_by(OrdenLab.creada_en.desc()).limit(limite)
    if estado:
        q = q.where(OrdenLab.estado == estado)
    out = []
    for o in db.scalars(q):
        lab = db.execute(select(Institucion.nombre_legal, Institucion.departamento, Institucion.municipio).where(Institucion.id == o.laboratorio_id)).one()
        out.append(OrdenOut(id=o.id, folio=o.folio, tipo=o.tipo, estado=o.estado, prioridad=o.prioridad, nivel_sensibilidad=o.nivel_sensibilidad,
                            creada_en=o.creada_en, completada_en=o.completada_en, estudios=_est_out(_estudios(db, o.id)),
                            laboratorio=LabDirectorioOut(id=o.laboratorio_id, nombre=lab.nombre_legal, departamento=lab.departamento, municipio=lab.municipio)))
    return out


@medico_router.get("/alertas-criticas", response_model=list[AlertaCriticaOut], responses=ERR_M, summary="Alertas de valores críticos de MIS órdenes",
                   description="Cada resultado con valores críticos genera una alerta para el médico que pidió la orden (y solo para él). Las órdenes de nivel 4 muestran la alerta "
                               "sin los valores (`restringido=true`): ábralos desde el expediente con justificación.")
def alertas(estado: str = Query("PENDIENTE", pattern="^(PENDIENTE|RECONOCIDA)$"), request: Request = None, med: Profesional = Depends(medico_activo),
            db: Session = Depends(get_db)):
    filas = db.execute(select(AlertaCritica, Persona.dui, Persona.nombres, Persona.apellidos).join(Persona, Persona.id == AlertaCritica.paciente_id)
                       .where(AlertaCritica.medico_id == med.persona.id, AlertaCritica.estado == estado).order_by(AlertaCritica.creada_en.desc()).limit(100)).all()
    auditar("ALERTA_CRITICA_CONSULTADA", actor_tipo="persona", actor_id=med.persona.id, recurso="alerta_critica", ip=ip_cliente(request), detalle={"estado": estado, "devueltas": len(filas)})
    return [AlertaCriticaOut(id=a.id, orden_folio=a.orden_folio, tipo_estudio=a.tipo_estudio, paciente_dui=dui, paciente_nombre=f"{nom} {ape}", creada_en=a.creada_en,
                             estado=a.estado, n_criticos=a.n_criticos, restringido=a.nivel_sensibilidad >= 4, valores_criticos=a.detalle, reconocida_en=a.reconocida_en)
            for a, dui, nom, ape in filas]


@medico_router.post("/alertas-criticas/{alerta_id}/reconocer", response_model=AlertaCriticaOut, responses=ERR_M, summary="Reconocer una alerta crítica",
                    description="El médico confirma que la vio (y opcionalmente la conducta). Solo el médico que pidió la orden; queda en la bitácora.")
def reconocer(alerta_id: uuid.UUID, datos: ReconocerIn, request: Request, med: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    a = db.scalar(select(AlertaCritica).where(AlertaCritica.id == alerta_id, AlertaCritica.medico_id == med.persona.id).with_for_update())
    if a is None:
        raise HTTPException(404, "Alerta no encontrada")
    if a.estado == "PENDIENTE":
        a.estado, a.reconocida_en, a.comentario = "RECONOCIDA", ahora(), datos.comentario
        db.commit()
        auditar("ALERTA_CRITICA_RECONOCIDA", actor_tipo="persona", actor_id=med.persona.id, recurso="alerta_critica", recurso_id=a.id, ip=ip_cliente(request),
                detalle={"orden_folio": a.orden_folio, "comentario": datos.comentario})
    p = db.execute(select(Persona.dui, Persona.nombres, Persona.apellidos).where(Persona.id == a.paciente_id)).one()
    return AlertaCriticaOut(id=a.id, orden_folio=a.orden_folio, tipo_estudio=a.tipo_estudio, paciente_dui=p.dui, paciente_nombre=f"{p.nombres} {p.apellidos}",
                            creada_en=a.creada_en, estado=a.estado, n_criticos=a.n_criticos, restringido=a.nivel_sensibilidad >= 4, valores_criticos=a.detalle,
                            reconocida_en=a.reconocida_en)


# ------------------------------------------------------------------ Laboratorio
@lab_router.get("/pendientes/{dui}", response_model=list[OrdenPendienteOut], responses=ERR_L, summary="Órdenes PENDIENTES de un paciente, dirigidas a mi laboratorio",
                description="El laboratorio consulta por DUI y recibe **solo las órdenes pendientes vinculadas a su institución**, con nombre, DUI y edad del paciente y la lista de estudios. "
                            "**Lectura restringida a la orden**: nunca diagnósticos, notas, antecedentes, alergias, signos vitales ni órdenes de otros laboratorios. "
                            "Si no hay órdenes (o el DUI no existe, o el paciente falleció) la respuesta es una lista vacía: no permite sondear DUIs.")
def pendientes(dui: str, request: Request, lab: Institucion = Depends(laboratorio_actual), db: Session = Depends(get_db)):
    limitar_ip(request, "lab_consulta", 120)
    espera = limitador.golpe(f"lab:{lab.id}", 120, 60)
    if espera:
        raise HTTPException(429, "Demasiadas consultas. Intente más tarde.", headers={"Retry-After": str(espera)})
    p = db.execute(select(Persona.id, Persona.dui, Persona.nombres, Persona.apellidos, Persona.fecha_nacimiento).where(Persona.dui == dui_o_422(dui))).first()
    ordenes = []
    if p is not None:
        ordenes = list(db.scalars(select(OrdenLab).where(
            OrdenLab.laboratorio_id == lab.id, OrdenLab.paciente_id == p.id, OrdenLab.estado == "PENDIENTE",
            ~exists().where(Defuncion.persona_id == p.id, Defuncion.vigente.is_(True))).order_by(OrdenLab.prioridad.desc(), OrdenLab.creada_en)))
    auditar("LAB_CONSULTA_PENDIENTES", actor_tipo="institucion", actor_id=lab.id, recurso="orden_lab", recurso_id=p.id if p else None, ip=ip_cliente(request),
            detalle={"ordenes": [o.folio for o in ordenes]})
    if not ordenes:
        return []
    paciente = PacienteLabOut(dui=p.dui, nombre=f"{p.nombres} {p.apellidos}", edad_anios=service.edad(p.fecha_nacimiento, ahora().astimezone(timezone.utc).date()))
    return [OrdenPendienteOut(folio=o.folio, tipo=o.tipo, prioridad=o.prioridad, creada_en=o.creada_en, paciente=paciente, estudios=_est_out(_estudios(db, o.id)))
            for o in ordenes]


@lab_router.post("/ordenes/{folio}/resultados", response_model=ResultadoOut, status_code=201, responses=ERR_L, summary="Subir resultados estructurados y completar la orden",
                 description="El laboratorio sube valores numéricos (con rangos de referencia y límites críticos) o de texto (imagenología) que cubran **todos** los estudios de la orden. "
                             "El servidor calcula las **banderas** (NORMAL/BAJO/ALTO/CRITICO_BAJO/CRITICO_ALTO). El resultado se **inyecta al expediente** (sección `resultados`; cifrado Fernet si es nivel 4), "
                             "queda en la bitácora y, si hay valores críticos, **genera una alerta para el médico que pidió la orden**. "
                             "**Una orden solo se completa una vez** (fila bloqueada + UNIQUE + trigger): el segundo intento recibe 409. 423 si el paciente falleció.")
def subir_resultado(folio: str, datos: SubirResultadoIn, request: Request, lab: Institucion = Depends(laboratorio_actual), db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    o = db.scalar(select(OrdenLab).where(OrdenLab.folio == folio.strip().upper(), OrdenLab.laboratorio_id == lab.id).with_for_update())
    if o is None:
        raise HTTPException(404, "Orden no encontrada en su laboratorio")
    oid, ofolio = o.id, o.folio

    def bloquear(codigo: int, motivo: str, msg: str):
        db.rollback()
        auditar("RESULTADO_LAB_RECHAZADO", actor_tipo="institucion", actor_id=lab.id, recurso="orden_lab", recurso_id=oid, resultado="FALLO", ip=ip,
                detalle={"folio": ofolio, "motivo": motivo})
        raise HTTPException(codigo, {"mensaje": msg, "motivos": [motivo]} if codigo == 409 else msg)

    if o.estado != "PENDIENTE":
        bloquear(409, "ORDEN_YA_COMPLETADA" if o.estado == "COMPLETADA" else "ORDEN_CANCELADA", "La orden ya no está pendiente: no se puede completar de nuevo")
    if esta_congelado(db, o.paciente_id):
        bloquear(423, "PACIENTE_FALLECIDO", "El paciente figura como fallecido: no se admiten resultados")
    items = _estudios(db, o.id)
    cubiertos, validos = {v.estudio for v in datos.valores}, {i.n for i in items}
    if cubiertos - validos:
        raise HTTPException(422, f"Estudios inexistentes en la orden: {sorted(cubiertos - validos)}")
    if validos - cubiertos:
        raise HTTPException(409, {"mensaje": "El resultado debe cubrir todos los estudios de la orden", "motivos": ["RESULTADO_INCOMPLETO"], "faltan": sorted(validos - cubiertos)})
    valores = service.valores_con_bandera(datos.valores)
    criticos = [v for v in valores if v["critico"]]
    sensibles = {"valores": valores, "observaciones": datos.observaciones or ""}
    nivel4 = o.nivel_sensibilidad >= 4
    token = cifrar_json(sensibles) if nivel4 else None
    r = ResultadoLab(
        paciente_id=o.paciente_id, atencion_id=o.atencion_id, institucion_id=lab.id, registrado_por=None, nivel_sensibilidad=o.nivel_sensibilidad, contenido_cifrado=token,
        hash_contenido=service.hash_contenido(token or {"orden": o.folio, **sensibles}), orden_id=o.id, orden_folio=o.folio, tipo_estudio=o.tipo, responsable=datos.responsable,
        hay_critico=bool(criticos), valores=None if nivel4 else valores, observaciones=None if nivel4 else sensibles["observaciones"])
    db.add(r)
    alerta = None
    try:
        db.flush()  # el trigger resultado_lab_guard valida la orden y la marca COMPLETADA
        if criticos:
            alerta = AlertaCritica(resultado_id=r.id, orden_id=o.id, orden_folio=o.folio, tipo_estudio=o.tipo, medico_id=o.medico_id, paciente_id=o.paciente_id,
                                   nivel_sensibilidad=o.nivel_sensibilidad, n_criticos=len(criticos),
                                   detalle=None if nivel4 else [{k: c[k] for k in ("estudio", "parametro", "valor_numerico", "valor_texto", "unidad", "bandera")} for c in criticos])
            db.add(alerta)
        db.commit()
    except IntegrityError:
        bloquear(409, "ORDEN_YA_COMPLETADA", "La orden ya no está pendiente: no se puede completar de nuevo")
    auditar("RESULTADO_LAB_SUBIDO", actor_tipo="institucion", actor_id=lab.id, recurso="resultado_lab", recurso_id=r.id, ip=ip,
            detalle={"folio": ofolio, "paciente_id": r.paciente_id, "tipo": r.tipo_estudio, "valores": len(valores), "criticos": len(criticos), "nivel": r.nivel_sensibilidad,
                     "hash": r.hash_contenido, "responsable": datos.responsable})
    if alerta is not None:
        auditar("ALERTA_CRITICA_GENERADA", actor_tipo="institucion", actor_id=lab.id, recurso="alerta_critica", recurso_id=alerta.id, ip=ip,
                detalle={"folio": ofolio, "medico_id": o.medico_id, "n_criticos": len(criticos)})
    return ResultadoOut(id=r.id, orden_folio=ofolio, completada_en=r.creado_en, hay_critico=bool(criticos), alerta_critica_generada=alerta is not None,
                        valores=[service.a_valor_out(v) for v in valores])


routers = [medico_router, lab_router]
