import uuid
from datetime import datetime
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from omega_core.schemas import DUI

Tipo = Literal["LABORATORIO", "IMAGENOLOGIA"]
Modalidad = Literal["RX", "US", "TC", "RM", "MAMOGRAFIA", "OTRO"]


class In(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")


class EstudioIn(In):
    nombre: Annotated[str, Field(min_length=2, max_length=120, description="Ej. 'Hemograma completo', 'Radiografía de tórax PA'.")]
    codigo: Annotated[str, Field(max_length=20)] | None = None
    modalidad: Modalidad | None = Field(None, description="Obligatoria en IMAGENOLOGIA; no aplica en LABORATORIO.")


class EstudioOut(EstudioIn):
    n: int


class CrearOrdenIn(In):
    dui: DUI = Field(description="DUI del paciente. Debe tener una atención abierta (fase 3 o 4) en su institución.")
    tipo: Tipo
    laboratorio_id: uuid.UUID = Field(description="Laboratorio/centro de imagen destino (ver GET /laboratorio/directorio).")
    prioridad: Literal["RUTINA", "URGENTE"] = "RUTINA"
    estudios: Annotated[list[EstudioIn], Field(min_length=1, max_length=20)]
    confidencial: bool = Field(False, description="Fuerza nivel 4: el resultado se guarda cifrado. Estudios de VIH, genéticos o toxicológicos son nivel 4 automáticamente.")

    @model_validator(mode="after")
    def _modalidad(self):
        for e in self.estudios:
            if self.tipo == "IMAGENOLOGIA" and e.modalidad is None:
                raise ValueError("En IMAGENOLOGIA cada estudio requiere 'modalidad'")
            if self.tipo == "LABORATORIO" and e.modalidad is not None:
                raise ValueError("'modalidad' solo aplica en IMAGENOLOGIA")
        return self


class LabDirectorioOut(BaseModel):
    id: uuid.UUID
    nombre: str
    departamento: str | None
    municipio: str | None


class OrdenOut(BaseModel):
    id: uuid.UUID
    folio: str
    tipo: str
    estado: str
    prioridad: str
    laboratorio: LabDirectorioOut
    nivel_sensibilidad: int
    creada_en: datetime
    completada_en: datetime | None = None
    estudios: list[EstudioOut]


class PacienteLabOut(BaseModel):
    dui: str
    nombre: str
    edad_anios: int | None


class OrdenPendienteOut(BaseModel):
    """Lo único que ve el laboratorio: qué estudios hacer y a quién. Sin diagnósticos, notas, antecedentes, alergias ni signos vitales."""

    folio: str
    tipo: str
    prioridad: str
    creada_en: datetime
    paciente: PacienteLabOut
    estudios: list[EstudioOut]


class ValorIn(In):
    estudio: Annotated[int, Field(ge=1, le=20, description="Número (n) del estudio de la orden al que pertenece el valor.")]
    parametro: Annotated[str, Field(min_length=1, max_length=120, description="Ej. 'Hemoglobina', 'Hallazgos', 'Conclusión'.")]
    valor_numerico: Annotated[float, Field(allow_inf_nan=False)] | None = None
    valor_texto: Annotated[str, Field(min_length=1, max_length=4000)] | None = None
    unidad: Annotated[str, Field(max_length=30)] | None = None
    ref_min: Annotated[float, Field(allow_inf_nan=False)] | None = Field(None, description="Límite inferior normal.")
    ref_max: Annotated[float, Field(allow_inf_nan=False)] | None = Field(None, description="Límite superior normal.")
    critico_min: Annotated[float, Field(allow_inf_nan=False)] | None = Field(None, description="Por debajo de este valor es CRÍTICO (genera alerta).")
    critico_max: Annotated[float, Field(allow_inf_nan=False)] | None = Field(None, description="Por encima de este valor es CRÍTICO (genera alerta).")
    bandera: Literal["NORMAL", "ANORMAL", "CRITICO"] | None = Field(None, description="Solo para valores de texto (p. ej. imagenología). En los numéricos la bandera la calcula el servidor.")

    @model_validator(mode="after")
    def _coherente(self):
        if (self.valor_numerico is None) == (self.valor_texto is None):
            raise ValueError("Indique exactamente uno: valor_numerico o valor_texto")
        if self.valor_numerico is not None and self.bandera is not None:
            raise ValueError("En valores numéricos la bandera se calcula con ref_min/ref_max/critico_min/critico_max")
        if self.valor_texto is not None and any(x is not None for x in (self.ref_min, self.ref_max, self.critico_min, self.critico_max)):
            raise ValueError("Los rangos solo aplican a valores numéricos")
        pares = [(self.critico_min, self.ref_min), (self.ref_min, self.ref_max), (self.ref_max, self.critico_max), (self.critico_min, self.critico_max)]
        if any(a is not None and b is not None and a > b for a, b in pares):
            raise ValueError("Rangos incoherentes: critico_min ≤ ref_min ≤ ref_max ≤ critico_max")
        return self


class SubirResultadoIn(In):
    responsable: Annotated[str, Field(min_length=2, max_length=150, description="Profesional del laboratorio que valida el resultado.")]
    observaciones: Annotated[str, Field(max_length=2000)] | None = None
    valores: Annotated[list[ValorIn], Field(min_length=1, max_length=300, description="Debe cubrir TODOS los estudios de la orden.")]


class ValorOut(BaseModel):
    estudio: int
    parametro: str
    valor_numerico: float | None
    valor_texto: str | None
    unidad: str | None
    ref_min: float | None
    ref_max: float | None
    critico_min: float | None
    critico_max: float | None
    bandera: Literal["NORMAL", "BAJO", "ALTO", "ANORMAL", "CRITICO_BAJO", "CRITICO_ALTO", "CRITICO"]
    critico: bool


class ResultadoOut(BaseModel):
    id: uuid.UUID
    orden_folio: str
    completada_en: datetime
    hay_critico: bool
    alerta_critica_generada: bool
    valores: list[ValorOut]


class AlertaCriticaOut(BaseModel):
    id: uuid.UUID
    orden_folio: str
    tipo_estudio: str
    paciente_dui: str
    paciente_nombre: str
    creada_en: datetime
    estado: str
    n_criticos: int
    restringido: bool = Field(description="True si la orden es nivel 4: los valores críticos solo se abren desde el expediente con justificación.")
    valores_criticos: list[dict] | None
    reconocida_en: datetime | None


class ReconocerIn(In):
    comentario: Annotated[str, Field(max_length=500)] | None = Field(None, description="Conducta tomada (opcional).")
