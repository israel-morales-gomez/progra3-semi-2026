"""Servicios del expediente: congelamiento por fallecimiento, control de acceso, registros versionados y lectura con nivel 4."""
import hashlib
import json
import secrets
import uuid
from dataclasses import dataclass

from fastapi import HTTPException
from sqlalchemy import exists, or_, select
from sqlalchemy.orm import Session, aliased

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.config import settings
from omega_core.models import Persona
from omega_core.models.base import ahora
from omega_core.security.campos import cifrar_json, descifrar_json
from omega_core.security.ratelimit import limitador
from omega_core.validadores import normalizar_dui

from .constantes import NIVEL_ESTANDAR, NIVEL_ULTRA, nivel_cie10, normalizar_texto
from .deps import Profesional
from .models import (
    Alergia, Antecedente, Atencion, Consentimiento, Defuncion, Diagnostico, Egreso, NotaSoap, SignosVitales,
)
from .schemas import EstadoVitalOut, ItemClinicoOut, SeccionOut

MODELOS = {"antecedentes": Antecedente, "alergias": Alergia, "diagnosticos": Diagnostico,
           "signos_vitales": SignosVitales, "notas": NotaSoap, "egresos": Egreso}
SECCIONES_RESUMEN = ["antecedentes", "alergias", "diagnosticos", "signos_vitales", "egresos"]  # otros módulos (laboratorio) registran las suyas
PLANOS = {  # campos que se muestran (los sensibles de nivel 4 se leen descifrados)
    "antecedentes": ("tipo", "descripcion"),
    "alergias": ("sustancia", "clase", "severidad", "reaccion", "estado"),
    "diagnosticos": ("codigo_cie10", "descripcion", "observaciones", "tipo", "estatus", "principal", "fecha_deteccion"),
    "signos_vitales": ("tomado_en", "ta_sistolica", "ta_diastolica", "fc", "fr", "temperatura", "spo2", "glucemia",
                       "peso_kg", "talla_cm", "imc", "dolor_eva"),
    "notas": ("subjetivo", "objetivo", "analisis", "plan"),
    "egresos": ("tipo_egreso", "condicion", "resumen", "plan_seguimiento", "proximo_control_en"),
}


def nuevo_folio(prefijo: str) -> str:
    return f"{prefijo}-{secrets.token_hex(5).upper()}"


def dui_o_422(dui: str) -> str:
    try:
        return normalizar_dui(dui)
    except ValueError as e:
        raise HTTPException(422, str(e))


def identidad_minima(db: Session, dui: str):
    """Solo id, DUI y nombre: nunca se carga la entidad Persona completa."""
    return db.execute(select(Persona.id, Persona.dui, Persona.nombres, Persona.apellidos).where(Persona.dui == dui)).first()


def esta_congelado(db: Session, paciente_id: uuid.UUID) -> bool:
    return db.scalar(select(Defuncion.id).where(Defuncion.persona_id == paciente_id, Defuncion.vigente.is_(True))) is not None


def asegurar_no_congelado(db: Session, paciente_id: uuid.UUID) -> None:
    """Debe llamarse antes de CUALQUIER escritura sobre un paciente (recetas, citas, registros clínicos...)."""
    if esta_congelado(db, paciente_id):
        raise HTTPException(423, "Expediente congelado: el paciente figura como fallecido. No se admiten recetas, citas ni nuevos registros.")


# ------------------------------------------------------------------ Control de acceso
@dataclass
class Acceso:
    via: str  # ATENCION_ACTIVA | CONSENTIMIENTO | PROPIO
    puede_nivel4: bool
    atencion_id: uuid.UUID | None = None


def resolver_acceso(db: Session, persona_id: uuid.UUID, institucion_id: uuid.UUID, paciente_id: uuid.UUID) -> Acceso | None:
    at = db.execute(select(Atencion.id, Atencion.medico_responsable_id).where(
        Atencion.paciente_id == paciente_id, Atencion.institucion_id == institucion_id, Atencion.estado == "ABIERTA")).first()
    cons = db.execute(select(Consentimiento.profesional_id, Consentimiento.nivel_maximo).where(
        Consentimiento.paciente_id == paciente_id, Consentimiento.revocado_en.is_(None), Consentimiento.vigente_hasta > ahora(),
        or_(Consentimiento.profesional_id == persona_id, Consentimiento.institucion_id == institucion_id))).all()
    # nivel 4: médico responsable de la atención activa, o consentimiento nivel 4 dirigido a este profesional
    nivel4 = (at is not None and at.medico_responsable_id == persona_id) or any(
        c.profesional_id == persona_id and c.nivel_maximo == NIVEL_ULTRA for c in cons)
    if at is not None:
        return Acceso("ATENCION_ACTIVA", nivel4, at.id)
    if cons:
        return Acceso("CONSENTIMIENTO", nivel4)
    return None


def _limitar_lecturas(persona_id: uuid.UUID) -> None:
    espera = limitador.golpe(f"lectura:{persona_id}", settings.expediente_max_lecturas_min, 60)
    if espera:
        raise HTTPException(429, "Demasiadas consultas de expedientes. Intente más tarde.", headers={"Retry-After": str(espera)})


def autorizar_lectura(db: Session, prof: Profesional, dui: str, seccion: str, ip: str):
    """Devuelve (identidad, acceso) o responde 403 (mismo mensaje exista o no el DUI) dejando rastro en la bitácora."""
    _limitar_lecturas(prof.persona.id)
    ident = identidad_minima(db, dui_o_422(dui))
    acceso = resolver_acceso(db, prof.persona.id, prof.institucion_id, ident.id) if ident else None
    if acceso is None:
        auditar("ACCESO_EXPEDIENTE_DENEGADO", actor_tipo="persona", actor_id=prof.persona.id, recurso="expediente",
                recurso_id=ident.id if ident else None, resultado="FALLO", ip=ip, detalle={"seccion": seccion})
        raise HTTPException(403, "Sin acceso al expediente de este paciente: requiere atención activa en su institución o consentimiento del paciente")
    return ident, acceso


def validar_justificacion(justificacion: str | None) -> str | None:
    if justificacion is not None and len(justificacion.strip()) < 10:
        raise HTTPException(422, "La justificación clínica debe tener al menos 10 caracteres")
    return justificacion.strip() if justificacion else None


def auditar_lectura(actor_id, paciente_id, acceso: Acceso, seccion: str, devueltos: int, restringidos: int,
                    abiertos4: int, justificacion: str | None, historial: bool, ip: str) -> None:
    auditar("ACCESO_EXPEDIENTE", actor_tipo="persona", actor_id=actor_id, recurso="expediente", recurso_id=paciente_id, ip=ip,
            detalle={"via": acceso.via, "seccion": seccion, "devueltos": devueltos, "restringidos": restringidos,
                     "nivel4_abierto": abiertos4 > 0, "justificacion": justificacion if abiertos4 else None, "historial": historial})


# ------------------------------------------------------------------ Lectura de secciones
def leer_seccion(db: Session, seccion: str, paciente_id: uuid.UUID, acceso: Acceso, justificacion: str | None,
                 historial: bool, limite: int = 50, offset: int = 0) -> tuple[SeccionOut, int]:
    M = MODELOS[seccion]
    versionable = hasattr(M, "reemplaza_id")
    q = select(M).where(M.paciente_id == paciente_id)
    if versionable and not historial:
        hijo = aliased(M)
        q = q.where(~exists().where(hijo.reemplaza_id == M.id))
    filas = db.scalars(q.order_by(M.creado_en.desc()).limit(limite).offset(offset)).all()
    reemplazados = set()
    if versionable and historial and filas:
        reemplazados = set(db.scalars(select(M.reemplaza_id).where(M.reemplaza_id.in_([f.id for f in filas]))))
    abrir4 = acceso.puede_nivel4 and bool(justificacion)
    items, restringidos, abiertos4 = [], 0, 0
    for f in filas:
        base = {"id": f.id, "nivel_sensibilidad": f.nivel_sensibilidad, "creado_en": f.creado_en}
        if f.nivel_sensibilidad >= NIVEL_ULTRA and not abrir4:
            restringidos += 1
            items.append(ItemClinicoOut(**base, restringido=True, requiere_justificacion=acceso.puede_nivel4))
            continue
        datos = {c: getattr(f, c) for c in PLANOS[seccion]}
        if f.nivel_sensibilidad >= NIVEL_ULTRA:
            datos.update(descifrar_json(f.contenido_cifrado))
            abiertos4 += 1
        items.append(ItemClinicoOut(**base, restringido=False, atencion_id=f.atencion_id, registrado_por=f.registrado_por,
                                    reemplaza_id=getattr(f, "reemplaza_id", None), motivo_correccion=getattr(f, "motivo_correccion", None),
                                    vigente=f.id not in reemplazados, datos=datos))
    return SeccionOut(seccion=seccion, devueltos=len(items), restringidos=restringidos, items=items), abiertos4


def estado_vital(db: Session, paciente_id: uuid.UUID) -> EstadoVitalOut:
    d = db.scalar(select(Defuncion).where(Defuncion.persona_id == paciente_id, Defuncion.vigente.is_(True)))
    if d is None:
        return EstadoVitalOut(estado="VIVO", congelado=False)
    return EstadoVitalOut(estado="FALLECIDO", congelado=True, fallecido_en=d.fallecido_en, causa_oficial=d.causa_oficial,
                          causa_cie10=d.causa_cie10, entidad_certificadora=d.entidad_certificadora, numero_certificado=d.numero_certificado)


def resumen_atenciones(db: Session, paciente_id: uuid.UUID, limite: int = 10) -> list[dict]:
    filas = db.scalars(select(Atencion).where(Atencion.paciente_id == paciente_id).order_by(Atencion.abierta_en.desc()).limit(limite))
    return [{"folio": a.folio, "tipo_atencion": a.tipo_atencion, "area": None if a.sensible_n4 else a.area,
             "institucion_id": str(a.institucion_id), "estado": a.estado, "fase": a.fase, "abierta_en": a.abierta_en,
             "cierre_tipo": a.cierre_tipo} for a in filas]


# ------------------------------------------------------------------ Escritura de registros (inmutables, versionados)
def _hash(valores: dict) -> str:
    return hashlib.sha256(json.dumps(valores, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode()).hexdigest()


def preparar_escritura(db: Session, prof: Profesional, atencion_id: uuid.UUID, *, solo_doctor: bool,
                       fases: tuple[int, ...], correccion: bool) -> Atencion:
    """Bloquea la atención en modo compartido (una transición concurrente espera) y valida estado, fase y congelamiento."""
    if solo_doctor and not prof.es_doctor:
        raise HTTPException(403, "Este registro es exclusivo de médicos")
    at = db.scalar(select(Atencion).where(Atencion.id == atencion_id, Atencion.institucion_id == prof.institucion_id)
                   .with_for_update(read=True))
    if at is None:
        raise HTTPException(404, "Atención no encontrada en su institución")
    asegurar_no_congelado(db, at.paciente_id)
    if not correccion:
        if at.estado != "ABIERTA":
            raise HTTPException(409, "La atención está cerrada: solo se admiten correcciones del autor (reemplaza_id)")
        if at.fase not in fases:
            raise HTTPException(409, f"Este registro solo se admite en fase(s) {list(fases)}; la atención está en fase {at.fase}")
    return at


def _previo(db: Session, Modelo, v, at: Atencion, actor_id: uuid.UUID):
    if v.reemplaza_id is None:
        return None
    prev = db.scalar(select(Modelo).where(Modelo.id == v.reemplaza_id).with_for_update())
    if prev is None or prev.paciente_id != at.paciente_id:
        raise HTTPException(404, "El registro a corregir no existe en este expediente")
    if db.scalar(select(Modelo.id).where(Modelo.reemplaza_id == prev.id)) is not None:
        raise HTTPException(409, "Ese registro ya fue corregido: corrija la versión vigente")
    if actor_id not in (prev.registrado_por, at.medico_responsable_id):
        raise HTTPException(403, "Solo el autor del registro o el médico responsable pueden corregirlo")
    return prev


def _guardar(db: Session, seccion: str, at: Atencion, actor_id: uuid.UUID, nivel: int, plano: dict, sensibles: dict, v, prev):
    Modelo = MODELOS[seccion]
    rid, creado = uuid.uuid4(), ahora()
    if prev is not None:
        nivel = max(nivel, prev.nivel_sensibilidad)  # una corrección nunca baja la sensibilidad
    token = cifrar_json(sensibles) if nivel >= NIVEL_ULTRA else None
    cols = {k: None for k in sensibles} if token else dict(sensibles)
    h = _hash({"seccion": seccion, "id": str(rid), "paciente": str(at.paciente_id), "atencion": str(at.id), "creado_en": creado.isoformat(),
               "nivel": nivel, "reemplaza": str(prev.id) if prev else None, **plano, "sensibles": token or sensibles})
    extra = {"reemplaza_id": prev.id if prev else None, "motivo_correccion": v.motivo_correccion} if hasattr(Modelo, "reemplaza_id") else {}
    row = Modelo(id=rid, paciente_id=at.paciente_id, atencion_id=at.id, institucion_id=at.institucion_id, registrado_por=actor_id,
                 nivel_sensibilidad=nivel, contenido_cifrado=token, hash_contenido=h, creado_en=creado, **plano, **cols, **extra)
    db.add(row)
    db.flush()
    return row


def crear_antecedente(db, at, actor_id, d):
    prev = _previo(db, Antecedente, d, at, actor_id)
    nivel = NIVEL_ULTRA if (d.confidencial or d.tipo == "GENETICO" or at.sensible_n4) else NIVEL_ESTANDAR
    return _guardar(db, "antecedentes", at, actor_id, nivel, {"tipo": d.tipo}, {"descripcion": d.descripcion}, d, prev)


def crear_alergia(db, at, actor_id, d):
    prev = _previo(db, Alergia, d, at, actor_id)
    plano = {"sustancia": normalizar_texto(d.sustancia), "clase": None, "severidad": d.severidad, "reaccion": d.reaccion, "estado": d.estado}
    return _guardar(db, "alergias", at, actor_id, NIVEL_ESTANDAR, plano, {}, d, prev)


def crear_diagnostico(db, at, actor_id, d):
    prev = _previo(db, Diagnostico, d, at, actor_id)
    if d.principal:
        hijo = aliased(Diagnostico)
        otro = db.scalar(select(Diagnostico.id).where(
            Diagnostico.atencion_id == at.id, Diagnostico.principal.is_(True), ~exists().where(hijo.reemplaza_id == Diagnostico.id),
            *( [Diagnostico.id != prev.id] if prev else [] )))
        if otro is not None:
            raise HTTPException(409, "La atención ya tiene un diagnóstico principal vigente: corríjalo con una nueva versión")
    nivel = max(nivel_cie10(d.codigo_cie10), NIVEL_ULTRA if (d.confidencial or at.sensible_n4) else NIVEL_ESTANDAR)
    plano = {"tipo": d.tipo, "estatus": d.estatus, "principal": d.principal, "fecha_deteccion": ahora()}
    sens = {"codigo_cie10": d.codigo_cie10, "descripcion": d.descripcion, "observaciones": d.observaciones}
    return _guardar(db, "diagnosticos", at, actor_id, nivel, plano, sens, d, prev)


def crear_signos(db, at, actor_id, d):
    prev = _previo(db, SignosVitales, d, at, actor_id)
    imc = round(d.peso_kg / ((d.talla_cm / 100) ** 2), 1) if d.peso_kg and d.talla_cm else None
    plano = {"tomado_en": d.tomado_en or ahora(), "ta_sistolica": d.ta_sistolica, "ta_diastolica": d.ta_diastolica, "fc": d.fc, "fr": d.fr,
             "temperatura": d.temperatura, "spo2": d.spo2, "glucemia": d.glucemia, "peso_kg": d.peso_kg, "talla_cm": d.talla_cm,
             "imc": imc, "dolor_eva": d.dolor_eva}
    return _guardar(db, "signos_vitales", at, actor_id, NIVEL_ESTANDAR, plano, {}, d, prev)


def crear_nota(db, at, actor_id, d):
    prev = _previo(db, NotaSoap, d, at, actor_id)
    nivel = NIVEL_ULTRA if (d.confidencial or at.sensible_n4) else NIVEL_ESTANDAR
    sens = {"subjetivo": d.subjetivo, "objetivo": d.objetivo, "analisis": d.analisis, "plan": d.plan}
    return _guardar(db, "notas", at, actor_id, nivel, {}, sens, d, prev)


def crear_egreso(db, at: Atencion, actor_id, e):
    nivel = NIVEL_ULTRA if at.sensible_n4 else NIVEL_ESTANDAR
    plano = {"tipo_egreso": e.tipo_egreso, "condicion": e.condicion_egreso, "proximo_control_en": e.proximo_control_en}
    return _guardar(db, "egresos", at, actor_id, nivel, plano, {"resumen": e.resumen_egreso, "plan_seguimiento": e.plan_seguimiento}, None, None)


def auditar_registro(actor_id, at: Atencion, row, seccion: str, ip: str, extra: dict | None = None) -> None:
    auditar("REGISTRO_CLINICO", actor_tipo="persona", actor_id=actor_id, recurso=seccion, recurso_id=row.id, ip=ip,
            detalle={"atencion_id": at.id, "paciente_id": at.paciente_id, "fase": at.fase, "nivel": row.nivel_sensibilidad,
                     "cifrado": row.contenido_cifrado is not None, "reemplaza_id": getattr(row, "reemplaza_id", None), **(extra or {})})
