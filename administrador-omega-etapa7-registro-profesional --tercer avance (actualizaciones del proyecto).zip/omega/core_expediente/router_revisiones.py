import uuid
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Institucion
from omega_core.models.base import ahora
from omega_core.security.ratelimit import ip_cliente

from .deps import hospital_actual
from .models import Atencion, RevisionBypass
from .schemas import RevisionBypassOut, RevisionCompletarIn

router = APIRouter(prefix="/revisiones-bypass", tags=["Código Rojo · revisión administrativa posterior"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Solo hospitales y clínicas"}, 404: {"description": "No encontrada"},
       409: {"description": "Ya completada"}}


def _out(r: RevisionBypass, folio: str) -> RevisionBypassOut:
    return RevisionBypassOut(id=r.id, atencion_folio=folio, motivo=r.motivo, activada_en=r.activada_en, vence_en=r.vence_en,
                             vencida=r.estado == "PENDIENTE" and ahora() > r.vence_en, estado=r.estado, resultado=r.resultado,
                             comentario=r.comentario, revisada_en=r.revisada_en)


@router.get("", response_model=list[RevisionBypassOut], responses=ERR, summary="Revisiones pendientes de bypass de emergencia",
            description="Todo Código Rojo con bypass obliga a una **revisión administrativa** en un plazo de 48 h (`BYPASS_REVISION_HORAS`). Acceso con la cuenta institucional del hospital/clínica. No expone datos del paciente, solo el folio y el motivo.")
def listar(estado: Literal["PENDIENTE", "COMPLETADA"] = "PENDIENTE", inst: Institucion = Depends(hospital_actual), db: Session = Depends(get_db)):
    filas = db.execute(select(RevisionBypass, Atencion.folio).join(Atencion, Atencion.id == RevisionBypass.atencion_id)
                       .where(RevisionBypass.institucion_id == inst.id, RevisionBypass.estado == estado).order_by(RevisionBypass.vence_en).limit(200)).all()
    return [_out(r, f) for r, f in filas]


@router.post("/{revision_id}/completar", response_model=RevisionBypassOut, responses=ERR, summary="Completar la revisión de un bypass",
             description="Registra el dictamen (`JUSTIFICADO` u `OBSERVADO`) y un comentario. Queda en la bitácora de auditoría.")
def completar(revision_id: uuid.UUID, datos: RevisionCompletarIn, request: Request, inst: Institucion = Depends(hospital_actual),
              db: Session = Depends(get_db)):
    fila = db.execute(select(RevisionBypass, Atencion.folio).join(Atencion, Atencion.id == RevisionBypass.atencion_id)
                      .where(RevisionBypass.id == revision_id, RevisionBypass.institucion_id == inst.id).with_for_update(of=RevisionBypass)).first()
    if fila is None:
        raise HTTPException(404, "Revisión no encontrada")
    r, folio = fila
    if r.estado != "PENDIENTE":
        raise HTTPException(409, "La revisión ya fue completada")
    r.estado, r.resultado, r.comentario, r.revisada_en = "COMPLETADA", datos.resultado, datos.comentario, ahora()
    db.commit()
    auditar("REVISION_BYPASS_COMPLETADA", actor_tipo="institucion", actor_id=inst.id, recurso="atencion", recurso_id=r.atencion_id,
            ip=ip_cliente(request), detalle={"resultado": datos.resultado, "folio": folio, "vencida": ahora() > r.vence_en})
    return _out(r, folio)
