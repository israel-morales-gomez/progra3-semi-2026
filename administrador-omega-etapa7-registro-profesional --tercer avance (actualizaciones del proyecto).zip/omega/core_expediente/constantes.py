import re
import unicodedata
from typing import Literal, get_args

TipoAtencion = Literal["AMBULATORIA", "URGENCIAS", "HOSPITALIZACION", "TELEMEDICINA"]
NivelTriaje = Literal["ROJO", "NARANJA", "AMARILLO", "VERDE", "AZUL"]
TipoEgreso = Literal["ALTA_MEDICA", "TRASLADO", "ALTA_VOLUNTARIA"]
TipoAntecedente = Literal["PERSONAL_PATOLOGICO", "FAMILIAR", "QUIRURGICO", "TRANSFUSIONAL", "GINECO_OBSTETRICO", "HABITOS", "GENETICO"]
Severidad = Literal["LEVE", "MODERADA", "GRAVE", "ANAFILAXIA"]
EstadoAlergia = Literal["ACTIVA", "DESCARTADA"]
TipoDiagnostico = Literal["PRESUNTIVO", "DEFINITIVO"]
EstatusDiagnostico = Literal["ACTIVA", "EN_REMISION", "CURADA"]

TIPOS_ATENCION = get_args(TipoAtencion)
NIVELES_TRIAJE = get_args(NivelTriaje)
TIPOS_EGRESO = get_args(TipoEgreso)
CIERRES = TIPOS_EGRESO + ("FALLECIMIENTO",)
TIPOS_ANTECEDENTE = get_args(TipoAntecedente)
SEVERIDADES = get_args(Severidad)
ESTADOS_ALERGIA = get_args(EstadoAlergia)
TIPOS_DIAGNOSTICO = get_args(TipoDiagnostico)
ESTATUS_DIAGNOSTICO = get_args(EstatusDiagnostico)

# Las 5 fases del algoritmo clínico
FASES = {1: "ADMISION", 2: "PREPARACION", 3: "EJECUCION", 4: "TRAZABILIDAD", 5: "CIERRE"}
# Transiciones normales; el Código Rojo añade 1->3 y 2->3 sin prerrequisitos administrativos.
TRANSICIONES = {(1, 2), (2, 3), (3, 4), (4, 3), (4, 5)}
# Tiempo máximo de espera sugerido por nivel (minutos, escala Manchester)
TIEMPO_MAX_ESPERA_MIN = {"ROJO": 0, "NARANJA": 10, "AMARILLO": 60, "VERDE": 120, "AZUL": 240}

NIVEL_ESTANDAR = 2  # clínico estándar: texto plano en BD, acceso por atención activa/consentimiento
NIVEL_ULTRA = 4     # ultra-sensible (VIH, salud mental, genética): cifrado de campo + justificación

AREAS_SALUD_MENTAL = {"psiquiatria", "psicologia", "psicologia clinica", "salud mental"}


def normalizar_texto(t: str) -> str:
    t = unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode().lower()
    return re.sub(r"\s+", " ", t).strip()


def es_area_salud_mental(area: str) -> bool:
    return normalizar_texto(area) in AREAS_SALUD_MENTAL


_CIE10 = re.compile(r"^[A-TV-Z][0-9]{2}(\.[0-9A-Z]{1,4})?$")
# Prefijos CIE-10 clasificados como nivel 4: salud mental (F), VIH (B20-B24, Z21, R75, Z11.4, Z71.7,
# O98.7), anomalías cromosómicas/genéticas (Q90-Q99). Ajustable en código tras revisión clínica.
_NIVEL4_CIE10 = [re.compile(p) for p in (r"^F\d", r"^B2[0-4]", r"^Z21", r"^R75", r"^O98\.7", r"^Q9\d", r"^Z11\.4", r"^Z71\.7")]


def normalizar_cie10(codigo: str) -> str:
    c = codigo.strip().upper().replace(" ", "")
    if len(c) > 3 and "." not in c:
        c = f"{c[:3]}.{c[3:]}"
    if not _CIE10.match(c):
        raise ValueError("Código CIE-10 inválido (ej. I10, E11.9, J18.9)")
    return c


def nivel_cie10(codigo: str) -> int:
    return NIVEL_ULTRA if any(p.match(codigo) for p in _NIVEL4_CIE10) else NIVEL_ESTANDAR
