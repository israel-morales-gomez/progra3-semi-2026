"""Máquina de estados de las 5 fases del algoritmo clínico.

Cada operación bloquea la fila de la atención (SELECT ... FOR UPDATE), valida la regla de negocio y escribe
atención + historial de transición en la MISMA transacción. Un trigger de PostgreSQL (atencion_guard) vuelve a
validar la transición, de modo que ni un SQL directo puede saltarse la máquina.
"""
import uuid
from datetime import timedelta

from fastapi import HTTPException
from sqlalchemy import exists, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, aliased

from omega_core.config import settings
from omega_core.models import PerfilProfesional, Persona
from omega_core.models.base import ahora
from omega_core.security.campos import cifrar_json

from . import service
from .constantes import FASES, TRANSICIONES, es_area_salud_mental
from .deps import Profesional
from .models import Atencion, AtencionTransicion, Diagnostico, NotaSoap, RevisionBypass, Triaje
from .schemas import AbrirAtencionIn, TransicionIn, TriajeIn


def _bloquear(db: Session, prof: Profesional, atencion_id: uuid.UUID) -> Atencion:
    at = db.scalar(select(Atencion).where(Atencion.id == atencion_id, Atencion.institucion_id == prof.institucion_id).with_for_update())
    if at is None:
        raise HTTPException(404, "Atención no encontrada en su institución")
    return at


def _registrar_transicion(db, at, de, a, actor_id, bypass=False, motivo=None, sistema=False):
    t = AtencionTransicion(atencion_id=at.id, de_fase=de, a_fase=a, actor_id=None if sistema else actor_id,
                           actor_tipo="sistema" if sistema else "persona", bypass=bypass, motivo=motivo)
    db.add(t)
    return t


def _activar_codigo_rojo(db, at: Atencion, actor_id, motivo: str) -> None:
    """Marca Código Rojo y crea la revisión administrativa obligatoria (24-48 h)."""
    at.codigo_rojo = True
    at.nivel_triaje = "ROJO"
    if db.scalar(select(RevisionBypass.id).where(RevisionBypass.atencion_id == at.id)) is None:
        db.add(RevisionBypass(atencion_id=at.id, institucion_id=at.institucion_id, motivo=motivo, activada_por=actor_id,
                              vence_en=ahora() + timedelta(hours=settings.bypass_revision_horas)))


def _doctor_valido(db, medico_id, institucion_id) -> bool:
    return db.scalar(select(PerfilProfesional.persona_id).where(
        PerfilProfesional.persona_id == medico_id, PerfilProfesional.tipo == "DOCTOR", PerfilProfesional.verificado.is_(True),
        PerfilProfesional.institucion_id == institucion_id)) is not None


# ------------------------------------------------------------------ Abrir atención (fase 1, o fase 3 si Código Rojo)
def abrir_atencion(db: Session, prof: Profesional, d: AbrirAtencionIn):
    """Devuelve (atencion, paciente_row, eventos_para_auditar)."""
    pac = service.identidad_minima(db, d.dui)
    if pac is None:
        raise HTTPException(404, "Paciente no registrado en el padrón")
    service.asegurar_no_congelado(db, pac.id)
    sensible = es_area_salud_mental(d.area)
    at = Atencion(
        folio=service.nuevo_folio("AT"), paciente_id=pac.id, institucion_id=prof.institucion_id, tipo_atencion=d.tipo_atencion,
        area=d.area, sensible_n4=sensible, abierta_por=prof.persona.id,
        motivo_consulta=None if sensible else d.motivo_consulta,
        contenido_cifrado=cifrar_json({"motivo_consulta": d.motivo_consulta}) if sensible else None,
        fase=3 if d.codigo_rojo else 1, estado="ABIERTA", codigo_rojo=d.codigo_rojo,
        nivel_triaje="ROJO" if d.codigo_rojo else None,
        medico_responsable_id=prof.persona.id if (d.codigo_rojo and prof.es_doctor) else None,
    )
    eventos = [("ATENCION_ABIERTA", {"folio": at.folio, "tipo": at.tipo_atencion, "fase_inicial": at.fase, "nivel4": sensible})]
    try:
        db.add(at)
        db.flush()
        if d.codigo_rojo:
            _activar_codigo_rojo(db, at, prof.persona.id, d.motivo_codigo_rojo)
            db.add(Triaje(atencion_id=at.id, nivel="ROJO", discriminador="Código Rojo declarado al ingreso",
                          motivo=d.motivo_codigo_rojo, realizado_por=prof.persona.id))
            _registrar_transicion(db, at, None, 3, prof.persona.id, bypass=True, motivo=d.motivo_codigo_rojo)
            eventos.append(("CODIGO_ROJO_ACTIVADO", {"folio": at.folio, "motivo": d.motivo_codigo_rojo, "origen": "ingreso"}))
        else:
            _registrar_transicion(db, at, None, 1, prof.persona.id)
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "El paciente ya tiene una atención abierta en esta institución")
    return at, pac, eventos


# ------------------------------------------------------------------ Triaje
def registrar_triaje(db: Session, prof: Profesional, atencion_id: uuid.UUID, d: TriajeIn):
    at = _bloquear(db, prof, atencion_id)
    service.asegurar_no_congelado(db, at.paciente_id)
    if at.estado != "ABIERTA":
        raise HTTPException(409, "La atención está cerrada")
    if at.fase not in (2, 3, 4):
        raise HTTPException(409, "El triaje se registra en las fases 2 a 4 (use codigo_rojo=true al abrir para emergencias)")
    eventos = []
    if d.nivel == "ROJO":
        era_rojo = at.codigo_rojo
        _activar_codigo_rojo(db, at, prof.persona.id, d.motivo)
        if not era_rojo:
            eventos.append(("CODIGO_ROJO_ACTIVADO", {"folio": at.folio, "motivo": d.motivo, "origen": "triaje"}))
    else:
        at.nivel_triaje = d.nivel
    db.add(Triaje(atencion_id=at.id, nivel=d.nivel, discriminador=d.discriminador, motivo=d.motivo, realizado_por=prof.persona.id))
    eventos.append(("TRIAJE_REGISTRADO", {"folio": at.folio, "nivel": d.nivel, "discriminador": d.discriminador}))
    db.flush()
    return at, eventos


def asumir(db: Session, prof: Profesional, atencion_id: uuid.UUID):
    if not prof.es_doctor:
        raise HTTPException(403, "Solo un médico puede asumir la responsabilidad de la atención")
    at = _bloquear(db, prof, atencion_id)
    service.asegurar_no_congelado(db, at.paciente_id)
    if at.estado != "ABIERTA":
        raise HTTPException(409, "La atención está cerrada")
    if at.medico_responsable_id is not None:
        raise HTTPException(409, "La atención ya tiene médico responsable")
    at.medico_responsable_id = prof.persona.id
    db.flush()
    return at, [("ATENCION_ASUMIDA", {"folio": at.folio})]


# ------------------------------------------------------------------ Transiciones
def transicionar(db: Session, prof: Profesional, atencion_id: uuid.UUID, d: TransicionIn):
    at = _bloquear(db, prof, atencion_id)
    service.asegurar_no_congelado(db, at.paciente_id)
    if at.estado != "ABIERTA":
        raise HTTPException(409, "La atención está cerrada")
    de, a = at.fase, d.a_fase
    permitido = (de, a) in TRANSICIONES or (a == 3 and de in (1, 2) and at.codigo_rojo)
    if not permitido:
        validas = sorted({y for (x, y) in TRANSICIONES if x == de} | ({3} if de in (1, 2) and at.codigo_rojo else set()))
        raise HTTPException(409, f"Transición no permitida: fase {de} ({FASES[de]}) → {a} ({FASES[a]}). Desde la fase {de} puede ir a: {validas}")

    bypass, extra = False, {}
    if (de, a) == (1, 2):
        if d.identidad_verificada:
            at.identidad_verificada = True
        if d.antecedentes_revisados:
            at.antecedentes_revisados = True
        faltan = [n for n, ok in (("identidad_verificada", at.identidad_verificada), ("antecedentes_revisados", at.antecedentes_revisados)) if not ok]
        if faltan:
            raise HTTPException(409, f"Admisión incompleta, confirme: {faltan}")
    elif a == 3 and de in (1, 2):
        responsable = d.medico_id or at.medico_responsable_id or (prof.persona.id if prof.es_doctor else None)
        if d.medico_id and not _doctor_valido(db, d.medico_id, at.institucion_id):
            raise HTTPException(422, "medico_id no corresponde a un médico verificado de esta institución")
        if responsable is not None and not _doctor_valido(db, responsable, at.institucion_id):
            responsable = None
        faltan = []
        if de == 1:
            faltan.append("fase 2 (preparación/triaje) omitida")
        if at.nivel_triaje is None:
            faltan.append("nivel de triaje")
        if responsable is None:
            faltan.append("médico responsable")
        if faltan:
            if not at.codigo_rojo:
                raise HTTPException(409, f"Preparación incompleta: {faltan}")
            if not d.motivo or len(d.motivo) < 10:
                raise HTTPException(422, "Bypass de Código Rojo: el campo 'motivo' (mín. 10 caracteres) es obligatorio")
            bypass = True
        if responsable is not None:
            at.medico_responsable_id = responsable
    elif (de, a) == (3, 4):
        if at.medico_responsable_id is None:
            raise HTTPException(409, "Un médico debe asumir la atención (POST /atenciones/{id}/asumir) antes de pasar a Trazabilidad")
    elif (de, a) == (4, 5):
        if at.medico_responsable_id != prof.persona.id:
            raise HTTPException(403, "Solo el médico responsable puede validar el egreso")
        if d.egreso is None:
            raise HTTPException(422, "El cierre exige 'egreso' con resumen de egreso y plan de seguimiento")
        hijo = aliased(Diagnostico)
        if db.scalar(select(NotaSoap.id).where(NotaSoap.atencion_id == at.id).limit(1)) is None:
            raise HTTPException(409, "Para cerrar se requiere al menos una nota SOAP registrada en la atención")
        if db.scalar(select(Diagnostico.id).where(Diagnostico.atencion_id == at.id, Diagnostico.principal.is_(True),
                                                  ~exists().where(hijo.reemplaza_id == Diagnostico.id)).limit(1)) is None:
            raise HTTPException(409, "Para cerrar se requiere un diagnóstico principal (CIE-10) vigente")
        egreso = service.crear_egreso(db, at, prof.persona.id, d.egreso)
        at.cerrada_en = ahora()
        at.cierre_tipo = d.egreso.tipo_egreso
        at.estado = "CERRADA"
        extra["egreso_id"] = str(egreso.id)

    at.fase = a
    _registrar_transicion(db, at, de, a, prof.persona.id, bypass=bypass, motivo=d.motivo)
    db.flush()
    eventos = [("TRANSICION_FASE", {"folio": at.folio, "de": de, "a": a, "bypass": bypass, "motivo": d.motivo, **extra})]
    if bypass:
        eventos.append(("BYPASS_EMERGENCIA", {"folio": at.folio, "de": de, "a": a, "motivo": d.motivo}))
    if a == 5:
        eventos.append(("ATENCION_CERRADA", {"folio": at.folio, "tipo_cierre": at.cierre_tipo}))
    return at, eventos


# ------------------------------------------------------------------ Cierre automático por fallecimiento
def cerrar_por_fallecimiento(db: Session, paciente_id: uuid.UUID) -> list[Atencion]:
    """Cierra (fase 5, FALLECIMIENTO) toda atención abierta del paciente, dentro de la transacción del llamador."""
    abiertas = db.scalars(select(Atencion).where(Atencion.paciente_id == paciente_id, Atencion.estado == "ABIERTA").with_for_update()).all()
    for at in abiertas:
        de = at.fase
        at.fase, at.estado, at.cierre_tipo, at.cerrada_en = 5, "CERRADA", "FALLECIMIENTO", ahora()
        _registrar_transicion(db, at, de, 5, None, motivo="Fallecimiento registrado: cierre automático", sistema=True)
    db.flush()
    return abiertas
