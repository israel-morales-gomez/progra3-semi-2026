from .router_atenciones import router as atenciones
from .router_camas import router as camas
from .router_estado_vital import router as estado_vital
from .router_expediente import router as expediente
from .router_revisiones import router as revisiones

routers = [atenciones, expediente, estado_vital, revisiones, camas]
