import uuid
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Persona
from omega_core.security.ratelimit import ip_cliente

from . import maquina, service
from .constantes import FASES
from .deps import Profesional, medico_activo, profesional_activo
from .models import Atencion, AtencionTransicion
from .schemas import (
    AbrirAtencionIn, AlergiaIn, AntecedenteIn, AtencionOut, DiagnosticoIn, NotaSoapIn, PacienteMin, RegistroCreadoOut,
    SignosVitalesIn, TransicionIn, TransicionOut, TriajeIn,
)

router = APIRouter(prefix="/atenciones", tags=["atenciones · 5 fases y triaje"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Perfil profesional verificado requerido / sin permiso"},
       404: {"description": "Atención no encontrada en su institución"}, 409: {"description": "Regla de la máquina de estados o del registro violada"},
       422: {"description": "Datos inválidos"}, 423: {"description": "Expediente congelado: paciente fallecido"}}
_PRIORIDAD = {"ROJO": 0, "NARANJA": 1, "AMARILLO": 2, "VERDE": 3, "AZUL": 4, None: 5}


def a_out(at: Atencion, pac, transiciones: list[AtencionTransicion] | None = None) -> AtencionOut:
    return AtencionOut(
        id=at.id, folio=at.folio, paciente=PacienteMin(dui=pac.dui, nombre=f"{pac.nombres} {pac.apellidos}"),
        institucion_id=at.institucion_id, tipo_atencion=at.tipo_atencion, area=at.area, motivo_consulta=at.motivo_consulta,
        motivo_restringido=at.sensible_n4, fase=at.fase, fase_nombre=FASES[at.fase], estado=at.estado, nivel_triaje=at.nivel_triaje,
        codigo_rojo=at.codigo_rojo, identidad_verificada=at.identidad_verificada, antecedentes_revisados=at.antecedentes_revisados,
        medico_responsable_id=at.medico_responsable_id, abierta_en=at.abierta_en, cerrada_en=at.cerrada_en, cierre_tipo=at.cierre_tipo,
        transiciones=None if transiciones is None else [TransicionOut(**{k: getattr(t, k) for k in TransicionOut.model_fields}) for t in transiciones])


def _paciente(db: Session, paciente_id: uuid.UUID):
    return db.execute(select(Persona.dui, Persona.nombres, Persona.apellidos).where(Persona.id == paciente_id)).one()


def _auditar_eventos(actor: Persona, at: Atencion, eventos, request: Request) -> None:
    for accion, detalle in eventos:
        auditar(accion, actor_tipo="persona", actor_id=actor.id, recurso="atencion", recurso_id=at.id, ip=ip_cliente(request),
                detalle={"paciente_id": at.paciente_id, **detalle})


@router.post("", response_model=AtencionOut, status_code=201, responses=ERR, summary="Abrir una atención (fase 1, o fase 3 con Código Rojo)",
             description="Abre el episodio de atención del paciente en su institución. Normalmente nace en **fase 1 (Admisión)**. "
                         "Con `codigo_rojo=true` activa el **bypass de emergencia**: nace en fase 3, omite las validaciones administrativas, "
                         "exige `motivo_codigo_rojo` (queda en la bitácora de auditoría) y crea la revisión administrativa obligatoria. "
                         "Un paciente solo puede tener una atención abierta por institución. Si el área es de salud mental, el motivo y todo el contenido de la atención son de nivel 4 (cifrados).")
def abrir(datos: AbrirAtencionIn, request: Request, prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    if "expediente:escribir" not in prof.persona.permisos:
        raise HTTPException(403, "Sin permiso para registrar atenciones")
    at, pac, eventos = maquina.abrir_atencion(db, prof, datos)
    db.commit()
    _auditar_eventos(prof.persona, at, eventos, request)
    return a_out(at, pac)


@router.get("", response_model=list[AtencionOut], responses=ERR, summary="Atenciones de mi institución (tablero operativo)",
            description="Lista las atenciones de **su institución**, ordenadas por prioridad de triaje. Muestra solo datos operativos (paciente, fase, triaje); nunca contenido clínico.")
def listar(estado: Literal["ABIERTA", "CERRADA"] = "ABIERTA", fase: int | None = Query(None, ge=1, le=5),
           limite: int = Query(50, ge=1, le=200), prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    q = (select(Atencion, Persona.dui, Persona.nombres, Persona.apellidos).join(Persona, Persona.id == Atencion.paciente_id)
         .where(Atencion.institucion_id == prof.institucion_id, Atencion.estado == estado))
    if fase:
        q = q.where(Atencion.fase == fase)
    filas = db.execute(q.order_by(Atencion.abierta_en).limit(limite)).all()
    filas.sort(key=lambda r: (_PRIORIDAD[r[0].nivel_triaje], r[0].abierta_en))
    return [a_out(r[0], r) for r in filas]


@router.get("/{atencion_id}", response_model=AtencionOut, responses=ERR, summary="Detalle de una atención con su historial de transiciones",
            description="Datos operativos de la atención y la línea de tiempo de fases (incluye bypass y cierres automáticos). No incluye contenido clínico.")
def detalle(atencion_id: uuid.UUID, prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    at = db.scalar(select(Atencion).where(Atencion.id == atencion_id, Atencion.institucion_id == prof.institucion_id))
    if at is None:
        raise HTTPException(404, "Atención no encontrada en su institución")
    trs = db.scalars(select(AtencionTransicion).where(AtencionTransicion.atencion_id == at.id).order_by(AtencionTransicion.creado_en)).all()
    return a_out(at, _paciente(db, at.paciente_id), trs)


@router.post("/{atencion_id}/transicion", response_model=AtencionOut, responses=ERR, summary="Avanzar la atención entre las 5 fases",
             description="Máquina de estados transaccional (bloqueo de fila + trigger de PostgreSQL). Transiciones: **1→2** (exige `identidad_verificada` y `antecedentes_revisados`), "
                         "**2→3** (exige triaje y médico responsable), **3→4**, **4→3** (bucle de reevaluación) y **4→5** (cierre: solo el médico responsable, con `egreso`, al menos una nota SOAP y un diagnóstico principal). "
                         "Con Código Rojo activo se permite **1→3 / 2→3 sin prerrequisitos** (bypass): `motivo` obligatorio y auditado. Cada transición queda en la bitácora.")
def transicion(atencion_id: uuid.UUID, datos: TransicionIn, request: Request, prof: Profesional = Depends(profesional_activo),
               db: Session = Depends(get_db)):
    at, eventos = maquina.transicionar(db, prof, atencion_id, datos)
    trs = db.scalars(select(AtencionTransicion).where(AtencionTransicion.atencion_id == at.id).order_by(AtencionTransicion.creado_en)).all()
    db.commit()
    _auditar_eventos(prof.persona, at, eventos, request)
    return a_out(at, _paciente(db, at.paciente_id), trs)


@router.post("/{atencion_id}/triaje", response_model=AtencionOut, responses=ERR, summary="Registrar o reevaluar el triaje",
             description="Niveles Manchester: ROJO (inmediato), NARANJA (10 min), AMARILLO (60), VERDE (120), AZUL (240). Se registra en fases 2 a 4. "
                         "**ROJO activa el Código Rojo**: exige `motivo`, queda auditado y crea la revisión administrativa obligatoria.")
def triaje(atencion_id: uuid.UUID, datos: TriajeIn, request: Request, prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    at, eventos = maquina.registrar_triaje(db, prof, atencion_id, datos)
    db.commit()
    _auditar_eventos(prof.persona, at, eventos, request)
    return a_out(at, _paciente(db, at.paciente_id))


@router.post("/{atencion_id}/asumir", response_model=AtencionOut, responses=ERR, summary="Un médico asume la responsabilidad de la atención",
             description="Útil tras un Código Rojo abierto por enfermería. Solo si la atención aún no tiene médico responsable.")
def asumir(atencion_id: uuid.UUID, request: Request, prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    at, eventos = maquina.asumir(db, prof, atencion_id)
    db.commit()
    _auditar_eventos(prof.persona, at, eventos, request)
    return a_out(at, _paciente(db, at.paciente_id))


# ------------------------------------------------------------------ Registros clínicos
def _registrar(db, prof, atencion_id, request, seccion, datos, creador, solo_doctor, fases) -> RegistroCreadoOut:
    at = service.preparar_escritura(db, prof, atencion_id, solo_doctor=solo_doctor, fases=fases, correccion=datos.reemplaza_id is not None)
    try:
        row = creador(db, at, prof.persona.id, datos)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Conflicto de versionado: ese registro ya fue corregido")
    service.auditar_registro(prof.persona.id, at, row, seccion, ip_cliente(request))
    return RegistroCreadoOut(id=row.id, seccion=seccion, nivel_sensibilidad=row.nivel_sensibilidad, cifrado=row.contenido_cifrado is not None,
                             reemplaza_id=getattr(row, "reemplaza_id", None), hash_contenido=row.hash_contenido, creado_en=row.creado_en)


_VERSION = ("**Los registros no se editan**: para corregir, envíe un registro nuevo con `reemplaza_id` (la versión vigente) y `motivo_correccion`; "
            "solo el autor o el médico responsable pueden hacerlo. ")


@router.post("/{atencion_id}/antecedentes", response_model=RegistroCreadoOut, status_code=201, responses=ERR,
             summary="Registrar un antecedente (fases 1-4)", description=_VERSION + "Los antecedentes genéticos o marcados `confidencial` son nivel 4 (cifrado de campo).")
def antecedente(atencion_id: uuid.UUID, datos: AntecedenteIn, request: Request, prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    if not prof.es_doctor and "expediente:escribir" not in prof.persona.permisos:
        raise HTTPException(403, "Sin permiso de escritura")
    return _registrar(db, prof, atencion_id, request, "antecedentes", datos, service.crear_antecedente, False, (1, 2, 3, 4))


@router.post("/{atencion_id}/alergias", response_model=RegistroCreadoOut, status_code=201, responses=ERR,
             summary="Registrar una alergia (fases 1-4, médico)", description=_VERSION + "Para descartar una alergia registre una nueva versión con `estado=DESCARTADA`. La sustancia se normaliza (minúsculas, sin tildes).")
def alergia(atencion_id: uuid.UUID, datos: AlergiaIn, request: Request, prof: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    return _registrar(db, prof, atencion_id, request, "alergias", datos, service.crear_alergia, True, (1, 2, 3, 4))


@router.post("/{atencion_id}/diagnosticos", response_model=RegistroCreadoOut, status_code=201, responses=ERR,
             summary="Registrar un diagnóstico CIE-10 (fases 3-4, médico)",
             description=_VERSION + "Los códigos de salud mental (F), VIH (B20-B24, Z21, R75) y genéticos (Q9x) son **nivel 4 automáticamente**: código, descripción y observaciones se guardan cifrados. Solo un diagnóstico principal vigente por atención.")
def diagnostico(atencion_id: uuid.UUID, datos: DiagnosticoIn, request: Request, prof: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    return _registrar(db, prof, atencion_id, request, "diagnosticos", datos, service.crear_diagnostico, True, (3, 4))


@router.post("/{atencion_id}/signos-vitales", response_model=RegistroCreadoOut, status_code=201, responses=ERR,
             summary="Registrar signos vitales (fases 1-4)", description=_VERSION + "Rangos fisiológicos validados; el IMC se calcula con peso y talla.")
def signos(atencion_id: uuid.UUID, datos: SignosVitalesIn, request: Request, prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    return _registrar(db, prof, atencion_id, request, "signos_vitales", datos, service.crear_signos, False, (1, 2, 3, 4))


@router.post("/{atencion_id}/notas", response_model=RegistroCreadoOut, status_code=201, responses=ERR,
             summary="Registrar una nota SOAP (fases 3-4, médico)",
             description=_VERSION + "Cada nota guarda un hash de contenido. Las notas `confidencial` (p. ej. psiquiátricas) y todas las de áreas de salud mental son **nivel 4**: los cuatro campos SOAP se guardan cifrados con Fernet (`CLAVE_CAMPOS`).")
def nota(atencion_id: uuid.UUID, datos: NotaSoapIn, request: Request, prof: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    return _registrar(db, prof, atencion_id, request, "notas", datos, service.crear_nota, True, (3, 4))
