import hashlib
import hmac
import json
import time
from ipaddress import ip_address

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import ValidationError
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.config import settings
from omega_core.database import get_db
from omega_core.deps import require_permiso
from omega_core.models import Persona
from omega_core.security.ratelimit import ip_cliente, limitar_ip

from . import service
from .estado_vital import firma_ml, registrar_defuncion, revertir_defuncion
from .schemas import DefuncionManualIn, DefuncionMLIn, DefuncionOut, RevertirIn

router = APIRouter(tags=["estado vital · fallecimiento y congelamiento"])
ERR = {401: {"description": "Firma/credenciales inválidas"}, 403: {"description": "Origen no permitido"}, 404: {"description": "DUI no registrado"},
       409: {"description": "Posible homónimo, certificado repetido u otro conflicto"}, 422: {"description": "Datos inválidos"}}


async def cuerpo_firmado(request: Request) -> tuple[bytes, str]:
    """Autentica a Medicina Legal: HMAC-SHA256(secreto, timestamp + '.' + cuerpo) en `X-ML-Firma`, con `X-ML-Timestamp` (anti-replay)."""
    if not settings.medicina_legal_secret:
        raise HTTPException(503, "Integración con Medicina Legal no configurada (MEDICINA_LEGAL_SECRET)")
    ip = ip_cliente(request)
    if settings.medicina_legal_redes:
        try:
            ok = any(ip_address(ip) in red for red in settings.medicina_legal_redes)
        except ValueError:
            ok = False
        if not ok:
            auditar("DEFUNCION_RECHAZADA", actor_tipo="integracion", resultado="FALLO", ip=ip, detalle={"motivo": "IP_NO_PERMITIDA"})
            raise HTTPException(403, "Origen no permitido")
    limitar_ip(request, "medicina_legal", 60)
    raw = await request.body()
    if len(raw) > 20_000:
        raise HTTPException(413, "Cuerpo demasiado grande")
    ts, firma = request.headers.get("X-ML-Timestamp", ""), request.headers.get("X-ML-Firma", "").lower()
    try:
        fresco = abs(time.time() - int(ts)) <= settings.medicina_legal_ventana_seg
    except ValueError:
        fresco = False
    if not fresco or not hmac.compare_digest(firma_ml(settings.medicina_legal_secret, ts, raw), firma):
        auditar("DEFUNCION_RECHAZADA", actor_tipo="integracion", resultado="FALLO", ip=ip, detalle={"motivo": "FIRMA_O_TIMESTAMP_INVALIDOS"})
        raise HTTPException(401, "Firma o marca de tiempo inválidas")
    return raw, firma


@router.post("/integraciones/medicina-legal/defunciones", response_model=DefuncionOut, responses=ERR,
             summary="Medicina Legal registra un fallecimiento (congela el DUI)",
             description="Endpoint de **máquina a máquina**. Autenticación: cabeceras `X-ML-Timestamp` (epoch, ±5 min) y `X-ML-Firma` = HMAC-SHA256(`MEDICINA_LEGAL_SECRET`, `timestamp + '.' + cuerpo`). "
                         "Verifica DUI + fecha de nacimiento (anti-homónimos). En **una transacción**: guarda causa oficial, entidad certificadora, fecha/hora y hash/token de la API emisora; "
                         "desactiva la cuenta, revoca sus sesiones y cierra las atenciones abiertas. Desde ese momento no se admiten recetas, citas ni registros nuevos (HTTP 423). Idempotente por `numero_certificado`.")
def registrar_ml(request: Request, cuerpo: tuple[bytes, str] = Depends(cuerpo_firmado), db: Session = Depends(get_db)):
    raw, firma = cuerpo
    ip = ip_cliente(request)
    try:
        datos = DefuncionMLIn.model_validate_json(raw)
    except ValidationError as e:
        raise HTTPException(422, json.loads(e.json(include_url=False, include_context=False)))
    try:
        pid, d, cerradas, nuevo = registrar_defuncion(db, dui=datos.dui, datos=datos, via="MEDICINA_LEGAL", actor_id=None,
                                                      fecha_nacimiento=datos.fecha_nacimiento, hash_payload=hashlib.sha256(raw).hexdigest(),
                                                      firma=firma, motivo_manual=None)
        db.commit()
    except HTTPException as e:
        db.rollback()
        auditar("DEFUNCION_RECHAZADA", actor_tipo="integracion", resultado="FALLO", ip=ip,
                detalle={"motivo": e.detail, "certificado": datos.numero_certificado})
        raise
    if nuevo:
        auditar("DEFUNCION_REGISTRADA", actor_tipo="integracion", actor_id="medicina_legal", recurso="persona", recurso_id=pid, ip=ip,
                detalle={"certificado": datos.numero_certificado, "entidad": datos.entidad_certificadora, "atenciones_cerradas": cerradas, "via": "MEDICINA_LEGAL"})
    return DefuncionOut(id=d.id, estado="FALLECIDO", congelado=True, atenciones_cerradas=cerradas)


@router.post("/omega/estado-vital/{dui}/fallecimiento", response_model=DefuncionOut, responses=ERR,
             summary="Omega registra un fallecimiento manualmente",
             description="Vía excepcional (p. ej. paciente sin fecha de nacimiento en el padrón). Solo el Administrador Omega (token + IP autorizada). Exige `motivo_verificacion_manual`; queda auditado.")
def registrar_manual(dui: str, datos: DefuncionManualIn, request: Request, omega: Persona = Depends(require_permiso("estadovital:administrar")),
                     db: Session = Depends(get_db)):
    dui_n = service.dui_o_422(dui)
    pid, d, cerradas, nuevo = registrar_defuncion(
        db, dui=dui_n, datos=datos, via="OMEGA_MANUAL", actor_id=omega.id, fecha_nacimiento=None,
        hash_payload=hashlib.sha256(datos.model_dump_json().encode()).hexdigest(), firma=None, motivo_manual=datos.motivo_verificacion_manual)
    db.commit()
    if nuevo:
        auditar("DEFUNCION_REGISTRADA", actor_tipo="omega", actor_id=omega.id, recurso="persona", recurso_id=pid, ip=ip_cliente(request),
                detalle={"certificado": datos.numero_certificado, "atenciones_cerradas": cerradas, "via": "OMEGA_MANUAL", "motivo": datos.motivo_verificacion_manual})
    return DefuncionOut(id=d.id, estado="FALLECIDO", congelado=True, atenciones_cerradas=cerradas)


@router.post("/omega/estado-vital/{dui}/revertir", response_model=DefuncionOut, responses=ERR,
             summary="Omega revierte un fallecimiento registrado por error (descongela el DUI)",
             description="Salvaguarda contra falsos positivos (homónimos). Reactiva la cuenta; el registro de defunción se conserva como histórico revertido. Solo Omega, con motivo; auditado.")
def revertir(dui: str, datos: RevertirIn, request: Request, omega: Persona = Depends(require_permiso("estadovital:administrar")),
             db: Session = Depends(get_db)):
    pid, d = revertir_defuncion(db, dui=service.dui_o_422(dui), actor_id=omega.id, motivo=datos.motivo)
    db.commit()
    auditar("DEFUNCION_REVERTIDA", actor_tipo="omega", actor_id=omega.id, recurso="persona", recurso_id=pid, ip=ip_cliente(request),
            detalle={"certificado": d.numero_certificado, "motivo": datos.motivo})
    return DefuncionOut(id=d.id, estado="VIVO", congelado=False)
