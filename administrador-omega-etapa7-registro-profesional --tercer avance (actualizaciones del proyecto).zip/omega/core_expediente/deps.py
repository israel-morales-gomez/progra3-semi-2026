import uuid
from dataclasses import dataclass

from fastapi import Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from omega_core.database import get_db
from omega_core.deps import institucion_actual, persona_actual
from omega_core.models import Institucion, Persona

TIPOS_CLINICOS = ("HOSPITAL", "CLINICA")


@dataclass
class Profesional:
    persona: Persona
    institucion_id: uuid.UUID
    es_doctor: bool


def profesional_de(persona: Persona, db: Session) -> Profesional:
    """Profesional de la salud VERIFICADO por Omega, asociado a un hospital o clínica ACTIVA. Lo usan la API (por JWT) y el portal web (por sesión)."""
    pf = persona.profesional
    if pf is None or not pf.verificado or not pf.activo or pf.institucion_id is None or "expediente:leer" not in persona.permisos:
        raise HTTPException(403, "Se requiere un perfil profesional verificado, activo y asociado a una institución")
    inst = db.execute(select(Institucion.estado, Institucion.tipo).where(Institucion.id == pf.institucion_id)).first()
    if inst is None or inst.estado != "ACTIVA" or inst.tipo not in TIPOS_CLINICOS:
        raise HTTPException(403, "Su institución no está activa como hospital o clínica")
    return Profesional(persona, pf.institucion_id, pf.tipo == "DOCTOR")


def profesional_activo(persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)) -> Profesional:
    return profesional_de(persona, db)


def medico_activo(prof: Profesional = Depends(profesional_activo)) -> Profesional:
    if not prof.es_doctor:
        raise HTTPException(403, "Esta acción es exclusiva de médicos")
    return prof


def hospital_actual(inst: Institucion = Depends(institucion_actual)) -> Institucion:
    if inst.tipo not in TIPOS_CLINICOS:
        raise HTTPException(403, "Solo hospitales y clínicas")
    return inst
