import uuid
from datetime import date, datetime
from typing import Annotated, Any, Literal

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, field_validator, model_validator

from omega_core.schemas import DUI

from .constantes import (
    EstadoAlergia, EstatusDiagnostico, NivelTriaje, Severidad, TipoAntecedente, TipoAtencion, TipoDiagnostico,
    TipoEgreso, normalizar_cie10,
)

CIE10 = Annotated[str, AfterValidator(normalizar_cie10)]


class In(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")


# ------------------------------------------------------------------ Atención / fases / triaje
class AbrirAtencionIn(In):
    dui: DUI = Field(description="DUI del paciente (formato 00000000-0).")
    tipo_atencion: TipoAtencion
    area: Annotated[str, Field(min_length=2, max_length=120)] = Field(description="Área o especialidad. Las áreas de salud mental (psiquiatría, psicología) crean la atención como nivel 4: todo su contenido va cifrado.")
    motivo_consulta: Annotated[str, Field(min_length=3, max_length=2000)]
    codigo_rojo: bool = Field(False, description="Activa el bypass de emergencia: la atención nace directamente en fase 3, sin validaciones administrativas.")
    motivo_codigo_rojo: Annotated[str, Field(min_length=10, max_length=1000)] | None = Field(None, description="OBLIGATORIO si codigo_rojo=true. Queda en la bitácora de auditoría.")

    @model_validator(mode="after")
    def _rojo(self):
        if self.codigo_rojo and not self.motivo_codigo_rojo:
            raise ValueError("motivo_codigo_rojo es obligatorio (mín. 10 caracteres) cuando codigo_rojo=true")
        if not self.codigo_rojo and self.motivo_codigo_rojo:
            raise ValueError("motivo_codigo_rojo solo aplica con codigo_rojo=true")
        return self


class TriajeIn(In):
    nivel: NivelTriaje = Field(description="ROJO (inmediato / Código Rojo), NARANJA (10 min), AMARILLO (60), VERDE (120), AZUL (240).")
    discriminador: Annotated[str, Field(min_length=3, max_length=300)] = Field(description="Criterio clínico que justifica el nivel.")
    motivo: Annotated[str, Field(min_length=10, max_length=1000)] | None = Field(None, description="OBLIGATORIO si nivel=ROJO: activa el Código Rojo y queda auditado.")

    @model_validator(mode="after")
    def _rojo(self):
        if self.nivel == "ROJO" and not self.motivo:
            raise ValueError("El nivel ROJO (Código Rojo) exige motivo (mín. 10 caracteres)")
        return self


class EgresoIn(In):
    tipo_egreso: TipoEgreso
    condicion_egreso: Annotated[str, Field(min_length=3, max_length=200)]
    resumen_egreso: Annotated[str, Field(min_length=10, max_length=20000)]
    plan_seguimiento: Annotated[str, Field(min_length=5, max_length=10000)]
    proximo_control_en: datetime | None = Field(None, description="Fecha/hora del próximo control (con zona horaria).")

    @field_validator("proximo_control_en")
    @classmethod
    def _tz(cls, v):
        if v is not None and v.tzinfo is None:
            raise ValueError("proximo_control_en debe incluir zona horaria")
        return v


class TransicionIn(In):
    a_fase: Annotated[int, Field(ge=2, le=5)] = Field(description="Fase destino (2 Preparación, 3 Ejecución, 4 Trazabilidad, 5 Cierre).")
    identidad_verificada: bool | None = Field(None, description="Fase 1→2: confirma la identidad del paciente.")
    antecedentes_revisados: bool | None = Field(None, description="Fase 1→2: confirma que antecedentes y alergias fueron revisados/registrados.")
    medico_id: uuid.UUID | None = Field(None, description="Fase 2→3: médico responsable (por defecto, quien transiciona si es médico).")
    motivo: Annotated[str, Field(min_length=3, max_length=1000)] | None = Field(None, description="OBLIGATORIO (≥10 caracteres) cuando la transición es un bypass de Código Rojo.")
    egreso: EgresoIn | None = Field(None, description="Fase 4→5: resumen de egreso y plan de seguimiento (obligatorio).")


# ------------------------------------------------------------------ Registros clínicos
class Versionado(In):
    reemplaza_id: uuid.UUID | None = Field(None, description="Si se informa, este registro es una NUEVA VERSIÓN que corrige al indicado (el original nunca se modifica).")
    motivo_correccion: Annotated[str, Field(min_length=5, max_length=300)] | None = None

    @model_validator(mode="after")
    def _v(self):
        if self.reemplaza_id and not self.motivo_correccion:
            raise ValueError("motivo_correccion es obligatorio al corregir un registro")
        if self.motivo_correccion and not self.reemplaza_id:
            raise ValueError("motivo_correccion solo aplica con reemplaza_id")
        return self


class AntecedenteIn(Versionado):
    tipo: TipoAntecedente
    descripcion: Annotated[str, Field(min_length=3, max_length=5000)]
    confidencial: bool = Field(False, description="Fuerza nivel 4 (cifrado). Los antecedentes GENETICO son siempre nivel 4.")


class AlergiaIn(Versionado):
    sustancia: Annotated[str, Field(min_length=2, max_length=80)] = Field(description="Principio activo o clase (ej. 'penicilina', 'AINE').")
    severidad: Severidad
    reaccion: Annotated[str, Field(max_length=300)] | None = None
    estado: EstadoAlergia = Field("ACTIVA", description="Para descartar una alergia registre una nueva versión con estado=DESCARTADA.")


class DiagnosticoIn(Versionado):
    codigo_cie10: CIE10
    descripcion: Annotated[str, Field(min_length=3, max_length=300)]
    observaciones: Annotated[str, Field(max_length=5000)] | None = None
    tipo: TipoDiagnostico
    estatus: EstatusDiagnostico = "ACTIVA"
    principal: bool = Field(False, description="Diagnóstico principal; las comorbilidades son los no principales.")
    confidencial: bool = Field(False, description="Fuerza nivel 4. Los códigos de salud mental (F), VIH (B20-B24, Z21, R75) y genéticos (Q9x) son nivel 4 automáticamente.")


class SignosVitalesIn(Versionado):
    tomado_en: datetime | None = Field(None, description="Por defecto, ahora. Con zona horaria.")
    ta_sistolica: Annotated[int, Field(ge=40, le=300)] | None = None
    ta_diastolica: Annotated[int, Field(ge=20, le=200)] | None = None
    fc: Annotated[int, Field(ge=20, le=300)] | None = Field(None, description="Frecuencia cardíaca (ppm)")
    fr: Annotated[int, Field(ge=4, le=80)] | None = Field(None, description="Frecuencia respiratoria (rpm)")
    temperatura: Annotated[float, Field(ge=25, le=45, allow_inf_nan=False)] | None = Field(None, description="°C")
    spo2: Annotated[int, Field(ge=30, le=100)] | None = Field(None, description="%")
    glucemia: Annotated[float, Field(ge=10, le=1500, allow_inf_nan=False)] | None = Field(None, description="mg/dL")
    peso_kg: Annotated[float, Field(ge=0.2, le=500, allow_inf_nan=False)] | None = None
    talla_cm: Annotated[float, Field(ge=20, le=260, allow_inf_nan=False)] | None = None
    dolor_eva: Annotated[int, Field(ge=0, le=10)] | None = Field(None, description="Escala visual análoga 0-10")

    @model_validator(mode="after")
    def _algo(self):
        medidas = [self.ta_sistolica, self.ta_diastolica, self.fc, self.fr, self.temperatura, self.spo2, self.glucemia,
                   self.peso_kg, self.talla_cm, self.dolor_eva]
        if all(m is None for m in medidas):
            raise ValueError("Informe al menos una medida")
        if self.ta_sistolica and self.ta_diastolica and self.ta_sistolica <= self.ta_diastolica:
            raise ValueError("La presión sistólica debe ser mayor que la diastólica")
        if self.tomado_en is not None and self.tomado_en.tzinfo is None:
            raise ValueError("tomado_en debe incluir zona horaria")
        return self


class NotaSoapIn(Versionado):
    subjetivo: Annotated[str, Field(min_length=1, max_length=10000)]
    objetivo: Annotated[str, Field(min_length=1, max_length=10000)]
    analisis: Annotated[str, Field(min_length=1, max_length=10000)]
    plan: Annotated[str, Field(min_length=1, max_length=10000)]
    confidencial: bool = Field(False, description="Fuerza nivel 4 (cifrado de campo), p. ej. notas psiquiátricas. Siempre nivel 4 si el área de la atención es de salud mental.")


# ------------------------------------------------------------------ Consentimiento y estado vital
class ConsentimientoIn(In):
    profesional_dui: DUI | None = Field(None, description="Autoriza a un profesional concreto (verificado).")
    institucion_id: uuid.UUID | None = Field(None, description="Autoriza a toda una institución (hospital o clínica activa).")
    dias: Annotated[int, Field(ge=1, le=365)] = 30
    incluye_nivel4: bool = Field(False, description="Solo con profesional_dui: permite además abrir datos de nivel 4 (con justificación).")

    @model_validator(mode="after")
    def _uno(self):
        if (self.profesional_dui is None) == (self.institucion_id is None):
            raise ValueError("Indique exactamente uno: profesional_dui o institucion_id")
        if self.incluye_nivel4 and self.profesional_dui is None:
            raise ValueError("incluye_nivel4 solo puede otorgarse a un profesional concreto")
        return self


class DefuncionDatos(In):
    fecha_hora_deceso: datetime = Field(description="Fecha y hora exacta del deceso, con zona horaria.")
    causa_oficial: Annotated[str, Field(min_length=3, max_length=2000)]
    causa_cie10: CIE10 | None = None
    entidad_certificadora: Annotated[str, Field(min_length=2, max_length=200)]
    numero_certificado: Annotated[str, Field(min_length=3, max_length=60)]
    token_verificacion: Annotated[str, Field(max_length=200)] | None = Field(None, description="Token de verificación emitido por la API certificadora.")

    @field_validator("fecha_hora_deceso")
    @classmethod
    def _tz(cls, v):
        if v.tzinfo is None:
            raise ValueError("fecha_hora_deceso debe incluir zona horaria")
        return v


class DefuncionMLIn(DefuncionDatos):
    dui: DUI
    fecha_nacimiento: date = Field(description="Verificación anti-homónimos: debe coincidir con la fecha de nacimiento del padrón.")


class DefuncionManualIn(DefuncionDatos):
    motivo_verificacion_manual: Annotated[str, Field(min_length=10, max_length=1000)] = Field(description="Por qué Omega registra el fallecimiento sin el canal de Medicina Legal.")


class RevertirIn(In):
    motivo: Annotated[str, Field(min_length=10, max_length=1000)]


class RevisionCompletarIn(In):
    resultado: Literal["JUSTIFICADO", "OBSERVADO"]
    comentario: Annotated[str, Field(min_length=5, max_length=2000)]


# ------------------------------------------------------------------ Salidas
class PacienteMin(BaseModel):
    dui: str
    nombre: str


class TransicionOut(BaseModel):
    de_fase: int | None
    a_fase: int
    actor_tipo: str
    actor_id: uuid.UUID | None
    bypass: bool
    motivo: str | None
    creado_en: datetime


class AtencionOut(BaseModel):
    id: uuid.UUID
    folio: str
    paciente: PacienteMin
    institucion_id: uuid.UUID
    tipo_atencion: str
    area: str
    motivo_consulta: str | None = Field(None, description="Nulo en atenciones de nivel 4 (cifrado).")
    motivo_restringido: bool = False
    fase: int
    fase_nombre: str
    estado: str
    nivel_triaje: str | None
    codigo_rojo: bool
    identidad_verificada: bool
    antecedentes_revisados: bool
    medico_responsable_id: uuid.UUID | None
    abierta_en: datetime
    cerrada_en: datetime | None
    cierre_tipo: str | None
    transiciones: list[TransicionOut] | None = None


class ItemClinicoOut(BaseModel):
    id: uuid.UUID
    nivel_sensibilidad: int
    restringido: bool = Field(description="True si es de nivel 4 y no se abrió el contenido (sin permiso o sin justificación).")
    requiere_justificacion: bool = Field(False, description="True si usted puede abrirlo enviando el parámetro 'justificacion'.")
    creado_en: datetime
    atencion_id: uuid.UUID | None = None
    registrado_por: uuid.UUID | None = None
    reemplaza_id: uuid.UUID | None = None
    motivo_correccion: str | None = None
    vigente: bool = True
    datos: dict[str, Any] | None = Field(None, description="Campos propios de la sección; nulo si está restringido.")


class SeccionOut(BaseModel):
    seccion: str
    devueltos: int
    restringidos: int
    items: list[ItemClinicoOut]


class AccesoOut(BaseModel):
    via: str = Field(description="ATENCION_ACTIVA | CONSENTIMIENTO | PROPIO")
    nivel4_habilitado: bool


class EstadoVitalOut(BaseModel):
    estado: Literal["VIVO", "FALLECIDO"]
    congelado: bool
    fallecido_en: datetime | None = None
    causa_oficial: str | None = None
    causa_cie10: str | None = None
    entidad_certificadora: str | None = None
    numero_certificado: str | None = None


class ResumenOut(BaseModel):
    paciente: PacienteMin
    estado_vital: EstadoVitalOut
    acceso: AccesoOut
    antecedentes: SeccionOut
    alergias: SeccionOut
    diagnosticos: SeccionOut
    signos_vitales: SeccionOut
    egresos: SeccionOut
    resultados: SeccionOut | None = Field(None, description="Resultados de laboratorio e imagenología inyectados por el módulo laboratorio.")
    vacunas: SeccionOut | None = Field(None, description="Registro de vacunación (módulo portal_civil).")
    atenciones: list[dict[str, Any]]


class RegistroCreadoOut(BaseModel):
    id: uuid.UUID
    seccion: str
    nivel_sensibilidad: int
    cifrado: bool
    reemplaza_id: uuid.UUID | None
    hash_contenido: str
    creado_en: datetime


class ConsentimientoOut(BaseModel):
    id: uuid.UUID
    profesional_id: uuid.UUID | None
    institucion_id: uuid.UUID | None
    nivel_maximo: int
    creado_en: datetime
    vigente_hasta: datetime
    revocado_en: datetime | None
    activo: bool


class DefuncionOut(BaseModel):
    id: uuid.UUID
    estado: Literal["FALLECIDO", "VIVO"]
    congelado: bool
    atenciones_cerradas: int = 0


class RevisionBypassOut(BaseModel):
    id: uuid.UUID
    atencion_folio: str
    motivo: str
    activada_en: datetime
    vence_en: datetime
    vencida: bool
    estado: str
    resultado: str | None
    comentario: str | None
    revisada_en: datetime | None
