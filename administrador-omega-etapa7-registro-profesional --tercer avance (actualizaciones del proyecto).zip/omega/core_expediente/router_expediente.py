import uuid
from datetime import timedelta
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.deps import persona_actual
from omega_core.models import Institucion, PerfilProfesional, Persona
from omega_core.models.base import ahora
from omega_core.security.ratelimit import ip_cliente

from . import service
from .deps import TIPOS_CLINICOS, Profesional, profesional_activo
from .models import Consentimiento
from .schemas import AccesoOut, ConsentimientoIn, ConsentimientoOut, PacienteMin, ResumenOut, SeccionOut

router = APIRouter(tags=["expediente clínico · lectura y consentimiento"])
Seccion = Literal["antecedentes", "alergias", "diagnosticos", "signos-vitales", "notas", "egresos", "resultados", "vacunas"]
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Sin acceso al expediente (queda auditado como ACCESO_EXPEDIENTE_DENEGADO)"},
       422: {"description": "Parámetros inválidos"}, 429: {"description": "Demasiadas consultas"}}
_PARAM_JUST = ("Para abrir el contenido de **nivel 4** (VIH, salud mental, genética) debe ser el médico responsable de la atención activa (o tener un "
               "consentimiento de nivel 4 del paciente) y enviar `justificacion` (mín. 10 caracteres); se audita con el texto. Sin ella, los registros de nivel 4 salen como `restringido`.")


def _consentimiento_out(c: Consentimiento) -> ConsentimientoOut:
    return ConsentimientoOut(id=c.id, profesional_id=c.profesional_id, institucion_id=c.institucion_id, nivel_maximo=c.nivel_maximo,
                             creado_en=c.creado_en, vigente_hasta=c.vigente_hasta, revocado_en=c.revocado_en,
                             activo=c.revocado_en is None and c.vigente_hasta > ahora())


def _resumen(db, ident, acceso, justificacion, historial, actor_id, ip) -> ResumenOut:
    secciones, abiertos, restr, dev = {}, 0, 0, 0
    for s in service.SECCIONES_RESUMEN:
        out, ab = service.leer_seccion(db, s, ident.id, acceso, justificacion, historial, limite=50 if s != "signos_vitales" else 10)
        secciones[s] = out
        abiertos += ab
        restr += out.restringidos
        dev += out.devueltos
    service.auditar_lectura(actor_id, ident.id, acceso, "resumen", dev, restr, abiertos, justificacion, historial, ip)
    return ResumenOut(paciente=PacienteMin(dui=ident.dui, nombre=f"{ident.nombres} {ident.apellidos}"),
                      estado_vital=service.estado_vital(db, ident.id), acceso=AccesoOut(via=acceso.via, nivel4_habilitado=acceso.puede_nivel4),
                      atenciones=service.resumen_atenciones(db, ident.id), **secciones)


# ------------------------------------------------------------------ Paciente: su propio expediente y consentimientos
# (declaradas ANTES de /mi-expediente/{seccion} para que "consentimientos" no se interprete como sección)
@router.post("/mi-expediente/consentimientos", response_model=ConsentimientoOut, status_code=201, summary="Otorgar consentimiento de lectura",
             description="El paciente autoriza a un profesional verificado (`profesional_dui`) o a una institución clínica activa (`institucion_id`) a **leer** su expediente por N días. "
                         "El nivel 4 solo puede concederse a un profesional concreto con `incluye_nivel4=true`. Revocable en cualquier momento. Queda auditado.",
             responses={**ERR, 404: {"description": "Profesional o institución no válidos"}, 423: {"description": "Expediente congelado"}})
def otorgar(datos: ConsentimientoIn, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    service.asegurar_no_congelado(db, persona.id)
    prof_id = inst_id = None
    if datos.profesional_dui:
        fila = db.execute(select(Persona.id).join(PerfilProfesional, PerfilProfesional.persona_id == Persona.id)
                          .where(Persona.dui == datos.profesional_dui, PerfilProfesional.verificado.is_(True))).first()
        if fila is None:
            raise HTTPException(404, "No existe un profesional verificado con ese DUI")
        if fila.id == persona.id:
            raise HTTPException(422, "No puede otorgarse consentimiento a sí mismo")
        prof_id = fila.id
    else:
        inst = db.execute(select(Institucion.id).where(Institucion.id == datos.institucion_id, Institucion.estado == "ACTIVA",
                                                       Institucion.tipo.in_(TIPOS_CLINICOS))).first()
        if inst is None:
            raise HTTPException(404, "No existe un hospital o clínica activa con ese id")
        inst_id = inst.id
    c = Consentimiento(paciente_id=persona.id, profesional_id=prof_id, institucion_id=inst_id,
                       nivel_maximo=4 if datos.incluye_nivel4 else 2, vigente_hasta=ahora() + timedelta(days=datos.dias))
    db.add(c)
    db.commit()
    auditar("CONSENTIMIENTO_OTORGADO", actor_tipo="persona", actor_id=persona.id, recurso="consentimiento", recurso_id=c.id,
            ip=ip_cliente(request), detalle={"profesional_id": prof_id, "institucion_id": inst_id, "nivel_maximo": c.nivel_maximo, "dias": datos.dias})
    return _consentimiento_out(c)


@router.get("/mi-expediente/consentimientos", response_model=list[ConsentimientoOut], summary="Mis consentimientos", responses=ERR)
def mis_consentimientos(persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    filas = db.scalars(select(Consentimiento).where(Consentimiento.paciente_id == persona.id).order_by(Consentimiento.creado_en.desc()).limit(100))
    return [_consentimiento_out(c) for c in filas]


@router.post("/mi-expediente/consentimientos/{consentimiento_id}/revocar", response_model=ConsentimientoOut, summary="Revocar un consentimiento",
             description="Efecto inmediato: el profesional o la institución pierde el acceso por esta vía.", responses={**ERR, 404: {"description": "No encontrado"}})
def revocar(consentimiento_id: uuid.UUID, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    c = db.scalar(select(Consentimiento).where(Consentimiento.id == consentimiento_id, Consentimiento.paciente_id == persona.id).with_for_update())
    if c is None:
        raise HTTPException(404, "Consentimiento no encontrado")
    if c.revocado_en is None:
        c.revocado_en = ahora()
        db.commit()
        auditar("CONSENTIMIENTO_REVOCADO", actor_tipo="persona", actor_id=persona.id, recurso="consentimiento", recurso_id=c.id, ip=ip_cliente(request))
    return _consentimiento_out(c)


def _propio(persona: Persona, db: Session):
    if "expediente:leer_propio" not in persona.permisos:
        raise HTTPException(403, "Sin permiso")
    return db.execute(select(Persona.id, Persona.dui, Persona.nombres, Persona.apellidos).where(Persona.id == persona.id)).one(), service.Acceso("PROPIO", False)


@router.get("/mi-expediente", response_model=ResumenOut, summary="Mi expediente clínico (solo lectura)", responses=ERR,
            description="Resumen del propio expediente. Los registros de nivel 4 se listan como `restringido` (se consultan con su médico tratante). Cada lectura queda auditada.")
def mi_expediente(request: Request, historial: bool = False, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    ident, acceso = _propio(persona, db)
    return _resumen(db, ident, acceso, None, historial, persona.id, ip_cliente(request))


@router.get("/mi-expediente/{seccion}", response_model=SeccionOut, summary="Una sección de mi expediente", responses=ERR,
            description="Secciones: antecedentes, alergias, diagnosticos, signos-vitales, notas, egresos, resultados (laboratorio/imagenología), vacunas. `historial=true` incluye versiones anteriores.")
def mi_seccion(seccion: Seccion, request: Request, historial: bool = False, limite: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
               persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    ident, acceso = _propio(persona, db)
    s = seccion.replace("-", "_")
    out, ab = service.leer_seccion(db, s, ident.id, acceso, None, historial, limite, offset)
    service.auditar_lectura(persona.id, ident.id, acceso, s, out.devueltos, out.restringidos, ab, None, historial, ip_cliente(request))
    return out


# ------------------------------------------------------------------ Profesional
@router.get("/expediente/{dui}", response_model=ResumenOut, summary="Resumen del expediente de un paciente", responses=ERR,
            description="Antecedentes, alergias, diagnósticos, últimos signos vitales, egresos, estado vital y atenciones recientes. **Control de acceso**: solo si el paciente "
                        "tiene una **atención activa en su institución** o un **consentimiento** vigente; en otro caso 403 (auditado, igual si el DUI no existe). " + _PARAM_JUST)
def resumen(dui: str, request: Request, justificacion: str | None = Query(None, max_length=1000), historial: bool = False,
            prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    just = service.validar_justificacion(justificacion)
    ident, acceso = service.autorizar_lectura(db, prof, dui, "resumen", ip_cliente(request))
    return _resumen(db, ident, acceso, just, historial, prof.persona.id, ip_cliente(request))


@router.get("/expediente/{dui}/{seccion}", response_model=SeccionOut, summary="Una sección del expediente (con paginación e historial)", responses=ERR,
            description="Secciones: antecedentes, alergias, diagnosticos, signos-vitales, notas (SOAP), egresos, resultados (laboratorio/imagenología), vacunas. Por defecto solo la **versión vigente** de cada registro; `historial=true` devuelve "
                        "también las versiones corregidas. " + _PARAM_JUST)
def seccion(dui: str, seccion: Seccion, request: Request, justificacion: str | None = Query(None, max_length=1000), historial: bool = False,
            limite: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
            prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    just = service.validar_justificacion(justificacion)
    s = seccion.replace("-", "_")
    ident, acceso = service.autorizar_lectura(db, prof, dui, s, ip_cliente(request))
    out, ab = service.leer_seccion(db, s, ident.id, acceso, just, historial, limite, offset)
    service.auditar_lectura(prof.persona.id, ident.id, acceso, s, out.devueltos, out.restringidos, ab, just, historial, ip_cliente(request))
    return out
