"""Estado vital: registro de fallecimiento (congelamiento del DUI) y su reversión por Omega."""
import hashlib
import hmac
import uuid
from datetime import date, timedelta

from fastapi import HTTPException
from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from omega_core.models import Persona
from omega_core.models.base import ahora
from omega_core.security.tokens import revocar_todos

from . import maquina
from .models import Defuncion
from .schemas import DefuncionDatos


def firma_ml(secreto: str, timestamp: str, cuerpo: bytes) -> str:
    return hmac.new(secreto.encode(), timestamp.encode() + b"." + cuerpo, hashlib.sha256).hexdigest()


def registrar_defuncion(db: Session, *, dui: str, datos: DefuncionDatos, via: str, actor_id: uuid.UUID | None,
                        fecha_nacimiento: date | None, hash_payload: str, firma: str | None, motivo_manual: str | None):
    """Transacción única: defuncion + desactivación de la cuenta + revocación de sesiones + cierre de atenciones abiertas."""
    p = db.execute(select(Persona.id, Persona.fecha_nacimiento).where(Persona.dui == dui).with_for_update()).first()
    if p is None:
        raise HTTPException(404, "DUI no registrado en el padrón")
    previa = db.scalar(select(Defuncion).where(Defuncion.persona_id == p.id, Defuncion.vigente.is_(True)))
    if previa is not None:
        if previa.numero_certificado == datos.numero_certificado:  # reintento idempotente
            return p.id, previa, 0, False
        raise HTTPException(409, "El paciente ya figura como fallecido con otro certificado")
    if via == "MEDICINA_LEGAL":  # anti-homónimos: DUI + fecha de nacimiento
        if p.fecha_nacimiento is None:
            raise HTTPException(409, "El padrón no tiene fecha de nacimiento para este DUI: requiere verificación manual de Omega")
        if p.fecha_nacimiento != fecha_nacimiento:
            raise HTTPException(409, "La fecha de nacimiento no coincide con el padrón: posible homónimo, no se congela la cuenta")
    ahora_ = ahora()
    if datos.fecha_hora_deceso > ahora_ + timedelta(minutes=5):
        raise HTTPException(422, "fecha_hora_deceso no puede estar en el futuro")
    if p.fecha_nacimiento and datos.fecha_hora_deceso.date() < p.fecha_nacimiento:
        raise HTTPException(422, "fecha_hora_deceso es anterior a la fecha de nacimiento")
    d = Defuncion(persona_id=p.id, fallecido_en=datos.fecha_hora_deceso, causa_oficial=datos.causa_oficial, causa_cie10=datos.causa_cie10,
                  entidad_certificadora=datos.entidad_certificadora, numero_certificado=datos.numero_certificado,
                  token_verificacion=datos.token_verificacion, hash_payload=hash_payload, firma_hmac=firma, via=via,
                  motivo_verificacion_manual=motivo_manual, registrado_por=actor_id)
    try:
        db.add(d)
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "El número de certificado ya fue utilizado")
    db.execute(update(Persona).where(Persona.id == p.id).values(activo=False))  # cuenta congelada: no puede iniciar sesión
    revocar_todos(db, "persona", p.id)
    cerradas = maquina.cerrar_por_fallecimiento(db, p.id)
    return p.id, d, len(cerradas), True


def revertir_defuncion(db: Session, *, dui: str, actor_id: uuid.UUID, motivo: str):
    p = db.execute(select(Persona.id).where(Persona.dui == dui).with_for_update()).first()
    d = db.scalar(select(Defuncion).where(Defuncion.persona_id == p.id, Defuncion.vigente.is_(True))) if p else None
    if d is None:
        raise HTTPException(404, "El paciente no tiene un fallecimiento vigente")
    d.vigente, d.revertida_en, d.revertida_por, d.motivo_reversion = False, ahora(), actor_id, motivo
    db.execute(update(Persona).where(Persona.id == p.id).values(activo=True))
    db.flush()
    return p.id, d
