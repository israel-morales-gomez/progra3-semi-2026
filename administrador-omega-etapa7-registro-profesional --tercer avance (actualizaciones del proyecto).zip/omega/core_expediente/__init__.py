"""core_expediente: expediente clínico único, máquina de 5 fases, triaje, estado vital y control de acceso."""
