import uuid
from datetime import date, datetime

from sqlalchemy import (
    Boolean, CheckConstraint, DateTime, Float, ForeignKey, Index, Integer, SmallInteger, String, Text, Uuid, text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, declared_attr, mapped_column

from omega_core.constantes import en_lista
from omega_core.models.base import Base, ahora

from .constantes import (
    CIERRES, ESTADOS_ALERGIA, ESTATUS_DIAGNOSTICO, NIVELES_TRIAJE, SEVERIDADES, TIPOS_ANTECEDENTE, TIPOS_ATENCION,
    TIPOS_DIAGNOSTICO, TIPOS_EGRESO,
)

_NIVEL_OK = CheckConstraint("nivel_sensibilidad IN (1, 2, 3, 4)", name="nivel_valido")


def _fk(tabla: str, **kw):
    return mapped_column(Uuid, ForeignKey(f"{tabla}.id", ondelete="RESTRICT"), **kw)


# ---------------------------------------------------------------- Atención (episodio) y máquina de fases
class Atencion(Base):
    """Episodio de atención. `fase` avanza por la máquina de 5 fases (validada en la app y por trigger de PostgreSQL)."""

    __tablename__ = "atencion"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    folio: Mapped[str] = mapped_column(String(20), unique=True)
    paciente_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    institucion_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    tipo_atencion: Mapped[str] = mapped_column(String(20))
    area: Mapped[str] = mapped_column(String(120))
    motivo_consulta: Mapped[str | None] = mapped_column(Text)
    contenido_cifrado: Mapped[str | None] = mapped_column(Text)  # motivo cifrado si el área es de salud mental
    sensible_n4: Mapped[bool] = mapped_column(Boolean, default=False)
    fase: Mapped[int] = mapped_column(SmallInteger, default=1)
    estado: Mapped[str] = mapped_column(String(10), default="ABIERTA")
    nivel_triaje: Mapped[str | None] = mapped_column(String(10))
    codigo_rojo: Mapped[bool] = mapped_column(Boolean, default=False)
    identidad_verificada: Mapped[bool] = mapped_column(Boolean, default=False)
    antecedentes_revisados: Mapped[bool] = mapped_column(Boolean, default=False)
    medico_responsable_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"))
    abierta_por: Mapped[uuid.UUID] = _fk("persona")
    abierta_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    cerrada_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    cierre_tipo: Mapped[str | None] = mapped_column(String(20))

    __table_args__ = (
        CheckConstraint(en_lista("tipo_atencion", TIPOS_ATENCION), name="tipo_valido"),
        CheckConstraint("fase BETWEEN 1 AND 5", name="fase_valida"),
        CheckConstraint("estado IN ('ABIERTA', 'CERRADA')", name="estado_valido"),
        CheckConstraint("(fase = 5) = (estado = 'CERRADA')", name="fase5_es_cerrada"),
        CheckConstraint(f"nivel_triaje IS NULL OR {en_lista('nivel_triaje', NIVELES_TRIAJE)}", name="triaje_valido"),
        CheckConstraint(f"cierre_tipo IS NULL OR {en_lista('cierre_tipo', CIERRES)}", name="cierre_valido"),
        CheckConstraint("(estado = 'CERRADA') = (cierre_tipo IS NOT NULL)", name="cierre_coherente"),
        CheckConstraint(
            "(sensible_n4 AND contenido_cifrado IS NOT NULL AND motivo_consulta IS NULL) OR "
            "(NOT sensible_n4 AND contenido_cifrado IS NULL AND motivo_consulta IS NOT NULL)", name="motivo_cifrado_coherente"),
        # una sola atención abierta por paciente e institución
        Index("uq_atencion_abierta", "paciente_id", "institucion_id", unique=True, postgresql_where=text("estado = 'ABIERTA'")),
    )


class AtencionTransicion(Base):
    """Historial append-only de transiciones de fase (con o sin bypass)."""

    __tablename__ = "atencion_transicion"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    atencion_id: Mapped[uuid.UUID] = _fk("atencion", index=True)
    de_fase: Mapped[int | None] = mapped_column(SmallInteger)
    a_fase: Mapped[int] = mapped_column(SmallInteger)
    actor_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"))
    actor_tipo: Mapped[str] = mapped_column(String(10))  # persona | sistema
    bypass: Mapped[bool] = mapped_column(Boolean, default=False)
    motivo: Mapped[str | None] = mapped_column(Text)
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)


class Triaje(Base):
    __tablename__ = "triaje"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    atencion_id: Mapped[uuid.UUID] = _fk("atencion", index=True)
    nivel: Mapped[str] = mapped_column(String(10))
    discriminador: Mapped[str] = mapped_column(String(300))
    motivo: Mapped[str | None] = mapped_column(Text)
    realizado_por: Mapped[uuid.UUID] = _fk("persona")
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    __table_args__ = (CheckConstraint(en_lista("nivel", NIVELES_TRIAJE), name="nivel_valido"),)


class RevisionBypass(Base):
    """Revisión administrativa obligatoria posterior a un Código Rojo (bypass de emergencia)."""

    __tablename__ = "revision_bypass"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    atencion_id: Mapped[uuid.UUID] = _fk("atencion", unique=True)
    institucion_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    motivo: Mapped[str] = mapped_column(Text)
    activada_por: Mapped[uuid.UUID] = _fk("persona")
    activada_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    vence_en: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    estado: Mapped[str] = mapped_column(String(12), default="PENDIENTE")
    resultado: Mapped[str | None] = mapped_column(String(12))
    comentario: Mapped[str | None] = mapped_column(Text)
    revisada_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        CheckConstraint("estado IN ('PENDIENTE', 'COMPLETADA')", name="estado_valido"),
        CheckConstraint("resultado IS NULL OR resultado IN ('JUSTIFICADO', 'OBSERVADO')", name="resultado_valido"),
    )


# ---------------------------------------------------------------- Registros clínicos (inmutables, versionados)
class RegistroBase:
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    nivel_sensibilidad: Mapped[int] = mapped_column(SmallInteger, default=2)
    contenido_cifrado: Mapped[str | None] = mapped_column(Text)  # Fernet (CLAVE_CAMPOS) cuando nivel = 4
    hash_contenido: Mapped[str] = mapped_column(String(64))
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)

    @declared_attr
    def paciente_id(cls) -> Mapped[uuid.UUID]:
        return mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"), index=True)

    @declared_attr
    def atencion_id(cls) -> Mapped[uuid.UUID]:
        return mapped_column(Uuid, ForeignKey("atencion.id", ondelete="RESTRICT"), index=True)

    @declared_attr
    def institucion_id(cls) -> Mapped[uuid.UUID]:
        return mapped_column(Uuid, ForeignKey("institucion.id", ondelete="RESTRICT"))

    @declared_attr
    def registrado_por(cls) -> Mapped[uuid.UUID]:
        return mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"))


class Versionable:
    """Una corrección es una fila nueva que referencia a la anterior; `reemplaza_id` único = cadena lineal sin bifurcaciones."""

    motivo_correccion: Mapped[str | None] = mapped_column(String(300))

    @declared_attr
    def reemplaza_id(cls) -> Mapped[uuid.UUID | None]:
        return mapped_column(Uuid, ForeignKey(f"{cls.__tablename__}.id", ondelete="RESTRICT"), unique=True)


def _coherencia(plano: str, cifrados: list[str]) -> CheckConstraint:
    """Nivel < 4: campos sensibles en claro y sin cifrado. Nivel 4: campos sensibles NULL y contenido cifrado."""
    nulos = " AND ".join(f"{c} IS NULL" for c in cifrados)
    no_nulos = " AND ".join(f"{c} IS NOT NULL" for c in cifrados)
    return CheckConstraint(
        f"(nivel_sensibilidad = 4 AND contenido_cifrado IS NOT NULL AND {nulos}) OR "
        f"(nivel_sensibilidad < 4 AND contenido_cifrado IS NULL AND {no_nulos})", name=plano)


class Antecedente(RegistroBase, Versionable, Base):
    __tablename__ = "antecedente"
    tipo: Mapped[str] = mapped_column(String(25))
    descripcion: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (_NIVEL_OK, CheckConstraint(en_lista("tipo", TIPOS_ANTECEDENTE), name="tipo_valido"),
                      _coherencia("cifrado_coherente", ["descripcion"]))


class Alergia(RegistroBase, Versionable, Base):
    __tablename__ = "alergia"
    sustancia: Mapped[str] = mapped_column(String(80))
    clase: Mapped[str | None] = mapped_column(String(40))
    severidad: Mapped[str] = mapped_column(String(12))
    reaccion: Mapped[str | None] = mapped_column(String(300))
    estado: Mapped[str] = mapped_column(String(12), default="ACTIVA")
    __table_args__ = (
        _NIVEL_OK, CheckConstraint("nivel_sensibilidad < 4 AND contenido_cifrado IS NULL", name="sin_cifrado"),
        CheckConstraint(en_lista("severidad", SEVERIDADES), name="severidad_valida"),
        CheckConstraint(en_lista("estado", ESTADOS_ALERGIA), name="estado_valido"),
    )


class Diagnostico(RegistroBase, Versionable, Base):
    """CIE-10. En nivel 4 el código, la descripción y las observaciones van cifrados (el código en claro delataría el diagnóstico)."""

    __tablename__ = "diagnostico"
    codigo_cie10: Mapped[str | None] = mapped_column(String(8), index=True)
    descripcion: Mapped[str | None] = mapped_column(String(300))
    observaciones: Mapped[str | None] = mapped_column(Text)
    tipo: Mapped[str] = mapped_column(String(12))
    estatus: Mapped[str] = mapped_column(String(12))
    principal: Mapped[bool] = mapped_column(Boolean, default=False)
    fecha_deteccion: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    __table_args__ = (
        _NIVEL_OK, CheckConstraint(en_lista("tipo", TIPOS_DIAGNOSTICO), name="tipo_valido"),
        CheckConstraint(en_lista("estatus", ESTATUS_DIAGNOSTICO), name="estatus_valido"),
        CheckConstraint(
            "(nivel_sensibilidad = 4 AND contenido_cifrado IS NOT NULL AND codigo_cie10 IS NULL AND descripcion IS NULL "
            "AND observaciones IS NULL) OR (nivel_sensibilidad < 4 AND contenido_cifrado IS NULL AND codigo_cie10 IS NOT NULL "
            "AND descripcion IS NOT NULL)", name="cifrado_coherente"),
    )


class SignosVitales(RegistroBase, Versionable, Base):
    __tablename__ = "signos_vitales"
    tomado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    ta_sistolica: Mapped[int | None] = mapped_column(Integer)
    ta_diastolica: Mapped[int | None] = mapped_column(Integer)
    fc: Mapped[int | None] = mapped_column(Integer)  # ppm
    fr: Mapped[int | None] = mapped_column(Integer)  # rpm
    temperatura: Mapped[float | None] = mapped_column(Float)
    spo2: Mapped[int | None] = mapped_column(Integer)
    glucemia: Mapped[float | None] = mapped_column(Float)
    peso_kg: Mapped[float | None] = mapped_column(Float)
    talla_cm: Mapped[float | None] = mapped_column(Float)
    imc: Mapped[float | None] = mapped_column(Float)
    dolor_eva: Mapped[int | None] = mapped_column(SmallInteger)
    __table_args__ = (_NIVEL_OK, CheckConstraint("nivel_sensibilidad < 4 AND contenido_cifrado IS NULL", name="sin_cifrado"))


class NotaSoap(RegistroBase, Versionable, Base):
    __tablename__ = "nota_soap"
    subjetivo: Mapped[str | None] = mapped_column(Text)
    objetivo: Mapped[str | None] = mapped_column(Text)
    analisis: Mapped[str | None] = mapped_column(Text)
    plan: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (_NIVEL_OK, _coherencia("cifrado_coherente", ["subjetivo", "objetivo", "analisis", "plan"]))


class Egreso(RegistroBase, Base):
    """Alta: resumen de egreso y plan de seguimiento (uno por atención; inmutable)."""

    __tablename__ = "egreso"
    atencion_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("atencion.id", ondelete="RESTRICT"), unique=True)
    tipo_egreso: Mapped[str] = mapped_column(String(20))
    condicion: Mapped[str] = mapped_column(String(200))
    resumen: Mapped[str | None] = mapped_column(Text)
    plan_seguimiento: Mapped[str | None] = mapped_column(Text)
    proximo_control_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (_NIVEL_OK, CheckConstraint(en_lista("tipo_egreso", TIPOS_EGRESO), name="tipo_valido"),
                      _coherencia("cifrado_coherente", ["resumen", "plan_seguimiento"]))


# ---------------------------------------------------------------- Consentimiento y estado vital
class Consentimiento(Base):
    """El paciente autoriza lectura a un profesional concreto o a una institución. Revocable."""

    __tablename__ = "consentimiento"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    paciente_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    profesional_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"))
    institucion_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("institucion.id", ondelete="RESTRICT"))
    nivel_maximo: Mapped[int] = mapped_column(SmallInteger, default=2)
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    vigente_hasta: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    revocado_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        CheckConstraint("(profesional_id IS NULL) <> (institucion_id IS NULL)", name="un_solo_destinatario"),
        CheckConstraint("nivel_maximo IN (2, 4)", name="nivel_valido"),
        CheckConstraint("nivel_maximo = 2 OR profesional_id IS NOT NULL", name="nivel4_solo_profesional"),
    )


class Defuncion(Base):
    """Estado vital FALLECIDO (ausencia de fila vigente = vivo). Mientras `vigente`, el DUI está congelado."""

    __tablename__ = "defuncion"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    persona_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    fallecido_en: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    causa_oficial: Mapped[str] = mapped_column(Text)
    causa_cie10: Mapped[str | None] = mapped_column(String(8))
    entidad_certificadora: Mapped[str] = mapped_column(String(200))
    numero_certificado: Mapped[str] = mapped_column(String(60), unique=True)
    token_verificacion: Mapped[str | None] = mapped_column(String(200))
    hash_payload: Mapped[str] = mapped_column(String(64))
    firma_hmac: Mapped[str | None] = mapped_column(String(64))
    via: Mapped[str] = mapped_column(String(20))  # MEDICINA_LEGAL | OMEGA_MANUAL
    motivo_verificacion_manual: Mapped[str | None] = mapped_column(Text)
    registrado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    registrado_por: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"))
    vigente: Mapped[bool] = mapped_column(Boolean, default=True)
    revertida_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    revertida_por: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"))
    motivo_reversion: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (
        CheckConstraint("via IN ('MEDICINA_LEGAL', 'OMEGA_MANUAL')", name="via_valida"),
        Index("uq_defuncion_vigente", "persona_id", unique=True, postgresql_where=text("vigente")),
    )


# ---------------------------------------------------------------- Camas y recursos
class Cama(Base):
    """Cama de un servicio de una institución. Estados LIBRE / OCUPADA / LIMPIEZA; las transiciones las valida un trigger de PostgreSQL."""

    __tablename__ = "cama"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    institucion_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    servicio: Mapped[str] = mapped_column(String(80))
    codigo: Mapped[str] = mapped_column(String(20))
    estado: Mapped[str] = mapped_column(String(10), default="LIBRE")
    estado_desde: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    activa: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")  # una cama retirada no se borra
    creada_por: Mapped[uuid.UUID] = _fk("persona")
    creada_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    __table_args__ = (
        CheckConstraint("estado IN ('LIBRE', 'OCUPADA', 'LIMPIEZA')", name="estado_valido"),
        Index("uq_cama_institucion_servicio_codigo", "institucion_id", "servicio", "codigo", unique=True),
    )


class OcupacionCama(Base):
    """Ingreso de un paciente a una cama, ligado a su atención. Se cierra con el egreso (nunca se borra).
    Los índices únicos parciales impiden que una cama, un paciente o una atención tengan dos ocupaciones abiertas a la vez."""

    __tablename__ = "ocupacion_cama"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    cama_id: Mapped[uuid.UUID] = _fk("cama", index=True)
    institucion_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    servicio: Mapped[str] = mapped_column(String(80))  # servicio de la cama al momento del ingreso
    atencion_id: Mapped[uuid.UUID] = _fk("atencion", index=True)
    paciente_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    ingreso_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    ingresado_por: Mapped[uuid.UUID] = _fk("persona")
    egreso_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    egresado_por: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"))
    motivo_egreso: Mapped[str | None] = mapped_column(String(20))
    nota_egreso: Mapped[str | None] = mapped_column(String(300))
    __table_args__ = (
        CheckConstraint("egreso_en IS NULL OR egreso_en >= ingreso_en", name="egreso_posterior"),
        CheckConstraint("(egreso_en IS NULL AND egresado_por IS NULL AND motivo_egreso IS NULL) OR (egreso_en IS NOT NULL AND egresado_por IS NOT NULL AND motivo_egreso IS NOT NULL)", name="egreso_completo"),
        CheckConstraint("motivo_egreso IS NULL OR motivo_egreso IN ('ALTA_MEDICA', 'TRASLADO', 'CAMBIO_DE_CAMA', 'FALLECIMIENTO', 'OTRO')", name="motivo_valido"),
        Index("uq_ocupacion_cama_abierta", "cama_id", unique=True, postgresql_where=text("egreso_en IS NULL")),
        Index("uq_ocupacion_paciente_abierta", "paciente_id", unique=True, postgresql_where=text("egreso_en IS NULL")),
        Index("uq_ocupacion_atencion_abierta", "atencion_id", unique=True, postgresql_where=text("egreso_en IS NULL")),
    )
