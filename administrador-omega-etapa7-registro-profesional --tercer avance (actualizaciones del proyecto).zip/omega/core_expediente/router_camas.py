import uuid
from datetime import date, datetime, time, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import func, select
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Persona
from omega_core.models.base import ahora
from omega_core.security.ratelimit import ip_cliente

from .deps import Profesional, medico_activo, profesional_activo
from .models import Atencion, Cama, OcupacionCama
from .schemas_camas import (ActivaIn, CamaIn, CamaOut, EgresoIn, EstadoCama, IngresoIn, OcupacionOut, OcupanteOut, ResumenOcupacionOut, ServicioOcupacionOut)
from .service import esta_congelado

router = APIRouter(prefix="/camas", tags=["camas y recursos · ingreso, egreso y ocupación"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Solo personal de salud verificado y activo de la institución"},
       404: {"description": "Cama o atención no encontrada en SU institución (igual respuesta si es de otra)"},
       409: {"description": "Cama no libre / paciente ya en otra cama / estado no permite la operación"}, 423: {"description": "DUI congelado por fallecimiento"}}
SV = timezone(timedelta(hours=-6))


def _lock_cama(db: Session, cama_id: uuid.UUID, prof: Profesional, ip: str, accion: str) -> Cama:
    c = db.scalar(select(Cama).where(Cama.id == cama_id).with_for_update())
    if c is None or c.institucion_id != prof.institucion_id:
        if c is not None:  # existe pero es de otra institución: se registra el intento, se responde igual que si no existiera
            auditar("CAMA_DENEGADA", actor_tipo="persona", actor_id=prof.persona.id, recurso="cama", recurso_id=cama_id, resultado="FALLO", ip=ip,
                    detalle={"motivo": "OTRA_INSTITUCION", "operacion": accion})
        raise HTTPException(404, "Cama no encontrada en su institución")
    return c


def _denegar(prof: Profesional, cama: Cama | None, ip: str, codigo: int, msg: str, motivo: str, **extra):
    auditar("CAMA_DENEGADA", actor_tipo="persona", actor_id=prof.persona.id, recurso="cama", recurso_id=cama.id if cama else None, resultado="FALLO", ip=ip,
            detalle={"motivo": motivo, "institucion_id": prof.institucion_id, **extra})
    raise HTTPException(codigo, msg)


def _out(c: Cama, o: tuple | None = None) -> CamaOut:
    ocup = None
    if o is not None:
        oc, folio, nombres, apellidos = o
        ocup = OcupanteOut(atencion_id=oc.atencion_id, atencion_folio=folio, paciente=f"{nombres} {apellidos}", ingreso_en=oc.ingreso_en, ingresado_por=oc.ingresado_por)
    return CamaOut(id=c.id, servicio=c.servicio, codigo=c.codigo, estado=c.estado, estado_desde=c.estado_desde, activa=c.activa, ocupante=ocup)


def _ocupacion_out(oc: OcupacionCama, c: Cama) -> OcupacionOut:
    horas = round(((oc.egreso_en or ahora()) - oc.ingreso_en).total_seconds() / 3600, 2) if oc.egreso_en else None
    return OcupacionOut(id=oc.id, cama_id=c.id, servicio=oc.servicio, codigo=c.codigo, atencion_id=oc.atencion_id, ingreso_en=oc.ingreso_en, egreso_en=oc.egreso_en,
                        motivo_egreso=oc.motivo_egreso, estancia_horas=horas, cama_estado=c.estado)


# ------------------------------------------------------------------ Camas
@router.post("", response_model=CamaOut, status_code=201, responses=ERR, summary="Dar de alta una cama en un servicio (médico)",
             description="La cama pertenece a la institución del médico y a un servicio; el código es único dentro del servicio. Nace LIBRE.")
def crear(datos: CamaIn, request: Request, prof: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    c = Cama(institucion_id=prof.institucion_id, servicio=datos.servicio, codigo=datos.codigo, creada_por=prof.persona.id)
    db.add(c)
    try:
        db.commit()
    except DBAPIError:
        db.rollback()
        raise HTTPException(409, "Ya existe una cama con ese código en ese servicio")
    auditar("CAMA_CREADA", actor_tipo="persona", actor_id=prof.persona.id, recurso="cama", recurso_id=c.id, ip=ip_cliente(request),
            detalle={"institucion_id": c.institucion_id, "servicio": c.servicio, "codigo": c.codigo})
    return _out(c)


@router.get("", response_model=list[CamaOut], responses=ERR, summary="Camas de mi institución (censo)",
            description="Solo las de la institución del personal autenticado, con estado y, si está ocupada, folio de la atención y nombre del paciente (sin DUI). Filtros por servicio y estado.")
def listar(request: Request, servicio: str | None = Query(None, max_length=80), estado: EstadoCama | None = None, incluir_retiradas: bool = False,
           prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    q = select(Cama).where(Cama.institucion_id == prof.institucion_id)
    if servicio:
        q = q.where(func.lower(Cama.servicio) == " ".join(servicio.split()).lower())
    if estado:
        q = q.where(Cama.estado == estado)
    if not incluir_retiradas:
        q = q.where(Cama.activa.is_(True))
    camas = db.scalars(q.order_by(Cama.servicio, Cama.codigo).limit(1000)).all()
    ocup = {}
    if camas:
        filas = db.execute(select(OcupacionCama, Atencion.folio, Persona.nombres, Persona.apellidos).join(Atencion, Atencion.id == OcupacionCama.atencion_id)
                           .join(Persona, Persona.id == OcupacionCama.paciente_id).where(OcupacionCama.cama_id.in_([c.id for c in camas]), OcupacionCama.egreso_en.is_(None))).all()
        ocup = {f[0].cama_id: f for f in filas}
    auditar("CAMAS_CONSULTADAS", actor_tipo="persona", actor_id=prof.persona.id, recurso="cama", ip=ip_cliente(request),
            detalle={"institucion_id": prof.institucion_id, "devueltas": len(camas), "con_paciente": len(ocup), "servicio": servicio, "estado": estado})
    return [_out(c, ocup.get(c.id)) for c in camas]


@router.put("/{cama_id}/activa", response_model=CamaOut, responses=ERR, summary="Retirar o reactivar una cama (médico)",
            description="Una cama retirada no se ofrece para ingresos ni cuenta en la ocupación. No se puede retirar una cama ocupada. No se borra nunca.")
def activar(cama_id: uuid.UUID, datos: ActivaIn, request: Request, prof: Profesional = Depends(medico_activo), db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    c = _lock_cama(db, cama_id, prof, ip, "activa")
    if not datos.activa and c.estado == "OCUPADA":
        _denegar(prof, c, ip, 409, "No se puede retirar una cama ocupada: egrese primero al paciente", "CAMA_OCUPADA")
    if c.activa != datos.activa:
        c.activa = datos.activa
        db.commit()
        auditar("CAMA_REACTIVADA" if datos.activa else "CAMA_RETIRADA", actor_tipo="persona", actor_id=prof.persona.id, recurso="cama", recurso_id=c.id, ip=ip,
                detalle={"institucion_id": c.institucion_id, "servicio": c.servicio, "codigo": c.codigo, "motivo": datos.motivo})
    return _out(c)


# ------------------------------------------------------------------ Ingreso / egreso
@router.post("/{cama_id}/ingresar", response_model=OcupacionOut, status_code=201, responses=ERR, summary="Ingresar un paciente a una cama (ligado a su atención activa)",
             description="La cama debe estar **LIBRE** y activa; la atención debe estar **abierta en esta institución**; el paciente **no puede ocupar dos camas** a la vez y el DUI **no puede estar congelado** (423). "
                         "La exclusión la garantiza la **base de datos** (bloqueo de fila e índices únicos parciales por cama, paciente y atención): con ingresos simultáneos solo uno gana.")
def ingresar(cama_id: uuid.UUID, datos: IngresoIn, request: Request, prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    c = _lock_cama(db, cama_id, prof, ip, "ingresar")
    if not c.activa:
        _denegar(prof, c, ip, 409, "La cama está retirada", "CAMA_RETIRADA")
    if c.estado != "LIBRE":
        _denegar(prof, c, ip, 409, f"La cama no está libre (estado: {c.estado})", "CAMA_NO_LIBRE", estado=c.estado)
    at = db.scalar(select(Atencion).where(Atencion.id == datos.atencion_id, Atencion.institucion_id == prof.institucion_id).with_for_update(read=True))
    if at is None:
        _denegar(prof, c, ip, 404, "Atención no encontrada en su institución", "ATENCION_NO_ENCONTRADA")
    if esta_congelado(db, at.paciente_id):
        _denegar(prof, c, ip, 423, "Expediente congelado: el paciente figura como fallecido. No se puede ingresar a una cama.", "DUI_CONGELADO", paciente_id=at.paciente_id)
    if at.estado != "ABIERTA":
        _denegar(prof, c, ip, 409, "La atención no está abierta: solo se ingresa con una atención activa", "ATENCION_CERRADA", atencion_id=at.id)
    otra = db.execute(select(Cama.codigo, Cama.servicio).join(OcupacionCama, OcupacionCama.cama_id == Cama.id).where(OcupacionCama.paciente_id == at.paciente_id, OcupacionCama.egreso_en.is_(None))).first()
    if otra is not None:
        _denegar(prof, c, ip, 409, f"El paciente ya ocupa la cama {otra.codigo} ({otra.servicio}): egréselo primero", "PACIENTE_YA_EN_CAMA", paciente_id=at.paciente_id)
    oc = OcupacionCama(cama_id=c.id, institucion_id=c.institucion_id, servicio=c.servicio, atencion_id=at.id, paciente_id=at.paciente_id, ingresado_por=prof.persona.id)
    db.add(oc)
    try:
        db.flush()
        c.estado, c.estado_desde = "OCUPADA", ahora()
        db.commit()
    except DBAPIError as e:  # índices únicos y triggers de la BD: última barrera
        db.rollback()
        _denegar(prof, c, ip, 409, "Conflicto: la cama o el paciente ya tienen una ocupación abierta", "CONFLICTO_BD", detalle_bd=str(e.orig)[:120])
    auditar("CAMA_INGRESO", actor_tipo="persona", actor_id=prof.persona.id, recurso="cama", recurso_id=c.id, ip=ip,
            detalle={"ocupacion_id": oc.id, "institucion_id": c.institucion_id, "servicio": c.servicio, "codigo": c.codigo, "atencion_id": at.id, "paciente_id": at.paciente_id})
    return _ocupacion_out(oc, c)


@router.post("/{cama_id}/egresar", response_model=OcupacionOut, responses=ERR, summary="Egresar al paciente de la cama (la cama pasa a LIMPIEZA)",
             description="Cierra la ocupación con motivo (`ALTA_MEDICA`, `TRASLADO`, `CAMBIO_DE_CAMA`, `FALLECIMIENTO`, `OTRO`) y deja la cama en **LIMPIEZA**: no vuelve a ofrecerse hasta confirmar la limpieza.")
def egresar(cama_id: uuid.UUID, datos: EgresoIn, request: Request, prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    c = _lock_cama(db, cama_id, prof, ip, "egresar")
    oc = db.scalar(select(OcupacionCama).where(OcupacionCama.cama_id == c.id, OcupacionCama.egreso_en.is_(None)).with_for_update())
    if oc is None:
        _denegar(prof, c, ip, 409, "La cama no tiene un paciente ingresado", "CAMA_SIN_PACIENTE")
    oc.egreso_en, oc.egresado_por, oc.motivo_egreso, oc.nota_egreso = ahora(), prof.persona.id, datos.motivo, datos.nota
    db.flush()  # primero se cierra la ocupación; luego la cama puede pasar a LIMPIEZA (lo exige el trigger)
    c.estado, c.estado_desde = "LIMPIEZA", ahora()
    db.commit()
    auditar("CAMA_EGRESO", actor_tipo="persona", actor_id=prof.persona.id, recurso="cama", recurso_id=c.id, ip=ip,
            detalle={"ocupacion_id": oc.id, "institucion_id": c.institucion_id, "servicio": c.servicio, "codigo": c.codigo, "atencion_id": oc.atencion_id, "paciente_id": oc.paciente_id,
                     "motivo": oc.motivo_egreso, "estancia_horas": round((oc.egreso_en - oc.ingreso_en).total_seconds() / 3600, 2), "ingresado_por": oc.ingresado_por})
    return _ocupacion_out(oc, c)


@router.post("/{cama_id}/limpieza-terminada", response_model=CamaOut, responses=ERR, summary="Confirmar que la cama quedó limpia (LIMPIEZA → LIBRE)",
             description="Cualquier personal de la institución. Solo desde LIMPIEZA; la cama vuelve a ofrecerse para ingresos.")
def limpieza_terminada(cama_id: uuid.UUID, request: Request, prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    c = _lock_cama(db, cama_id, prof, ip, "limpieza")
    if c.estado != "LIMPIEZA":
        _denegar(prof, c, ip, 409, f"La cama no está en limpieza (estado: {c.estado})", "CAMA_NO_EN_LIMPIEZA", estado=c.estado)
    c.estado, c.estado_desde = "LIBRE", ahora()
    db.commit()
    auditar("CAMA_LIMPIEZA_TERMINADA", actor_tipo="persona", actor_id=prof.persona.id, recurso="cama", recurso_id=c.id, ip=ip,
            detalle={"institucion_id": c.institucion_id, "servicio": c.servicio, "codigo": c.codigo})
    return _out(c)


# ------------------------------------------------------------------ Resumen de ocupación
@router.get("/ocupacion", response_model=ResumenOcupacionOut, responses=ERR, summary="Resumen de ocupación del día por servicio",
            description="Camas activas, ocupadas, libres y en limpieza, % de ocupación, ingresos y egresos del día (hora de El Salvador), por servicio y en total para **mi institución**. "
                        "Sin `fecha` es hoy (estado actual). Para un día pasado, `ocupadas` son los pacientes con cama al cierre de ese día (según el historial) y libres/limpieza no aplican.")
def ocupacion(request: Request, fecha: date | None = None, prof: Profesional = Depends(profesional_activo), db: Session = Depends(get_db)):
    hoy = datetime.now(SV).date()
    d = fecha or hoy
    if d > hoy:
        raise HTTPException(422, "No hay resumen de fechas futuras")
    ini, fin = datetime.combine(d, time.min, SV), datetime.combine(d + timedelta(days=1), time.min, SV)
    inst = prof.institucion_id
    base = {s: {"activas": 0, "ocupadas": 0, "libres": 0, "limpieza": 0, "ing": 0, "egr": 0} for s in ()}
    reg = lambda s: base.setdefault(s, {"activas": 0, "ocupadas": 0, "libres": 0, "limpieza": 0, "ing": 0, "egr": 0})  # noqa: E731
    for s, estado, n in db.execute(select(Cama.servicio, Cama.estado, func.count()).where(Cama.institucion_id == inst, Cama.activa.is_(True)).group_by(Cama.servicio, Cama.estado)):
        r = reg(s)
        r["activas"] += n
        r[{"LIBRE": "libres", "OCUPADA": "ocupadas", "LIMPIEZA": "limpieza"}[estado]] += n
    if d < hoy:  # historial: pacientes con cama al cierre del día
        for s in base.values():
            s["ocupadas"] = 0
        for s, n in db.execute(select(OcupacionCama.servicio, func.count()).where(OcupacionCama.institucion_id == inst, OcupacionCama.ingreso_en < fin,
                                                                                   (OcupacionCama.egreso_en.is_(None)) | (OcupacionCama.egreso_en >= fin)).group_by(OcupacionCama.servicio)):
            reg(s)["ocupadas"] += n
    for s, n in db.execute(select(OcupacionCama.servicio, func.count()).where(OcupacionCama.institucion_id == inst, OcupacionCama.ingreso_en >= ini, OcupacionCama.ingreso_en < fin).group_by(OcupacionCama.servicio)):
        reg(s)["ing"] += n
    for s, n in db.execute(select(OcupacionCama.servicio, func.count()).where(OcupacionCama.institucion_id == inst, OcupacionCama.egreso_en >= ini, OcupacionCama.egreso_en < fin).group_by(OcupacionCama.servicio)):
        reg(s)["egr"] += n
    hoy_es = d == hoy
    pct = lambda o, a: round(100 * o / a, 1) if a else 0.0  # noqa: E731
    servicios = [ServicioOcupacionOut(servicio=s, camas_activas=v["activas"], ocupadas=v["ocupadas"], libres=v["libres"] if hoy_es else None, en_limpieza=v["limpieza"] if hoy_es else None,
                                      ocupacion_pct=pct(v["ocupadas"], v["activas"]), ingresos_del_dia=v["ing"], egresos_del_dia=v["egr"]) for s, v in sorted(base.items())]
    tot = lambda k: sum(v[k] for v in base.values())  # noqa: E731
    auditar("CAMAS_OCUPACION_CONSULTADA", actor_tipo="persona", actor_id=prof.persona.id, recurso="cama", ip=ip_cliente(request), detalle={"institucion_id": inst, "fecha": d})
    return ResumenOcupacionOut(fecha=d, institucion_id=inst, camas_activas=tot("activas"), ocupadas=tot("ocupadas"), libres=tot("libres") if hoy_es else None,
                               en_limpieza=tot("limpieza") if hoy_es else None, ocupacion_pct=pct(tot("ocupadas"), tot("activas")), ingresos_del_dia=tot("ing"), egresos_del_dia=tot("egr"),
                               servicios=servicios)
