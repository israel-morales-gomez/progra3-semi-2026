import uuid
from datetime import date, datetime
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

EstadoCama = Literal["LIBRE", "OCUPADA", "LIMPIEZA"]
MotivoEgreso = Literal["ALTA_MEDICA", "TRASLADO", "CAMBIO_DE_CAMA", "FALLECIMIENTO", "OTRO"]


class _In(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class CamaIn(_In):
    servicio: Annotated[str, Field(min_length=2, max_length=80, description="Servicio al que pertenece (p. ej. 'Medicina Interna', 'Pediatría', 'UCI').")]
    codigo: Annotated[str, Field(min_length=1, max_length=20, pattern=r"^[A-Za-z0-9][A-Za-z0-9\-_.]*$", description="Código de la cama, único dentro del servicio (p. ej. 'MI-01').")]

    @field_validator("servicio")
    @classmethod
    def _sin_dobles_espacios(cls, v: str) -> str:
        return " ".join(v.split())

    @field_validator("codigo")
    @classmethod
    def _mayusculas(cls, v: str) -> str:
        return v.upper()


class ActivaIn(_In):
    activa: bool
    motivo: Annotated[str, Field(min_length=5, max_length=300)]


class IngresoIn(_In):
    atencion_id: uuid.UUID = Field(description="Atención ABIERTA del paciente en esta institución.")


class EgresoIn(_In):
    motivo: MotivoEgreso
    nota: Annotated[str, Field(max_length=300)] | None = None


class OcupanteOut(BaseModel):
    atencion_id: uuid.UUID
    atencion_folio: str
    paciente: str = Field(description="Solo el nombre (no el DUI), para el censo de camas del personal de la institución.")
    ingreso_en: datetime
    ingresado_por: uuid.UUID


class CamaOut(BaseModel):
    id: uuid.UUID
    servicio: str
    codigo: str
    estado: EstadoCama
    estado_desde: datetime
    activa: bool
    ocupante: OcupanteOut | None = None


class OcupacionOut(BaseModel):
    id: uuid.UUID
    cama_id: uuid.UUID
    servicio: str
    codigo: str
    atencion_id: uuid.UUID
    ingreso_en: datetime
    egreso_en: datetime | None = None
    motivo_egreso: MotivoEgreso | None = None
    estancia_horas: float | None = None
    cama_estado: EstadoCama


class ServicioOcupacionOut(BaseModel):
    servicio: str
    camas_activas: int
    ocupadas: int = Field(description="Hoy: camas ocupadas ahora. Otro día: pacientes ocupando cama al cierre de ese día.")
    libres: int | None = Field(None, description="Solo cuando la fecha es hoy.")
    en_limpieza: int | None = Field(None, description="Solo cuando la fecha es hoy.")
    ocupacion_pct: float
    ingresos_del_dia: int
    egresos_del_dia: int


class ResumenOcupacionOut(BaseModel):
    fecha: date
    institucion_id: uuid.UUID
    camas_activas: int
    ocupadas: int
    libres: int | None
    en_limpieza: int | None
    ocupacion_pct: float
    ingresos_del_dia: int
    egresos_del_dia: int
    servicios: list[ServicioOcupacionOut]
