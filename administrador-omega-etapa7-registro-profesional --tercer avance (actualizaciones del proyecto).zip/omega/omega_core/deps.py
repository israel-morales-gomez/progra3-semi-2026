import uuid
from ipaddress import ip_address

from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from .config import settings
from .database import get_db
from .models import Institucion, Persona
from .security.ratelimit import ip_cliente
from .security.tokens import decodificar

_bearer = HTTPBearer(auto_error=False)
_NO_AUTH = HTTPException(401, "No autenticado", headers={"WWW-Authenticate": "Bearer"})


def _payload(cred: HTTPAuthorizationCredentials | None, typ: str) -> dict:
    if cred is None:
        raise _NO_AUTH
    p = decodificar(cred.credentials, "access")
    if p["typ"] != typ:
        raise HTTPException(403, "Tipo de credencial no permitido para este recurso")
    return p


def persona_actual(cred: HTTPAuthorizationCredentials | None = Depends(_bearer), db: Session = Depends(get_db)) -> Persona:
    p = _payload(cred, "persona")
    persona = db.get(Persona, uuid.UUID(p["sub"]))
    if persona is None or not persona.activo or persona.es_omega:
        raise _NO_AUTH
    return persona


def institucion_actual(cred: HTTPAuthorizationCredentials | None = Depends(_bearer), db: Session = Depends(get_db)) -> Institucion:
    p = _payload(cred, "institucion")
    inst = db.get(Institucion, uuid.UUID(p["sub"]))
    if inst is None or inst.estado != "ACTIVA":
        raise _NO_AUTH
    return inst


def ip_permitida_omega(ip: str) -> bool:
    try:
        direccion = ip_address(ip)
    except ValueError:
        return False
    return any(direccion in red for red in settings.omega_redes)


def require_omega(request: Request, cred: HTTPAuthorizationCredentials | None = Depends(_bearer), db: Session = Depends(get_db)) -> Persona:
    """Token de Omega + rol OMEGA vigente + IP autorizada, validados en CADA petición."""
    if not ip_permitida_omega(ip_cliente(request)):
        raise HTTPException(403, "Acceso no permitido desde esta red")
    p = _payload(cred, "omega")
    persona = db.get(Persona, uuid.UUID(p["sub"]))
    if persona is None or not persona.activo or not persona.es_omega:
        raise _NO_AUTH
    return persona


def require_permiso(codigo: str):
    def _dep(persona: Persona = Depends(require_omega)) -> Persona:
        if codigo not in persona.permisos:
            raise HTTPException(403, "Permiso insuficiente")
        return persona
    return _dep
