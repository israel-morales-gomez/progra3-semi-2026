import uuid
from datetime import date
from typing import Annotated, Literal

from pydantic import AfterValidator, BaseModel, ConfigDict, EmailStr, Field, HttpUrl, field_validator, model_validator

from .constantes import TipoInstitucion, TipoProfesional, TipoSangre
from .validadores import (
    correo_institucional, normalizar_dui, normalizar_nit, normalizar_telefono, validar_password,
)

DUI = Annotated[str, AfterValidator(normalizar_dui)]
NIT = Annotated[str, AfterValidator(normalizar_nit)]
Telefono = Annotated[str, AfterValidator(normalizar_telefono)]
Password = Annotated[str, Field(max_length=128), AfterValidator(validar_password)]
Texto = Annotated[str, Field(min_length=1, max_length=150)]


class Base(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")


# ---------- Perfiles ----------
class PerfilCivilIn(Base):
    tipo_sangre: TipoSangre | None = None
    contacto_emergencia_nombre: Texto | None = None
    contacto_emergencia_telefono: Telefono | None = None


class PerfilEstudianteIn(Base):
    carne: Annotated[str, Field(min_length=3, max_length=30)]
    universidad_nombre: Texto  # UES, UNIVO, UGB...
    universidad_id: uuid.UUID | None = None
    facultad: Texto | None = None
    carrera: Texto
    ciclo: Annotated[str, Field(min_length=1, max_length=60)]
    correo_institucional: Annotated[EmailStr, AfterValidator(correo_institucional)]


class PerfilProfesionalIn(Base):
    tipo: TipoProfesional
    especialidad: Texto | None = None
    rol_clave: str | None = Field(None, description="Ámbito laboral (uno de los 65 del documento). Decide la plantilla del portal profesional.")
    numero_junta: Annotated[str, Field(min_length=1, max_length=30)]  # JVPM (doctor) / JVPE (enfermera)
    institucion_id: uuid.UUID | None = None  # lugar donde trabaja

    @model_validator(mode="after")
    def _rol(self):
        if self.rol_clave is None:
            return self
        from .roles_profesionales import ENFERMERIA, POR_CLAVE
        if self.rol_clave not in POR_CLAVE:
            raise ValueError("rol_clave no es uno de los 65 ámbitos laborales")
        if (self.tipo == "ENFERMERA") != (self.rol_clave in ENFERMERIA):
            raise ValueError("rol_clave no corresponde al tipo de profesional (enfermería ↔ roles de enfermería)")
        return self


# ---------- Personas ----------
class PersonaRegistro(Base):
    dui: DUI
    nit: NIT | None = None
    nombres: Texto
    apellidos: Texto
    fecha_nacimiento: date | None = None
    sexo: Literal["F", "M"] | None = None
    correo: EmailStr
    telefono: Telefono
    departamento: Annotated[str, Field(max_length=60)] | None = None
    municipio: Annotated[str, Field(max_length=80)] | None = None
    direccion: Annotated[str, Field(max_length=500)] | None = None
    password: Password
    civil: PerfilCivilIn | None = None
    estudiante: PerfilEstudianteIn | None = None
    profesional: PerfilProfesionalIn | None = None


class PersonaActualiza(Base):
    """Datos menores de contacto/ubicación editables por el propio usuario."""
    correo: EmailStr | None = None
    telefono: Telefono | None = None
    departamento: Annotated[str, Field(max_length=60)] | None = None
    municipio: Annotated[str, Field(max_length=80)] | None = None
    direccion: Annotated[str, Field(max_length=500)] | None = None


class OrmOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class PerfilCivilOut(OrmOut):
    tipo_sangre: str | None
    contacto_emergencia_nombre: str | None
    contacto_emergencia_telefono: str | None


class PerfilEstudianteOut(OrmOut):
    carne: str
    universidad_nombre: str
    universidad_id: uuid.UUID | None
    facultad: str | None
    carrera: str
    ciclo: str
    correo_institucional: str
    verificado: bool
    activo: bool


class PerfilProfesionalOut(OrmOut):
    tipo: str
    junta: str
    especialidad: str | None
    rol_clave: str | None = None
    numero_junta: str
    institucion_id: uuid.UUID | None
    verificado: bool
    activo: bool


class PersonaOut(OrmOut):
    id: uuid.UUID
    dui: str
    nit: str | None
    nombres: str
    apellidos: str
    fecha_nacimiento: date | None
    correo: str
    telefono: str
    departamento: str | None
    municipio: str | None
    direccion: str | None
    activo: bool
    roles: list[str] = Field(validation_alias="nombres_roles")
    permisos: list[str]
    civil: PerfilCivilOut | None
    estudiante: PerfilEstudianteOut | None
    profesional: PerfilProfesionalOut | None

    @field_validator("permisos", mode="before")
    @classmethod
    def _ordenar(cls, v):
        return sorted(v)


# ---------- Instituciones ----------
class MedicoDeclarado(Base):
    nombre: Texto
    jvpm: Annotated[str, Field(min_length=1, max_length=30)]


class InstitucionRegistro(Base):
    tipo: TipoInstitucion
    nombre_legal: Annotated[str, Field(min_length=2, max_length=200)]
    nit: NIT
    nrc: Annotated[str, Field(max_length=20)] | None = None
    codigo_minsal: Annotated[str, Field(min_length=2, max_length=30)] | None = None
    numero_registro: Annotated[str, Field(min_length=2, max_length=40)] | None = None  # farmacias
    credencial_autorizacion: Annotated[str, Field(max_length=80)] | None = None  # universidades: MINED/CSSP

    departamento: Annotated[str, Field(max_length=60)] | None = None
    municipio: Annotated[str, Field(max_length=80)] | None = None
    direccion: Annotated[str, Field(min_length=3, max_length=500)]
    latitud: float | None = Field(default=None, ge=-90, le=90)
    longitud: float | None = Field(default=None, ge=-180, le=180)
    telefono: Telefono
    whatsapp: Telefono | None = None
    correo: EmailStr

    responsable_nombre: Texto
    responsable_dui: DUI
    responsable_cargo: Texto | None = None
    responsable_junta: Annotated[str, Field(max_length=30)] | None = None  # JVQF / junta del director técnico
    responsable_correo: EmailStr | None = None
    responsable_telefono: Telefono | None = None

    horario: Annotated[str, Field(max_length=200)] | None = None
    atiende_domicilio: bool = False
    tiene_laboratorio: bool = False
    especialidades: list[Texto] = Field(default_factory=list, max_length=100)
    medicos: list[MedicoDeclarado] = Field(default_factory=list, max_length=2000)
    url_integracion: HttpUrl | None = None

    documento_permiso_ref: Annotated[str, Field(max_length=300)] | None = None
    documento_junta_ref: Annotated[str, Field(max_length=300)] | None = None
    logo_ref: Annotated[str, Field(max_length=300)] | None = None
    password: Password

    @model_validator(mode="after")
    def _requisitos_por_tipo(self):
        faltan: list[str] = []

        def exige(*campos: str):
            faltan.extend(c for c in campos if not getattr(self, c))

        if self.tipo in ("HOSPITAL", "CLINICA"):
            exige("codigo_minsal", "documento_permiso_ref", "horario")
        elif self.tipo == "FARMACIA":
            exige("numero_registro", "responsable_junta", "documento_junta_ref", "documento_permiso_ref")
        elif self.tipo == "LABORATORIO":
            exige("codigo_minsal", "responsable_junta", "documento_permiso_ref")
        elif self.tipo == "UNIVERSIDAD":
            exige("credencial_autorizacion", "responsable_cargo", "responsable_correo", "responsable_telefono")
        if faltan:
            raise ValueError(f"Campos obligatorios para {self.tipo}: {', '.join(faltan)}")
        return self


class InstitucionOut(OrmOut):
    id: uuid.UUID
    tipo: str
    nombre_legal: str
    nit: str
    codigo_minsal: str | None
    numero_registro: str | None
    direccion: str
    telefono: str
    correo: str
    responsable_nombre: str
    responsable_dui: str
    horario: str | None
    especialidades: list
    medicos_declarados: list
    requiere_2fa: bool
    estado: str
    sector: str | None = None
    red_seguros: str | None = None


class EstadoInstitucionIn(Base):
    estado: Literal["ACTIVA", "SUSPENDIDA"]
    motivo: Annotated[str, Field(min_length=3, max_length=300)]


class CoberturaInstitucionIn(Base):
    """Sector y red de seguros de un hospital o clínica (los gestiona Omega). Envíe al menos uno."""

    sector: Literal["PUBLICO", "PRIVADO"] | None = None
    red_seguros: Literal["PUBLICA", "POLIZA_PRIVADA", "AMBAS"] | None = None
    motivo: Annotated[str, Field(min_length=3, max_length=300)]

    @model_validator(mode="after")
    def _alguno(self):
        if self.sector is None and self.red_seguros is None:
            raise ValueError("indique sector, red_seguros o ambos")
        return self


# ---------- Autenticación ----------
class LoginPersona(Base):
    dui: Annotated[str, Field(max_length=20)]
    password: Annotated[str, Field(max_length=128)]


class LoginInstitucion(Base):
    identificador: Annotated[str, Field(max_length=40)]  # NIT o código de establecimiento
    password: Annotated[str, Field(max_length=128)]


class LoginOmega(Base):
    dui: Annotated[str, Field(max_length=20)]
    password: Annotated[str, Field(max_length=128)]
    totp: Annotated[str, Field(max_length=8)]


class Verificar2FA(Base):
    desafio_id: uuid.UUID
    codigo: Annotated[str, Field(min_length=6, max_length=6)]


class RefreshIn(Base):
    refresh_token: Annotated[str, Field(max_length=2000)]


class TokenOut(BaseModel):
    access_token: str
    refresh_token: str | None = None
    token_type: str = "bearer"
    expira_en_seg: int


class LoginRespuesta(BaseModel):
    requiere_2fa: bool = False
    desafio_id: uuid.UUID | None = None
    tokens: TokenOut | None = None


class AuditoriaOut(OrmOut):
    id: int
    fecha_local: str
    actor_tipo: str
    actor_id: str | None
    accion: str
    recurso: str | None
    recurso_id: str | None
    resultado: str
    detalle: dict
    ip: str | None
    hash: str
    hash_prev: str


class VerificacionCadena(BaseModel):
    integra: bool
    registros_verificados: int
    primer_error_id: int | None
    motivo: str | None
    ultimo_hash: str


class VerificacionIn(Base):
    perfil: Literal["profesional", "estudiante"]
    verificado: bool
    motivo: Annotated[str, Field(min_length=3, max_length=300)]
