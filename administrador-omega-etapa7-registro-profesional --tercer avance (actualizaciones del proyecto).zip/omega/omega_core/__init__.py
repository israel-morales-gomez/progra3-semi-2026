"""omega_core: identidad, seguridad, instituciones y auditoría del Administrador Omega."""
