from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

_ph = PasswordHasher()  # argon2id con parámetros por defecto seguros
_DUMMY = _ph.hash("contraseña-ficticia-para-igualar-tiempos")


def hash_password(password: str) -> str:
    return _ph.hash(password)


def verificar_password(hash_guardado: str | None, password: str) -> bool:
    """Verifica en tiempo similar exista o no el usuario (evita enumeración por tiempos)."""
    try:
        _ph.verify(hash_guardado or _DUMMY, password)
        return hash_guardado is not None
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def necesita_rehash(hash_guardado: str) -> bool:
    return _ph.check_needs_rehash(hash_guardado)
