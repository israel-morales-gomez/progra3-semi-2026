import uuid
from datetime import datetime, timedelta, timezone

import jwt
from fastapi import HTTPException
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from ..config import settings
from ..models import RefreshToken

ISS = "administrador-omega"
_REQUERIDOS = ["exp", "iat", "sub", "jti", "typ", "tk", "iss"]


def _emitir(tk: str, typ: str, sub: uuid.UUID, delta: timedelta) -> tuple[str, uuid.UUID, datetime]:
    ahora = datetime.now(timezone.utc)
    jti = uuid.uuid4()
    exp = ahora + delta
    payload = {"iss": ISS, "sub": str(sub), "typ": typ, "tk": tk, "jti": str(jti), "iat": ahora, "exp": exp}
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algoritmo), jti, exp


def emitir_acceso(typ: str, sub: uuid.UUID) -> dict:
    minutos = settings.omega_token_minutos if typ == "omega" else settings.access_token_minutos
    token, _, _ = _emitir("access", typ, sub, timedelta(minutes=minutos))
    return {"access_token": token, "token_type": "bearer", "expira_en_seg": minutos * 60}


def emitir_par(db: Session, typ: str, sub: uuid.UUID) -> dict:
    """Acceso + refresh (el refresh queda registrado para poder rotarlo/revocarlo). El caller hace commit."""
    out = emitir_acceso(typ, sub)
    refresh, jti, exp = _emitir("refresh", typ, sub, timedelta(days=settings.refresh_token_dias))
    db.add(RefreshToken(jti=jti, sujeto_tipo=typ, sujeto_id=sub, expira_en=exp))
    out["refresh_token"] = refresh
    return out


def decodificar(token: str, tk: str) -> dict:
    err = HTTPException(401, "Token inválido o vencido", headers={"WWW-Authenticate": "Bearer"})
    try:
        # algoritmo fijo en la lista: impide ataques de confusión de algoritmo / alg=none
        payload = jwt.decode(
            token, settings.jwt_secret, algorithms=[settings.jwt_algoritmo], issuer=ISS, options={"require": _REQUERIDOS}
        )
        uuid.UUID(payload["sub"])
    except (jwt.PyJWTError, ValueError):
        raise err
    if payload["tk"] != tk:
        raise err
    return payload


def revocar_todos(db: Session, sujeto_tipo: str, sujeto_id: uuid.UUID) -> None:
    db.execute(
        update(RefreshToken)
        .where(RefreshToken.sujeto_tipo == sujeto_tipo, RefreshToken.sujeto_id == sujeto_id)
        .values(revocado=True)
    )


def obtener_refresh(db: Session, jti: uuid.UUID) -> RefreshToken | None:
    return db.scalar(select(RefreshToken).where(RefreshToken.jti == jti).with_for_update())
