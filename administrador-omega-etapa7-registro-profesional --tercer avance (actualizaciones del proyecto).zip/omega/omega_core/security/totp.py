import hmac
import time

import pyotp


def generar_secreto() -> str:
    return pyotp.random_base32()


def uri_aprovisionamiento(secreto: str, cuenta: str) -> str:
    return pyotp.TOTP(secreto).provisioning_uri(name=cuenta, issuer_name="Administrador Omega")


def verificar_totp(secreto: str, codigo: str, ultimo_paso: int | None) -> int | None:
    """Devuelve el paso (time-step) aceptado o None. Rechaza reutilizar un código (anti-replay)."""
    if not (codigo.isdigit() and len(codigo) == 6):
        return None
    totp = pyotp.TOTP(secreto)
    actual = int(time.time()) // 30
    for paso in (actual - 1, actual, actual + 1):
        if hmac.compare_digest(totp.at(paso * 30), codigo):
            if ultimo_paso is not None and paso <= ultimo_paso:
                return None
            return paso
    return None
