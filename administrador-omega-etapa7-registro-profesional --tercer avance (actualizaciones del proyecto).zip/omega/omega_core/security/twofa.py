"""Segundo factor por código. El envío (SMS/WhatsApp) está SIMULADO: se escribe en consola/log."""
import hashlib
import hmac
import logging
import secrets
import uuid
from datetime import timedelta

from sqlalchemy import update
from sqlalchemy.orm import Session

from ..config import settings
from ..models import Desafio2FA
from ..models.base import ahora

logger = logging.getLogger("omega.twofa")
MAX_INTENTOS = 5


def enviar_codigo(destino: str | None, codigo: str, sujeto: str) -> None:
    """Punto de integración con el proveedor SMS/WhatsApp. Aquí solo se registra en el log."""
    if settings.produccion:
        raise RuntimeError("Proveedor de SMS/WhatsApp no configurado")
    logger.warning("[2FA SIMULADO] sujeto=%s destino=%s CÓDIGO=%s", sujeto, destino, codigo)


def _hmac(desafio_id: uuid.UUID, codigo: str) -> str:
    return hmac.new(settings.jwt_secret.encode(), f"{desafio_id}:{codigo}".encode(), hashlib.sha256).hexdigest()


def crear_desafio(db: Session, sujeto_tipo: str, sujeto_id: uuid.UUID, destino: str | None, etiqueta: str) -> uuid.UUID:
    db.execute(
        update(Desafio2FA)
        .where(Desafio2FA.sujeto_tipo == sujeto_tipo, Desafio2FA.sujeto_id == sujeto_id, Desafio2FA.usado.is_(False))
        .values(usado=True)
    )
    codigo = f"{secrets.randbelow(10**6):06d}"
    desafio = Desafio2FA(
        id=uuid.uuid4(), sujeto_tipo=sujeto_tipo, sujeto_id=sujeto_id,
        codigo_hash="", expira_en=ahora() + timedelta(minutes=settings.twofa_minutos),
    )
    desafio.codigo_hash = _hmac(desafio.id, codigo)
    db.add(desafio)
    db.flush()
    enviar_codigo(destino, codigo, etiqueta)
    return desafio.id


def validar_desafio(db: Session, desafio_id: uuid.UUID, codigo: str) -> Desafio2FA | None:
    """Devuelve el desafío si el código es correcto; None si no. Hace commit de intentos/uso."""
    d = db.get(Desafio2FA, desafio_id)
    if d is None or d.usado or d.expira_en <= ahora() or d.intentos >= MAX_INTENTOS:
        return None
    if hmac.compare_digest(d.codigo_hash, _hmac(d.id, codigo.strip())):
        d.usado = True
        db.commit()
        return d
    d.intentos += 1
    db.commit()
    return None
