"""Cifrado de campos sensibles en reposo (Fernet) para datos clínicos de nivel 4.

CLAVE_CAMPOS admite varias claves separadas por coma para rotación: la primera cifra y todas descifran.
"""
import json
from functools import lru_cache

from cryptography.fernet import Fernet, MultiFernet

from ..config import settings


@lru_cache
def _fernet() -> MultiFernet:
    claves = [Fernet(k.strip().encode()) for k in settings.clave_campos.split(",") if k.strip()]
    return MultiFernet(claves)


def cifrar(texto: str) -> str:
    return _fernet().encrypt(texto.encode()).decode()


def descifrar(token: str) -> str:
    return _fernet().decrypt(token.encode()).decode()


def cifrar_json(obj: dict) -> str:
    return cifrar(json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")))


def descifrar_json(token: str) -> dict:
    return json.loads(descifrar(token))
