"""Rate limiting en memoria (un solo proceso; sin Redis en estas etapas)."""
import threading
import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request

from ..config import settings


class Limitador:
    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._bloqueos: dict[str, float] = {}
        self._lock = threading.Lock()

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()
            self._bloqueos.clear()

    def _limpiar(self, clave: str, ventana: float, ahora: float) -> deque[float]:
        q = self._hits[clave]
        while q and q[0] <= ahora - ventana:
            q.popleft()
        if not q:
            self._hits.pop(clave, None)
            return deque()
        return q

    def golpe(self, clave: str, maximo: int, ventana: float) -> int:
        """Registra un intento. Devuelve 0 si se permite o los segundos de espera si se excede."""
        ahora = time.monotonic()
        with self._lock:
            q = self._limpiar(clave, ventana, ahora)
            if len(q) >= maximo:
                return max(1, int(q[0] + ventana - ahora))
            self._hits[clave].append(ahora)  # defaultdict recrea la deque si fue limpiada
            return 0

    def bloqueado(self, clave: str) -> int:
        with self._lock:
            hasta = self._bloqueos.get(clave)
            if hasta is None:
                return 0
            resto = hasta - time.monotonic()
            if resto <= 0:
                del self._bloqueos[clave]
                return 0
            return int(resto) + 1

    def fallo(self, clave: str) -> None:
        ahora = time.monotonic()
        with self._lock:
            q = self._limpiar("f:" + clave, settings.login_bloqueo_seg, ahora)
            self._hits["f:" + clave].append(ahora)
            if len(q) + 1 >= settings.login_max_fallos_id:
                self._bloqueos[clave] = ahora + settings.login_bloqueo_seg
                self._hits.pop("f:" + clave, None)

    def exito(self, clave: str) -> None:
        with self._lock:
            self._hits.pop("f:" + clave, None)
            self._bloqueos.pop(clave, None)


limitador = Limitador()


def _429(espera: int) -> HTTPException:
    return HTTPException(429, "Demasiados intentos. Intente más tarde.", headers={"Retry-After": str(espera)})


def ip_cliente(request: Request) -> str:
    return request.client.host if request.client else "desconocida"


def limitar_ip(request: Request, cubo: str, maximo: int | None = None) -> None:
    espera = limitador.golpe(f"ip:{cubo}:{ip_cliente(request)}", maximo or settings.login_max_por_ip, settings.login_ventana_seg)
    if espera:
        raise _429(espera)


def comprobar_bloqueo(clave: str) -> None:
    espera = limitador.bloqueado(clave)
    if espera:
        raise _429(espera)
