import re

from .config import settings

_DUI = re.compile(r"^(\d{8})-?(\d)$")
_NIT = re.compile(r"^(\d{4})-?(\d{6})-?(\d{3})-?(\d)$")


def digito_dui(ocho: str) -> int:
    suma = sum(int(d) * p for d, p in zip(ocho, range(9, 1, -1)))
    return (10 - suma % 10) % 10


def normalizar_dui(valor: str) -> str:
    m = _DUI.match(valor.strip())
    if not m:
        raise ValueError("DUI inválido: use el formato 00000000-0")
    ocho, dv = m.groups()
    if settings.dui_validar_digito and digito_dui(ocho) != int(dv):
        raise ValueError("DUI inválido: dígito verificador incorrecto")
    return f"{ocho}-{dv}"


def normalizar_nit(valor: str) -> str:
    m = _NIT.match(valor.strip())
    if not m:
        raise ValueError("NIT inválido: use el formato 0000-000000-000-0")
    return "-".join(m.groups())


def normalizar_telefono(valor: str) -> str:
    digitos = re.sub(r"[\s\-()]", "", valor)
    for prefijo in ("+503", "503"):
        if digitos.startswith(prefijo) and len(digitos) == len(prefijo) + 8:
            digitos = digitos[len(prefijo):]
    if not re.fullmatch(r"[267]\d{7}", digitos):
        raise ValueError("Teléfono inválido: 8 dígitos (opcional +503)")
    return f"+503{digitos}"


def validar_password(valor: str) -> str:
    if len(valor) < 10:
        raise ValueError("La contraseña debe tener al menos 10 caracteres")
    if not (re.search(r"[a-z]", valor) and re.search(r"[A-Z]", valor) and re.search(r"\d", valor)):
        raise ValueError("La contraseña debe incluir mayúscula, minúscula y número")
    return valor


def correo_institucional(valor: str) -> str:
    if not valor.lower().endswith(".edu.sv"):
        raise ValueError("El correo institucional debe terminar en .edu.sv")
    return valor.lower()
