from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..auditoria.servicio import registrar as auditar
from ..database import get_db
from ..deps import institucion_actual
from ..models import Institucion
from ..schemas import InstitucionOut, InstitucionRegistro
from ..security.ratelimit import ip_cliente, limitar_ip
from ..servicios.instituciones import crear_institucion

router = APIRouter(prefix="/instituciones", tags=["instituciones"])


@router.post("", response_model=InstitucionOut, status_code=201)
def registrar(datos: InstitucionRegistro, request: Request, db: Session = Depends(get_db)):
    limitar_ip(request, "registro", 20)
    try:
        inst = crear_institucion(db, datos)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "NIT, código de establecimiento o número de registro ya registrado")
    auditar("INSTITUCION_REGISTRADA", actor_tipo="institucion", actor_id=inst.id, recurso="institucion", recurso_id=inst.id,
            ip=ip_cliente(request), detalle={"tipo": inst.tipo, "estado": inst.estado})
    return InstitucionOut.model_validate(inst)


@router.get("/me", response_model=InstitucionOut)
def mi_institucion(inst: Institucion = Depends(institucion_actual)):
    return InstitucionOut.model_validate(inst)
