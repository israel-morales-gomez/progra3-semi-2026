import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..auditoria.servicio import enmascarar
from ..auditoria.servicio import registrar as auditar
from ..config import settings
from ..database import get_db
from ..models import Institucion, Persona
from ..schemas import LoginInstitucion, LoginPersona, LoginRespuesta, RefreshIn, TokenOut, Verificar2FA
from ..security import twofa
from ..security.passwords import hash_password, necesita_rehash, verificar_password
from ..security.ratelimit import comprobar_bloqueo, ip_cliente, limitador, limitar_ip
from ..security.tokens import decodificar, emitir_par, obtener_refresh, revocar_todos
from ..validadores import normalizar_dui, normalizar_nit

router = APIRouter(prefix="/auth", tags=["autenticación"])
_INVALIDAS = HTTPException(401, "Credenciales inválidas")


@router.post("/login/persona", response_model=LoginRespuesta)
def login_persona(datos: LoginPersona, request: Request, db: Session = Depends(get_db)):
    """DUI + contraseña (civiles, estudiantes, doctores, enfermeras)."""
    ip = ip_cliente(request)
    limitar_ip(request, "login")
    try:
        dui = normalizar_dui(datos.dui)
    except ValueError:
        dui = None
    clave = f"persona:{dui or datos.dui.strip()[:20]}"
    comprobar_bloqueo(clave)
    persona = db.scalar(select(Persona).where(Persona.dui == dui)) if dui else None
    ok = verificar_password(persona.password_hash if persona else None, datos.password)
    if not (ok and persona.activo and not persona.es_omega):  # Omega solo entra por /omega/login
        limitador.fallo(clave)
        auditar("LOGIN_PERSONA", actor_tipo="persona" if persona else "anonimo", actor_id=persona.id if persona else None,
                resultado="FALLO", ip=ip, detalle={"identificador": enmascarar(datos.dui)})
        raise _INVALIDAS
    limitador.exito(clave)
    if necesita_rehash(persona.password_hash):
        persona.password_hash = hash_password(datos.password)
    persona.ultimo_login = datetime.now(timezone.utc)
    tokens = emitir_par(db, "persona", persona.id)
    db.commit()
    auditar("LOGIN_PERSONA", actor_tipo="persona", actor_id=persona.id, ip=ip)
    return LoginRespuesta(tokens=TokenOut(**tokens))


def _buscar_institucion(db: Session, ident: str) -> Institucion | None:
    ident = ident.strip()
    try:
        nit = normalizar_nit(ident)
    except ValueError:
        nit = None
    condiciones = [Institucion.codigo_minsal == ident.upper()]
    if nit:
        condiciones.append(Institucion.nit == nit)
    return db.scalar(select(Institucion).where(or_(*condiciones)))


@router.post("/login/institucion", response_model=LoginRespuesta)
def login_institucion(datos: LoginInstitucion, request: Request, db: Session = Depends(get_db)):
    """NIT o código de establecimiento + contraseña. Hospitales y laboratorios requieren además 2FA."""
    ip = ip_cliente(request)
    limitar_ip(request, "login")
    clave = f"inst:{datos.identificador.strip().upper()[:40]}"
    comprobar_bloqueo(clave)
    inst = _buscar_institucion(db, datos.identificador)
    ok = verificar_password(inst.password_hash if inst else None, datos.password)
    if not (ok and inst.estado == "ACTIVA"):
        limitador.fallo(clave)
        auditar("LOGIN_INSTITUCION", actor_tipo="institucion" if inst else "anonimo", actor_id=inst.id if inst else None,
                resultado="FALLO", ip=ip, detalle={"identificador": enmascarar(datos.identificador),
                                                  "estado": inst.estado if inst and ok else None})
        raise _INVALIDAS
    limitador.exito(clave)
    if inst.requiere_2fa or inst.tipo in settings.twofa_set:
        try:
            desafio = twofa.crear_desafio(db, "institucion", inst.id, inst.responsable_telefono or inst.telefono, inst.nombre_legal)
        except RuntimeError:
            db.rollback()
            raise HTTPException(503, "Servicio de segundo factor no disponible")
        db.commit()
        auditar("LOGIN_INSTITUCION_2FA_EMITIDO", actor_tipo="institucion", actor_id=inst.id, ip=ip)
        return LoginRespuesta(requiere_2fa=True, desafio_id=desafio)
    tokens = emitir_par(db, "institucion", inst.id)
    db.commit()
    auditar("LOGIN_INSTITUCION", actor_tipo="institucion", actor_id=inst.id, ip=ip)
    return LoginRespuesta(tokens=TokenOut(**tokens))



@router.post("/2fa/verificar", response_model=LoginRespuesta)
def verificar_2fa(datos: Verificar2FA, request: Request, db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    limitar_ip(request, "2fa")
    desafio = twofa.validar_desafio(db, datos.desafio_id, datos.codigo)
    if desafio is None:
        auditar("LOGIN_2FA", actor_tipo="anonimo", resultado="FALLO", ip=ip, detalle={"desafio_id": datos.desafio_id})
        raise HTTPException(401, "Código inválido o vencido")
    inst = db.get(Institucion, desafio.sujeto_id)
    if inst is None or inst.estado != "ACTIVA":
        raise _INVALIDAS
    tokens = emitir_par(db, "institucion", inst.id)
    db.commit()
    auditar("LOGIN_INSTITUCION", actor_tipo="institucion", actor_id=inst.id, ip=ip, detalle={"segundo_factor": True})
    return LoginRespuesta(tokens=TokenOut(**tokens))


@router.post("/refresh", response_model=TokenOut)
def refrescar(datos: RefreshIn, request: Request, db: Session = Depends(get_db)):
    """Rota el refresh token. Reusar uno ya rotado se interpreta como robo y revoca todas las sesiones del sujeto."""
    ip = ip_cliente(request)
    limitar_ip(request, "refresh", 30)
    p = decodificar(datos.refresh_token, "refresh")
    if p["typ"] not in ("persona", "institucion"):
        raise HTTPException(401, "Token inválido o vencido")
    sujeto = uuid.UUID(p["sub"])
    rt = obtener_refresh(db, uuid.UUID(p["jti"]))
    if rt is None:
        raise HTTPException(401, "Token inválido o vencido")
    if rt.revocado:
        revocar_todos(db, p["typ"], sujeto)
        db.commit()
        auditar("REFRESH_REUSO_DETECTADO", actor_tipo=p["typ"], actor_id=sujeto, resultado="FALLO", ip=ip)
        raise HTTPException(401, "Token inválido o vencido")
    if p["typ"] == "persona":
        s = db.get(Persona, sujeto)
        activo = s is not None and s.activo and not s.es_omega
    else:
        s = db.get(Institucion, sujeto)
        activo = s is not None and s.estado == "ACTIVA"
    if not activo:
        rt.revocado = True
        db.commit()
        raise HTTPException(401, "Token inválido o vencido")
    rt.revocado = True
    tokens = emitir_par(db, p["typ"], sujeto)
    db.commit()
    auditar("TOKEN_REFRESCADO", actor_tipo=p["typ"], actor_id=sujeto, ip=ip)
    return TokenOut(**tokens)


@router.post("/logout", status_code=204)
def logout(datos: RefreshIn, request: Request, db: Session = Depends(get_db)):
    p = decodificar(datos.refresh_token, "refresh")
    rt = obtener_refresh(db, uuid.UUID(p["jti"]))
    if rt is not None:
        rt.revocado = True
        db.commit()
        auditar("LOGOUT", actor_tipo=p["typ"], actor_id=p["sub"], ip=ip_cliente(request))
