from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auditoria.servicio import verificar_cadena
from ..database import get_db
from ..deps import require_permiso
from ..models import Auditoria, Persona
from ..schemas import AuditoriaOut, VerificacionCadena

router = APIRouter(prefix="/auditoria", tags=["auditoría"])
_SV = ZoneInfo("America/El_Salvador")


@router.get("", response_model=list[AuditoriaOut])
def listar(limit: int = Query(50, ge=1, le=500), offset: int = Query(0, ge=0), accion: str | None = Query(None, max_length=60),
           _: Persona = Depends(require_permiso("auditoria:ver")), db: Session = Depends(get_db)):
    q = select(Auditoria).order_by(Auditoria.id.desc()).limit(limit).offset(offset)
    if accion:
        q = q.where(Auditoria.accion == accion)
    return [
        AuditoriaOut(**{c: getattr(f, c) for c in ("id", "actor_tipo", "actor_id", "accion", "recurso", "recurso_id",
                                                  "resultado", "detalle", "ip", "hash", "hash_prev")},
                     fecha_local=f.ts.astimezone(_SV).strftime("%d/%m/%Y - %H:%M"))
        for f in db.scalars(q)
    ]


@router.get("/verificar", response_model=VerificacionCadena)
def verificar(_: Persona = Depends(require_permiso("auditoria:verificar")), db: Session = Depends(get_db)):
    """Recorre toda la cadena recalculando hashes. Guarde `ultimo_hash` fuera del sistema como ancla."""
    return verificar_cadena(db)
