import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auditoria.servicio import enmascarar
from ..auditoria.servicio import registrar as auditar
from ..database import get_db
from ..deps import ip_permitida_omega, require_omega, require_permiso
from ..models import Institucion, Persona
from ..schemas import CoberturaInstitucionIn, EstadoInstitucionIn, InstitucionOut, LoginOmega, PersonaOut, TokenOut, VerificacionIn
from ..security.campos import descifrar
from ..security.passwords import verificar_password
from ..security.ratelimit import comprobar_bloqueo, ip_cliente, limitador, limitar_ip
from ..security.tokens import emitir_acceso
from ..security.totp import verificar_totp
from ..validadores import normalizar_dui

router = APIRouter(prefix="/omega", tags=["administrador omega"])


@router.post("/login", response_model=TokenOut)
def login_omega(datos: LoginOmega, request: Request, db: Session = Depends(get_db)):
    """DUI + contraseña + TOTP obligatorio, solo desde IPs autorizadas. Emite solo token de acceso (sin refresh)."""
    ip = ip_cliente(request)
    if not ip_permitida_omega(ip):
        auditar("OMEGA_LOGIN", resultado="FALLO", actor_tipo="anonimo", ip=ip, detalle={"motivo": "IP_NO_PERMITIDA"})
        raise HTTPException(403, "Acceso no permitido desde esta red")
    limitar_ip(request, "omega_login")
    try:
        dui = normalizar_dui(datos.dui)
    except ValueError:
        dui = None
    clave = f"omega:{dui or datos.dui.strip()[:20]}"
    comprobar_bloqueo(clave)

    persona = db.scalar(select(Persona).where(Persona.dui == dui)) if dui else None
    ok_pass = verificar_password(persona.password_hash if persona else None, datos.password)
    motivo = None
    if not ok_pass:
        motivo = "PASSWORD"
    elif not (persona.activo and persona.es_omega):
        motivo = "NO_OMEGA"
    elif not (persona.totp_activo and persona.totp_secret_cifrado):
        motivo = "TOTP_NO_CONFIGURADO"
    else:
        paso = verificar_totp(descifrar(persona.totp_secret_cifrado), datos.totp, persona.totp_ultimo_paso)
        if paso is None:
            motivo = "TOTP"
        else:
            persona.totp_ultimo_paso = paso  # anti-replay: este código ya no sirve
    if motivo:
        db.rollback()
        limitador.fallo(clave)
        auditar("OMEGA_LOGIN", resultado="FALLO", actor_tipo="persona" if persona else "anonimo",
                actor_id=persona.id if persona else None, ip=ip, detalle={"motivo": motivo, "identificador": enmascarar(datos.dui)})
        raise HTTPException(401, "Credenciales inválidas")
    limitador.exito(clave)
    db.commit()
    auditar("OMEGA_LOGIN", actor_tipo="omega", actor_id=persona.id, ip=ip)
    return TokenOut(**emitir_acceso("omega", persona.id))


@router.get("/me", response_model=PersonaOut)
def yo(persona: Persona = Depends(require_omega)):
    return PersonaOut.model_validate(persona)


@router.get("/instituciones", response_model=list[InstitucionOut])
def listar_instituciones(estado: str | None = Query(None, pattern="^(PENDIENTE|ACTIVA|SUSPENDIDA)$"),
                         limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
                         _: Persona = Depends(require_permiso("instituciones:aprobar")), db: Session = Depends(get_db)):
    q = select(Institucion).order_by(Institucion.creado_en.desc()).limit(limit).offset(offset)
    if estado:
        q = q.where(Institucion.estado == estado)
    return [InstitucionOut.model_validate(i) for i in db.scalars(q)]


@router.patch("/instituciones/{institucion_id}/estado", response_model=InstitucionOut)
def cambiar_estado(institucion_id: uuid.UUID, datos: EstadoInstitucionIn, request: Request,
                   omega: Persona = Depends(require_permiso("instituciones:aprobar")), db: Session = Depends(get_db)):
    inst = db.get(Institucion, institucion_id)
    if inst is None:
        raise HTTPException(404, "Institución no encontrada")
    anterior = inst.estado
    inst.estado = datos.estado
    inst.aprobado_por = omega.id if datos.estado == "ACTIVA" else inst.aprobado_por
    db.commit()
    auditar("INSTITUCION_ESTADO", actor_tipo="omega", actor_id=omega.id, recurso="institucion", recurso_id=inst.id,
            ip=ip_cliente(request), detalle={"de": anterior, "a": datos.estado, "motivo": datos.motivo})
    return InstitucionOut.model_validate(inst)


@router.patch("/instituciones/{institucion_id}/cobertura", response_model=InstitucionOut, summary="Definir sector y red de seguros de un hospital o clínica",
              description="Omega clasifica cada centro como **público o privado** y a qué **red de seguros** atiende (pública, póliza privada o ambas). "
                          "Es lo que filtra el directorio y la selección de citas del ciudadano. Solo hospitales y clínicas. Queda en la bitácora.")
def definir_cobertura(institucion_id: uuid.UUID, datos: CoberturaInstitucionIn, request: Request,
                      omega: Persona = Depends(require_permiso("instituciones:aprobar")), db: Session = Depends(get_db)):
    inst = db.get(Institucion, institucion_id)
    if inst is None:
        raise HTTPException(404, "Institución no encontrada")
    if inst.tipo not in ("HOSPITAL", "CLINICA"):
        raise HTTPException(422, "El sector y la red de seguros solo aplican a hospitales y clínicas")
    antes = {"sector": inst.sector, "red_seguros": inst.red_seguros}
    if datos.sector is not None:
        inst.sector = datos.sector
    if datos.red_seguros is not None:
        inst.red_seguros = datos.red_seguros
    db.commit()
    auditar("INSTITUCION_COBERTURA", actor_tipo="omega", actor_id=omega.id, recurso="institucion", recurso_id=inst.id, ip=ip_cliente(request),
            detalle={"de": antes, "a": {"sector": inst.sector, "red_seguros": inst.red_seguros}, "motivo": datos.motivo})
    return InstitucionOut.model_validate(inst)


@router.patch("/personas/{persona_id}/verificacion", response_model=PersonaOut, summary="Verificar perfil profesional o de estudiante",
              description="Omega confirma (o revoca) la verificación de la JVPM/JVPE o del carné. Solo los profesionales verificados pueden operar en el expediente clínico.")
def verificar_perfil(persona_id: uuid.UUID, datos: VerificacionIn, request: Request,
                     omega: Persona = Depends(require_permiso("personas:verificar")), db: Session = Depends(get_db)):
    persona = db.get(Persona, persona_id)
    perfil = None if persona is None else (persona.profesional if datos.perfil == "profesional" else persona.estudiante)
    if perfil is None:
        raise HTTPException(404, "Persona o perfil no encontrado")
    perfil.verificado = datos.verificado
    db.commit()
    auditar("PERFIL_VERIFICACION", actor_tipo="omega", actor_id=omega.id, recurso=f"perfil_{datos.perfil}", recurso_id=persona.id,
            ip=ip_cliente(request), detalle={"verificado": datos.verificado, "motivo": datos.motivo})
    return PersonaOut.model_validate(persona)
