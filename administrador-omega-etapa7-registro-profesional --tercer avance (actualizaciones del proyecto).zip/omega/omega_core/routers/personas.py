from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..auditoria.servicio import registrar as auditar
from ..database import get_db
from ..deps import persona_actual
from ..models import Persona
from ..schemas import (
    PerfilCivilIn, PerfilCivilOut, PerfilEstudianteIn, PerfilEstudianteOut, PerfilProfesionalIn, PerfilProfesionalOut,
    PersonaActualiza, PersonaOut, PersonaRegistro,
)
from ..security.ratelimit import ip_cliente, limitar_ip
from ..servicios.personas import crear_persona, upsert_civil, upsert_estudiante, upsert_profesional

router = APIRouter(prefix="/personas", tags=["personas"])
_DUPLICADO = HTTPException(409, "Dato ya registrado (DUI, NIT, correo, carné o número de junta)")


@router.post("", response_model=PersonaOut, status_code=201)
def registrar(datos: PersonaRegistro, request: Request, db: Session = Depends(get_db)):
    limitar_ip(request, "registro", 20)
    try:
        persona = crear_persona(db, datos)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise _DUPLICADO
    auditar("PERSONA_REGISTRADA", actor_tipo="persona", actor_id=persona.id, recurso="persona", recurso_id=persona.id,
            ip=ip_cliente(request), detalle={"perfiles": [n for n in ("civil", "estudiante", "profesional") if getattr(persona, n)]})
    return PersonaOut.model_validate(persona)


@router.get("/me", response_model=PersonaOut)
def mi_perfil(persona: Persona = Depends(persona_actual)):
    return PersonaOut.model_validate(persona)


@router.patch("/me", response_model=PersonaOut)
def actualizar_contacto(datos: PersonaActualiza, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    cambios = datos.model_dump(exclude_unset=True, exclude_none=True)
    if "correo" in cambios:
        cambios["correo"] = str(cambios["correo"]).lower()
    for k, v in cambios.items():
        setattr(persona, k, v)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise _DUPLICADO
    auditar("PERSONA_CONTACTO_ACTUALIZADO", actor_tipo="persona", actor_id=persona.id, recurso="persona", recurso_id=persona.id,
            ip=ip_cliente(request), detalle={"campos": sorted(cambios)})
    return PersonaOut.model_validate(persona)


def _guardar(db: Session, persona: Persona, request: Request, perfil: str):
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise _DUPLICADO
    auditar("PERFIL_ACTUALIZADO", actor_tipo="persona", actor_id=persona.id, recurso=f"perfil_{perfil}",
            recurso_id=persona.id, ip=ip_cliente(request))


@router.put("/me/perfiles/civil", response_model=PerfilCivilOut)
def perfil_civil(datos: PerfilCivilIn, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    upsert_civil(db, persona, datos)
    _guardar(db, persona, request, "civil")
    return persona.civil


@router.put("/me/perfiles/estudiante", response_model=PerfilEstudianteOut)
def perfil_estudiante(datos: PerfilEstudianteIn, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    upsert_estudiante(db, persona, datos)
    _guardar(db, persona, request, "estudiante")
    return persona.estudiante


@router.put("/me/perfiles/profesional", response_model=PerfilProfesionalOut)
def perfil_profesional(datos: PerfilProfesionalIn, request: Request, persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)):
    upsert_profesional(db, persona, datos)
    _guardar(db, persona, request, "profesional")
    return persona.profesional
