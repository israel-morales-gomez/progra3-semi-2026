"""Catálogo base de roles y permisos (idempotente)."""
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import Permiso, Rol

PERMISOS = {
    "expediente:leer_propio": "Leer el propio expediente (solo lectura)",
    "citas:agendar_manual": "Agendar citas de forma manual",
    "expediente:leer": "Leer expedientes con asignación activa",
    "expediente:escribir": "Registrar atenciones y notas SOAP",
    "receta:emitir": "Emitir recetas y órdenes médicas firmadas",
    "borrador:crear": "Crear borradores pendientes de co-firma",
    "borrador:cofirmar": "Co-firmar borradores de estudiantes",
    "instituciones:aprobar": "Aprobar o suspender instituciones",
    "auditoria:ver": "Consultar la bitácora de auditoría",
    "auditoria:verificar": "Verificar la integridad de la cadena de auditoría",
    "omega:administrar": "Administración soberana del sistema",
    "personas:verificar": "Verificar perfiles profesionales y de estudiante",
    "estadisticas:consultar": "Consultar estadísticas epidemiológicas agregadas y anonimizadas",
    "estadovital:administrar": "Registrar o revertir el estado vital (fallecimiento) de un paciente",
}

ROLES = {
    "OMEGA": ("Administrador Omega (superusuario soberano)", list(PERMISOS)),
    "CIVIL": ("Persona civil", ["expediente:leer_propio", "citas:agendar_manual"]),
    "ESTUDIANTE": ("Estudiante en práctica", ["borrador:crear"]),
    "SALUD_PUBLICA": ("Salud pública (solo estadísticas agregadas y anonimizadas)", ["estadisticas:consultar"]),
    "PROFESIONAL": ("Profesional de la salud", ["expediente:leer", "expediente:escribir", "receta:emitir", "borrador:cofirmar"]),
}


def asegurar_catalogo(db: Session) -> None:
    existentes = {p.codigo: p for p in db.scalars(select(Permiso))}
    for codigo, desc in PERMISOS.items():
        if codigo not in existentes:
            existentes[codigo] = Permiso(codigo=codigo, descripcion=desc)
            db.add(existentes[codigo])
    roles = {r.nombre: r for r in db.scalars(select(Rol))}
    for nombre, (desc, permisos) in ROLES.items():
        rol = roles.get(nombre) or Rol(nombre=nombre, descripcion=desc, permisos=[])
        db.add(rol)
        actuales = {p.codigo for p in rol.permisos}
        rol.permisos.extend(existentes[c] for c in permisos if c not in actuales)
    db.commit()
