"""Bitácora inalterable: cada registro guarda el hash del anterior (cadena). El trigger de la BD bloquea UPDATE/DELETE/TRUNCATE."""
import hashlib
import json
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from ..database import SessionLocal
from ..models import Auditoria

GENESIS = "0" * 64
_LOCK_KEY = 7_242_122_19  # advisory lock: serializa escrituras para mantener la cadena lineal


def _ts(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def calcular_hash(prev: str, id_: int, ts: datetime, actor_tipo: str, actor_id: str | None, accion: str,
                  recurso: str | None, recurso_id: str | None, resultado: str, detalle: dict, ip: str | None) -> str:
    payload = json.dumps(
        {"id": id_, "ts": _ts(ts), "actor_tipo": actor_tipo, "actor_id": actor_id, "accion": accion,
         "recurso": recurso, "recurso_id": recurso_id, "resultado": resultado, "detalle": detalle, "ip": ip},
        sort_keys=True, separators=(",", ":"), ensure_ascii=False,
    )
    return hashlib.sha256((prev + payload).encode("utf-8")).hexdigest()


def registrar(accion: str, *, actor_tipo: str = "sistema", actor_id: Any = None, recurso: str | None = None,
              recurso_id: Any = None, resultado: str = "OK", detalle: dict | None = None, ip: str | None = None) -> int:
    """Escribe un registro en su propia transacción (queda aunque la petición falle)."""
    detalle_json = json.loads(json.dumps(detalle or {}, default=str))
    actor_id = str(actor_id) if actor_id is not None else None
    recurso_id = str(recurso_id) if recurso_id is not None else None
    with SessionLocal() as s, s.begin():
        s.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": _LOCK_KEY})
        prev = s.execute(text("SELECT hash FROM auditoria ORDER BY id DESC LIMIT 1")).scalar() or GENESIS
        nuevo_id = s.execute(text("SELECT nextval(pg_get_serial_sequence('auditoria', 'id'))")).scalar_one()
        ts = datetime.now(timezone.utc)
        h = calcular_hash(prev, nuevo_id, ts, actor_tipo, actor_id, accion, recurso, recurso_id, resultado, detalle_json, ip)
        s.add(Auditoria(id=nuevo_id, ts=ts, actor_tipo=actor_tipo, actor_id=actor_id, accion=accion, recurso=recurso,
                        recurso_id=recurso_id, resultado=resultado, detalle=detalle_json, ip=ip, hash_prev=prev, hash=h))
    return nuevo_id


def verificar_cadena(db: Session) -> dict:
    prev = GENESIS
    n = 0
    filas = db.execute(select(Auditoria).order_by(Auditoria.id).execution_options(yield_per=1000)).scalars()
    for f in filas:
        if f.hash_prev != prev:
            return {"integra": False, "registros_verificados": n, "primer_error_id": f.id, "motivo": "hash_prev no coincide con el registro anterior", "ultimo_hash": prev}
        esperado = calcular_hash(f.hash_prev, f.id, f.ts, f.actor_tipo, f.actor_id, f.accion, f.recurso, f.recurso_id, f.resultado, f.detalle, f.ip)
        if esperado != f.hash:
            return {"integra": False, "registros_verificados": n, "primer_error_id": f.id, "motivo": "el contenido del registro no coincide con su hash", "ultimo_hash": prev}
        prev = f.hash
        n += 1
    return {"integra": True, "registros_verificados": n, "primer_error_id": None, "motivo": None, "ultimo_hash": prev}


def enmascarar(valor: str) -> str:
    v = (valor or "").strip()
    return f"{v[:2]}***{v[-1:]}" if len(v) > 4 else "***"
