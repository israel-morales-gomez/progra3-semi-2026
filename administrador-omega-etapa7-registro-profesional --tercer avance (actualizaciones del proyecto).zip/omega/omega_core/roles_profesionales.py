"""Registro de los 65 ámbitos laborales del portal profesional (datos de documentacion_clasificada.docx, v1.2).

Vive en omega_core (sin dependencias web) para que el esquema del perfil pueda validar `rol_clave`.

Cada rol = un layout base + un widget especializado + las fases del algoritmo en que actúa de forma dominante.
`layout_alt` solo existe en los 2 roles híbridos (39 y 60): su layout principal es el primero que cita la matriz.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class Rol:
    n: int
    clave: str
    nombre: str
    layout: str
    layout_alt: str | None
    widget: str
    fases: tuple[int, ...]
    envia: str
    recibe: str
    agregado: bool = False  # roles 58-65, añadidos en v1.1


LAYOUTS = ("clinico_general", "urgencias", "quirurgico", "apoyo_lis", "apoyo_enfermeria", "apoyo_gerencial")

ROLES = (
    Rol(1, 'cardiologo', 'Cardiólogo', 'clinico_general', None, 'EKG y Score de Riesgo', (3, 5), 'Recetas de anticoagulantes, notas SOAP cardíacas, órdenes de EKG', 'Trazos de Holter, analíticas de enzimas cardíacas'),
    Rol(2, 'neurologo', 'Neurólogo', 'clinico_general', None, 'Escala Glasgow y Mapeo Sensitivo', (3, 4), 'Órdenes de Tomografía cerebral, notas neurológicas', 'Resultados de punción lumbar y estudios de imagen PACS'),
    Rol(3, 'endocrinologo', 'Endocrinólogo', 'clinico_general', None, 'Curvas de Glucosa y HbA1c', (3, 5), 'Ajustes de dosis de insulina, planes metabólicos', 'Perfiles de glucemia continua y analíticas del LIS'),
    Rol(4, 'gastroenterologo', 'Gastroenterólogo', 'clinico_general', None, 'Escala Child-Pugh', (3, 4), 'Órdenes de endoscopia, diagnósticos CIE-10/11', 'Reportes de biopsias digestivas del LIS'),
    Rol(5, 'neumologo', 'Neumólogo', 'clinico_general', None, 'Espirometría y Oximetría', (3, 5), 'Programas de oxigenoterapia, recetas EPOC', 'Pruebas de función pulmonar y radiografías de tórax'),
    Rol(6, 'nefrologo', 'Nefrólogo', 'clinico_general', None, 'Clamps de Creatinina y Balances', (3, 4), 'Programación de hemodiálisis, ajustes de nefroprotección', 'Electrolitos séricos críticos del LIS'),
    Rol(7, 'hematologo', 'Hematólogo', 'clinico_general', None, 'Frotis y Tiempos de Coagulación', (3, 4), 'Esquemas transfusionales, órdenes de frotis', 'Biometrías hemáticas completas del LIS'),
    Rol(8, 'oncologo_medico', 'Oncólogo Médico', 'clinico_general', None, 'Superficie Corporal y Estadios TNM', (3, 5), 'Protocolos de quimioterapia, notas paliativas', 'Marcadores tumorales y resultados de patología avanzada'),
    Rol(9, 'reumatologo', 'Reumatólogo', 'clinico_general', None, 'Índices de Actividad Articular (DAS28)', (3, 4), 'Recetas de fármacos biológicos y FAMEs', 'Anticuerpos específicos y perfil inmunológico del LIS'),
    Rol(10, 'dermatologo', 'Dermatólogo', 'clinico_general', None, 'Repositorio Fotográfico Cutáneo', (3, 5), 'Órdenes de biopsia de piel, recetas magistrales', 'Dictámenes de anatomía patológica dermatológica'),
    Rol(11, 'infectologo', 'Infectólogo', 'clinico_general', None, 'Mapa Microbiano y Cultivos', (3, 4), 'Restricciones de uso de antibióticos, pautas de aislamiento', 'Cultivos bacteriológicos y antibiogramas del LIS'),
    Rol(12, 'pediatra', 'Pediatra', 'clinico_general', None, 'Curvas OMS de Crecimiento y Vacunas', (3, 5), 'Dosis pediátricas (mg/kg), notas de desarrollo', 'Cartilla de vacunación y analíticas infantiles'),
    Rol(13, 'geriatra', 'Geriatra', 'clinico_general', None, 'Escalas Morse y Criterios STOPP', (3, 5), 'Planes de autonomía, control de polifarmacia', 'Evaluaciones cognitivas y de riesgo de caídas'),
    Rol(14, 'psiquiatra', 'Psiquiatra', 'clinico_general', None, 'Test Psicométricos (PHQ-9)', (3, 4), 'Recetarios de psicofármacos controlados, notas de evolución', 'Alertas de riesgo y reportes de interacciones'),
    Rol(15, 'medico_internista', 'Médico Internista', 'clinico_general', None, 'Notas SOAP Extendidas', (3, 5), 'Órdenes de interconsulta múltiple, epicrisis', 'Resultados integrales de laboratorios e imagenología'),
    Rol(16, 'medico_de_urgencias', 'Médico de Urgencias', 'urgencias', None, 'Código Rojo / Triaje', (1, 3), 'Activación de alertas masivas, estabilización inicial', 'Alertas de alergias críticas del Administrador Omega en rojo'),
    Rol(17, 'intensivista_uci', 'Intensivista (UCI)', 'urgencias', None, 'Telemetría y APACHE II', (3, 4), 'Indicación de drogas vasoactivas, balances horarios', 'Alertas hápticas de inestabilidad y flujos IoT'),
    Rol(18, 'fisiatra', 'Fisiatra', 'clinico_general', None, 'Escala FIM de Independencia', (3, 5), 'Programas de rehabilitación motora y órtesis', 'Historial quirúrgico y notas de traumatología'),
    Rol(19, 'medico_del_deporte', 'Médico del Deporte', 'clinico_general', None, 'Pruebas de Esfuerzo WADA', (3, 5), 'Certificados de aptitud, planes de prevención', 'Evaluaciones biomecánicas y analíticas cardiovasculares'),
    Rol(20, 'medico_del_trabajo', 'Médico del Trabajo', 'clinico_general', None, 'Registro de Siniestralidad', (3, 5), 'Exámenes de ingreso/retiro, constancias de incapacidad', 'Reportes de exposición a riesgos y accidentes laborales'),
    Rol(21, 'genetista_medico', 'Genetista Médico', 'clinico_general', None, 'Árbol Genealógico y Pedigrís', (3, 4), 'Solicitudes de secuenciación de ADN', 'Reportes de genética molecular y biología diagnóstica'),
    Rol(22, 'toxicologo', 'Toxicólogo', 'urgencias', None, 'Guía de Antídotos', (1, 3), 'Protocolos de descontaminación y dosis de antídotos', 'Exámenes toxicológicos de urgencia del LIS'),
    Rol(23, 'alergologo', 'Alergólogo', 'clinico_general', None, 'Prick Test y Desensibilización', (3, 5), 'Esquemas de inmunoterapia, actualización de alergias Omega', 'Resultados de pruebas cutáneas y perfiles de anticuerpos'),
    Rol(24, 'medico_paliativo', 'Médico Paliativo', 'clinico_general', None, 'Escala Análoga Visual del Dolor', (3, 5), 'Titulación de opioides, planes de confort familiar', 'Notas de evolución de medicina interna y oncológica'),
    Rol(25, 'cirujano_general', 'Cirujano General', 'quirurgico', None, 'Lista de Verificación Cirugía Segura', (2, 3), 'Notas operatorias, reserva de quirófano', 'Disponibilidad de camas y muestras para patología'),
    Rol(26, 'cirujano_pediatrico', 'Cirujano Pediátrico', 'quirurgico', None, 'Parámetros Pediátricos Transquirúrgicos', (2, 3), 'Programación de malformaciones congénitas', 'Reportes de anestesia infantil y banco de sangre'),
    Rol(27, 'cirujano_cardiovascular', 'Cirujano Cardiovascular', 'quirurgico', None, 'Tiempos de Circulación Extracorpórea', (2, 3), 'Requerimiento de hemoderivados masivos, notas de bypass', 'Parámetros de perfusión miocárdica en vivo'),
    Rol(28, 'cirujano_toracico', 'Cirujano Torácico', 'quirurgico', None, 'Drenajes Pleurales y Sellos de Agua', (2, 3), 'Órdenes de cirugía VATs y control ventilatorio', 'Radiografías de tórax de control postoperatorio'),
    Rol(29, 'neurocirujano', 'Neurocirujano', 'quirurgico', None, 'Presión Intracraneal (PIC) y Navegación', (2, 3), 'Reportes de microcirugía cerebral, control de PIC', 'Resonancias estereotáxicas del PACS'),
    Rol(30, 'traumatologo_ortopeda', 'Traumatólogo / Ortopeda', 'quirurgico', None, 'Catálogo de Placas, Clavos y Prótesis', (2, 3), 'Solicitudes de osteosíntesis al inventario central', 'Rayos X óseos y confirmación de instrumental estéril'),
    Rol(31, 'cirujano_plastico', 'Cirujano Plástico', 'quirurgico', None, 'Regla de los Nueve (Quemados)', (2, 3), 'Cálculo de reanimación hídrica, notas de colgajos', 'Reportes de viabilidad microvascular y laboratorios'),
    Rol(32, 'urologo', 'Urólogo', 'quirurgico', None, 'Láser de Holmio y Flujometría', (2, 3), 'Programación de litotripsias y prostatectomías', 'Urocultivos y estudios urológicos del LIS'),
    Rol(33, 'oftalmologo', 'Oftalmólogo', 'quirurgico', None, 'Fórmulas Biométricas de Lentes', (2, 3), 'Órdenes de microcirugía ocular y tonometrías', 'Topografías corneales y campos visuales'),
    Rol(34, 'otorrinolaringologo', 'Otorrinolaringólogo', 'quirurgico', None, 'Curvas Audiométricas', (2, 3), 'Programación de amigdalectomías y septoplastias', 'Audiometrías tonales y tomografías de senos paranasales'),
    Rol(35, 'cirujano_maxilofacial', 'Cirujano Maxilofacial', 'quirurgico', None, 'Simulador de Oclusión Dental', (2, 3), 'Tratamientos de fracturas faciales y osteotomías', 'Tomografías 3D maxilofaciales del PACS'),
    Rol(36, 'angiologo_vascular', 'Angiólogo / Vascular', 'quirurgico', None, 'Mapeo Doppler Periférico', (2, 3), 'Solicitudes de bypass periférico y accesos de diálisis', 'Estudios Doppler y angiografías del PACS'),
    Rol(37, 'cirujano_oncologo', 'Cirujano Oncólogo', 'quirurgico', None, 'Márgenes Quirúrgicos y Ganglios', (2, 3), 'Reportes de vaciamiento ganglionar, notas tumorales', 'Patología transoperatoria (corte congelado)'),
    Rol(38, 'cirujano_de_trasplantes', 'Cirujano de Trasplantes', 'quirurgico', None, 'Cruce HLA y Tiempo de Isquemia', (2, 3), 'Activación de operativo nacional de órganos al Omega', 'Historial de compatibilidad y estatus de lista nacional'),
    Rol(39, 'gineco_obstetra', 'Gineco-Obstetra', 'clinico_general', 'quirurgico', 'Calculadora Gestacional', (2, 3), 'Programación de cesáreas, control prenatal, notas de parto', 'Monitoreo fetal continuo y ultrasonidos obstétricos'),
    Rol(40, 'neonatologo', 'Neonatólogo', 'clinico_general', None, 'Capurro/Ballard y CPAP', (3, 4), 'Ingresos a UCIN, órdenes de soporte respiratorio infantil', 'Gasometrías neonatales y analíticas de tamizaje'),
    Rol(41, 'perinatologo', 'Perinatólogo', 'clinico_general', None, 'Doppler Fetal y Curvas', (3, 4), 'Diagnósticos de alto riesgo obstétrico, amniocentesis', 'Ecocardiografías fetales e imágenes de alta definición'),
    Rol(42, 'anatomopatologo', 'Anatomopatólogo', 'apoyo_lis', None, 'Nomenclatura SNOMED-CT', (3, 4), 'Dictámenes histopatológicos estructurados con imágenes', 'Especímenes biológicos y piezas quirúrgicas asociadas al DUI'),
    Rol(43, 'analista_de_laboratorio', 'Analista de Laboratorio', 'apoyo_lis', None, 'Códigos de Barra y Valores', (3, 4), 'Resultados cuantitativos con banderas de valores críticos en rojo', 'Solicitudes de laboratorio con justificación clínica'),
    Rol(44, 'radiologo_pacs', 'Radiólogo / PACS', 'apoyo_lis', None, 'Visor DICOM e IA', (3, 4), 'Dictámenes radiológicos estructurados y enlaces a imágenes', 'Órdenes de TAC, RMN, Rayos X ligadas al DUI'),
    Rol(45, 'genetista_molecular', 'Genetista Molecular', 'apoyo_lis', None, 'Secuenciador y Control de PCR', (3, 4), 'Resultados de cargas virales y perfiles genómicos moleculares', 'Muestras de ADN y solicitudes de biología molecular'),
    Rol(46, 'enfermero_general', 'Enfermero General', 'apoyo_enfermeria', None, 'Carrusel y Signos', (1, 4), 'Registro de signos vitales, confirmación de aplicación de fármacos', 'Órdenes médicas directas del Algoritmo Laboral (Fase 3)'),
    Rol(47, 'odontologo', 'Odontólogo', 'clinico_general', None, 'Odontograma Digital Interactivo', (3, 5), 'Recetas odontológicas, notas de endodoncia y profilaxis', 'Alertas de alergias y antecedentes del paciente'),
    Rol(48, 'farmaceutico_clinico', 'Farmacéutico Clínico', 'apoyo_enfermeria', None, 'Despacho y Stock', (2, 4), 'Validación de recetas, control de lotes y fechas de caducidad', 'Recetas electrónicas del tronco común y bloqueos'),
    Rol(49, 'nutricionista', 'Nutricionista', 'clinico_general', None, 'Harris-Benedict y Dietas', (3, 4), 'Prescripción de dietas hospitalarias y enterales/parenterales', 'Alertas de desnutrición y perfiles metabólicos'),
    Rol(50, 'fisioterapeuta', 'Fisioterapeuta', 'apoyo_enfermeria', None, 'Movilización y Arcos', (3, 4), 'Evolución de sesiones de terapia física y respiratoria', 'Indicaciones médicas de rehabilitación postquirúrgica'),
    Rol(51, 'psicologo_clinico', 'Psicólogo Clínico', 'clinico_general', None, 'Notas de Psicoterapia y Crisis', (3, 5), 'Notas de evolución psicológica y baterías psicodiagnósticas', 'Derivaciones de psiquiatría y medicina interna'),
    Rol(52, 'fonoaudiologo', 'Fonoaudiólogo', 'clinico_general', None, 'Protocolo Deglutorio', (3, 4), 'Evaluaciones de disfagia y planes de reeducación vocal', 'Órdenes de terapia de lenguaje post-extubación'),
    Rol(53, 'tecnologo_medico', 'Tecnólogo Médico', 'apoyo_lis', None, 'Calibración Biomédica', (2, 4), 'Reportes de fallas técnicas y bitácoras de calibración', 'Programación de mantenimiento de equipos críticos'),
    Rol(54, 'especialista_en_salud_publica', 'Especialista en Salud Pública', 'apoyo_gerencial', None, 'Tableros Macro', (5,), 'Informes de impacto sanitario y directrices preventivas', 'Datos agregados anónimos de la red nacional del Omega'),
    Rol(55, 'epidemiologo', 'Epidemiólogo', 'apoyo_gerencial', None, 'SIMMOW / VIGEPES', (4, 5), 'Alertas de brotes, reportes automáticos a sistemas nacionales', 'Consumo en vivo de diagnósticos CIE-10/11 del expediente'),
    Rol(56, 'medico_preventivo', 'Médico Preventivo', 'apoyo_gerencial', None, 'Tamizajes y Vacunas', (3, 5), 'Convocatorias de tamizaje, control de coberturas preventivas', 'Padrones poblacionales del Administrador Omega'),
    Rol(57, 'administrador_hospitalario', 'Administrador Hospitalario', 'apoyo_gerencial', None, 'Ocupación y Costos', (2, 5), 'Asignación presupuestaria, gestión de suministros institucionales', 'Métricas de lead time hospitalario y ocupación de camas UCI'),
    Rol(58, 'anestesiologo', 'Anestesiólogo', 'quirurgico', None, 'Monitoreo de Profundidad Anestésica (BIS) y Vía Aérea', (2, 3), 'Plan anestésico, registro transanestésico, manejo de vía aérea', 'Antecedentes alérgicos, resultados preoperatorios y disponibilidad de hemoderivados', True),
    Rol(59, 'enfermero_de_uci', 'Enfermero de UCI', 'apoyo_enfermeria', None, 'Telemetría y Escala de Sedación (RASS)', (3, 4), 'Balances horarios, registro de sedación y ventilación', 'Órdenes médicas de cuidados críticos y flujos IoT de monitores', True),
    Rol(60, 'enfermero_de_urgencias_instrumentista_quirurgico', 'Enfermero de Urgencias / Instrumentista Quirúrgico', 'urgencias', 'quirurgico', 'Conteo de Instrumental y Triaje', (1, 2), 'Conteo de gasas e instrumental, confirmación de triaje', 'Órdenes de cirugía y protocolos de urgencia', True),
    Rol(61, 'enfermero_de_control_de_infecciones', 'Enfermero de Control de Infecciones', 'apoyo_gerencial', None, 'Vigilancia de IAAS', (4, 5), 'Reportes de infecciones asociadas a la atención sanitaria, alertas de aislamiento', 'Cultivos positivos y antibiogramas del LIS', True),
    Rol(62, 'trabajador_social', 'Trabajador Social', 'clinico_general', None, 'Ficha Socioeconómica y Red de Apoyo', (3, 5), 'Evaluaciones socioeconómicas, gestión de referencias comunitarias', 'Alertas de pacientes en riesgo social o sin red de apoyo', True),
    Rol(63, 'capellan_apoyo_espiritual', 'Capellán / Apoyo Espiritual', 'clinico_general', None, 'Registro de Visitas Pastorales', (5,), 'Notas de acompañamiento espiritual y consentimientos religiosos especiales', 'Solicitudes de la familia o del equipo de medicina paliativa', True),
    Rol(64, 'gestor_de_expedientes_clinicos_archivo', 'Gestor de Expedientes Clínicos (Archivo)', 'apoyo_gerencial', None, 'Control de Integridad Documental', (4, 5), 'Reportes de completitud de expedientes, gestión de solicitudes de copias', 'Cierres de expediente de todos los roles clínicos', True),
    Rol(65, 'oficial_de_calidad_y_seguridad_del_paciente', 'Oficial de Calidad y Seguridad del Paciente', 'apoyo_gerencial', None, 'Indicadores de Eventos Adversos', (4, 5), 'Reportes de eventos adversos y cuasi-fallas', 'Datos agregados de auditoría de todos los módulos', True),
)

POR_CLAVE = {r.clave: r for r in ROLES}
assert len(ROLES) == 65 and len(POR_CLAVE) == 65

ENFERMERIA = frozenset({"enfermero_general", "enfermero_de_uci", "enfermero_de_urgencias_instrumentista_quirurgico", "enfermero_de_control_de_infecciones"})

# Especialidad escrita en el perfil (texto libre, ya normalizada: minúsculas, sin tildes) -> rol. Solo se usa si el perfil no trae `rol_clave`.
ALIAS_ESPECIALIDAD = {
    "cardiologia": "cardiologo", "neurologia": "neurologo", "endocrinologia": "endocrinologo", "gastroenterologia": "gastroenterologo",
    "neumologia": "neumologo", "nefrologia": "nefrologo", "hematologia": "hematologo", "oncologia": "oncologo_medico", "oncologia medica": "oncologo_medico",
    "reumatologia": "reumatologo", "dermatologia": "dermatologo", "infectologia": "infectologo", "pediatria": "pediatra", "geriatria": "geriatra",
    "psiquiatria": "psiquiatra", "medicina interna": "medico_internista", "urgencias": "medico_de_urgencias", "medicina de urgencias": "medico_de_urgencias",
    "cuidados intensivos": "intensivista_uci", "medicina critica": "intensivista_uci", "fisiatria": "fisiatra", "medicina del deporte": "medico_del_deporte",
    "medicina del trabajo": "medico_del_trabajo", "genetica medica": "genetista_medico", "toxicologia": "toxicologo", "alergologia": "alergologo",
    "alergia e inmunologia": "alergologo", "medicina paliativa": "medico_paliativo", "cirugia general": "cirujano_general", "cirugia pediatrica": "cirujano_pediatrico",
    "cirugia cardiovascular": "cirujano_cardiovascular", "cirugia toracica": "cirujano_toracico", "neurocirugia": "neurocirujano", "traumatologia": "traumatologo_ortopeda",
    "ortopedia": "traumatologo_ortopeda", "cirugia plastica": "cirujano_plastico", "urologia": "urologo", "oftalmologia": "oftalmologo", "otorrinolaringologia": "otorrinolaringologo",
    "cirugia maxilofacial": "cirujano_maxilofacial", "angiologia": "angiologo_vascular", "cirugia vascular": "angiologo_vascular", "cirugia oncologica": "cirujano_oncologo",
    "trasplantes": "cirujano_de_trasplantes", "ginecologia": "gineco_obstetra", "obstetricia": "gineco_obstetra", "ginecologia y obstetricia": "gineco_obstetra",
    "neonatologia": "neonatologo", "perinatologia": "perinatologo", "anatomia patologica": "anatomopatologo", "patologia": "anatomopatologo", "radiologia": "radiologo_pacs",
    "odontologia": "odontologo", "anestesiologia": "anestesiologo", "medicina preventiva": "medico_preventivo", "salud publica": "especialista_en_salud_publica",
    "epidemiologia": "epidemiologo", "nutricion": "nutricionista", "psicologia": "psicologo_clinico", "psicologia clinica": "psicologo_clinico",
}
