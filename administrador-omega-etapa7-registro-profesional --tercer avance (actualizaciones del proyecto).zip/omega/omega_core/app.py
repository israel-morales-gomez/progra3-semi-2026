import logging

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from .catalogo import asegurar_catalogo
from .config import settings
from .database import SessionLocal, engine
from .routers import auditoria, auth, instituciones, omega, personas

_RUTAS_DOCS = ("/docs", "/redoc", "/openapi.json")


CSP_HTML = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; "
            "form-action 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'")


def crear_app() -> FastAPI:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        with SessionLocal() as db:
            asegurar_catalogo(db)
        yield

    docs = settings.docs_activos
    app = FastAPI(
        title="Administrador Omega - Protocol Zero (V-242122-19)", version="0.1.0", lifespan=lifespan,
        docs_url="/docs" if docs else None, redoc_url=None, openapi_url="/openapi.json" if docs else None,
    )

    if settings.cors_lista:
        app.add_middleware(
            CORSMiddleware, allow_origins=settings.cors_lista, allow_credentials=False,
            allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"], allow_headers=["Authorization", "Content-Type"],
        )

    @app.middleware("http")
    async def cabeceras_seguridad(request: Request, call_next):
        resp = await call_next(request)
        h = resp.headers
        h["X-Content-Type-Options"] = "nosniff"
        h["X-Frame-Options"] = "DENY"
        h["Referrer-Policy"] = "no-referrer"
        h["Permissions-Policy"] = "geolocation=(), camera=(), microphone=()"
        h["Cross-Origin-Resource-Policy"] = "same-origin"
        if not request.url.path.startswith(_RUTAS_DOCS):  # Swagger UI necesita cargar su JS/CSS
            if h.get("content-type", "").startswith("text/html"):  # páginas de los portales: solo scripts y estilos propios de /static
                h["Content-Security-Policy"] = CSP_HTML
                h["Cross-Origin-Opener-Policy"] = "same-origin"
            else:  # respuestas JSON de la API (y estáticos): CSP cerrada
                h["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'"
            h["Cache-Control"] = "public, max-age=3600" if request.url.path.startswith("/static/") else "no-store"
        if settings.hsts_activo:
            h["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        return resp

    @app.get("/health", tags=["sistema"])
    def health():
        with engine.connect() as c:
            c.execute(text("SELECT 1"))
        return {"estado": "ok"}

    for r in (personas.router, instituciones.router, auth.router, omega.router, auditoria.router):
        app.include_router(r)
    from core_expediente.routers import routers as routers_expediente

    for r in routers_expediente:
        app.include_router(r)
    from farmacia.routers import routers as routers_farmacia
    for r in routers_farmacia:
        app.include_router(r)
    from laboratorio.routers import routers as routers_laboratorio
    for r in routers_laboratorio:
        app.include_router(r)
    from portal_civil.routers import routers as routers_portal
    for r in routers_portal:
        app.include_router(r)
    from academico_cofirma.routers import routers as routers_academico
    for r in routers_academico:
        app.include_router(r)
    from nodo_edge_sync.routers import routers as routers_sync
    for r in routers_sync:
        app.include_router(r)
    from estadistica_epidemiologia.routers import routers as routers_estadistica
    for r in routers_estadistica:
        app.include_router(r)
    from web.comun.instalar import instalar_frontend  # frontend: siete portales (Etapa 7)
    instalar_frontend(app)
    return app
