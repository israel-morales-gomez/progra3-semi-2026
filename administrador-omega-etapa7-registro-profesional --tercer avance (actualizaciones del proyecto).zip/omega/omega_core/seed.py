"""Datos semilla de DESARROLLO: un Omega, un hospital, un médico y un civil.

Uso:  uv run python -m omega_core.seed
Es idempotente: si ya existen, no los duplica ni cambia sus contraseñas.
"""
import sys

from sqlalchemy import select

from .catalogo import asegurar_catalogo
from .config import settings
from .database import SessionLocal
from .models import Institucion, PerfilCivil, PerfilProfesional, Persona, Rol
from .security.campos import cifrar
from .security.passwords import hash_password
from .security.totp import uri_aprovisionamiento
from .validadores import digito_dui

PASSWORD_OMEGA = "Omega#Dev2026"
PASSWORD_HOSPITAL = "Hospital#Dev2026"
PASSWORD_MEDICO = "Medico#Dev2026"
PASSWORD_CIVIL = "Civil#Dev2026"
PASSWORD_FARMACIA = "Farmacia#Dev2026"
TOTP_OMEGA = "JBSWY3DPEHPK3PXP"  # secreto fijo SOLO para desarrollo (agregarlo en cualquier app TOTP)


def _dui(ocho: str) -> str:
    return f"{ocho}-{digito_dui(ocho)}"


DUI_OMEGA, DUI_MEDICO, DUI_CIVIL, DUI_DIRECTOR = _dui("00000001"), _dui("01234567"), _dui("07654321"), _dui("02222222")
NIT_HOSPITAL = "0614-010190-101-1"
CODIGO_HOSPITAL = "H-0001"
NIT_FARMACIA = "0614-020290-102-2"
REGISTRO_FARMACIA = "FARM-0001"


def _rol(db, nombre: str) -> Rol:
    return db.scalars(select(Rol).where(Rol.nombre == nombre)).one()


def sembrar() -> None:
    if settings.produccion:
        sys.exit("El seed de desarrollo no se ejecuta con ENTORNO=produccion.")
    with SessionLocal() as db:
        asegurar_catalogo(db)

        hospital = db.scalar(select(Institucion).where(Institucion.nit == NIT_HOSPITAL))
        if hospital is None:
            hospital = Institucion(
                tipo="HOSPITAL", nombre_legal="Hospital Nacional Demo", nit=NIT_HOSPITAL, nrc="123456-7",
                codigo_minsal=CODIGO_HOSPITAL, departamento="San Salvador", municipio="San Salvador",
                direccion="Colonia Médica, San Salvador", latitud=13.7, longitud=-89.2, telefono="+50322220000",
                correo="hospital.demo@example.sv", responsable_nombre="Dra. Directora Demo", responsable_dui=DUI_DIRECTOR,
                responsable_cargo="Director", responsable_telefono="+50370000000", horario="24 horas",
                tiene_laboratorio=True, especialidades=["Medicina Interna", "Pediatría", "Cardiología"],
                medicos_declarados=[{"nombre": "Dr. Médico Demo", "jvpm": "12345"}],
                documento_permiso_ref="seed://permiso-minsal-demo.pdf", password_hash=hash_password(PASSWORD_HOSPITAL),
                requiere_2fa=True, estado="ACTIVA",
            )
            db.add(hospital)
            db.flush()

        if db.scalar(select(Institucion).where(Institucion.nit == NIT_FARMACIA)) is None:
            db.add(Institucion(
                tipo="FARMACIA", nombre_legal="Farmacia Demo", nit=NIT_FARMACIA, numero_registro=REGISTRO_FARMACIA,
                departamento="San Salvador", municipio="San Salvador", direccion="Calle Principal, San Salvador", telefono="+50322230000",
                correo="farmacia.demo@example.sv", responsable_nombre="Lic. Químico Demo", responsable_dui=DUI_DIRECTOR, responsable_junta="JVQF-1001",
                horario="8:00-20:00", documento_junta_ref="seed://junta-demo.pdf", documento_permiso_ref="seed://permiso-farmacia-demo.pdf",
                password_hash=hash_password(PASSWORD_FARMACIA), requiere_2fa=False, estado="ACTIVA"))

        omega = db.scalar(select(Persona).where(Persona.dui == DUI_OMEGA))
        if omega is None:
            omega = Persona(
                dui=DUI_OMEGA, nombres="Administrador", apellidos="Omega", correo="omega@example.sv", telefono="+50370000001",
                password_hash=hash_password(PASSWORD_OMEGA), totp_secret_cifrado=cifrar(TOTP_OMEGA), totp_activo=True,
                roles=[_rol(db, "OMEGA")],
            )
            db.add(omega)

        if db.scalar(select(Persona).where(Persona.dui == DUI_MEDICO)) is None:
            db.add(Persona(
                dui=DUI_MEDICO, nombres="Médico", apellidos="Demo", correo="medico@example.sv", telefono="+50370000002",
                departamento="San Salvador", municipio="San Salvador", password_hash=hash_password(PASSWORD_MEDICO),
                roles=[_rol(db, "CIVIL"), _rol(db, "PROFESIONAL")], civil=PerfilCivil(tipo_sangre="O+"),
                profesional=PerfilProfesional(tipo="DOCTOR", especialidad="Medicina Interna", numero_junta="12345",
                                              institucion_id=hospital.id, verificado=True),
            ))

        if db.scalar(select(Persona).where(Persona.dui == DUI_CIVIL)) is None:
            db.add(Persona(
                dui=DUI_CIVIL, nombres="Ciudadano", apellidos="Demo", correo="civil@example.sv", telefono="+50370000003",
                departamento="La Libertad", municipio="Santa Tecla", password_hash=hash_password(PASSWORD_CIVIL),
                roles=[_rol(db, "CIVIL")], civil=PerfilCivil(tipo_sangre="A-"),
            ))
        db.commit()

    print("\n=== Datos semilla (SOLO DESARROLLO) ===")
    print(f"Omega      DUI {DUI_OMEGA}  clave {PASSWORD_OMEGA}  TOTP secreto {TOTP_OMEGA}")
    print(f"           URI TOTP: {uri_aprovisionamiento(TOTP_OMEGA, DUI_OMEGA)}")
    print(f"Hospital   NIT {NIT_HOSPITAL} (o código {CODIGO_HOSPITAL})  clave {PASSWORD_HOSPITAL}  [2FA: el código sale en la consola del servidor]")
    print(f"Médico     DUI {DUI_MEDICO}  clave {PASSWORD_MEDICO}")
    print(f"Civil      DUI {DUI_CIVIL}  clave {PASSWORD_CIVIL}")
    print(f"Farmacia   NIT {NIT_FARMACIA} (o registro {REGISTRO_FARMACIA})  clave {PASSWORD_FARMACIA}")


if __name__ == "__main__":
    sembrar()
