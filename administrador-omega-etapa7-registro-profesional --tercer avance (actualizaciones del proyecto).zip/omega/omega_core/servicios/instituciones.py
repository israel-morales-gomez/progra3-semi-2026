from sqlalchemy.orm import Session

from ..config import settings
from ..models import Institucion
from ..schemas import InstitucionRegistro
from ..security.passwords import hash_password


def crear_institucion(db: Session, d: InstitucionRegistro) -> Institucion:
    inst = Institucion(
        tipo=d.tipo, nombre_legal=d.nombre_legal, nit=d.nit, nrc=d.nrc,
        codigo_minsal=d.codigo_minsal.upper() if d.codigo_minsal else None,
        numero_registro=d.numero_registro, credencial_autorizacion=d.credencial_autorizacion,
        departamento=d.departamento, municipio=d.municipio, direccion=d.direccion,
        latitud=d.latitud, longitud=d.longitud, telefono=d.telefono, whatsapp=d.whatsapp, correo=str(d.correo).lower(),
        responsable_nombre=d.responsable_nombre, responsable_dui=d.responsable_dui, responsable_cargo=d.responsable_cargo,
        responsable_junta=d.responsable_junta,
        responsable_correo=str(d.responsable_correo).lower() if d.responsable_correo else None,
        responsable_telefono=d.responsable_telefono, horario=d.horario,
        atiende_domicilio=d.atiende_domicilio, tiene_laboratorio=d.tiene_laboratorio,
        especialidades=list(d.especialidades), medicos_declarados=[m.model_dump() for m in d.medicos],
        url_integracion=str(d.url_integracion) if d.url_integracion else None,
        documento_permiso_ref=d.documento_permiso_ref, documento_junta_ref=d.documento_junta_ref, logo_ref=d.logo_ref,
        password_hash=hash_password(d.password),
        requiere_2fa=d.tipo in settings.twofa_set,
        estado="PENDIENTE",  # un administrador Omega debe aprobarla antes de que pueda iniciar sesión
    )
    db.add(inst)
    db.flush()
    return inst
