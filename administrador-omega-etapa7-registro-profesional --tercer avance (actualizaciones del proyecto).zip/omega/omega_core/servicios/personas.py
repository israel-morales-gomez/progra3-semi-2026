from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Institucion, PerfilCivil, PerfilEstudiante, PerfilProfesional, Persona, Rol
from ..schemas import PerfilCivilIn, PerfilEstudianteIn, PerfilProfesionalIn, PersonaRegistro
from ..security.passwords import hash_password


def _dar_rol(db: Session, persona: Persona, nombre: str) -> None:
    if nombre not in persona.nombres_roles:
        persona.roles.append(db.scalars(select(Rol).where(Rol.nombre == nombre)).one())


def upsert_civil(db: Session, p: Persona, d: PerfilCivilIn) -> None:
    perfil = p.civil or PerfilCivil()
    for k, v in d.model_dump().items():
        setattr(perfil, k, v)
    p.civil = perfil
    _dar_rol(db, p, "CIVIL")


def upsert_estudiante(db: Session, p: Persona, d: PerfilEstudianteIn) -> None:
    if d.universidad_id is not None:
        uni = db.get(Institucion, d.universidad_id)
        if uni is None or uni.tipo != "UNIVERSIDAD":
            raise HTTPException(422, "universidad_id no corresponde a una universidad registrada")
    perfil = p.estudiante or PerfilEstudiante()
    cambia = p.estudiante is not None and (perfil.carne != d.carne or perfil.universidad_nombre != d.universidad_nombre)
    for k, v in d.model_dump().items():
        setattr(perfil, k, v)
    if p.estudiante is None or cambia:
        perfil.verificado = False
    p.estudiante = perfil
    _dar_rol(db, p, "ESTUDIANTE")


def upsert_profesional(db: Session, p: Persona, d: PerfilProfesionalIn) -> None:
    if d.institucion_id is not None:
        inst = db.get(Institucion, d.institucion_id)
        if inst is None or inst.tipo == "UNIVERSIDAD":
            raise HTTPException(422, "institucion_id no corresponde a hospital, clínica, farmacia o laboratorio")
    perfil = p.profesional or PerfilProfesional()
    cambia = p.profesional is not None and (perfil.tipo != d.tipo or perfil.numero_junta != d.numero_junta)
    for k, v in d.model_dump().items():
        setattr(perfil, k, v)
    if p.profesional is None or cambia:
        perfil.verificado = False  # un cambio de profesión/junta requiere nueva verificación
    p.profesional = perfil
    _dar_rol(db, p, "PROFESIONAL")


def crear_persona(db: Session, d: PersonaRegistro) -> Persona:
    p = Persona(
        dui=d.dui, nit=d.nit, nombres=d.nombres, apellidos=d.apellidos, fecha_nacimiento=d.fecha_nacimiento, sexo=d.sexo,
        correo=str(d.correo).lower(), telefono=d.telefono, departamento=d.departamento, municipio=d.municipio,
        direccion=d.direccion, password_hash=hash_password(d.password), roles=[],
    )
    db.add(p)
    upsert_civil(db, p, d.civil or PerfilCivilIn())  # todo ciudadano es civil
    if d.estudiante:
        upsert_estudiante(db, p, d.estudiante)
    if d.profesional:
        upsert_profesional(db, p, d.profesional)
    db.flush()
    return p
