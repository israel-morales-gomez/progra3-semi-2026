from typing import Literal, get_args

TipoInstitucion = Literal["HOSPITAL", "CLINICA", "FARMACIA", "LABORATORIO", "UNIVERSIDAD"]
TipoProfesional = Literal["DOCTOR", "ENFERMERA"]
TipoSangre = Literal["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
EstadoInstitucion = Literal["PENDIENTE", "ACTIVA", "SUSPENDIDA"]
SectorInstitucion = Literal["PUBLICO", "PRIVADO"]
RedSeguros = Literal["PUBLICA", "POLIZA_PRIVADA", "AMBAS"]  # a qué red de seguros atiende el centro

TIPOS_INSTITUCION = get_args(TipoInstitucion)
TIPOS_PROFESIONAL = get_args(TipoProfesional)
TIPOS_SANGRE = get_args(TipoSangre)
ESTADOS_INSTITUCION = get_args(EstadoInstitucion)
SECTORES_INSTITUCION = get_args(SectorInstitucion)
REDES_SEGUROS = get_args(RedSeguros)


def en_lista(columna: str, valores: tuple[str, ...]) -> str:
    return f"{columna} IN (" + ", ".join(f"'{v}'" for v in valores) + ")"
