import uuid
from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Table, Uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, ahora

rol_permiso = Table(
    "rol_permiso",
    Base.metadata,
    Column("rol_id", Integer, ForeignKey("rol.id", ondelete="CASCADE"), primary_key=True),
    Column("permiso_id", Integer, ForeignKey("permiso.id", ondelete="CASCADE"), primary_key=True),
)

persona_rol = Table(
    "persona_rol",
    Base.metadata,
    Column("persona_id", Uuid, ForeignKey("persona.id", ondelete="CASCADE"), primary_key=True),
    Column("rol_id", Integer, ForeignKey("rol.id", ondelete="CASCADE"), primary_key=True),
)


class Permiso(Base):
    __tablename__ = "permiso"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    codigo: Mapped[str] = mapped_column(String(60), unique=True)
    descripcion: Mapped[str] = mapped_column(String(200))


class Rol(Base):
    __tablename__ = "rol"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    nombre: Mapped[str] = mapped_column(String(40), unique=True)
    descripcion: Mapped[str] = mapped_column(String(200))
    permisos: Mapped[list[Permiso]] = relationship(secondary=rol_permiso, lazy="selectin")


class RefreshToken(Base):
    """Refresh tokens emitidos (rotación: cada uso revoca el anterior)."""

    __tablename__ = "refresh_token"
    jti: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True)
    sujeto_tipo: Mapped[str] = mapped_column(String(20))
    sujeto_id: Mapped[uuid.UUID] = mapped_column(Uuid, index=True)
    expira_en: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    revocado: Mapped[bool] = mapped_column(Boolean, default=False)
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)


class Desafio2FA(Base):
    """Código de segundo factor (se guarda solo su HMAC)."""

    __tablename__ = "desafio_2fa"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True)
    sujeto_tipo: Mapped[str] = mapped_column(String(20))
    sujeto_id: Mapped[uuid.UUID] = mapped_column(Uuid, index=True)
    codigo_hash: Mapped[str] = mapped_column(String(64))
    expira_en: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    intentos: Mapped[int] = mapped_column(Integer, default=0)
    usado: Mapped[bool] = mapped_column(Boolean, default=False)
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
