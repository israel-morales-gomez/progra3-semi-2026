import threading
from datetime import datetime, timedelta, timezone

from sqlalchemy import DateTime, MetaData
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

NAMING = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING)


_cerrojo, _ultimo = threading.Lock(), None


def ahora() -> datetime:
    """Hora UTC estrictamente creciente dentro del proceso: en Windows el reloj tiene ~15 ms de resolución y dos registros seguidos
    podían quedar con la misma marca, dejando su orden (`ORDER BY creado_en`) al azar."""
    global _ultimo
    with _cerrojo:
        t = datetime.now(timezone.utc)
        if _ultimo is not None and t <= _ultimo:
            t = _ultimo + timedelta(microseconds=1)
        _ultimo = t
        return t


class MarcaTiempo:
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    actualizado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora, onupdate=ahora)
