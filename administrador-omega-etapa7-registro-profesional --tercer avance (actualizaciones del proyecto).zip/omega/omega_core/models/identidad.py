import uuid
from datetime import date, datetime

from sqlalchemy import BigInteger, Boolean, CheckConstraint, Date, DateTime, ForeignKey, String, Text, UniqueConstraint, Uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..constantes import TIPOS_PROFESIONAL, TIPOS_SANGRE, en_lista
from .base import Base, MarcaTiempo
from .seguridad import Rol, persona_rol


class Persona(MarcaTiempo, Base):
    """Padrón maestro de identidad (clave única: DUI)."""

    __tablename__ = "persona"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    dui: Mapped[str] = mapped_column(String(10), unique=True)
    nit: Mapped[str | None] = mapped_column(String(17), unique=True)
    nombres: Mapped[str] = mapped_column(String(120))
    apellidos: Mapped[str] = mapped_column(String(120))
    fecha_nacimiento: Mapped[date | None] = mapped_column(Date)
    sexo: Mapped[str | None] = mapped_column(String(1))  # F | M (opcional; solo se usa en estadísticas agregadas)
    correo: Mapped[str] = mapped_column(String(254), unique=True)
    telefono: Mapped[str] = mapped_column(String(20))
    departamento: Mapped[str | None] = mapped_column(String(60))
    municipio: Mapped[str | None] = mapped_column(String(80))
    direccion: Mapped[str | None] = mapped_column(Text)
    password_hash: Mapped[str] = mapped_column(String(255))
    activo: Mapped[bool] = mapped_column(Boolean, default=True)
    ultimo_login: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # TOTP (obligatorio para Omega): secreto cifrado en reposo + anti-replay
    totp_secret_cifrado: Mapped[str | None] = mapped_column(Text)
    totp_activo: Mapped[bool] = mapped_column(Boolean, default=False)
    totp_ultimo_paso: Mapped[int | None] = mapped_column(BigInteger)

    __table_args__ = (CheckConstraint("sexo IS NULL OR sexo IN ('F', 'M')", name="sexo_valido"),)

    roles: Mapped[list[Rol]] = relationship(secondary=persona_rol, lazy="selectin")
    civil: Mapped["PerfilCivil | None"] = relationship(back_populates="persona", uselist=False, cascade="all, delete-orphan", lazy="selectin")
    estudiante: Mapped["PerfilEstudiante | None"] = relationship(back_populates="persona", uselist=False, cascade="all, delete-orphan", lazy="selectin")
    profesional: Mapped["PerfilProfesional | None"] = relationship(back_populates="persona", uselist=False, cascade="all, delete-orphan", lazy="selectin")

    @property
    def nombres_roles(self) -> list[str]:
        return sorted(r.nombre for r in self.roles)

    @property
    def permisos(self) -> set[str]:
        return {p.codigo for r in self.roles for p in r.permisos}

    @property
    def es_omega(self) -> bool:
        return any(r.nombre == "OMEGA" for r in self.roles)


class PerfilCivil(MarcaTiempo, Base):
    __tablename__ = "perfil_civil"
    persona_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="CASCADE"), primary_key=True)
    tipo_sangre: Mapped[str | None] = mapped_column(String(3))
    contacto_emergencia_nombre: Mapped[str | None] = mapped_column(String(150))
    contacto_emergencia_telefono: Mapped[str | None] = mapped_column(String(20))
    persona: Mapped[Persona] = relationship(back_populates="civil")
    __table_args__ = (CheckConstraint(f"tipo_sangre IS NULL OR {en_lista('tipo_sangre', TIPOS_SANGRE)}", name="tipo_sangre_valido"),)


class PerfilEstudiante(MarcaTiempo, Base):
    __tablename__ = "perfil_estudiante"
    persona_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="CASCADE"), primary_key=True)
    carne: Mapped[str] = mapped_column(String(30))
    universidad_nombre: Mapped[str] = mapped_column(String(150))  # UES, UNIVO, UGB...
    universidad_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("institucion.id", ondelete="SET NULL"))
    facultad: Mapped[str | None] = mapped_column(String(150))
    carrera: Mapped[str] = mapped_column(String(150))
    ciclo: Mapped[str] = mapped_column(String(60))  # ciclo de prácticas o año de internado
    correo_institucional: Mapped[str] = mapped_column(String(254))
    verificado: Mapped[bool] = mapped_column(Boolean, default=False)
    activo: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")  # el ciudadano puede activarlo/desactivarlo (portal)
    persona: Mapped[Persona] = relationship(back_populates="estudiante")
    __table_args__ = (UniqueConstraint("universidad_nombre", "carne", name="uq_estudiante_universidad_carne"),)


class PerfilProfesional(MarcaTiempo, Base):
    __tablename__ = "perfil_profesional"
    persona_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="CASCADE"), primary_key=True)
    tipo: Mapped[str] = mapped_column(String(10))  # DOCTOR (JVPM) | ENFERMERA (JVPE)
    especialidad: Mapped[str | None] = mapped_column(String(120))
    rol_clave: Mapped[str | None] = mapped_column(String(60))  # uno de los 65 ámbitos laborales (omega_core.roles_profesionales); decide la plantilla del portal
    numero_junta: Mapped[str] = mapped_column(String(30))
    institucion_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("institucion.id", ondelete="SET NULL"))
    verificado: Mapped[bool] = mapped_column(Boolean, default=False)
    activo: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")  # desactivado = no opera como profesional (conserva su verificación)
    persona: Mapped[Persona] = relationship(back_populates="profesional")
    __table_args__ = (
        CheckConstraint(en_lista("tipo", TIPOS_PROFESIONAL), name="tipo_valido"),
        UniqueConstraint("tipo", "numero_junta", name="uq_profesional_tipo_junta"),
    )

    @property
    def junta(self) -> str:
        return "JVPM" if self.tipo == "DOCTOR" else "JVPE"
