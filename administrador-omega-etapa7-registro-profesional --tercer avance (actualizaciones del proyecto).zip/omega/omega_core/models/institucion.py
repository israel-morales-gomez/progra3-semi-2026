import uuid

from sqlalchemy import Boolean, CheckConstraint, Float, ForeignKey, String, Text, Uuid
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from ..constantes import ESTADOS_INSTITUCION, REDES_SEGUROS, SECTORES_INSTITUCION, TIPOS_INSTITUCION, en_lista
from .base import Base, MarcaTiempo


class Institucion(MarcaTiempo, Base):
    """Hospital, clínica, farmacia, laboratorio o universidad."""

    __tablename__ = "institucion"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    tipo: Mapped[str] = mapped_column(String(20))
    nombre_legal: Mapped[str] = mapped_column(String(200))
    nit: Mapped[str] = mapped_column(String(17), unique=True)
    nrc: Mapped[str | None] = mapped_column(String(20))
    codigo_minsal: Mapped[str | None] = mapped_column(String(30), unique=True)
    numero_registro: Mapped[str | None] = mapped_column(String(40), unique=True)  # farmacias
    credencial_autorizacion: Mapped[str | None] = mapped_column(String(80))  # universidades (MINED/CSSP)

    departamento: Mapped[str | None] = mapped_column(String(60))
    municipio: Mapped[str | None] = mapped_column(String(80))
    direccion: Mapped[str] = mapped_column(Text)
    latitud: Mapped[float | None] = mapped_column(Float)
    longitud: Mapped[float | None] = mapped_column(Float)
    telefono: Mapped[str] = mapped_column(String(20))
    whatsapp: Mapped[str | None] = mapped_column(String(20))
    correo: Mapped[str] = mapped_column(String(254))

    responsable_nombre: Mapped[str] = mapped_column(String(150))
    responsable_dui: Mapped[str] = mapped_column(String(10))
    responsable_cargo: Mapped[str | None] = mapped_column(String(80))
    responsable_junta: Mapped[str | None] = mapped_column(String(30))  # JVQF / junta del director técnico
    responsable_correo: Mapped[str | None] = mapped_column(String(254))
    responsable_telefono: Mapped[str | None] = mapped_column(String(20))

    horario: Mapped[str | None] = mapped_column(String(200))
    # Los gestiona solo Omega (no se editan al registrarse). NULL = aún sin clasificar.
    sector: Mapped[str | None] = mapped_column(String(10))  # PUBLICO | PRIVADO
    red_seguros: Mapped[str | None] = mapped_column(String(15))  # PUBLICA | POLIZA_PRIVADA | AMBAS
    atiende_domicilio: Mapped[bool] = mapped_column(Boolean, default=False)
    tiene_laboratorio: Mapped[bool] = mapped_column(Boolean, default=False)
    especialidades: Mapped[list] = mapped_column(JSONB, default=list)
    medicos_declarados: Mapped[list] = mapped_column(JSONB, default=list)  # [{nombre, jvpm}]
    url_integracion: Mapped[str | None] = mapped_column(String(300))  # LMS universitario

    documento_permiso_ref: Mapped[str | None] = mapped_column(String(300))
    documento_junta_ref: Mapped[str | None] = mapped_column(String(300))
    logo_ref: Mapped[str | None] = mapped_column(String(300))

    password_hash: Mapped[str] = mapped_column(String(255))
    requiere_2fa: Mapped[bool] = mapped_column(Boolean, default=False)
    estado: Mapped[str] = mapped_column(String(12), default="PENDIENTE")
    aprobado_por: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="SET NULL"))

    __table_args__ = (
        CheckConstraint(en_lista("tipo", TIPOS_INSTITUCION), name="tipo_valido"),
        CheckConstraint(en_lista("estado", ESTADOS_INSTITUCION), name="estado_valido"),
        CheckConstraint("sector IS NULL OR " + en_lista("sector", SECTORES_INSTITUCION), name="sector_valido"),
        CheckConstraint("red_seguros IS NULL OR " + en_lista("red_seguros", REDES_SEGUROS), name="red_seguros_valida"),
    )
