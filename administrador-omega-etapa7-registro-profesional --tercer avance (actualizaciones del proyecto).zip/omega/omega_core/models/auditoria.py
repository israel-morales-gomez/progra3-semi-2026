from datetime import datetime

from sqlalchemy import BigInteger, DateTime, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class Auditoria(Base):
    """Bitácora append-only encadenada por hash (trigger PostgreSQL bloquea UPDATE/DELETE/TRUNCATE)."""

    __tablename__ = "auditoria"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    actor_tipo: Mapped[str] = mapped_column(String(20))
    actor_id: Mapped[str | None] = mapped_column(String(64))
    accion: Mapped[str] = mapped_column(String(60), index=True)
    recurso: Mapped[str | None] = mapped_column(String(60))
    recurso_id: Mapped[str | None] = mapped_column(String(64))
    resultado: Mapped[str] = mapped_column(String(10))
    detalle: Mapped[dict] = mapped_column(JSONB)
    ip: Mapped[str | None] = mapped_column(String(45))
    hash_prev: Mapped[str] = mapped_column(String(64))
    hash: Mapped[str] = mapped_column(String(64), unique=True)
