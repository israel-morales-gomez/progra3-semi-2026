"""Configuración por variables de entorno (.env)."""
import re
from functools import lru_cache
from ipaddress import ip_network

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    entorno: str = "desarrollo"
    database_url: str

    jwt_secret: str = Field(min_length=32)
    jwt_algoritmo: str = "HS256"
    access_token_minutos: int = 15
    omega_token_minutos: int = 10
    refresh_token_dias: int = 7
    clave_campos: str

    cors_origenes: str = ""
    omega_ips_permitidas: str = "127.0.0.1/32,::1/128"
    omega_ruta_web: str = "/gestion-interna-x7k2m9"  # ruta SECRETA del portal web de Omega (no se publica en ningún índice)
    twofa_tipos: str = "HOSPITAL,LABORATORIO"
    twofa_minutos: int = 5

    login_max_por_ip: int = 10
    login_max_fallos_id: int = 8
    login_ventana_seg: int = 60
    login_bloqueo_seg: int = 900

    dui_validar_digito: bool = False
    hsts_activo: bool = False
    docs_activos: bool = True

    # Integración con Medicina Legal (firma HMAC-SHA256 de cada petición). Vacío = integración deshabilitada.
    medicina_legal_secret: str = ""
    medicina_legal_ips: str = ""  # CIDR separados por coma; vacío = sin restricción de IP
    medicina_legal_ventana_seg: int = 300
    bypass_revision_horas: int = 48
    expediente_max_lecturas_min: int = 120

    @model_validator(mode="after")
    def _validar(self):
        if self.jwt_algoritmo not in {"HS256", "HS384", "HS512"}:
            raise ValueError("JWT_ALGORITMO debe ser HS256, HS384 o HS512")
        if self.entorno == "produccion" and "CAMBIAR" in self.jwt_secret.upper():
            raise ValueError("JWT_SECRET debe cambiarse en producción")
        _ = self.omega_redes  # falla temprano si hay un CIDR inválido
        r = self.omega_ruta_web
        reservadas = {"ciudadano", "profesional", "institucion", "farmacia", "laboratorio", "universidad", "omega", "static", "docs", "redoc", "openapi.json", "health", "auth", "personas", "instituciones"}
        if not re.fullmatch(r"/[a-z0-9][a-z0-9-]{9,60}", r) or r[1:] in reservadas:
            raise ValueError("OMEGA_RUTA_WEB debe ser una sola ruta (ej. /mi-ruta-secreta-123) de 10 a 61 caracteres [a-z0-9-], sin repetir un nombre de portal ni de la API")
        _ = self.medicina_legal_redes
        if self.medicina_legal_secret and len(self.medicina_legal_secret) < 32:
            raise ValueError("MEDICINA_LEGAL_SECRET debe tener al menos 32 caracteres")
        if self.produccion and "CAMBIAR" in self.medicina_legal_secret.upper():
            raise ValueError("MEDICINA_LEGAL_SECRET debe cambiarse en producción")
        return self

    @property
    def produccion(self) -> bool:
        return self.entorno == "produccion"

    @property
    def cors_lista(self) -> list[str]:
        return [o.strip() for o in self.cors_origenes.split(",") if o.strip()]

    @property
    def omega_redes(self):
        return [ip_network(x.strip(), strict=False) for x in self.omega_ips_permitidas.split(",") if x.strip()]

    @property
    def medicina_legal_redes(self):
        return [ip_network(x.strip(), strict=False) for x in self.medicina_legal_ips.split(",") if x.strip()]

    @property
    def twofa_set(self) -> set[str]:
        return {t.strip().upper() for t in self.twofa_tipos.split(",") if t.strip()}


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
