from omega_core.app import crear_app

app = crear_app()
