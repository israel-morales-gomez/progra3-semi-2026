# Administrador Omega — Protocol Zero (V-242122-19)

Monolito modular en FastAPI + PostgreSQL + SQLAlchemy 2 + Alembic.
**Etapa 1: base y seguridad** (identidad, login, 2FA, Omega con TOTP + IP, auditoría encadenada).

## Ejecutar en Windows 10 (PowerShell)

Requisitos: PostgreSQL nativo en marcha (puerto 5432) y [uv](https://docs.astral.sh/uv/).

1. Instalar uv (una vez; luego cierra y abre PowerShell):
   ```powershell
   powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
   ```
2. Descomprime el zip y entra a la carpeta:
   ```powershell
   cd C:\ruta\administrador-omega
   ```
3. Crea la base de datos (ajusta la versión de PostgreSQL en la ruta; pedirá la clave de `postgres`):
   ```powershell
   & "C:\Program Files\PostgreSQL\16\bin\psql.exe" -U postgres -c "CREATE DATABASE omega;"
   ```
4. Crea tu `.env` y edita `DATABASE_URL` con tu usuario/clave de PostgreSQL:
   ```powershell
   copy .env.example .env
   notepad .env
   ```
   Si la clave tiene `@ : / #` debe ir codificada en URL (`@` = `%40`).
5. Instala dependencias (descarga Python 3.12 si hace falta):
   ```powershell
   uv sync
   ```
6. Crea las tablas (migración inicial, incluye el trigger de la bitácora):
   ```powershell
   uv run alembic upgrade head
   ```
7. Datos semilla de desarrollo (imprime las credenciales):
   ```powershell
   uv run python -m omega_core.seed
   ```
8. Arranca el servidor y abre <http://127.0.0.1:8000/docs>:
   ```powershell
   uv run uvicorn main:app --reload
   ```
9. Pruebas automáticas (usan la BD del `.env`; la bitácora es inmutable, para empezar limpio recrea la BD):
   ```powershell
   uv run pytest
   ```

## Credenciales semilla (solo desarrollo)

| Quién | Usuario | Clave | Extra |
|---|---|---|---|
| Omega | DUI `00000001-8` | `Omega#Dev2026` | TOTP, secreto `JBSWY3DPEHPK3PXP` (agrégalo a Google Authenticator/Authy, o genera el código con `uv run python -c "import pyotp; print(pyotp.TOTP('JBSWY3DPEHPK3PXP').now())"`) |
| Hospital | NIT `0614-010190-101-1` o código `H-0001` | `Hospital#Dev2026` | 2FA: el código de 6 dígitos aparece en la consola del servidor (`[2FA SIMULADO]`) |
| Médico | DUI `01234567-8` | `Medico#Dev2026` | |
| Civil | DUI `07654321-2` | `Civil#Dev2026` | |

En `/docs` copia el `access_token` de un login y pulsa **Authorize**.

## Endpoints

- `POST /personas` registro (civil por defecto; `estudiante` y `profesional` opcionales) · `GET/PATCH /personas/me` · `PUT /personas/me/perfiles/{civil|estudiante|profesional}` (agrega o actualiza un perfil).
- `POST /instituciones` registro (queda `PENDIENTE` hasta que Omega la apruebe) · `GET /instituciones/me`.
- `POST /auth/login/persona` · `POST /auth/login/institucion` · `POST /auth/2fa/verificar` · `POST /auth/refresh` (rota) · `POST /auth/logout`.
- `POST /omega/login` (DUI + clave + TOTP, solo IPs permitidas, sin refresh) · `GET /omega/instituciones` · `PATCH /omega/instituciones/{id}/estado`.
- `GET /auditoria` · `GET /auditoria/verificar` (recorre la cadena de hashes y reporta si es íntegra).

## Estructura

`omega_core/` (identidad, seguridad, auditoría; **lo implementado**) y carpetas vacías para las siguientes etapas: `core_expediente`, `farmacia`, `laboratorio`, `portal_civil`, `academico_cofirma`, `nodo_edge_sync`, `estadistica_epidemiologia`.

## Seguridad aplicada

argon2id · JWT con algoritmo fijado, `iss`, `exp`, `jti`; refresh con rotación y detección de reuso · rate limiting + bloqueo por cuenta · respuestas de login genéricas (sin enumeración de usuarios) · TOTP con anti-replay y secreto cifrado (Fernet) · allowlist de IP de Omega revalidada en cada petición · auditoría con trigger PostgreSQL (UPDATE/DELETE/TRUNCATE bloqueados) y cadena SHA-256 · cabeceras de seguridad, CORS configurable (`CORS_ORIGENES`), validación estricta de entradas, consultas parametrizadas.

## Pendiente / a tener en cuenta

- Cualquiera puede registrar un DUI: falta la validación contra RNPN y la verificación de JVPM/JVPE/carné (los perfiles nacen `verificado=false`).
- Los documentos (permiso MINSAL, JVQF, logo) se reciben como referencia de texto; la subida de archivos llega en una etapa posterior.
- El 2FA es simulado (consola); `enviar_codigo()` en `omega_core/security/twofa.py` es el punto para el proveedor SMS/WhatsApp.
- El rate limiting vive en memoria (un solo proceso). Detrás de un proxy, configura uvicorn con `--proxy-headers --forwarded-allow-ips=<ip del proxy>` para que Omega vea la IP real.
- En producción: `ENTORNO=produccion`, regenerar `JWT_SECRET` y `CLAVE_CAMPOS`, HTTPS + `HSTS_ACTIVO=true`, y que la aplicación se conecte con un rol de BD que **no** sea dueño de las tablas (para que no pueda quitar el trigger de la bitácora). Guarda `ultimo_hash` de `/auditoria/verificar` fuera del sistema como ancla.

## Etapa 2 · núcleo clínico (`core_expediente`)
- Tras actualizar: `uv sync`, copia a tu `.env` las variables nuevas de `.env.example` (`MEDICINA_LEGAL_SECRET`, `CLAVE_CAMPOS`…) y corre `uv run alembic upgrade head` (migración `0002`).
- Un expediente por DUI: antecedentes, alergias, diagnósticos CIE-10, signos vitales y notas SOAP. Los registros **no se editan** (trigger de PostgreSQL lo impide): se corrige enviando uno nuevo con `reemplaza_id` + `motivo_correccion`; la versión vigente es la última de la cadena y `?historial=true` muestra todas.
- Nivel 4 (VIH, salud mental, genético o `confidencial=true`): cifrado Fernet con `CLAVE_CAMPOS`; leerlo exige justificación (`?justificacion=…`).
- Estado vital: `POST /integraciones/medicina-legal/defunciones` (HMAC `X-ML-Timestamp` + `X-ML-Firma` = HMAC-SHA256(`MEDICINA_LEGAL_SECRET`, `timestamp + "." + cuerpo`)). Congela el DUI (cuenta inactiva, HTTP 423 en nuevas atenciones/escrituras; recetas y citas usarán `service.asegurar_no_congelado`) y guarda la causa. Solo Omega puede revertirlo (`/omega/estado-vital/{dui}/revertir`).
- Todo registro, corrección, lectura y defunción queda en la bitácora de auditoría. Flujo de prueba en `/docs`: login médico → `POST /atenciones` → triaje → fases → registros.
- Pruebas: `uv run pytest` (77).

### Etapa 2 · parte B (episodio y 5 fases)
`POST /atenciones` abre el episodio; `POST /atenciones/{id}/transicion` avanza 1→2→3→4→5 (4→3 permitido); no se salta de fase (409), cada paso valida prerrequisitos, queda en la bitácora (`TRANSICION_FASE`) y se ejecuta con bloqueo de fila en una transacción; el trigger `atencion_guard` lo vuelve a validar en PostgreSQL. `POST /atenciones/{id}/triaje` (ROJO/NARANJA/AMARILLO/VERDE/AZUL). **Código Rojo** (`codigo_rojo=true` al abrir, o triaje ROJO): salta las validaciones administrativas, exige `motivo` ≥10 caracteres, se audita (`CODIGO_ROJO_ACTIVADO`, `BYPASS_EMERGENCIA`) y crea una revisión posterior en `/revisiones-bypass`.

### Etapa 2 · parte C (acceso, nivel 4 y alta)
- **Acceso**: un profesional lee `/expediente/{dui}` solo con atención abierta en su institución o consentimiento vigente del paciente (`/mi-expediente/consentimientos`, revocable). Permitido o denegado, todo queda en la bitácora (`ACCESO_EXPEDIENTE`, `ACCESO_EXPEDIENTE_DENEGADO`); el 403 es idéntico exista o no el DUI. El alta cierra la atención y con ella el acceso por esa vía.
- **Nivel 4** (VIH, salud mental, genético, `confidencial`): cifrado con `security/campos.py` (Fernet, `CLAVE_CAMPOS`); abrirlo exige ser médico responsable o tener consentimiento nivel 4, más `?justificacion=` (queda auditada). El paciente nunca ve su contenido nivel 4 por la API.
- **Alta**: transición 4→5 con `egreso` (resumen + plan de seguimiento), solo el médico responsable; se lee en `/expediente/{dui}/egresos`.

## Etapa 3 · parte A (farmacia: receta y despacho)
- Seed nuevo: **Farmacia** NIT `0614-020290-102-2` (o registro `FARM-0001`) / `Farmacia#Dev2026` (sin 2FA). Tras actualizar: `uv run alembic upgrade head` (migración `0003`) y `uv run python -m omega_core.seed`.
- **Médico**: `POST /farmacia/firma/enrolar` (PIN; genera clave Ed25519, la privada queda cifrada con scrypt + AES-GCM) → `POST /recetas` (necesita atención abierta en fase 3/4, el PIN y DUI no congelado; **423 si el paciente falleció**). Devuelve folio + **token de canje (una sola vez)**; la receta queda firmada e inmutable.
- **Farmacia** (login institucional): `POST /farmacia/recetas/consulta` (folio + token) → solo medicamentos, dosis, iniciales/DUI parcial, validez de firma y **las alergias que chocan con esa receta**; nunca diagnósticos, notas, antecedentes ni signos vitales. `POST /farmacia/recetas/despachar`.
- **Anti doble canje**: `SELECT … FOR UPDATE` + `UNIQUE(despacho.receta_id)` + trigger `despacho_guard` (receta EMITIDA, vigente, paciente vivo, farmacia activa). Con 8 peticiones simultáneas, 1 gana y 7 reciben 409 (cubierto por tests).
- **Alergias**: diccionario de clases en `farmacia/alergias.py` (penicilinas, cefalosporinas, AINE, sulfas…, ampliable). Una alergia descartada con nueva versión deja de bloquear.
- Bitácora: `RECETA_EMITIDA`, `RECETA_CONSULTADA`, `RECETA_DESPACHADA`, `RECETA_DESPACHO_BLOQUEADO`, `RECETA_EMISION_DENEGADA`, `RECETA_CANJE_FALLIDO`, `FIRMA_ENROLADA`, `FIRMA_PIN_INCORRECTO`.

### Etapa 3 · parte B (inventario de farmacia)
- Migración `0004`: `lote`, `movimiento_inventario` (libro append-only), `umbral_stock`. Endpoints bajo `/farmacia/inventario` (login de farmacia): `POST /lotes`, `GET /lotes`, `GET /lotes/{id}`, `GET /lotes/{id}/movimientos`, `POST /lotes/{id}/ajustes` (ENTRADA / MERMA / CORRECCION), `PUT /umbrales/{medicamento}`, `GET /existencias`, `GET /alertas?dias=30`.
- Cada farmacia solo ve y modifica **su** inventario (un lote ajeno responde 404, igual que uno inexistente). El medicamento se normaliza (minúsculas, sin tildes) y debe coincidir con el de las recetas.
- **Despacho FEFO**: `POST /farmacia/recetas/despachar` descuenta de los lotes **vigentes** que vencen primero, con `FOR UPDATE` de los lotes en orden fijo (sin interbloqueos). Sin stock vigente suficiente → 409 `STOCK_INSUFICIENTE` (+ `LOTE_VENCIDO` si hay unidades vencidas) y no se descuenta nada. Un lote vence al terminar su `fecha_vencimiento`; el trigger `movimiento_guard` lo impide también desde SQL. `CHECK (cantidad_actual >= 0)` evita stock negativo.
- Alertas: `stock_bajo` (umbral configurable por medicamento; el stock vencido no cuenta), `lotes_por_vencer` (`dias`) y `lotes_vencidos_con_stock` (registrar MERMA).
- Bitácora: `INVENTARIO_LOTE_REGISTRADO`, `INVENTARIO_AJUSTE`, `INVENTARIO_UMBRAL_CONFIGURADO`, `INVENTARIO_DESCUENTO_DESPACHO`.

### Etapa 3 · parte C (laboratorio e imagenología)
- Migración `0005`: `orden_lab`, `orden_lab_item`, `resultado_lab`, `alerta_critica` (triggers: orden inmutable salvo estado, resultado único por orden con bloqueo de fila, sin órdenes ni resultados para DUI congelado).
- **Médico**: `GET /laboratorio/directorio`, `POST /laboratorio/ordenes` (LABORATORIO o IMAGENOLOGIA; atención abierta fase 3/4; **423 si el DUI está congelado**), `GET /laboratorio/ordenes`, `GET /laboratorio/alertas-criticas`, `POST /laboratorio/alertas-criticas/{id}/reconocer`.
- **Laboratorio** (login institucional con 2FA): `GET /laboratorio/pendientes/{dui}` (solo órdenes PENDIENTES dirigidas a su institución: nombre, DUI, edad y estudios; lista vacía si no hay, no permite sondear DUIs) y `POST /laboratorio/ordenes/{folio}/resultados` (valores numéricos o de texto que cubran todos los estudios; las banderas NORMAL/BAJO/ALTO/CRITICO_BAJO/CRITICO_ALTO las calcula el servidor con los rangos). Una orden se completa **una sola vez** (409 después; probado con 6 envíos simultáneos).
- **Inyección al expediente**: sección `resultados` en `/expediente/{dui}/resultados`, en el resumen y en `/mi-expediente/resultados`. Estudios de VIH, genéticos o toxicológicos (o `confidencial=true`) son nivel 4: se guardan cifrados (Fernet) y la alerta no revela los valores.
- Un resultado con valores críticos crea una **alerta solo para el médico que pidió la orden**. Bitácora: `ORDEN_LAB_CREADA/DENEGADA`, `LAB_CONSULTA_PENDIENTES`, `RESULTADO_LAB_SUBIDO/RECHAZADO`, `ALERTA_CRITICA_GENERADA/CONSULTADA/RECONOCIDA`.
- Mínimo privilegio (tests): un espía de SQL demuestra que laboratorio y farmacia nunca leen diagnósticos, notas, antecedentes, alergias (el laboratorio), signos vitales ni atenciones, y sus credenciales no abren ningún endpoint clínico.

## Etapa 4 · parte A (portal civil)
Módulo `portal_civil`, todo bajo `/portal` (ver `/docs`, etiquetas "portal"):
- `GET/PATCH /portal/perfil`: contacto y dirección editables (DUI, nombres, nacimiento y roles no). `PUT /portal/perfil/{estudiante|profesional}/estado`: activar/desactivar (conserva datos y `verificado`; un profesional inactivo pierde acceso clínico de inmediato).
- `GET /portal/mi-expediente/{diagnosticos|resultados|vacunas|recetas}`: solo lectura, siempre del titular autenticado. Nivel 4 solo con desbloqueo 2FA: `POST /portal/nivel4/desafio` → `/desbloquear` (token 10 min en cabecera `X-Desbloqueo-N4`) → `/bloquear`.
- `POST /vacunas` (profesional con atención activa o consentimiento; correcciones versionadas, tabla inmutable). Se lee también en `/expediente/{dui}/vacunas`.
- `GET /portal/accesos`: quién consultó el expediente (sin IP, justificación ni hash). Todo queda en `auditoria`.
- Migración `0006_portal_civil`. Tests: 87 hasta la 4A (`uv run pytest`).

### Etapa 4 · parte B (citas y chatbot)
- **Cascada** (ciudadano): `GET /citas/especialidades` → `/citas/centros?especialidad=` → `/citas/doctores?especialidad=&institucion_id=` → `/citas/fechas?medico_id=` → `/citas/horas?medico_id=&fecha=` → `POST /citas {medico_id, fecha, hora}`. Solo aparecen doctores verificados y activos, de centros activos, con agenda vigente. Horas en El Salvador (UTC-6), anticipación mínima 60 min, máximo 60 días, 5 citas vigentes por persona.
- **Sin doble reserva**: índices únicos parciales en la BD (`uq_cita_medico_inicio`, `uq_cita_paciente_inicio`, `WHERE estado='PROGRAMADA'`); con 6 reservas simultáneas, 1 gana y 5 reciben 409. DUI congelado: 401 (sesión caída) y, como defensa en profundidad, 423.
- **Agenda del médico**: `POST/GET /agenda`, `DELETE /agenda/{id}` (desactiva; las citas ya hechas se conservan), `GET /agenda/citas` (solo nombre del paciente).
- **Ciudadano**: `GET /citas`, `POST /citas/{id}/cancelar`, `POST /citas/{id}/reprogramar` (atómico: si el nuevo horario está ocupado, la cita original sigue intacta). Trigger `cita_guard`: el horario no se edita, no se borra, y una cita cerrada no cambia.
- **Chatbot** `POST /chatbot/mensaje`: reglas simples (FAQ, orientación, cómo agendar); NO agenda ni diagnostica y redirige a `/citas/...`; emergencias → 911. Interfaz opcional `ProveedorLLM` en `portal_civil/chatbot.py` (`proveedor_llm = None`, sin conectar). La bitácora guarda la intención, nunca el texto.
- Auditoría: `CITA_RESERVADA|CANCELADA|REPROGRAMADA|DENEGADA`, `AGENDA_BLOQUE_CREADO|RETIRADO`, `CHATBOT_CONSULTA`. Migración `0007_citas_y_agenda`. Tests: 99.

## Etapa 5 · parte A (estudiantes en práctica y co-firma)
Módulo `academico_cofirma` (migración `0008`):
- **Asignación** (la registra el hospital/clínica con su cuenta institucional): `POST /practicas {estudiante_dui, tutor_dui, nivel}`, `GET /practicas`, `POST /practicas/{id}/finalizar`. Liga al estudiante (perfil verificado por Omega, activo, con universidad registrada) con **un médico tutor de ese centro**. Una sola asignación activa por estudiante. Finalizarla corta el acceso y **cancela sus borradores pendientes**.
- **Alcance por nivel**: `PRIMER_ANO_CLINICA` = solo lectura (`GET /practica/atenciones/{id}/expediente/{seccion}`, nivel 4 nunca se abre) y signos vitales; `INTERNADO` = además redacta borradores (`POST /practica/borradores/diagnostico|receta|orden-lab`). Solo ve atenciones abiertas cuyo médico responsable es su tutor. Todo se revalida en cada petición (perfil activo, universidad, tutor habilitado).
- **Borrador Pendiente de Validación**: vive solo en la tabla `borrador` (contenido cifrado). No existe como diagnóstico, receta ni orden, así que farmacia y laboratorio **no pueden** verlo (probado, incluso con espía de SQL).
- **Co-firma** (`/cofirma/borradores/...`): `aprobar`, `corregir` (comentario obligatorio + contenido corregido) y `rechazar` (comentario obligatorio). Solo el tutor asignado (403 + `COFIRMA_DENEGADA` para cualquier otro; la BD lo impone con el trigger `borrador_guard`). El registro real se crea a nombre del tutor **en la misma transacción** que cierra el borrador; las recetas exigen el PIN de firma del tutor y devuelven el token una sola vez.
- **Auditoría dual**: `BORRADOR_REDACTADO`, `COFIRMA_APROBADA|CORREGIDA|RECHAZADA|DENEGADA`, `BORRADOR_CANCELADO`, `PRACTICA_ASIGNADA|FINALIZADA`; cada una (y el registro real: `REGISTRO_CLINICO`, `RECETA_EMITIDA`, `ORDEN_LAB_CREADA`) guarda `redactado_por` y `autorizado_por`. Los signos vitales del estudiante guardan al tutor supervisor.
- Para que el tutor pueda co-firmar, debe ser el médico responsable de la atención (se asigna al pasar a fase 3 o con `/atenciones/{id}/asumir`). Tests: 111.

### Etapa 5 · parte B (portal de universidades)
Migración `0009`. Todo en `academico_cofirma`:
- **Registro y verificación**: la universidad se registra en `POST /instituciones` (`tipo=UNIVERSIDAD`: NIT, `credencial_autorizacion` MINED/CSSP y coordinador = `responsable_nombre/cargo/correo/telefono`, todos obligatorios). Omega la verifica y activa (`PATCH /omega/instituciones/{id}/estado`); solo entonces `POST /auth/login/institucion`. Si Omega la suspende, pierde el acceso de inmediato. `GET /universidad/perfil`.
- **Horas y asistencias**: el estudiante marca `POST /practica/asistencias/entrada|salida` (un turno abierto a la vez, máx. 16 h) y su tutor valida o rechaza (`/cofirma/asistencias`). Trigger `asistencia_guard`: turnos inmutables, solo el tutor valida.
- **Portal de solo lectura** (`/universidad/resumen`, `/universidad/estudiantes`, `/universidad/estudiantes/{id}`): por estudiante, horas registradas/validadas, asistencias y casos aprobados (conteo por tipo, corregidos y por mes). **Nunca** diagnósticos, recetas, órdenes, resultados ni DUI, nombre, id o folio de pacientes (probado por contenido, por llaves y con espía de SQL). Una universidad solo ve a sus estudiantes; uno ajeno responde 404 igual que uno inexistente y se audita.
- **LMS (solo estructura, sin conectar)**: `POST/GET/DELETE /universidad/lms/tokens` (token de solo lectura, se muestra una vez, se guarda su hash, máx. 5 activos) y `GET /integraciones/lms/estudiantes` con cabecera `X-LMS-Token`.
- Auditoría: `UNIVERSIDAD_CONSULTA|_DENEGADA`, `LMS_TOKEN_CREADO|REVOCADO|RECHAZADO`, `LMS_CONSULTA`, `ASISTENCIA_ENTRADA|SALIDA|VALIDADA|RECHAZADA`. Tests: 117.

## Etapa 6 · parte A (camas y recursos)
Módulo `core_expediente`, migración `0010`, todo bajo `/camas`:
- **Camas** por institución y servicio (`POST /camas`, médico; código único por servicio) con estado `LIBRE / OCUPADA / LIMPIEZA`. Se retiran/reactivan (`PUT /camas/{id}/activa`), nunca se borran. Censo: `GET /camas?servicio=&estado=` (folio y nombre del ocupante, sin DUI).
- **Ingreso** `POST /camas/{id}/ingresar {atencion_id}`: la cama debe estar libre y activa, la atención abierta en la institución, el DUI no congelado (423) y el paciente no puede ocupar dos camas. **Egreso** `POST /camas/{id}/egresar {motivo}` → la cama pasa a LIMPIEZA; `POST /camas/{id}/limpieza-terminada` → LIBRE.
- **Sin doble asignación, a nivel de BD**: bloqueo de fila de la cama + índices únicos parciales (`uq_ocupacion_cama_abierta`, `uq_ocupacion_paciente_abierta`, `uq_ocupacion_atencion_abierta`) + triggers `ocupacion_guard` / `cama_guard` (transiciones válidas, ocupación inmutable tras el egreso, sin borrados). Con 6 ingresos simultáneos a una cama gana 1; con 5 camas para un mismo paciente gana 1.
- **Solo el personal de la institución**: cada operación se limita a la institución del profesional verificado y activo; una cama de otra institución responde 404 igual que una inexistente (y se audita `CAMA_DENEGADA`).
- **Resumen** `GET /camas/ocupacion?fecha=`: por servicio y total, camas activas, ocupadas, libres, en limpieza, % de ocupación, ingresos y egresos del día (UTC-6). Días pasados usan el historial de ocupaciones.
- Auditoría: `CAMA_CREADA|RETIRADA|REACTIVADA|INGRESO|EGRESO|LIMPIEZA_TERMINADA|DENEGADA`, `CAMAS_CONSULTADAS`, `CAMAS_OCUPACION_CONSULTADA`. Tests: 126.

## Etapa 6 · parte B (sincronización offline, `nodo_edge_sync`)
- **Nodos**: la institución (hospital, clínica, laboratorio o farmacia) registra un nodo con `POST /sync/nodos` y recibe un token (se muestra una vez; se guarda su hash; `DELETE /sync/nodos/{id}` lo revoca). El nodo queda ligado a esa institución: solo puede enviar eventos de ella.
- **Recepción por lotes**: `POST /sync/lotes` con cabecera `X-Nodo-Token`, hasta 200 eventos `{clave, tipo, ts, payload}`. Responde, evento por evento, `APLICADO | DUPLICADO | CONFLICTO | ERROR` y los totales. Un evento malo no frena a los demás y no consume su clave.
- **Idempotencia**: `UNIQUE (institucion_id, clave)` en `sync_evento`; la clave se reclama primero. Reenviar el mismo lote (o un lote cruzado entre hilos) es seguro: lo ya procesado se devuelve como `DUPLICADO`.
- **Conflictos**: gana el evento más reciente (marca de tiempo del evento). Cada conflicto queda en `sync_conflicto` (inmutable) y se consulta en `GET /sync/conflictos`; el estado vigente en `GET /sync/estado`. Marcas en el futuro (>5 min) o de más de 30 días se rechazan.
- **Tipos de evento**: `NODO_ESTADO` (todos) y `CAMA_LIMPIEZA_TERMINADA` (hospital/clínica). Para añadir uno: payload + función + fila en `handlers.HANDLERS`.
- **Cliente de ejemplo** (`nodo_edge_sync/cliente.py`, solo biblioteca estándar): cola en archivo SQLite que reenvía los pendientes en lotes al recuperar la conexión.
  `python -m nodo_edge_sync.cliente --token <TOKEN> --cola cola.sqlite --evento NODO_ESTADO '{"clave":"horario","valor":"7-15"}' --enviar`
- Auditoría: `SYNC_NODO_CREADO|REVOCADO|RECHAZADO`, `SYNC_LOTE_RECIBIDO`, `SYNC_EVENTO_APLICADO|CONFLICTO`, `SYNC_CLAVE_REUTILIZADA`, `CAMA_LIMPIEZA_TERMINADA` (vía `SYNC_NODO`). Migración `0011`. Tests: 141.
- Nota de pruebas: los tests crean instituciones nuevas en cada corrida y el directorio de laboratorios muestra 200; si tras muchísimas corridas falla `test_creacion_de_ordenes_y_reglas`, recrea la base de desarrollo (`uv run alembic downgrade base && uv run alembic upgrade head`).

## Etapa 6 · parte C (base de estadísticas epidemiológicas, `estadistica_epidemiologia`)
- **Acceso exclusivo**: Administrador Omega (token Omega + IP autorizada) o una persona con el rol nuevo `SALUD_PUBLICA` (lo concede/retira Omega con `PUT /omega/personas/{id}/salud-publica`, con motivo). Cualquier otro rol, institución o token → 403/401, y el intento queda en la bitácora (`ESTADISTICA_ACCESO_DENEGADO`). El rol no abre ningún dato clínico ni de identidad.
- **Anonimización**: las consultas leen la vista `v_epi_evento` (sin DUI, nombres ni ids) y devuelven solo agregados. Las celdas con menos de **5** casos se suprimen en SQL (el umbral no se puede bajar por parámetro); no se publican totales; solo se informa cuántas celdas se ocultaron. Los diagnósticos de nivel 4 nunca entran.
- **Endpoints** (`/docs`): `GET /estadisticas/fallecidos` (causa × edad × género), `/enfermedades-comunes` (causa × edad × zona rural/urbana), `/enfermedades-graves` (causa × género × edad; prefijos CIE-10 de la tabla `cie10_grave`), `/municipios` (catálogo). Filtros: `origen` (`REAL` por defecto | `EJEMPLO` | `TODOS`), `anio_desde`, `anio_hasta`, `zona`. Rangos de edad: 0-4, 5-14, 15-29, 30-44, 45-59, 60-74, 75+.
- **Catálogo de municipios** (`municipio_catalogo`, zona RURAL/URBANA): viene un catálogo base en la migración; Omega lo amplía con `PUT /estadisticas/municipios`. Un municipio fuera del catálogo cuenta como zona `SIN_DATO`.
- **Género**: nueva columna opcional `persona.sexo` (F|M), aceptada al registrar una persona. Sin dato → `SIN_DATO`.
- **Datos de ejemplo** (ficticios, tabla aparte `epi_ejemplo`): `python -m estadistica_epidemiologia.datos_ejemplo --generar [--semilla 42] [--cantidad 4000]` (repetible), `--borrar`, `--contar`. No toca datos reales ni corre con `ENTORNO=produccion`. Se consultan con `?origen=EJEMPLO`.
- Auditoría: `ESTADISTICA_CONSULTADA`, `ESTADISTICA_ACCESO_DENEGADO`, `ESTADISTICA_ROL_SALUD_PUBLICA`, `ESTADISTICA_MUNICIPIO_GUARDADO`. Migración `0012`. Tests: 152.

## Etapa 6 · parte D (indicadores epidemiológicos y medicamentos)
- Mismas reglas que la parte C: solo Omega y `SALUD_PUBLICA`, solo agregados, celdas con menos de 5 casos suprimidas (en SQL), sin identificadores, todo en la bitácora (`ESTADISTICA_CONSULTADA`). Filtro `origen=REAL|EJEMPLO|TODOS` (REAL por defecto).
- **Indicadores** (`desde`/`hasta`, `causa` CIE-10, `departamento`): `GET /estadisticas/indicadores/incidencia` (diagnósticos nuevos en el periodo), `/prevalencia` (ACTIVA o EN_REMISION hasta `hasta`) y `/mortalidad` (defunciones por causa). Cada celda trae casos, población y tasa por 100 000. La población (`poblacion_region`) la carga Omega con `PUT /estadisticas/poblacion`; sin población la tasa es `null` (no se inventan cifras). Se usa el último año ≤ el del fin del periodo. Periodo máximo: 10 años.
- **Brotes** `GET /estadisticas/brotes` (`ventana_dias`=7, `periodos_base`=8, `factor`=2): por enfermedad y municipio compara la ventana reciente con el promedio de los periodos previos; `alerta` si casos ≥ factor × max(promedio, 1). Solo municipios con ≥ 5 casos; si la base suma < 5 no se revela su promedio.
- **Medicamentos**: `GET /estadisticas/medicamentos/mas-prescritos` y `/antibioticos` (por `periodo`=mes|anio y `departamento`; el segundo incluye la proporción sobre el total de la celda). Cuentan renglones de receta (no personas ni médicos); las recetas anuladas no cuentan. Antibiótico = el nombre empieza por un principio activo de `antibiotico_catalogo` (sembrado en la migración).
- La vista `v_epi_evento` ganó departamento, municipio y estatus; nueva vista `v_epi_receta`. Ejemplos: el script de la parte C ahora también genera prescripciones ficticias y un brote de ejemplo. Migración `0013`. Tests: 159.

## Etapa 6 · parte E (vacunación y recursos) — cierre de la Etapa 6
- Mismas reglas de acceso y anonimización que C y D (solo Omega y `SALUD_PUBLICA`; sin identificadores de personas; todo auditado como `ESTADISTICA_CONSULTADA`). Sin gráficos: solo JSON documentado en `/docs`.
- **Cobertura de vacunación** `GET /estadisticas/vacunacion/cobertura` (`desde`/`hasta`, `vacuna`, `departamento`, `min_dosis`, `origen`): personas distintas con la primera dosis en el periodo, por vacuna × departamento × rango de edad (edad de la primera dosis), y `cobertura_pct` = vacunadas / población objetivo × 100. La población objetivo (`poblacion_objetivo`: departamento, año, vacuna, rango de edad) la carga Omega con `PUT /estadisticas/poblacion-objetivo` (consulta: `GET /estadisticas/poblacion-objetivo`); sin denominador la cobertura es `null`. Una persona cuenta una vez por vacuna; celdas con menos de 5 personas suprimidas. Vista `v_epi_vacuna` (sin ids).
- **Insumos** `GET /estadisticas/recursos/insumos`: inventario de las farmacias activas por departamento y medicamento (no se muestran farmacias): existencias vigentes, umbrales, consumo de 30 días, cobertura en días, por vencer a 90 días. `FALTA` (sin existencias con demanda o umbral, ≤ umbral, o cobertura < `dias_minimos`=15) y `SOBRA` (cobertura > `dias_exceso`=180, o por vencer > 3× el consumo mensual); `estado=TODOS` incluye lo adecuado.
- **Consultas y hospitalizaciones** `GET /estadisticas/recursos/consultas` (`nivel=institucion|region`, `periodo=mes|anio`): atenciones abiertas y las de tipo HOSPITALIZACION. Filas con < 5 consultas suprimidas; hospitalizaciones de 1 a 4 ocultas.
- **Camas** `GET /estadisticas/recursos/camas` (`nivel=institucion|region`): camas activas, ocupadas ahora y % de ocupación; una ocupación de 1 a 4 camas se oculta. Se muestra el nombre legal de la institución (dato público), nunca ids ni pacientes.
- El script de ejemplo (`datos_ejemplo --generar`) también crea vacunados ficticios. Migración `0014`. Tests: 165 en total.

### Resumen de la Etapa 6
A camas y recursos · B sincronización offline de nodos · C base epidemiológica (acceso exclusivo, anonimización, catálogo de municipios, datos de ejemplo) · D indicadores, brotes y medicamentos · E vacunación y recursos. Migraciones `0010`–`0014`.

## Etapa 7 · parte A (base del frontend, `web/`)
Portales separados (Jinja2 + HTMX + Alpine CSP, sin CDN): **personas** (`/ciudadano`, con login único para ciudadano, profesional y estudiante; `/profesional` es solo su panel), `/institucion` (hospital o clínica), `/farmacia`, `/laboratorio`, `/universidad` y **Omega en una ruta secreta** (`OMEGA_RUTA_WEB` del `.env`; no aparece en `/`, ni en enlaces, ni en `/static/omega`). Ningún portal enlaza a otro; `/` es solo un índice neutro sin sesión.
- **Estructura:** `web/comun` (sesión, CSRF, vista, rutas de ingreso, guardias, definición de portales, estáticos `vendor/` de npm) y una carpeta por portal con `router.py`, `templates/` (su `base.html` con su cabecera, panel y cuenta) y `static/portal.css` (solo sus colores). Una sola hoja base: `comun/static/css/comun.css`.
- **Sesión:** cookie opaca `omega_<portal>` (HttpOnly, SameSite=Strict, `Path=/<portal>`, Secure con prefijo `__Secure-` en producción); en base de datos solo su SHA-256 (`sesion_web`, con el portal que la abrió). El JWT nunca llega al navegador ni hay `localStorage`. Inactividad 30 min (Omega: `OMEGA_TOKEN_MINUTOS`), vigencia absoluta 8 h (Omega: 3×), y en cada petición se revalida que la cuenta siga activa y cumpla el perfil del portal (y la IP en Omega). Cerrar sesión revoca la sesión y el refresh token.
- **CSRF:** token firmado, ligado a la cookie y al portal, en formularios (`csrf_token`) y en HTMX (`X-CSRF-Token`), más comprobación de `Origin`. Rechazos auditados (`WEB_CSRF_RECHAZADO`).
- **Quién entra dónde:** ciudadano = personas; profesional = personas con perfil profesional o de estudiante activo; institución = HOSPITAL/CLINICA; farmacia; laboratorio; universidad; omega = Administrador Omega (TOTP). Un login válido de otro tipo recibe 403 y se revoca el refresh emitido (`WEB_ACCESO_DENEGADO`). Los logins llaman a las funciones de `omega_core` (límites, 2FA institucional, TOTP, bitácora); no hay lógica de negocio duplicada. **Login único de personas** (`/ciudadano/ingresar`): selector «Ingresar como» = Ciudadano · Profesional de salud · Estudiante universitario. Ciudadano abre `/ciudadano/panel`; profesional o estudiante exigen su perfil ACTIVO y, una vez confirmado, abren `/profesional/panel` (si no lo tienen: 403, refresh revocado y `WEB_ACCESO_DENEGADO`). `/profesional/ingresar` redirige al login único. Registro de personas: `/ciudadano/registro`; el del profesional de salud tiene su propia página en `/profesional/registro` (ver «Registro web del profesional»). Estética: verdes `#81ff85`, `#bbffda`, `#e8ff88` y blanco, bordes redondeados.
- **Cabeceras:** las páginas HTML llevan CSP estricta (`script-src 'self'`, sin inline); las respuestas JSON conservan `default-src 'none'`. `/docs` y `/health` sin cambios.
- **Vendor:** `cd web && npm install && npm run vendor` regenera `comun/static/vendor/` (htmx 2.0.11, Alpine CSP 3.17.4, con `SHA256SUMS`). `node_modules` no va en el zip y el servidor no usa Node.
- Migraciones `0015` (`sesion_web`) y `0016` (la sesión pasa a pertenecer a un portal; si ya tenía la tabla de una versión anterior, `alembic upgrade head` la actualiza). Los paneles y cuentas son la base: el contenido de cada portal llega en las siguientes partes. Tests: 202 en total.

## Etapa 7 · parte 1 (base común, completada)
Sobre la parte A se agregó lo que faltaba de la base común:
- **`requiere_area(portal, permitido=None)`** (`web/comun/sesion.py`): guardia de las páginas internas de un portal. Sin sesión válida DE ESE portal redirige a su login propio (HTMX: 401 + `HX-Redirect`); con sesión pero sin el permiso pedido responde 403 y lo anota (`WEB_AREA_DENEGADA`). Los `panel` y `cuenta` de los siete portales ya la usan.
- **Expiración propia por portal**: `Portal.inactividad_min` y `Portal.absoluta_min` (por defecto 30 min y 8 h; Omega usa `OMEGA_TOKEN_MINUTOS` y 3×). `abrir_sesion(...)` es la fábrica de sesión: valor opaco, solo su hash en BD, `Path` del portal, HttpOnly, SameSite=Strict y Secure con `ENTORNO=produccion`.
- **Páginas de error** (`web/comun/errores.py`, plantilla `error.html`): 403, 404, 405 y 500 con mensajes fijos para navegadores (`Accept: text/html`); sin rutas, trazas ni detalles. La API conserva su JSON. Un 500 lleva CSP y `no-store` desde el propio manejador.
- **CSS base**: se añadió `.tabla` (y `.tabla-scroll` para móvil) a `comun.css`, junto a tarjeta, formulario y alerta; misma paleta verde.
- **Procedimiento de htmx y Alpine (sin CDN):** `cd web && npm install && npm run vendor`. Copia htmx 2.0.11 y Alpine CSP 3.17.4 a `web/comun/static/vendor/` y escribe `SHA256SUMS`; un test verifica los hashes. Para actualizar, cambie las versiones en `web/package.json` y repita. `node_modules` no va en el zip y el servidor no usa Node.
- **Tests** (`tests/test_etapa7b.py`): dos portales falsos (`/prueba-a` y `/prueba-b`) montados en una mini-app prueban que la cookie de uno no abre el otro, el redirect al login propio, la expiración distinta, CSRF ligado al portal, cabeceras sin enlaces cruzados y las páginas de error.

## Etapa 7 · parte 2c (portal `/ciudadano`: datos protegidos y accesos)
- **Desbloqueo 2FA del nivel 4** (`/ciudadano/nivel4`): pide el código y lo verifica con los mismos servicios de la API (`portal_civil.router_expediente.pedir_desafio` / `abrir_desbloqueo`): desafío, 5 intentos, bloqueo por cuenta, 5 solicitudes cada 10 min y bitácora. El token **nunca llega al navegador**: la sesión web guarda solo el id del desbloqueo (`sesion_web.n4_desbloqueo_id`, migración `0017`). Dura 10 minutos, «Ocultar ahora» lo revoca y se pierde al cerrar sesión; una sesión nueva siempre empieza bloqueada.
- **Quién consultó mi expediente** (`/ciudadano/accesos`): usa `GET /portal/accesos` (bitácora de auditoría) y muestra solo quién, institución, fecha y motivo; sin sección, IP, justificaciones ni datos clínicos.
- **Tests** (`tests/test_etapa7e.py`): flujo 2FA, límite de intentos y de solicitudes, desafío ajeno, vencimiento, cierre de sesión, CSRF, «quién consultó» (campos y paginación) y que la cookie de `/ciudadano` no abre ninguna ruta de los otros portales (rutas leídas de la aplicación, con la cookie inyectada en cada portal).

## Etapa 7 · integración web del expediente civil · parte 1: Medicamentos (historial farmacológico)
- Nueva pestaña **Medicamentos** en `/ciudadano/expediente`: línea de tiempo única (recetas · administraciones hospitalarias · autocompras), más reciente primero, de 10 en 10.
- Formulario para **declarar una autocompra** (`POST /ciudadano/medicamentos/autocompra`, con CSRF). Reutiliza `portal_civil.service_autocompras`: mismas validaciones, mismo registro en bitácora, siempre «Declarada por el paciente».
- **Alertas de interacciones** (`portal_civil/interacciones.py`): catálogo editable de grupos y reglas, al estilo de `farmacia/alergias.py`. Cruza los medicamentos de recetas vigentes (o en tratamiento) con las autocompras de los últimos 30 días y detecta también duplicidad. Es informativo: nunca indica suspender un tratamiento.
- El canal **administraciones** queda preparado (`service_historial._administraciones`) pero devuelve vacío: el expediente aún no guarda fármacos aplicados; llegará con la bitácora integral del portal `/profesional` (parte 6b).
- Sin migración Alembic. Pruebas: `tests/test_etapa7i.py`.

## Etapa 7 · integración web del expediente civil · entrega A (partes 2 a 5)
Todo vive en `web/ciudadano` (módulo `servicios.py` + plantillas) y reutiliza las funciones de `portal_civil`: la web solo presenta; reglas, límites y bitácora son los de la API.
- **Citas** (`/ciudadano/citas`): recorrido Especialidad > Centro > Doctor > Fecha > Hora por GET (funciona sin JavaScript), filtros de sector y red de seguros, confirmación con CSRF, `Mis citas` (`/citas/mis`) con cancelar y reprogramar. Las horas salen de la API; la doble reserva (409) y el expediente congelado (423) se muestran con su mensaje.
- **Directorio** (`/ciudadano/directorio`): filtros y paginación; «Agendar aquí» abre el recorrido con el centro elegido.
- **Asistente** (`/ciudadano/asistente`): chat consultivo (no agenda, no diagnostica; sin LLM). El texto solo vive en la página: la bitácora guarda la intención, nunca el mensaje. **Farmacias** (`/ciudadano/farmacias`): disponibilidad aproximada y comparación de precios solo con al menos dos precios.
- **Estado vital y datos civiles** en el panel. La causa oficial de un fallecimiento se trata como dato protegido (solo con desbloqueo de nivel 4).
- **Perfil**: ahora edita tipo de sangre y contacto de emergencia; el NIT es de solo lectura (no existe en `PerfilCiudadanoIn`); indicador «perfil completo X de 8». DUI, nombres y fecha de nacimiento nunca se leen del formulario.
- Sin migraciones Alembic. Pruebas: `tests/test_etapa7j.py` (citas y directorio), `7k` (estado vital), `7l` (asistente y farmacias), `7m` (perfil).

## Etapa 7 · parte 6a (portal `/profesional`: plantillas de los 65 ámbitos y las 5 fases)
- **Ámbitos laborales** (`omega_core/roles_profesionales.py`): los 65 roles de la matriz del documento (v1.2) con su layout, widget, fases dominantes y qué envía y recibe. Columna nueva `perfil_profesional.rol_clave` (migración `0020`, opcional) y validación en `PerfilProfesionalIn` (enfermería ↔ los 4 roles de enfermería). Si el perfil no trae `rol_clave`, el portal lo deduce de `especialidad` (tabla de alias) y, en último caso, usa Médico Internista o Enfermero General, avisándolo en el panel.
- **Plantillas** (`web/profesional/roles.py`, `templates/layouts/`): 6 layouts (Clínico General, Urgencias/Trauma, Quirúrgico, Apoyo/Enfermería, Apoyo y LIS, Apoyo/Gerencial); los roles híbridos 39 y 60 suman las acciones de sus dos layouts. Apoyo y LIS y Apoyo/Gerencial son de consulta; enfermería no asume ni cierra; el Código Rojo está disponible en todas las plantillas operativas. Cada POST vuelve a comprobar la plantilla (`WEB_AREA_DENEGADA` si no corresponde).
- **Las 5 fases en la web**: tablero de atenciones abiertas (orden por triaje, refresco cada 5 s), barra de fases con línea de tiempo (cada 4 s) y acciones por fase: abrir (con Código Rojo), triaje, asumir, avanzar, reevaluar (4→3), bypass de Código Rojo y cierre con egreso. Todo por HTMX con fragmentos: la pantalla se refresca al instante tras cada acción y detecta si otra persona movió la atención. La web solo presenta: reglas, bloqueos de fila, trigger y bitácora son los de `core_expediente.maquina` (`profesional_de` en `core_expediente/deps.py` es la misma validación que usa la API).
- **Salud mental** (psiquiatra, psicólogo clínico): el área queda fija para que el contenido siempre se cifre como nivel 4.
- **Pendiente**: los instrumentos que aún faltan de los widgets (ver parte 6c). Tests nuevos en `tests/test_etapa7m.py`.

## Etapa 7 · portal `/profesional` · parte 6b (notas SOAP, diagnósticos y signos vitales)
Nueva sección **Registro clínico** en la página de cada atención (`web/profesional/registros.py`, `templates/_clinico.html`). La web solo convierte formularios en los esquemas de la API (`NotaSoapIn`, `DiagnosticoIn`, `SignosVitalesIn`) y guarda con la misma función (`router_atenciones._registrar`): fases, solo médicos, un único diagnóstico principal vigente, nivel 4 automático, bloqueo de fila, expediente congelado (423) y bitácora (`REGISTRO_CLINICO`) son los de la API.
- **Nota SOAP** (médico, fases 3-4) y **diagnóstico CIE-10** (médico, fases 3-4; tipo, estatus, principal/comorbilidad, observaciones). **Signos vitales** (médico o enfermería, fases 1-4; el IMC lo calcula el servidor).
- **Requisitos de cierre** a la vista («Nota SOAP: Sí/Falta», «Diagnóstico principal: Sí/Falta»); el cierre sigue validándolo la máquina.
- **Corrección, no edición**: «Corregir» precarga la versión vigente y guarda una nueva con `reemplaza_id` + `motivo_correccion` (solo autor o médico responsable; el original no se toca). La lista muestra solo versiones vigentes.
- **Nivel 4**: salud mental, VIH, genética, «Confidencial» o atención de área de salud mental se guardan cifrados y salen como «restringido». El médico responsable los abre con una justificación (≥10 caracteres, auditada en `ACCESO_EXPEDIENTE`); la justificación no se guarda en la sesión y una recarga vuelve a restringirlos.
- **Permisos de plantilla** (`roles.py`): nuevas acciones `notar`, `diagnosticar`, `signos`. Todas las plantillas operativas las tienen; enfermería solo `signos`; Apoyo LIS y Gerencial siguen siendo de consulta. Cada POST las vuelve a comprobar (`WEB_AREA_DENEGADA`).
- Al cerrar la atención termina la vía de lectura por «atención activa» (regla de la API): el fragmento lo avisa y no ofrece nuevos registros (las correcciones posteriores, por la API o con consentimiento del paciente).
- Sin migraciones. Tests: `tests/test_etapa7n.py` (con base de datos).

## Etapa 7 · portal `/profesional` · parte 6c (instrumentos de los widgets, primer lote)
Calculadoras y escalas **sin estado** en `web/profesional/instrumentos.py`, mostradas dentro del widget del rol (panel y página de la atención). No leen ni guardan datos de pacientes (nada que auditar) y no sustituyen el criterio clínico: el resultado se transcribe a la nota SOAP. Cada instrumento declara sus campos; el servidor valida tipo, rango y opciones (`validar`) y `POST /profesional/instrumentos/{clave}` solo acepta los del widget del rol de la persona (si no: 403 y `WEB_AREA_DENEGADA`), con CSRF.
- **14 instrumentos**: Glasgow, PHQ-9 (alerta destacada si el ítem 9 es positivo), Child-Pugh, DAS28-VSG, regla de los nueve + Parkland (adulto), superficie corporal (Mosteller y DuBois), calculadora gestacional (FUM, Naegele), Harris-Benedict revisada + IMC, función renal (CKD-EPI 2021 y Cockcroft-Gault), HbA1c → glucosa media (ADAG), Morse, EVA, RASS y FIM.
- **Rol → instrumentos** (`instrumentos.ROLES`): neurólogo, neurocirujano, médico de urgencias → Glasgow; intensivista → Glasgow y RASS; enfermero de UCI → RASS y Glasgow; endocrinólogo → HbA1c; gastroenterólogo → Child-Pugh; nefrólogo → renal; oncólogo médico → superficie corporal; reumatólogo → DAS28; geriatra → Morse; psiquiatra y psicólogo clínico → PHQ-9; fisiatra → FIM; paliativista → EVA; cirujano plástico → regla de los nueve; gineco-obstetra → gestacional; nutricionista → Harris-Benedict.
- **Sin instrumento todavía** (siguen con su tarjeta informativa): el resto de los 65 ámbitos, entre ellos EKG y score de riesgo, APACHE II, curvas OMS de crecimiento, Capurro/Ballard, odontograma, espirometría, Doppler, DICOM, listas de verificación y los tableros gerenciales; necesitan tablas de referencia, datos nuevos o almacenamiento propio.
- Las fórmulas están cubiertas por pruebas con valores calculados a mano. **Antes de uso clínico real conviene que un profesional de cada área revise puntos de corte y textos** (están en `instrumentos.py`, un solo lugar).
- Sin migraciones. Tests: `tests/test_etapa7o.py`.

## Etapa 7 · portal `/profesional` · registro web del profesional
- **Página** `GET/POST /profesional/registro` (sin sesión; con sesión redirige al panel). `web/profesional/alta.py` solo convierte el formulario en `PersonaRegistro` con su `profesional` anidado y guarda con `omega_core.routers.personas.registrar`: DUI, correo, teléfono y contraseña se validan con el esquema de la API, con el mismo límite de 20 registros por IP, el mismo 409 por duplicados (DUI, correo, número de junta) y la misma bitácora (`PERSONA_REGISTRADA`). No hay reglas duplicadas.
- **Campos**: los datos personales del registro de personas más tipo de profesión (Doctor / Enfermera), número de junta (JVPM o JVPE), ámbito laboral (uno de los 65, agrupados por plantilla; obligatorio en la web), especialidad (opcional) y lugar de trabajo (opcional; hospitales, clínicas, farmacias y laboratorios activos, nunca universidades). Un ámbito de enfermería con tipo Doctor, o al revés, se rechaza con el mensaje de la validación cruzada del esquema.
- **Verificación**: el perfil nace `verificado=false` y `activo=true`. El profesional puede ingresar por el login único (`Ingresar como › Profesional de salud`) y ve su plantilla, pero el panel le avisa y no habilita el tablero hasta que Omega confirme su junta (`profesional_de`). El formulario no lee `verificado`, `activo` ni roles: un registro web nunca otorga privilegios.
- **Enlaces**: tras registrarse se vuelve a `/ciudadano/ingresar?registrado=1&tipo=profesional` con un aviso de verificación pendiente. El login único de personas ofrece siempre «Regístrese como ciudadano» o «como profesional de salud» (única excepción a «ningún portal enlaza a otro», recogida en `test_etapa7a`), y la cabecera del portal profesional (sin sesión) enlaza a «Registrarse».
- Sin migraciones. Tests nuevos: `tests/test_etapa7p.py` (con base de datos). `tests/test_etapa7a.py::test_registro_solo_en_ciudadano` ahora admite también `/profesional/registro`.
