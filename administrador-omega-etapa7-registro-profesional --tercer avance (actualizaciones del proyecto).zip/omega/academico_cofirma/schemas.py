import uuid
from datetime import date, datetime
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from core_expediente.schemas import DiagnosticoIn, PacienteMin
from farmacia.schemas import MedicamentoIn
from laboratorio.schemas import EstudioIn, Tipo

Nivel = Literal["PRIMER_ANO_CLINICA", "INTERNADO"]
TipoBorrador = Literal["DIAGNOSTICO", "RECETA", "ORDEN_LAB"]
EstadoBorrador = Literal["PENDIENTE_VALIDACION", "APROBADO", "CORREGIDO", "RECHAZADO", "CANCELADO"]
TEXTO_ESTADO = {"PENDIENTE_VALIDACION": "Borrador Pendiente de Validación", "APROBADO": "Aprobado y co-firmado", "CORREGIDO": "Corregido y co-firmado por el tutor",
                "RECHAZADO": "Rechazado por el tutor", "CANCELADO": "Cancelado (la asignación terminó)"}
Comentario = Annotated[str, Field(min_length=5, max_length=1000)]


class _In(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


# ------------------------------------------------------------------ Asignación (la registra el hospital)
class AsignacionIn(_In):
    estudiante_dui: str = Field(description="DUI del estudiante (perfil de estudiante verificado por Omega y activo).")
    tutor_dui: str = Field(description="DUI del médico tutor (médico verificado y activo de ESTE hospital o clínica).")
    nivel: Nivel = Field(description="PRIMER_ANO_CLINICA: solo lectura y signos vitales. INTERNADO: además puede redactar borradores para co-firma.")
    vigente_hasta: date | None = None


class FinalizarIn(_In):
    motivo: Annotated[str, Field(min_length=5, max_length=300)]


class AsignacionOut(BaseModel):
    id: uuid.UUID
    estudiante: PacienteMin
    tutor: PacienteMin
    universidad_id: uuid.UUID
    universidad: str
    institucion_id: uuid.UUID
    nivel: Nivel
    alcance: list[str]
    vigente_desde: date
    vigente_hasta: date | None
    activa: bool


# ------------------------------------------------------------------ Borradores
class BorradorDiagnosticoIn(DiagnosticoIn):
    atencion_id: uuid.UUID = Field(description="Atención abierta (fase 3 o 4) cuyo médico responsable es su tutor.")


class ContenidoReceta(_In):
    vigencia_dias: Annotated[int, Field(ge=1, le=90)] = 30
    medicamentos: Annotated[list[MedicamentoIn], Field(min_length=1, max_length=15)]


class BorradorRecetaIn(ContenidoReceta):
    atencion_id: uuid.UUID


class ContenidoOrden(_In):
    tipo: Tipo
    laboratorio_id: uuid.UUID
    prioridad: Literal["RUTINA", "URGENTE"] = "RUTINA"
    estudios: Annotated[list[EstudioIn], Field(min_length=1, max_length=20)]
    confidencial: bool = False

    @model_validator(mode="after")
    def _modalidad(self):
        for e in self.estudios:
            if self.tipo == "IMAGENOLOGIA" and e.modalidad is None:
                raise ValueError("En IMAGENOLOGIA cada estudio requiere 'modalidad'")
            if self.tipo == "LABORATORIO" and e.modalidad is not None:
                raise ValueError("'modalidad' solo aplica en IMAGENOLOGIA")
        return self


class BorradorOrdenIn(ContenidoOrden):
    atencion_id: uuid.UUID


class BorradorOut(BaseModel):
    id: uuid.UUID
    tipo: TipoBorrador
    estado: EstadoBorrador
    estado_texto: str
    atencion_id: uuid.UUID
    paciente: PacienteMin
    redactado_por: PacienteMin = Field(description="Estudiante que lo redactó.")
    tutor: PacienteMin = Field(description="Único médico que puede co-firmarlo.")
    creado_en: datetime
    decidido_en: datetime | None = None
    autorizado_por: PacienteMin | None = Field(None, description="Médico que lo aprobó/corrigió (el tutor). Vacío mientras esté pendiente o si fue rechazado.")
    comentario: str | None = None
    contenido: dict = Field(description="Lo que redactó el estudiante.")
    contenido_final: dict | None = Field(None, description="Solo si el tutor lo corrigió: lo que quedó co-firmado.")
    resultado_tipo: str | None = None
    resultado_id: uuid.UUID | None = Field(None, description="Id del registro real (diagnóstico, receta u orden) creado al co-firmar.")


class BorradorCreadoOut(BaseModel):
    id: uuid.UUID
    tipo: TipoBorrador
    estado: EstadoBorrador
    estado_texto: str
    tutor: PacienteMin
    aviso: str = "Queda pendiente: no llega a farmacia, laboratorio ni al expediente hasta que su tutor lo co-firme."


class BorradoresOut(BaseModel):
    total: int
    items: list[BorradorOut]


# ------------------------------------------------------------------ Co-firma
class AprobarIn(_In):
    pin: Annotated[str, Field(min_length=6, max_length=64)] | None = Field(None, description="PIN de firma. Obligatorio para recetas (la receta la firma el médico).")
    comentario: Annotated[str, Field(max_length=1000)] | None = None


class RechazarIn(_In):
    comentario: Comentario


class CorregirIn(_In):
    comentario: Comentario
    pin: Annotated[str, Field(min_length=6, max_length=64)] | None = None
    diagnostico: DiagnosticoIn | None = None
    receta: ContenidoReceta | None = None
    orden: ContenidoOrden | None = None


class CofirmaOut(BaseModel):
    borrador_id: uuid.UUID
    estado: EstadoBorrador
    estado_texto: str
    resultado_tipo: str | None = None
    resultado_id: uuid.UUID | None = None
    folio: str | None = Field(None, description="Folio de la receta u orden creada.")
    token: str | None = Field(None, description="Solo en recetas: token de canje, SE MUESTRA UNA SOLA VEZ (entréguelo al paciente).")


# ------------------------------------------------------------------ Estudiante: lectura supervisada
class AtencionSupervisadaOut(BaseModel):
    id: uuid.UUID
    folio: str
    fase: int
    paciente: PacienteMin
    area: str | None


# ------------------------------------------------------------------ Asistencias (estudiante / tutor)
class AsistenciaOut(BaseModel):
    id: uuid.UUID
    estado: Literal["ABIERTA", "CERRADA", "VALIDADA", "RECHAZADA"]
    entrada: datetime
    salida: datetime | None = None
    horas: float | None = None
    comentario: str | None = None


class AsistenciaTutorOut(AsistenciaOut):
    estudiante: PacienteMin


class ValidarAsistenciaIn(_In):
    valida: bool
    comentario: Annotated[str, Field(max_length=300)] | None = None


# ------------------------------------------------------------------ Portal de universidades (agregados: SIN datos clínicos ni de pacientes)
class CasosOut(BaseModel):
    aprobados: int = Field(description="Borradores del estudiante que el tutor co-firmó (aprobados tal cual o corregidos). Solo conteos.")
    de_ellos_corregidos: int
    diagnosticos: int
    recetas: int
    ordenes: int


class AsignacionResumenOut(BaseModel):
    nivel: Nivel
    centro: str
    tutor: str
    desde: date
    hasta: date | None
    activa: bool


class EstudianteUniOut(BaseModel):
    id: uuid.UUID
    dui: str
    nombre: str
    carne: str
    carrera: str
    ciclo: str
    perfil_verificado: bool
    asignacion_activa: AsignacionResumenOut | None
    horas_registradas: float = Field(description="Turnos cerrados (excluye los rechazados por el tutor).")
    horas_validadas: float = Field(description="Turnos que el tutor validó.")
    asistencias_registradas: int
    asistencias_validadas: int
    casos: CasosOut


class EstudiantesUniOut(BaseModel):
    total: int
    items: list[EstudianteUniOut]


class CasosMesOut(BaseModel):
    mes: str
    aprobados: int


class AsistenciaUniOut(BaseModel):
    fecha: date
    entrada: datetime
    salida: datetime | None
    horas: float | None
    estado: str


class EstudianteDetalleUniOut(EstudianteUniOut):
    asignaciones: list[AsignacionResumenOut]
    asistencias: list[AsistenciaUniOut]
    casos_por_mes: list[CasosMesOut]


class ResumenUniOut(BaseModel):
    estudiantes: int
    con_asignacion_activa: int
    horas_validadas: float
    asistencias_validadas: int
    casos: CasosOut


class CoordinadorOut(BaseModel):
    nombre: str
    cargo: str | None
    correo: str | None
    telefono: str | None


class PerfilUniOut(BaseModel):
    id: uuid.UUID
    nombre_legal: str
    nit: str
    credencial_autorizacion: str | None = Field(description="Credencial MINED / CSSP.")
    estado: str = Field(description="PENDIENTE hasta que Omega la verifique y la active.")
    coordinador: CoordinadorOut


# ------------------------------------------------------------------ Token de lectura para un LMS
class LmsTokenIn(_In):
    nombre: Annotated[str, Field(min_length=3, max_length=80, description="Etiqueta, p. ej. 'Moodle producción'.")]
    dias: Annotated[int, Field(ge=1, le=365)] = 90


class LmsTokenOut(BaseModel):
    id: uuid.UUID
    nombre: str
    prefijo: str
    alcance: str
    creado_en: datetime
    expira_en: datetime
    revocado_en: datetime | None = None
    ultimo_uso: datetime | None = None


class LmsTokenCreadoOut(LmsTokenOut):
    token: str = Field(description="SE MUESTRA UNA SOLA VEZ. Se envía en la cabecera `X-LMS-Token` a `/integraciones/lms/estudiantes`.")


class LmsEstudianteOut(BaseModel):
    carne: str
    nombre: str
    correo_institucional: str
    nivel_actual: Nivel | None
    horas_registradas: float
    horas_validadas: float
    asistencias_validadas: int
    casos_aprobados: int
    casos_por_tipo: dict[str, int]


class LmsOut(BaseModel):
    lms_version: str = "1.0"
    universidad: dict
    generado_en: datetime
    estudiantes: list[LmsEstudianteOut]
