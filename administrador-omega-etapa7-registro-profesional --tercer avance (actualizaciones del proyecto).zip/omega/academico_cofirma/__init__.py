"""Módulo academico_cofirma: estudiantes en práctica, borradores pendientes de validación y co-firma del médico tutor."""
