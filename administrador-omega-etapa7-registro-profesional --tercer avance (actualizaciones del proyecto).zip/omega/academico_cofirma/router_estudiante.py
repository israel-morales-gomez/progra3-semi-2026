import uuid
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from core_expediente import service as core
from core_expediente.models import Atencion
from core_expediente.router_expediente import Seccion
from core_expediente.schemas import PacienteMin, RegistroCreadoOut, SeccionOut, SignosVitalesIn
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Persona
from omega_core.security.ratelimit import ip_cliente

from . import service
from .models import AsistenciaPractica, Borrador
from omega_core.models.base import ahora
from .schemas import (AsignacionOut, AsistenciaOut, AtencionSupervisadaOut, BorradorCreadoOut, BorradorDiagnosticoIn, BorradorOrdenIn, BorradorOut, BorradorRecetaIn, BorradoresOut,
                      TEXTO_ESTADO, EstadoBorrador)
from .service import Estudiante, estudiante_practica

router = APIRouter(prefix="/practica", tags=["estudiante en práctica · lectura, signos vitales y borradores"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Sin perfil de estudiante verificado/activo, sin asignación vigente o fuera de su nivel"},
       404: {"description": "No está entre las atenciones que supervisa su tutor"}, 409: {"description": "Atención fuera de fase / cerrada"}, 423: {"description": "DUI congelado por fallecimiento"}}


def _internado(db, est: Estudiante, request: Request, tipo: str):
    if est.asignacion.nivel != "INTERNADO":
        auditar("BORRADOR_DENEGADO", actor_tipo="persona", actor_id=est.persona.id, recurso="borrador", resultado="FALLO", ip=ip_cliente(request),
                detalle={"motivo": "NIVEL_INSUFICIENTE", "tipo": tipo, "nivel": est.asignacion.nivel, "tutor_id": est.asignacion.tutor_id})
        raise HTTPException(403, "Solo el internado puede redactar borradores: en primer año de clínica usted solo lee y registra signos vitales")


@router.get("/mi-asignacion", response_model=AsignacionOut, responses=ERR, summary="Mi universidad, mi tutor y mi alcance")
def mi_asignacion(est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    return service.asignacion_out(db, est.asignacion)


@router.get("/atenciones", response_model=list[AtencionSupervisadaOut], responses=ERR, summary="Atenciones abiertas que supervisa mi tutor",
            description="Solo las atenciones **abiertas** de su centro cuyo **médico responsable es su tutor**. Es el único universo de pacientes al que el estudiante tiene acceso.")
def atenciones(est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    filas = db.execute(select(Atencion, Persona.dui, Persona.nombres, Persona.apellidos).join(Persona, Persona.id == Atencion.paciente_id).where(
        Atencion.institucion_id == est.asignacion.institucion_id, Atencion.medico_responsable_id == est.asignacion.tutor_id, Atencion.estado == "ABIERTA")
        .order_by(Atencion.abierta_en.desc()).limit(100)).all()
    return [AtencionSupervisadaOut(id=a.id, folio=a.folio, fase=a.fase, paciente=PacienteMin(dui=d, nombre=f"{n} {ap}"), area=None if a.sensible_n4 else a.area) for a, d, n, ap in filas]


@router.get("/atenciones/{atencion_id}/expediente/{seccion}", response_model=SeccionOut, responses=ERR, summary="Leer una sección del expediente (solo lectura)",
            description="Solo lectura, solo de pacientes de atenciones que supervisa su tutor. **Los datos de nivel 4 nunca se abren** para el estudiante (salen como restringidos). Cada lectura queda en la bitácora con el estudiante y el tutor.")
def leer(atencion_id: uuid.UUID, seccion: Seccion, request: Request, historial: bool = False, limite: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
         est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    core._limitar_lecturas(est.persona.id)
    at = service.atencion_supervisada(db, est, atencion_id)
    s = seccion.replace("-", "_")
    acceso = core.Acceso("ESTUDIANTE_SUPERVISADO", False, at.id)
    out, _ = core.leer_seccion(db, s, at.paciente_id, acceso, None, historial, limite, offset)
    auditar("ACCESO_EXPEDIENTE", actor_tipo="persona", actor_id=est.persona.id, recurso="expediente", recurso_id=at.paciente_id, ip=ip_cliente(request),
            detalle={"via": acceso.via, "seccion": s, "devueltos": out.devueltos, "restringidos": out.restringidos, "nivel4_abierto": False, "justificacion": None, "historial": historial,
                     "estudiante": True, "supervisor_id": est.asignacion.tutor_id})
    return out


@router.post("/atenciones/{atencion_id}/signos-vitales", response_model=RegistroCreadoOut, status_code=201, responses=ERR, summary="Registrar signos vitales (ambos niveles)",
             description="Único registro clínico directo del estudiante. Queda a su nombre y la bitácora guarda además al **tutor supervisor**. Las correcciones (`reemplaza_id`) las hace el médico.")
def signos(atencion_id: uuid.UUID, datos: SignosVitalesIn, request: Request, est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    if datos.reemplaza_id is not None:
        raise HTTPException(422, "El estudiante no corrige registros: pídale a su tutor que lo haga")
    service.atencion_supervisada(db, est, atencion_id)
    at = core.preparar_escritura(db, est.como_profesional, atencion_id, solo_doctor=False, fases=(1, 2, 3, 4), correccion=False)
    try:
        row = core.crear_signos(db, at, est.persona.id, datos)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Conflicto al registrar")
    ip = ip_cliente(request)
    core.auditar_registro(est.persona.id, at, row, "signos_vitales", ip, {"redactado_por": est.persona.id, "autorizado_por": est.asignacion.tutor_id, "modo": "SUPERVISION_TUTOR"})
    return RegistroCreadoOut(id=row.id, seccion="signos_vitales", nivel_sensibilidad=row.nivel_sensibilidad, cifrado=False, reemplaza_id=None, hash_contenido=row.hash_contenido, creado_en=row.creado_en)


# ------------------------------------------------------------------ Borradores (solo internado)
def _crear(db: Session, est: Estudiante, request: Request, tipo: str, atencion_id: uuid.UUID, contenido: dict) -> BorradorCreadoOut:
    _internado(db, est, request, tipo)
    at = service.atencion_supervisada(db, est, atencion_id)
    b = service.nuevo_borrador(db, est, tipo, at, contenido)
    db.commit()
    auditar("BORRADOR_REDACTADO", actor_tipo="persona", actor_id=est.persona.id, recurso="borrador", recurso_id=b.id, ip=ip_cliente(request),
            detalle={"tipo": tipo, "estado": b.estado, "paciente_id": at.paciente_id, "atencion_id": at.id, "redactado_por": est.persona.id, "autorizado_por": None,
                     "tutor_id": b.tutor_id, "hash": b.hash_contenido})
    return BorradorCreadoOut(id=b.id, tipo=tipo, estado=b.estado, estado_texto=TEXTO_ESTADO[b.estado], tutor=service._min(db, b.tutor_id))


@router.post("/borradores/diagnostico", response_model=BorradorCreadoOut, status_code=201, responses=ERR, summary="Redactar un diagnóstico (borrador, internado)",
             description="Queda como **Borrador Pendiente de Validación**: NO existe en el expediente hasta que el tutor lo co-firme.")
def borrador_diagnostico(datos: BorradorDiagnosticoIn, request: Request, est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    if datos.reemplaza_id is not None:
        raise HTTPException(422, "El estudiante no corrige registros existentes")
    return _crear(db, est, request, "DIAGNOSTICO", datos.atencion_id, datos.model_dump(mode="json", exclude={"atencion_id", "reemplaza_id", "motivo_correccion"}))


@router.post("/borradores/receta", response_model=BorradorCreadoOut, status_code=201, responses=ERR, summary="Redactar una receta (borrador, internado)",
             description="Pendiente de validación: **no se firma, no tiene folio ni token y farmacia no puede verla** hasta que el tutor la co-firme con su PIN.")
def borrador_receta(datos: BorradorRecetaIn, request: Request, est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    return _crear(db, est, request, "RECETA", datos.atencion_id, datos.model_dump(mode="json", exclude={"atencion_id"}))


@router.post("/borradores/orden-lab", response_model=BorradorCreadoOut, status_code=201, responses=ERR, summary="Redactar una orden de laboratorio/imagen (borrador, internado)",
             description="Pendiente de validación: **no existe como orden** y el laboratorio no puede verla hasta que el tutor la co-firme.")
def borrador_orden(datos: BorradorOrdenIn, request: Request, est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    return _crear(db, est, request, "ORDEN_LAB", datos.atencion_id, datos.model_dump(mode="json", exclude={"atencion_id"}))


@router.get("/borradores", response_model=BorradoresOut, responses=ERR, summary="Mis borradores",
            description="Solo los que yo redacté, con su estado, el comentario del tutor y (si fue co-firmado) el id del registro real.")
def mis_borradores(estado: EstadoBorrador | None = None, est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    q = select(Borrador).where(Borrador.estudiante_id == est.persona.id)
    if estado:
        q = q.where(Borrador.estado == estado)
    bs = db.scalars(q.order_by(Borrador.creado_en.desc()).limit(200)).all()
    return BorradoresOut(total=len(bs), items=[service.a_out(db, b) for b in bs])


@router.get("/borradores/{borrador_id}", response_model=BorradorOut, responses=ERR, summary="Un borrador mío")
def mi_borrador(borrador_id: uuid.UUID, est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    b = db.scalar(select(Borrador).where(Borrador.id == borrador_id, Borrador.estudiante_id == est.persona.id))
    if b is None:
        raise HTTPException(404, "Borrador no encontrado")
    return service.a_out(db, b)


# ------------------------------------------------------------------ Asistencias (turnos de práctica)
def _asist_out(a) -> AsistenciaOut:
    return AsistenciaOut(id=a.id, estado=a.estado, entrada=a.entrada, salida=a.salida, horas=round(a.minutos / 60, 2) if a.minutos else None, comentario=a.comentario)


@router.post("/asistencias/entrada", response_model=AsistenciaOut, status_code=201, responses=ERR, summary="Marcar entrada a mi turno de práctica",
             description="Abre un turno (solo uno a la vez). Con la salida se calculan las horas; después el tutor lo valida. La universidad ve las horas, nunca con qué pacientes.")
def entrada(request: Request, est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    a = AsistenciaPractica(asignacion_id=est.asignacion.id, estudiante_id=est.persona.id, tutor_id=est.asignacion.tutor_id, universidad_id=est.asignacion.universidad_id,
                           institucion_id=est.asignacion.institucion_id)
    db.add(a)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Ya tiene un turno abierto: marque primero su salida")
    auditar("ASISTENCIA_ENTRADA", actor_tipo="persona", actor_id=est.persona.id, recurso="asistencia", recurso_id=a.id, ip=ip_cliente(request),
            detalle={"redactado_por": est.persona.id, "autorizado_por": None, "tutor_id": est.asignacion.tutor_id, "universidad_id": a.universidad_id})
    return _asist_out(a)


@router.post("/asistencias/salida", response_model=AsistenciaOut, responses=ERR, summary="Marcar salida y cerrar mi turno",
             description="Un turno no puede durar más de 16 h. Si lo olvidó, el hospital finaliza la asignación y el turno abierto no suma horas.")
def salida(request: Request, est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    a = db.scalar(select(AsistenciaPractica).where(AsistenciaPractica.estudiante_id == est.persona.id, AsistenciaPractica.salida.is_(None)).with_for_update())
    if a is None:
        raise HTTPException(404, "No tiene un turno abierto")
    ahora_ = ahora()
    minutos = int((ahora_ - a.entrada).total_seconds() // 60)
    if minutos > 960:
        raise HTTPException(409, "El turno superó las 16 horas: consulte con su tutor")
    a.salida, a.minutos, a.estado = ahora_, max(minutos, 1), "CERRADA"
    db.commit()
    auditar("ASISTENCIA_SALIDA", actor_tipo="persona", actor_id=est.persona.id, recurso="asistencia", recurso_id=a.id, ip=ip_cliente(request),
            detalle={"redactado_por": est.persona.id, "autorizado_por": None, "minutos": a.minutos, "tutor_id": a.tutor_id})
    return _asist_out(a)


@router.get("/asistencias", response_model=list[AsistenciaOut], responses=ERR, summary="Mis turnos y su validación")
def mis_asistencias(est: Estudiante = Depends(estudiante_practica), db: Session = Depends(get_db)):
    return [_asist_out(a) for a in db.scalars(select(AsistenciaPractica).where(AsistenciaPractica.estudiante_id == est.persona.id).order_by(AsistenciaPractica.entrada.desc()).limit(200))]
