"""Consultas agregadas del portal de universidades. Solo conteos y horas por estudiante: ninguna consulta toca diagnósticos, recetas, órdenes,
atenciones ni pacientes (el contenido del borrador y los identificadores del caso nunca se seleccionan)."""
import uuid
from collections import defaultdict

from fastapi import Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from omega_core.database import get_db
from omega_core.deps import institucion_actual
from omega_core.models import Institucion, PerfilEstudiante, Persona

from .models import AsignacionPractica, AsistenciaPractica, Borrador
from .schemas import AsignacionResumenOut, CasosMesOut, CasosOut, EstudianteDetalleUniOut, EstudianteUniOut
from .service import SV

TIPO = {"DIAGNOSTICO": "diagnosticos", "RECETA": "recetas", "ORDEN_LAB": "ordenes"}


def universidad_actual(inst: Institucion = Depends(institucion_actual)) -> Institucion:
    if inst.tipo != "UNIVERSIDAD":
        raise HTTPException(403, "Solo universidades registradas y verificadas")
    return inst


def _estudiantes(db: Session, uni_id: uuid.UUID, limite=None, offset=0, ids=None):
    q = (select(PerfilEstudiante, Persona.id, Persona.dui, Persona.nombres, Persona.apellidos).join(Persona, Persona.id == PerfilEstudiante.persona_id)
         .where(PerfilEstudiante.universidad_id == uni_id).order_by(Persona.apellidos, Persona.nombres, Persona.id))
    if ids is not None:
        q = q.where(Persona.id.in_(ids))
    if limite:
        q = q.limit(limite).offset(offset)
    return db.execute(q).all()


def _horas(db: Session, uni_id: uuid.UUID) -> dict:
    out = defaultdict(lambda: {"reg": 0, "val": 0, "n_reg": 0, "n_val": 0})
    q = select(AsistenciaPractica.estudiante_id, AsistenciaPractica.estado, func.coalesce(func.sum(AsistenciaPractica.minutos), 0), func.count()).where(
        AsistenciaPractica.universidad_id == uni_id, AsistenciaPractica.estado.in_(("CERRADA", "VALIDADA"))).group_by(AsistenciaPractica.estudiante_id, AsistenciaPractica.estado)
    for eid, estado, minutos, n in db.execute(q):
        out[eid]["reg"] += minutos
        out[eid]["n_reg"] += n
        if estado == "VALIDADA":
            out[eid]["val"] += minutos
            out[eid]["n_val"] += n
    return out


def _casos(db: Session, uni_id: uuid.UUID) -> dict:
    out = defaultdict(lambda: {"DIAGNOSTICO": 0, "RECETA": 0, "ORDEN_LAB": 0, "corr": 0})
    q = (select(Borrador.estudiante_id, Borrador.tipo, Borrador.estado, func.count()).join(AsignacionPractica, AsignacionPractica.id == Borrador.asignacion_id)
         .where(AsignacionPractica.universidad_id == uni_id, Borrador.estado.in_(("APROBADO", "CORREGIDO"))).group_by(Borrador.estudiante_id, Borrador.tipo, Borrador.estado))
    for eid, tipo, estado, n in db.execute(q):
        out[eid][tipo] += n
        if estado == "CORREGIDO":
            out[eid]["corr"] += n
    return out


def casos_out(c: dict | None) -> CasosOut:
    c = c or {"DIAGNOSTICO": 0, "RECETA": 0, "ORDEN_LAB": 0, "corr": 0}
    return CasosOut(aprobados=c["DIAGNOSTICO"] + c["RECETA"] + c["ORDEN_LAB"], de_ellos_corregidos=c["corr"], diagnosticos=c["DIAGNOSTICO"], recetas=c["RECETA"], ordenes=c["ORDEN_LAB"])


def _asignaciones(db: Session, uni_id: uuid.UUID, ids) -> dict:
    tut, hosp = Persona.__table__.alias("t"), Institucion.__table__.alias("h")
    q = (select(AsignacionPractica.estudiante_id, AsignacionPractica.nivel, hosp.c.nombre_legal, tut.c.nombres, tut.c.apellidos, AsignacionPractica.vigente_desde,
                AsignacionPractica.vigente_hasta, AsignacionPractica.activa)
         .join(hosp, hosp.c.id == AsignacionPractica.institucion_id).join(tut, tut.c.id == AsignacionPractica.tutor_id)
         .where(AsignacionPractica.universidad_id == uni_id, AsignacionPractica.estudiante_id.in_(ids)).order_by(AsignacionPractica.vigente_desde.desc(), AsignacionPractica.creada_en.desc()))
    out = defaultdict(list)
    for eid, nivel, centro, n, a, d, h, act in db.execute(q):
        out[eid].append(AsignacionResumenOut(nivel=nivel, centro=centro, tutor=f"{n} {a}", desde=d, hasta=h, activa=act))
    return out


def resumenes(db: Session, uni_id: uuid.UUID, limite=None, offset=0, ids=None) -> list[EstudianteUniOut]:
    filas = _estudiantes(db, uni_id, limite, offset, ids)
    if not filas:
        return []
    horas, casos, asig = _horas(db, uni_id), _casos(db, uni_id), _asignaciones(db, uni_id, [f[1] for f in filas])
    out = []
    for pe, pid, dui, nombres, apellidos in filas:
        h = horas.get(pid, {"reg": 0, "val": 0, "n_reg": 0, "n_val": 0})
        out.append(EstudianteUniOut(
            id=pid, dui=dui, nombre=f"{nombres} {apellidos}", carne=pe.carne, carrera=pe.carrera, ciclo=pe.ciclo, perfil_verificado=pe.verificado,
            asignacion_activa=next((a for a in asig.get(pid, []) if a.activa), None), horas_registradas=round(h["reg"] / 60, 2), horas_validadas=round(h["val"] / 60, 2),
            asistencias_registradas=h["n_reg"], asistencias_validadas=h["n_val"], casos=casos_out(casos.get(pid))))
    return out


def detalle(db: Session, uni_id: uuid.UUID, pid: uuid.UUID) -> EstudianteDetalleUniOut:
    r = resumenes(db, uni_id, ids=[pid])
    if not r:
        raise HTTPException(404, "Estudiante no encontrado")  # igual respuesta para estudiantes de otra universidad o inexistentes
    asig = _asignaciones(db, uni_id, [pid])[pid]
    turnos = db.execute(select(AsistenciaPractica.entrada, AsistenciaPractica.salida, AsistenciaPractica.minutos, AsistenciaPractica.estado).where(
        AsistenciaPractica.universidad_id == uni_id, AsistenciaPractica.estudiante_id == pid).order_by(AsistenciaPractica.entrada.desc()).limit(500)).all()
    mes = func.to_char(func.timezone("America/El_Salvador", Borrador.decidido_en), "YYYY-MM")
    por_mes = db.execute(select(mes, func.count()).join(AsignacionPractica, AsignacionPractica.id == Borrador.asignacion_id).where(
        AsignacionPractica.universidad_id == uni_id, Borrador.estudiante_id == pid, Borrador.estado.in_(("APROBADO", "CORREGIDO"))).group_by(mes).order_by(mes.desc())).all()
    from .schemas import AsistenciaUniOut
    return EstudianteDetalleUniOut(**r[0].model_dump(), asignaciones=asig, casos_por_mes=[CasosMesOut(mes=m, aprobados=n) for m, n in por_mes],
                                   asistencias=[AsistenciaUniOut(fecha=e.astimezone(SV).date(), entrada=e, salida=s, horas=round(m / 60, 2) if m else None, estado=est) for e, s, m, est in turnos])
