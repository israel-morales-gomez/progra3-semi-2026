import hashlib
import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from fastapi import Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from core_expediente.deps import Profesional
from core_expediente.models import Atencion
from core_expediente.schemas import PacienteMin
from core_expediente.service import asegurar_no_congelado
from omega_core.database import get_db
from omega_core.deps import persona_actual
from omega_core.models import Institucion, PerfilProfesional, Persona
from omega_core.security.campos import cifrar_json, descifrar_json

from .models import AsignacionPractica, Borrador
from .schemas import TEXTO_ESTADO, AsignacionOut, BorradorOut

SV = timezone(timedelta(hours=-6))
ALCANCE = {
    "PRIMER_ANO_CLINICA": ["leer expedientes de pacientes de su tutor (solo lectura)", "registrar signos vitales"],
    "INTERNADO": ["leer expedientes de pacientes de su tutor (solo lectura)", "registrar signos vitales",
                  "redactar borradores de diagnósticos, recetas y órdenes de laboratorio (requieren co-firma del tutor)"],
}


@dataclass
class Estudiante:
    persona: Persona
    asignacion: AsignacionPractica

    @property
    def como_profesional(self) -> Profesional:
        """Solo para reutilizar `preparar_escritura` en signos vitales: NO es un profesional (es_doctor=False)."""
        return Profesional(self.persona, self.asignacion.institucion_id, False)


def hoy():
    return datetime.now(SV).date()


def _vigente(a: AsignacionPractica) -> bool:
    return a.activa and a.vigente_desde <= hoy() and (a.vigente_hasta is None or a.vigente_hasta >= hoy())


def tutor_valido(db: Session, tutor_id: uuid.UUID, institucion_id: uuid.UUID) -> bool:
    pf = db.get(PerfilProfesional, tutor_id)
    inst = db.get(Institucion, institucion_id)
    return bool(pf and pf.tipo == "DOCTOR" and pf.verificado and pf.activo and pf.institucion_id == institucion_id and inst is not None and inst.estado == "ACTIVA")


def estudiante_practica(persona: Persona = Depends(persona_actual), db: Session = Depends(get_db)) -> Estudiante:
    """Estudiante con perfil verificado y activo, asignación vigente, universidad y hospital activos y tutor todavía válido. Se revalida en CADA petición."""
    pe = persona.estudiante
    if pe is None or not pe.verificado or not pe.activo or "borrador:crear" not in persona.permisos:
        raise HTTPException(403, "Se requiere un perfil de estudiante verificado y activo")
    a = db.scalar(select(AsignacionPractica).where(AsignacionPractica.estudiante_id == persona.id, AsignacionPractica.activa.is_(True)))
    if a is None or not _vigente(a):
        raise HTTPException(403, "No tiene una asignación de práctica vigente")
    uni, hosp = db.get(Institucion, a.universidad_id), db.get(Institucion, a.institucion_id)
    if pe.universidad_id != a.universidad_id or uni is None or uni.estado != "ACTIVA" or hosp is None or hosp.estado != "ACTIVA":
        raise HTTPException(403, "Su universidad o el centro de práctica no están activos")
    if not tutor_valido(db, a.tutor_id, a.institucion_id):
        raise HTTPException(403, "Su médico tutor ya no está habilitado: pida al hospital una nueva asignación")
    return Estudiante(persona, a)


def atencion_supervisada(db: Session, est: Estudiante, atencion_id: uuid.UUID, *, bloquear: bool = False) -> Atencion:
    """Solo atenciones ABIERTAS del centro de práctica cuyo médico responsable es SU tutor; cualquier otra: 404 (no se revela su existencia)."""
    q = select(Atencion).where(Atencion.id == atencion_id, Atencion.institucion_id == est.asignacion.institucion_id,
                               Atencion.medico_responsable_id == est.asignacion.tutor_id, Atencion.estado == "ABIERTA")
    at = db.scalar(q.with_for_update(read=True) if bloquear else q)
    if at is None:
        raise HTTPException(404, "Atención no encontrada entre las que supervisa su tutor")
    return at


def nuevo_borrador(db: Session, est: Estudiante, tipo: str, at: Atencion, contenido: dict) -> Borrador:
    asegurar_no_congelado(db, at.paciente_id)
    if at.fase not in (3, 4):
        raise HTTPException(409, "Los borradores se redactan durante la ejecución o la trazabilidad de la atención (fase 3 o 4)")
    canon = json.dumps(contenido, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
    b = Borrador(tipo=tipo, estudiante_id=est.persona.id, tutor_id=est.asignacion.tutor_id, asignacion_id=est.asignacion.id, atencion_id=at.id, paciente_id=at.paciente_id,
                 institucion_id=at.institucion_id, contenido_cifrado=cifrar_json(contenido),
                 hash_contenido=hashlib.sha256(f"{tipo}|{at.id}|{est.persona.id}|{canon}".encode()).hexdigest())
    db.add(b)
    db.flush()
    return b


def _min(db: Session, pid: uuid.UUID | None) -> PacienteMin | None:
    if pid is None:
        return None
    p = db.execute(select(Persona.dui, Persona.nombres, Persona.apellidos).where(Persona.id == pid)).first()
    return PacienteMin(dui=p.dui, nombre=f"{p.nombres} {p.apellidos}")


def a_out(db: Session, b: Borrador) -> BorradorOut:
    autorizador = b.decidido_por if b.estado in ("APROBADO", "CORREGIDO") else None
    return BorradorOut(id=b.id, tipo=b.tipo, estado=b.estado, estado_texto=TEXTO_ESTADO[b.estado], atencion_id=b.atencion_id, paciente=_min(db, b.paciente_id),
                       redactado_por=_min(db, b.estudiante_id), tutor=_min(db, b.tutor_id), creado_en=b.creado_en, decidido_en=b.decidido_en,
                       autorizado_por=_min(db, autorizador), comentario=b.comentario, contenido=descifrar_json(b.contenido_cifrado),
                       contenido_final=descifrar_json(b.contenido_final_cifrado) if b.contenido_final_cifrado else None,
                       resultado_tipo=b.resultado_tipo, resultado_id=b.resultado_id)


def asignacion_out(db: Session, a: AsignacionPractica) -> AsignacionOut:
    uni = db.scalar(select(Institucion.nombre_legal).where(Institucion.id == a.universidad_id))
    return AsignacionOut(id=a.id, estudiante=_min(db, a.estudiante_id), tutor=_min(db, a.tutor_id), universidad_id=a.universidad_id, universidad=uni,
                         institucion_id=a.institucion_id, nivel=a.nivel, alcance=ALCANCE[a.nivel], vigente_desde=a.vigente_desde, vigente_hasta=a.vigente_hasta, activa=a.activa)
