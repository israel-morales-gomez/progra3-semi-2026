import hashlib
import secrets
import uuid
from datetime import timedelta

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Institucion, PerfilEstudiante
from omega_core.models.base import ahora
from omega_core.security.ratelimit import ip_cliente, limitar_ip

from . import universidad as uni
from .models import LmsToken
from .schemas import (CoordinadorOut, EstudianteDetalleUniOut, EstudiantesUniOut, LmsEstudianteOut, LmsOut, LmsTokenCreadoOut, LmsTokenIn, LmsTokenOut, PerfilUniOut,
                      ResumenUniOut)
from .universidad import universidad_actual

router = APIRouter(prefix="/universidad", tags=["portal de universidades (solo lectura, sin datos clínicos)"])
lms_router = APIRouter(prefix="/integraciones/lms", tags=["integración LMS (token de lectura; sin conectar)"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Solo universidades activas (verificadas por Omega)"}, 404: {"description": "Estudiante no encontrado (o de otra universidad)"}}
_AVISO = ("**Solo agregados por estudiante** (horas, asistencias, conteo de casos aprobados). Nunca devuelve diagnósticos, recetas, órdenes, resultados, ni DUI, nombres, ids o folios de pacientes. "
          "Una universidad solo ve a **sus** estudiantes.")


@router.get("/perfil", response_model=PerfilUniOut, responses=ERR, summary="Datos de mi universidad y de su coordinador",
            description="El registro lo hace la universidad en `POST /instituciones` (NIT, credencial MINED/CSSP, coordinador); **Omega la verifica y activa** (`PATCH /omega/instituciones/{id}/estado`) y solo entonces puede iniciar sesión (`POST /auth/login/institucion`).")
def perfil(request: Request, u: Institucion = Depends(universidad_actual)):
    auditar("UNIVERSIDAD_CONSULTA", actor_tipo="institucion", actor_id=u.id, recurso="perfil", recurso_id=u.id, ip=ip_cliente(request))
    return PerfilUniOut(id=u.id, nombre_legal=u.nombre_legal, nit=u.nit, credencial_autorizacion=u.credencial_autorizacion, estado=u.estado,
                        coordinador=CoordinadorOut(nombre=u.responsable_nombre, cargo=u.responsable_cargo, correo=u.responsable_correo, telefono=u.responsable_telefono))


@router.get("/resumen", response_model=ResumenUniOut, responses=ERR, summary="Totales de mis estudiantes", description=_AVISO)
def resumen(request: Request, u: Institucion = Depends(universidad_actual), db: Session = Depends(get_db)):
    es = uni.resumenes(db, u.id)
    tot = {"DIAGNOSTICO": sum(e.casos.diagnosticos for e in es), "RECETA": sum(e.casos.recetas for e in es), "ORDEN_LAB": sum(e.casos.ordenes for e in es), "corr": sum(e.casos.de_ellos_corregidos for e in es)}
    auditar("UNIVERSIDAD_CONSULTA", actor_tipo="institucion", actor_id=u.id, recurso="resumen", ip=ip_cliente(request), detalle={"estudiantes": len(es)})
    return ResumenUniOut(estudiantes=len(es), con_asignacion_activa=sum(1 for e in es if e.asignacion_activa), horas_validadas=round(sum(e.horas_validadas for e in es), 2),
                         asistencias_validadas=sum(e.asistencias_validadas for e in es), casos=uni.casos_out(tot))


@router.get("/estudiantes", response_model=EstudiantesUniOut, responses=ERR, summary="Mis estudiantes: horas de práctica, asistencias y casos aprobados", description=_AVISO)
def estudiantes(request: Request, limite: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0), u: Institucion = Depends(universidad_actual), db: Session = Depends(get_db)):
    items = uni.resumenes(db, u.id, limite, offset)
    auditar("UNIVERSIDAD_CONSULTA", actor_tipo="institucion", actor_id=u.id, recurso="estudiantes", ip=ip_cliente(request), detalle={"devueltos": len(items), "offset": offset})
    return EstudiantesUniOut(total=len(items), items=items)


@router.get("/estudiantes/{estudiante_id}", response_model=EstudianteDetalleUniOut, responses=ERR, summary="Detalle de un estudiante mío: turnos, asignaciones y casos por mes", description=_AVISO)
def estudiante(estudiante_id: uuid.UUID, request: Request, u: Institucion = Depends(universidad_actual), db: Session = Depends(get_db)):
    try:
        d = uni.detalle(db, u.id, estudiante_id)
    except HTTPException:
        auditar("UNIVERSIDAD_CONSULTA_DENEGADA", actor_tipo="institucion", actor_id=u.id, recurso="estudiante", resultado="FALLO", ip=ip_cliente(request), detalle={"motivo": "NO_ES_SU_ESTUDIANTE"})
        raise
    auditar("UNIVERSIDAD_CONSULTA", actor_tipo="institucion", actor_id=u.id, recurso="estudiante", recurso_id=estudiante_id, ip=ip_cliente(request))
    return d


# ------------------------------------------------------------------ Tokens de lectura para el LMS
def _token_out(t: LmsToken) -> LmsTokenOut:
    return LmsTokenOut(id=t.id, nombre=t.nombre, prefijo=t.prefijo, alcance=t.alcance, creado_en=t.creado_en, expira_en=t.expira_en, revocado_en=t.revocado_en, ultimo_uso=t.ultimo_uso)


@router.post("/lms/tokens", response_model=LmsTokenCreadoOut, status_code=201, responses=ERR, summary="Crear un token de lectura para mi LMS",
             description="Solo estructura: no se conecta a ningún LMS. El token es de **solo lectura**, vale hasta 365 días, se muestra **una sola vez** (se guarda su hash) y se revoca con `DELETE`.")
def crear_token(datos: LmsTokenIn, request: Request, u: Institucion = Depends(universidad_actual), db: Session = Depends(get_db)):
    activos = db.scalars(select(LmsToken.id).where(LmsToken.universidad_id == u.id, LmsToken.revocado_en.is_(None), LmsToken.expira_en > ahora())).all()
    if len(activos) >= 5:
        raise HTTPException(409, "Ya tiene 5 tokens activos: revoque alguno")
    token = "lms_" + secrets.token_urlsafe(32)
    t = LmsToken(universidad_id=u.id, nombre=datos.nombre, prefijo=token[:8], token_hash=hashlib.sha256(token.encode()).hexdigest(), expira_en=ahora() + timedelta(days=datos.dias))
    db.add(t)
    db.commit()
    auditar("LMS_TOKEN_CREADO", actor_tipo="institucion", actor_id=u.id, recurso="lms_token", recurso_id=t.id, ip=ip_cliente(request),
            detalle={"nombre": t.nombre, "prefijo": t.prefijo, "alcance": t.alcance, "expira_en": t.expira_en})
    return LmsTokenCreadoOut(**_token_out(t).model_dump(), token=token)


@router.get("/lms/tokens", response_model=list[LmsTokenOut], responses=ERR, summary="Mis tokens de LMS (sin el valor del token)")
def listar_tokens(u: Institucion = Depends(universidad_actual), db: Session = Depends(get_db)):
    return [_token_out(t) for t in db.scalars(select(LmsToken).where(LmsToken.universidad_id == u.id).order_by(LmsToken.creado_en.desc()).limit(100))]


@router.delete("/lms/tokens/{token_id}", response_model=LmsTokenOut, responses=ERR, summary="Revocar un token de LMS")
def revocar_token(token_id: uuid.UUID, request: Request, u: Institucion = Depends(universidad_actual), db: Session = Depends(get_db)):
    t = db.scalar(select(LmsToken).where(LmsToken.id == token_id, LmsToken.universidad_id == u.id))
    if t is None:
        raise HTTPException(404, "Token no encontrado")
    if t.revocado_en is None:
        t.revocado_en = ahora()
        db.commit()
        auditar("LMS_TOKEN_REVOCADO", actor_tipo="institucion", actor_id=u.id, recurso="lms_token", recurso_id=t.id, ip=ip_cliente(request), detalle={"prefijo": t.prefijo})
    return _token_out(t)


# ------------------------------------------------------------------ Endpoint de integración (lo consume el LMS, no una persona)
def lms_actual(request: Request, x_lms_token: str | None = Header(None, alias="X-LMS-Token", description="Token de lectura creado en `POST /universidad/lms/tokens`."),
               db: Session = Depends(get_db)) -> Institucion:
    ip = ip_cliente(request)
    limitar_ip(request, "lms", 120)
    t = None
    if x_lms_token:
        t = db.scalar(select(LmsToken).where(LmsToken.token_hash == hashlib.sha256(x_lms_token.encode()).hexdigest()))
    u = db.get(Institucion, t.universidad_id) if t else None
    if t is None or t.revocado_en is not None or t.expira_en <= ahora() or u is None or u.estado != "ACTIVA" or u.tipo != "UNIVERSIDAD":
        auditar("LMS_TOKEN_RECHAZADO", actor_tipo="anonimo", actor_id=None, recurso="lms_token", recurso_id=t.id if t else None, resultado="FALLO", ip=ip,
                detalle={"motivo": "REVOCADO_O_VENCIDO" if t else "DESCONOCIDO"})
        raise HTTPException(401, "Token de LMS inválido, vencido o revocado")
    t.ultimo_uso = ahora()
    db.commit()
    request.state.lms_token_id = t.id
    return u


@lms_router.get("/estudiantes", response_model=LmsOut, responses={401: {"description": "Token inválido, vencido o revocado"}}, summary="Estructura de integración: avance de práctica por estudiante",
                description="Para que el LMS de la universidad sincronice avance. **Solo lectura, solo agregados** (carné, horas, asistencias, conteo de casos), sin datos clínicos ni de pacientes, "
                            "y solo de los estudiantes de la universidad dueña del token. Cabecera `X-LMS-Token`. Hoy no hay ningún LMS conectado: es únicamente la estructura.")
def lms_estudiantes(request: Request, u: Institucion = Depends(lms_actual), db: Session = Depends(get_db)):
    es = uni.resumenes(db, u.id)
    auditar("LMS_CONSULTA", actor_tipo="institucion", actor_id=u.id, recurso="lms", recurso_id=getattr(request.state, "lms_token_id", None), ip=ip_cliente(request), detalle={"estudiantes": len(es)})
    correos = dict(db.execute(select(PerfilEstudiante.persona_id, PerfilEstudiante.correo_institucional).where(PerfilEstudiante.universidad_id == u.id)).all())
    return LmsOut(universidad={"id": str(u.id), "nombre": u.nombre_legal}, generado_en=ahora(), estudiantes=[
        LmsEstudianteOut(carne=e.carne, nombre=e.nombre, correo_institucional=correos[e.id], nivel_actual=e.asignacion_activa.nivel if e.asignacion_activa else None,
                         horas_registradas=e.horas_registradas, horas_validadas=e.horas_validadas, asistencias_validadas=e.asistencias_validadas, casos_aprobados=e.casos.aprobados,
                         casos_por_tipo={"diagnosticos": e.casos.diagnosticos, "recetas": e.casos.recetas, "ordenes": e.casos.ordenes}) for e in es])
