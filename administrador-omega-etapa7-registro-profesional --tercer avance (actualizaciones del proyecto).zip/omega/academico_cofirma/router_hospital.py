import uuid
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from core_expediente.deps import hospital_actual
from core_expediente.service import dui_o_422
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Institucion, Persona
from omega_core.models.base import ahora
from omega_core.security.ratelimit import ip_cliente

from . import service
from .models import AsignacionPractica, Borrador
from .schemas import AsignacionIn, AsignacionOut, FinalizarIn

router = APIRouter(prefix="/practicas", tags=["estudiantes en práctica · asignación (hospital)"])
ERR = {401: {"description": "No autenticado"}, 403: {"description": "Solo hospitales y clínicas activos"}, 404: {"description": "Asignación no encontrada en su centro"},
       409: {"description": "El estudiante ya tiene una asignación activa / ya finalizada"}, 422: {"description": "Estudiante o tutor no habilitados"}}


@router.post("", response_model=AsignacionOut, status_code=201, responses=ERR, summary="Asignar un estudiante a un médico tutor",
             description="El hospital o clínica liga al **estudiante** (perfil verificado por Omega, activo y con universidad registrada) con **un médico tutor de su propio centro** y fija el **nivel**: "
                         "`PRIMER_ANO_CLINICA` = solo lectura y signos vitales; `INTERNADO` = además redacta borradores que requieren co-firma. Un estudiante tiene una sola asignación activa.")
def asignar(datos: AsignacionIn, request: Request, inst: Institucion = Depends(hospital_actual), db: Session = Depends(get_db)):
    est = db.scalar(select(Persona).where(Persona.dui == dui_o_422(datos.estudiante_dui)))
    tut = db.scalar(select(Persona).where(Persona.dui == dui_o_422(datos.tutor_dui)))
    pe = est.estudiante if est else None
    if est is None or pe is None or not pe.verificado or not pe.activo or pe.universidad_id is None:
        raise HTTPException(422, "El estudiante no existe o su perfil no está verificado, activo y ligado a una universidad registrada")
    uni = db.get(Institucion, pe.universidad_id)
    if uni is None or uni.tipo != "UNIVERSIDAD" or uni.estado != "ACTIVA":
        raise HTTPException(422, "La universidad del estudiante no está activa")
    if tut is None or tut.id == est.id or not service.tutor_valido(db, tut.id, inst.id):
        raise HTTPException(422, "El tutor debe ser un médico verificado y activo de su centro (y distinto del estudiante)")
    if datos.vigente_hasta is not None and datos.vigente_hasta < service.hoy():
        raise HTTPException(422, "vigente_hasta ya pasó")
    a = AsignacionPractica(estudiante_id=est.id, tutor_id=tut.id, universidad_id=uni.id, institucion_id=inst.id, nivel=datos.nivel, vigente_desde=service.hoy(), vigente_hasta=datos.vigente_hasta)
    db.add(a)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "El estudiante ya tiene una asignación activa: finalícela antes de crear otra")
    auditar("PRACTICA_ASIGNADA", actor_tipo="institucion", actor_id=inst.id, recurso="asignacion_practica", recurso_id=a.id, ip=ip_cliente(request),
            detalle={"estudiante_id": est.id, "tutor_id": tut.id, "universidad_id": uni.id, "nivel": a.nivel, "vigente_hasta": a.vigente_hasta})
    return service.asignacion_out(db, a)


@router.get("", response_model=list[AsignacionOut], responses=ERR, summary="Asignaciones de mi centro")
def listar(estado: Literal["ACTIVA", "FINALIZADA"] = "ACTIVA", inst: Institucion = Depends(hospital_actual), db: Session = Depends(get_db)):
    q = select(AsignacionPractica).where(AsignacionPractica.institucion_id == inst.id, AsignacionPractica.activa.is_(estado == "ACTIVA"))
    return [service.asignacion_out(db, a) for a in db.scalars(q.order_by(AsignacionPractica.creada_en.desc()).limit(200))]


@router.post("/{asignacion_id}/finalizar", response_model=AsignacionOut, responses=ERR, summary="Finalizar una asignación",
             description="Termina la práctica de inmediato (el estudiante pierde todo acceso) y **cancela sus borradores aún pendientes**: nada pendiente puede llegar a farmacia ni laboratorio.")
def finalizar(asignacion_id: uuid.UUID, datos: FinalizarIn, request: Request, inst: Institucion = Depends(hospital_actual), db: Session = Depends(get_db)):
    a = db.scalar(select(AsignacionPractica).where(AsignacionPractica.id == asignacion_id, AsignacionPractica.institucion_id == inst.id).with_for_update())
    if a is None:
        raise HTTPException(404, "Asignación no encontrada")
    if not a.activa:
        raise HTTPException(409, "La asignación ya está finalizada")
    a.activa, a.finalizada_en, a.motivo_fin = False, ahora(), datos.motivo
    pend = db.scalars(select(Borrador).where(Borrador.asignacion_id == a.id, Borrador.estado == "PENDIENTE_VALIDACION").with_for_update()).all()
    for b in pend:
        b.estado, b.decidido_en, b.comentario = "CANCELADO", ahora(), "Cancelado: la asignación de práctica finalizó"
    db.commit()
    auditar("PRACTICA_FINALIZADA", actor_tipo="institucion", actor_id=inst.id, recurso="asignacion_practica", recurso_id=a.id, ip=ip_cliente(request),
            detalle={"estudiante_id": a.estudiante_id, "tutor_id": a.tutor_id, "motivo": datos.motivo, "borradores_cancelados": len(pend)})
    for b in pend:
        auditar("BORRADOR_CANCELADO", actor_tipo="institucion", actor_id=inst.id, recurso="borrador", recurso_id=b.id, ip=ip_cliente(request),
                detalle={"tipo": b.tipo, "redactado_por": b.estudiante_id, "autorizado_por": None, "tutor_id": b.tutor_id})
    return service.asignacion_out(db, a)
