from .router_cofirma import router as cofirma_router
from .router_estudiante import router as estudiante_router
from .router_hospital import router as hospital_router
from .router_universidad import lms_router, router as universidad_router

routers = [hospital_router, estudiante_router, cofirma_router, universidad_router, lms_router]
