import uuid
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from core_expediente import service as core
from core_expediente.deps import Profesional, medico_activo
from core_expediente.models import Atencion
from core_expediente.schemas import DiagnosticoIn, PacienteMin
from farmacia.routers import emitir_receta
from farmacia.schemas import EmitirRecetaIn
from laboratorio.routers import crear_orden_lab
from laboratorio.schemas import CrearOrdenIn
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Persona
from omega_core.models.base import ahora
from omega_core.security.campos import cifrar_json, descifrar_json
from omega_core.security.ratelimit import ip_cliente

from . import service
from .models import AsistenciaPractica, Borrador
from .schemas import TEXTO_ESTADO, AprobarIn, AsistenciaOut, AsistenciaTutorOut, ValidarAsistenciaIn, BorradorOut, BorradoresOut, CofirmaOut, CorregirIn, EstadoBorrador, RechazarIn

router = APIRouter(prefix="/cofirma", tags=["co-firma · médico tutor"])
ERR = {401: {"description": "No autenticado / PIN de firma incorrecto"}, 403: {"description": "No es médico verificado, o no es el tutor asignado a ese borrador"},
       404: {"description": "Borrador no encontrado"}, 409: {"description": "Ya decidido, o la atención/regla clínica ya no lo permite"}, 422: {"description": "Falta PIN/comentario/contenido"},
       423: {"description": "DUI congelado por fallecimiento"}}


def _prof(prof: Profesional = Depends(medico_activo)) -> Profesional:
    if "borrador:cofirmar" not in prof.persona.permisos:
        raise HTTPException(403, "Sin permiso para co-firmar")
    return prof


def _cargar(db: Session, bid: uuid.UUID, prof: Profesional, ip: str, *, pendiente: bool) -> Borrador:
    b = db.scalar(select(Borrador).where(Borrador.id == bid).with_for_update())
    if b is None:
        raise HTTPException(404, "Borrador no encontrado")
    if b.tutor_id != prof.persona.id:
        auditar("COFIRMA_DENEGADA", actor_tipo="persona", actor_id=prof.persona.id, recurso="borrador", recurso_id=b.id, resultado="FALLO", ip=ip,
                detalle={"motivo": "NO_ES_EL_TUTOR_ASIGNADO", "redactado_por": b.estudiante_id, "tutor_id": b.tutor_id, "tipo": b.tipo})
        raise HTTPException(403, "Solo el tutor asignado puede co-firmar este borrador")
    if pendiente and b.estado != "PENDIENTE_VALIDACION":
        raise HTTPException(409, f"El borrador ya fue decidido ({TEXTO_ESTADO[b.estado].lower()})")
    return b


def _cerrar(b: Borrador, estado: str, prof: Profesional, comentario: str | None, rtipo: str | None = None, rid: uuid.UUID | None = None, final: dict | None = None) -> None:
    b.estado, b.decidido_en, b.decidido_por, b.comentario = estado, ahora(), prof.persona.id, comentario
    b.resultado_tipo, b.resultado_id = rtipo, rid
    b.contenido_final_cifrado = cifrar_json(final) if final is not None else None


def _atencion_vigente(db: Session, prof: Profesional, b: Borrador) -> Atencion:
    at = db.scalar(select(Atencion).where(Atencion.id == b.atencion_id, Atencion.institucion_id == prof.institucion_id).with_for_update(read=True))
    if at is None:
        raise HTTPException(404, "Atención no encontrada en su institución")
    core.asegurar_no_congelado(db, at.paciente_id)
    if at.estado != "ABIERTA":
        raise HTTPException(409, "La atención ya está cerrada: el borrador no puede convertirse en registro")
    if at.medico_responsable_id != prof.persona.id:
        raise HTTPException(409, "Usted ya no es el médico responsable de la atención")
    if at.fase not in (3, 4):
        raise HTTPException(409, "La atención ya no está en fase 3 o 4")
    return at


def _cofirmar(db: Session, prof: Profesional, b: Borrador, contenido: dict, estado: str, comentario: str | None, pin: str | None, ip: str, final: dict | None) -> CofirmaOut:
    """Convierte el borrador en el registro real A NOMBRE DEL TUTOR, en la misma transacción que cierra el borrador."""
    at = _atencion_vigente(db, prof, b)
    dui = db.scalar(select(Persona.dui).where(Persona.id == at.paciente_id))
    dual = {"borrador_id": b.id, "redactado_por": b.estudiante_id, "autorizado_por": prof.persona.id, "via": "COFIRMA_TUTOR"}
    folio = token = None
    if b.tipo == "DIAGNOSTICO":
        at = core.preparar_escritura(db, prof, b.atencion_id, solo_doctor=True, fases=(3, 4), correccion=False)
        row = core.crear_diagnostico(db, at, prof.persona.id, DiagnosticoIn(**contenido))
        _cerrar(b, estado, prof, comentario, "diagnostico", row.id, final)
        db.commit()
        core.auditar_registro(prof.persona.id, at, row, "diagnosticos", ip, dual)
        rid, rtipo = row.id, "diagnostico"
    elif b.tipo == "RECETA":
        if not pin:
            raise HTTPException(422, "La receta la firma el médico: envíe su PIN de firma")
        datos = EmitirRecetaIn(dui=dui, pin=pin, **contenido)

        def hook(db_, receta):
            if receta.atencion_id != b.atencion_id:
                raise HTTPException(409, "La receta no correspondería a la atención del borrador")
            _cerrar(b, estado, prof, comentario, "receta", receta.id, final)

        r = emitir_receta(db, prof, datos, ip, antes_commit=hook, auditoria_extra=dual)
        rid, rtipo, folio, token = r.id, "receta", r.folio, r.token
    else:
        datos = CrearOrdenIn(dui=dui, **contenido)

        def hook(db_, orden):
            if orden.atencion_id != b.atencion_id:
                raise HTTPException(409, "La orden no correspondería a la atención del borrador")
            _cerrar(b, estado, prof, comentario, "orden_lab", orden.id, final)

        o = crear_orden_lab(db, prof, datos, ip, antes_commit=hook, auditoria_extra=dual)
        rid, rtipo, folio = o.id, "orden_lab", o.folio
    auditar("COFIRMA_APROBADA" if estado == "APROBADO" else "COFIRMA_CORREGIDA", actor_tipo="persona", actor_id=prof.persona.id, recurso="borrador", recurso_id=b.id, ip=ip,
            detalle={"tipo": b.tipo, "estado": estado, "paciente_id": b.paciente_id, "atencion_id": b.atencion_id, "redactado_por": b.estudiante_id, "autorizado_por": prof.persona.id,
                     "resultado_tipo": rtipo, "resultado_id": rid, "comentario_caracteres": len(comentario or ""), "hash_borrador": b.hash_contenido})
    return CofirmaOut(borrador_id=b.id, estado=estado, estado_texto=TEXTO_ESTADO[estado], resultado_tipo=rtipo, resultado_id=rid, folio=folio, token=token)


@router.get("/borradores", response_model=BorradoresOut, responses=ERR, summary="Borradores de mis estudiantes",
            description="Solo los borradores en que **yo soy el tutor asignado**. Por defecto, los pendientes de validación.")
def listar(estado: EstadoBorrador = "PENDIENTE_VALIDACION", prof: Profesional = Depends(_prof), db: Session = Depends(get_db)):
    bs = db.scalars(select(Borrador).where(Borrador.tutor_id == prof.persona.id, Borrador.estado == estado).order_by(Borrador.creado_en).limit(200)).all()
    return BorradoresOut(total=len(bs), items=[service.a_out(db, b) for b in bs])


@router.get("/borradores/{borrador_id}", response_model=BorradorOut, responses=ERR, summary="Revisar un borrador (solo su tutor)")
def ver(borrador_id: uuid.UUID, request: Request, prof: Profesional = Depends(_prof), db: Session = Depends(get_db)):
    return service.a_out(db, _cargar(db, borrador_id, prof, ip_cliente(request), pendiente=False))


@router.post("/borradores/{borrador_id}/aprobar", response_model=CofirmaOut, responses=ERR, summary="Aprobar y co-firmar tal como está",
             description="Crea el registro real **a nombre del médico tutor** (diagnóstico en el expediente, receta firmada con su PIN, u orden de laboratorio). Solo desde este momento farmacia/laboratorio pueden verlo. "
                         "La bitácora guarda quién lo redactó (estudiante) y quién lo autorizó (tutor). Una receta devuelve su **token de canje una sola vez**.")
def aprobar(borrador_id: uuid.UUID, datos: AprobarIn, request: Request, prof: Profesional = Depends(_prof), db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    b = _cargar(db, borrador_id, prof, ip, pendiente=True)
    return _cofirmar(db, prof, b, descifrar_json(b.contenido_cifrado), "APROBADO", datos.comentario, datos.pin, ip, None)


@router.post("/borradores/{borrador_id}/corregir", response_model=CofirmaOut, responses=ERR, summary="Corregir y co-firmar (con comentario)",
             description="El tutor sustituye el contenido (`diagnostico`, `receta` u `orden`, según el tipo del borrador) y lo co-firma. Se conservan el contenido original del estudiante y el corregido, más el comentario obligatorio.")
def corregir(borrador_id: uuid.UUID, datos: CorregirIn, request: Request, prof: Profesional = Depends(_prof), db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    b = _cargar(db, borrador_id, prof, ip, pendiente=True)
    campo = {"DIAGNOSTICO": "diagnostico", "RECETA": "receta", "ORDEN_LAB": "orden"}[b.tipo]
    enviados = [c for c in ("diagnostico", "receta", "orden") if getattr(datos, c) is not None]
    if enviados != [campo]:
        raise HTTPException(422, f"Un borrador de tipo {b.tipo} se corrige enviando únicamente `{campo}`")
    nuevo = getattr(datos, campo)
    if campo == "diagnostico" and nuevo.reemplaza_id is not None:
        raise HTTPException(422, "Un borrador no corrige versiones anteriores (reemplaza_id)")
    contenido = nuevo.model_dump(mode="json", exclude={"reemplaza_id", "motivo_correccion"} if campo == "diagnostico" else set())
    return _cofirmar(db, prof, b, contenido, "CORREGIDO", datos.comentario, datos.pin, ip, contenido)


@router.post("/borradores/{borrador_id}/rechazar", response_model=CofirmaOut, responses=ERR, summary="Rechazar con comentario",
             description="No se crea ningún registro: el borrador queda RECHAZADO (inmutable) con el comentario del tutor. Nada llega a farmacia, laboratorio ni al expediente.")
def rechazar(borrador_id: uuid.UUID, datos: RechazarIn, request: Request, prof: Profesional = Depends(_prof), db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    b = _cargar(db, borrador_id, prof, ip, pendiente=True)
    _cerrar(b, "RECHAZADO", prof, datos.comentario)
    db.commit()
    auditar("COFIRMA_RECHAZADA", actor_tipo="persona", actor_id=prof.persona.id, recurso="borrador", recurso_id=b.id, ip=ip,
            detalle={"tipo": b.tipo, "estado": "RECHAZADO", "paciente_id": b.paciente_id, "atencion_id": b.atencion_id, "redactado_por": b.estudiante_id, "autorizado_por": None,
                     "rechazado_por": prof.persona.id, "comentario_caracteres": len(datos.comentario), "hash_borrador": b.hash_contenido})
    return CofirmaOut(borrador_id=b.id, estado="RECHAZADO", estado_texto=TEXTO_ESTADO["RECHAZADO"])


# ------------------------------------------------------------------ Validación de asistencias
@router.get("/asistencias", response_model=list[AsistenciaTutorOut], responses=ERR, summary="Turnos de mis estudiantes",
            description="Por defecto, los turnos cerrados que aún esperan mi validación. Solo de estudiantes de quienes soy tutor.")
def asistencias(estado: Literal["ABIERTA", "CERRADA", "VALIDADA", "RECHAZADA"] = "CERRADA", prof: Profesional = Depends(_prof), db: Session = Depends(get_db)):
    filas = db.execute(select(AsistenciaPractica, Persona.dui, Persona.nombres, Persona.apellidos).join(Persona, Persona.id == AsistenciaPractica.estudiante_id).where(
        AsistenciaPractica.tutor_id == prof.persona.id, AsistenciaPractica.estado == estado).order_by(AsistenciaPractica.entrada).limit(200)).all()
    return [AsistenciaTutorOut(id=a.id, estado=a.estado, entrada=a.entrada, salida=a.salida, horas=round(a.minutos / 60, 2) if a.minutos else None, comentario=a.comentario,
                               estudiante=PacienteMin(dui=d, nombre=f"{n} {ap}")) for a, d, n, ap in filas]


@router.post("/asistencias/{asistencia_id}/validar", response_model=AsistenciaOut, responses=ERR, summary="Validar o rechazar el turno de un estudiante",
             description="Solo el tutor asignado. Una vez validada o rechazada, la asistencia es definitiva. Las horas validadas son las que la universidad ve como tales.")
def validar_asistencia(asistencia_id: uuid.UUID, datos: ValidarAsistenciaIn, request: Request, prof: Profesional = Depends(_prof), db: Session = Depends(get_db)):
    ip = ip_cliente(request)
    a = db.scalar(select(AsistenciaPractica).where(AsistenciaPractica.id == asistencia_id).with_for_update())
    if a is None:
        raise HTTPException(404, "Asistencia no encontrada")
    if a.tutor_id != prof.persona.id:
        auditar("COFIRMA_DENEGADA", actor_tipo="persona", actor_id=prof.persona.id, recurso="asistencia", recurso_id=a.id, resultado="FALLO", ip=ip,
                detalle={"motivo": "NO_ES_EL_TUTOR_ASIGNADO", "redactado_por": a.estudiante_id, "tutor_id": a.tutor_id})
        raise HTTPException(403, "Solo el tutor asignado puede validar esta asistencia")
    if a.estado != "CERRADA":
        raise HTTPException(409, f"La asistencia está {a.estado.lower()}: solo se validan turnos cerrados")
    if not datos.valida and not (datos.comentario and len(datos.comentario.strip()) >= 5):
        raise HTTPException(422, "Rechazar una asistencia exige un comentario")
    a.estado, a.validada_en, a.validada_por, a.comentario = ("VALIDADA" if datos.valida else "RECHAZADA"), ahora(), prof.persona.id, datos.comentario
    db.commit()
    auditar("ASISTENCIA_VALIDADA" if datos.valida else "ASISTENCIA_RECHAZADA", actor_tipo="persona", actor_id=prof.persona.id, recurso="asistencia", recurso_id=a.id, ip=ip,
            detalle={"redactado_por": a.estudiante_id, "autorizado_por": prof.persona.id if datos.valida else None, "minutos": a.minutos})
    return AsistenciaOut(id=a.id, estado=a.estado, entrada=a.entrada, salida=a.salida, horas=round(a.minutos / 60, 2), comentario=a.comentario)
