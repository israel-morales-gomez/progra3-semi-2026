import uuid
from datetime import date, datetime

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, SmallInteger, String, Text, Uuid, text
from sqlalchemy.orm import Mapped, mapped_column

from omega_core.models.base import Base, ahora

NIVELES_PRACTICA = ("PRIMER_ANO_CLINICA", "INTERNADO")
TIPOS_BORRADOR = ("DIAGNOSTICO", "RECETA", "ORDEN_LAB")
ESTADOS_BORRADOR = ("PENDIENTE_VALIDACION", "APROBADO", "CORREGIDO", "RECHAZADO", "CANCELADO")


def _fk(tabla: str, **kw):
    return mapped_column(Uuid, ForeignKey(f"{tabla}.id", ondelete="RESTRICT"), **kw)


class AsignacionPractica(Base):
    """Estudiante en práctica ligado a una universidad, a un hospital/clínica y a UN médico tutor, con un nivel que fija su alcance.
    Un estudiante tiene como máximo una asignación activa (índice único parcial)."""

    __tablename__ = "asignacion_practica"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    estudiante_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    tutor_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    universidad_id: Mapped[uuid.UUID] = _fk("institucion")
    institucion_id: Mapped[uuid.UUID] = _fk("institucion")  # hospital o clínica donde practica (quien la asigna)
    nivel: Mapped[str] = mapped_column(String(20))
    vigente_desde: Mapped[date] = mapped_column(Date)
    vigente_hasta: Mapped[date | None] = mapped_column(Date)
    activa: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    creada_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    finalizada_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    motivo_fin: Mapped[str | None] = mapped_column(String(300))
    __table_args__ = (
        CheckConstraint("nivel IN ('PRIMER_ANO_CLINICA','INTERNADO')", name="nivel_valido"),
        CheckConstraint("estudiante_id <> tutor_id", name="tutor_distinto"),
        CheckConstraint("vigente_hasta IS NULL OR vigente_hasta >= vigente_desde", name="vigencia_valida"),
        Index("uq_asignacion_estudiante_activa", "estudiante_id", unique=True, postgresql_where=text("activa")),
    )


class Borrador(Base):
    """Borrador pendiente de validación. Vive SOLO en esta tabla: no existe como receta, diagnóstico ni orden hasta que el tutor lo co-firma,
    por eso farmacia y laboratorio (que solo leen recetas y órdenes) jamás pueden verlo. El contenido va cifrado (puede ser nivel 4).
    Una vez decidido es inmutable; la BD exige que quien decide sea el tutor asignado."""

    __tablename__ = "borrador"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    tipo: Mapped[str] = mapped_column(String(12))
    estado: Mapped[str] = mapped_column(String(22), default="PENDIENTE_VALIDACION")
    estudiante_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    tutor_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    asignacion_id: Mapped[uuid.UUID] = _fk("asignacion_practica")
    atencion_id: Mapped[uuid.UUID] = _fk("atencion", index=True)
    paciente_id: Mapped[uuid.UUID] = _fk("persona")
    institucion_id: Mapped[uuid.UUID] = _fk("institucion")
    contenido_cifrado: Mapped[str] = mapped_column(Text)
    hash_contenido: Mapped[str] = mapped_column(String(64))
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    decidido_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    decidido_por: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"))
    comentario: Mapped[str | None] = mapped_column(String(1000))
    contenido_final_cifrado: Mapped[str | None] = mapped_column(Text)  # solo si el tutor corrigió
    resultado_tipo: Mapped[str | None] = mapped_column(String(20))  # diagnostico | receta | orden_lab
    resultado_id: Mapped[uuid.UUID | None] = mapped_column(Uuid)
    __table_args__ = (
        CheckConstraint("tipo IN ('DIAGNOSTICO','RECETA','ORDEN_LAB')", name="tipo_valido"),
        CheckConstraint("estado IN ('PENDIENTE_VALIDACION','APROBADO','CORREGIDO','RECHAZADO','CANCELADO')", name="estado_valido"),
        Index("ix_borrador_tutor_estado", "tutor_id", "estado"),
    )


class AsistenciaPractica(Base):
    """Turno de práctica del estudiante: entrada y salida que él marca, y que su tutor valida. Es lo único que la universidad ve de las horas
    (nunca con qué pacientes). Un estudiante solo puede tener un turno abierto (índice único parcial); el turno cerrado no se edita."""

    __tablename__ = "asistencia_practica"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    asignacion_id: Mapped[uuid.UUID] = _fk("asignacion_practica", index=True)
    estudiante_id: Mapped[uuid.UUID] = _fk("persona", index=True)
    tutor_id: Mapped[uuid.UUID] = _fk("persona")
    universidad_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    institucion_id: Mapped[uuid.UUID] = _fk("institucion")
    entrada: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    salida: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    minutos: Mapped[int | None] = mapped_column(SmallInteger)  # se fija al cerrar el turno
    estado: Mapped[str] = mapped_column(String(10), default="ABIERTA")  # ABIERTA | CERRADA | VALIDADA | RECHAZADA
    validada_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    validada_por: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("persona.id", ondelete="RESTRICT"))
    comentario: Mapped[str | None] = mapped_column(String(300))
    __table_args__ = (
        CheckConstraint("estado IN ('ABIERTA','CERRADA','VALIDADA','RECHAZADA')", name="estado_valido"),
        CheckConstraint("salida IS NULL OR salida > entrada", name="salida_posterior"),
        CheckConstraint("(estado = 'ABIERTA') = (salida IS NULL)", name="estado_coherente"),
        CheckConstraint("minutos IS NULL OR minutos BETWEEN 1 AND 960", name="turno_maximo_16h"),
        Index("uq_asistencia_turno_abierto", "estudiante_id", unique=True, postgresql_where=text("salida IS NULL")),
        Index("ix_asistencia_universidad_estudiante", "universidad_id", "estudiante_id"),
    )


class LmsToken(Base):
    """Token de LECTURA para que el LMS de una universidad consulte los agregados de SUS estudiantes. Solo se guarda el hash; se muestra una vez."""

    __tablename__ = "lms_token"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    universidad_id: Mapped[uuid.UUID] = _fk("institucion", index=True)
    nombre: Mapped[str] = mapped_column(String(80))
    prefijo: Mapped[str] = mapped_column(String(12))
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    alcance: Mapped[str] = mapped_column(String(10), default="lectura")
    creado_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    expira_en: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    revocado_en: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ultimo_uso: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (CheckConstraint("alcance = 'lectura'", name="solo_lectura"),)
