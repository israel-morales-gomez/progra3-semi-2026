"""Portal laboratorio: ingreso, salida, panel y cuenta. Solo usa los servicios de omega_core a través de web.comun."""
from pathlib import Path

from fastapi import APIRouter, Depends, Request

from web.comun.ingreso import instalar_ingreso
from web.comun.portales import LABORATORIO
from web.comun.sesion import Guardias, Sesion, requiere_area
from web.comun.vista import Vista

PORTAL = LABORATORIO
vista = Vista(PORTAL, Path(__file__).parent)
guardias = Guardias(PORTAL)
area = requiere_area(PORTAL)  # guardia de las páginas internas del portal
router = APIRouter(prefix=PORTAL.base, include_in_schema=False)  # las páginas no aparecen en /docs (que documenta la API)
instalar_ingreso(router, PORTAL, vista, guardias)


@router.get("/panel")
def panel(request: Request, sesion: Sesion = Depends(area)):
    return vista.render(request, "panel.html", sesion)


@router.get("/cuenta")
def cuenta(request: Request, sesion: Sesion = Depends(area)):
    return vista.render(request, "cuenta.html", sesion)
