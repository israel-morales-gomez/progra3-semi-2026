"""Instrumentos clínicos de los widgets: calculadoras y escalas validadas, sin estado.

Son apoyo al cálculo: no guardan nada en el expediente ni se ligan a un paciente (no hay datos personales que auditar) y no
sustituyen el criterio clínico. Cada instrumento declara sus campos; `validar` comprueba tipo y rango en el servidor (el HTML
no es una barrera) y `calcular` recibe valores ya tipados y devuelve un `Resultado`. La web los muestra en el widget del rol
(`ROLES`, por clave de ámbito laboral del documento v1.2).
"""
import math
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Callable


@dataclass(frozen=True)
class Campo:
    nombre: str
    etiqueta: str
    tipo: str = "numero"  # numero | entero | opcion | fecha
    opciones: tuple[tuple[str, str], ...] = ()
    minimo: float | None = None
    maximo: float | None = None
    unidad: str = ""
    requerido: bool = True
    ayuda: str = ""
    grupo: str = ""


@dataclass
class Resultado:
    titulo: str
    nivel: str = "info"  # ok | info | alerta
    lineas: list[tuple[str, str]] = field(default_factory=list)
    notas: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class Instrumento:
    clave: str
    titulo: str
    descripcion: str
    campos: tuple[Campo, ...]
    calcular: Callable[[dict], Resultado]


def _n(x: float, d: int = 1) -> str:
    return f"{x:.{d}f}"


# ------------------------------------------------------------------ Validación genérica
def validar(inst: Instrumento, crudos: dict) -> dict:
    """Convierte el formulario en valores tipados. Lanza ValueError con un mensaje legible por campo."""
    out: dict = {}
    for c in inst.campos:
        bruto = (crudos.get(c.nombre) or "").strip()
        if not bruto:
            if c.requerido:
                raise ValueError(f"{c.etiqueta}: es obligatorio")
            out[c.nombre] = None
            continue
        if c.tipo == "opcion":
            if bruto not in {v for v, _ in c.opciones}:
                raise ValueError(f"{c.etiqueta}: opción no válida")
            out[c.nombre] = bruto
        elif c.tipo == "fecha":
            try:
                out[c.nombre] = date.fromisoformat(bruto)
            except ValueError:
                raise ValueError(f"{c.etiqueta}: fecha no válida") from None
        else:
            try:
                v = float(bruto.replace(",", "."))
            except ValueError:
                raise ValueError(f"{c.etiqueta}: debe ser un número") from None
            if not math.isfinite(v):
                raise ValueError(f"{c.etiqueta}: debe ser un número")
            if c.tipo == "entero":
                if v != int(v):
                    raise ValueError(f"{c.etiqueta}: debe ser un número entero")
                v = int(v)
            if (c.minimo is not None and v < c.minimo) or (c.maximo is not None and v > c.maximo):
                raise ValueError(f"{c.etiqueta}: debe estar entre {c.minimo:g} y {c.maximo:g}")
            out[c.nombre] = v
    return out


def _op(*pares) -> tuple[tuple[str, str], ...]:
    return tuple((str(v), t) for v, t in pares)


SEXO = _op(("M", "Masculino"), ("F", "Femenino"))


# ------------------------------------------------------------------ Escala de coma de Glasgow
def _glasgow(v: dict) -> Resultado:
    e, ver, m = int(v["ocular"]), int(v["verbal"]), int(v["motora"])
    total = e + ver + m
    cat, nivel = ("Traumatismo leve (13-15)", "ok") if total >= 13 else ("Moderado (9-12)", "info") if total >= 9 else ("Grave (≤ 8)", "alerta")
    return Resultado(f"Glasgow {total}/15 · {cat}", nivel, [("Respuesta ocular", f"{e}/4"), ("Respuesta verbal", f"{ver}/5"), ("Respuesta motora", f"{m}/6")],
                     [f"Anótelo por componentes: E{e} V{ver} M{m}.", "Si hay intubación o lesión que impide un componente, la escala total no es comparable."])


GLASGOW = Instrumento("glasgow", "Escala de coma de Glasgow", "Nivel de conciencia (3 a 15).", (
    Campo("ocular", "Apertura ocular", "opcion", _op((4, "4 · Espontánea"), (3, "3 · A la voz"), (2, "2 · Al dolor"), (1, "1 · Ninguna"))),
    Campo("verbal", "Respuesta verbal", "opcion", _op((5, "5 · Orientado"), (4, "4 · Confuso"), (3, "3 · Palabras inapropiadas"), (2, "2 · Sonidos incomprensibles"), (1, "1 · Ninguna"))),
    Campo("motora", "Respuesta motora", "opcion", _op((6, "6 · Obedece órdenes"), (5, "5 · Localiza el dolor"), (4, "4 · Retira al dolor"),
                                                      (3, "3 · Flexión anormal"), (2, "2 · Extensión anormal"), (1, "1 · Ninguna"))),
), _glasgow)


# ------------------------------------------------------------------ PHQ-9
_PHQ_ITEMS = ("Poco interés o placer en hacer las cosas", "Se ha sentido decaído(a), deprimido(a) o sin esperanza",
              "Dificultad para dormir o permanecer dormido(a), o ha dormido demasiado", "Se ha sentido cansado(a) o con poca energía",
              "Sin apetito o ha comido en exceso", "Se ha sentido mal consigo mismo(a), o que es un fracaso o que ha quedado mal con su familia",
              "Dificultad para concentrarse, como al leer o ver televisión",
              "Se mueve o habla tan despacio que otros lo han notado, o al contrario, está tan inquieto(a) que se mueve mucho más de lo normal",
              "Pensamientos de que estaría mejor muerto(a) o de lastimarse de alguna manera")
_PHQ_OP = _op((0, "0 · Nunca"), (1, "1 · Varios días"), (2, "2 · Más de la mitad de los días"), (3, "3 · Casi todos los días"))


def _phq9(v: dict) -> Resultado:
    pts = [int(v[f"p{i}"]) for i in range(1, 10)]
    total = sum(pts)
    sev, nivel = (("Mínima (0-4)", "ok") if total <= 4 else ("Leve (5-9)", "info") if total <= 9 else ("Moderada (10-14)", "info")
                  if total <= 14 else ("Moderadamente grave (15-19)", "alerta") if total <= 19 else ("Grave (20-27)", "alerta"))
    r = Resultado(f"PHQ-9: {total}/27 · Depresión {sev}", nivel, [("Total", f"{total}/27"), ("Ítem 9 (ideas de muerte o autolesión)", f"{pts[8]}/3")],
                  ["Es una herramienta de tamizaje y seguimiento; el diagnóstico es clínico.", "Este resultado no se guarda: regístrelo en la nota si corresponde (salud mental es de nivel 4)."])
    if pts[8] > 0:
        r.nivel = "alerta"
        r.notas.insert(0, "ÍTEM 9 POSITIVO: evalúe el riesgo suicida de inmediato y siga el protocolo de la institución.")
    return r


PHQ9 = Instrumento("phq9", "PHQ-9 (depresión)", "Durante las últimas 2 semanas, ¿con qué frecuencia le han molestado estos problemas?",
                   tuple(Campo(f"p{i}", f"{i}. {t}", "opcion", _PHQ_OP) for i, t in enumerate(_PHQ_ITEMS, 1)), _phq9)


# ------------------------------------------------------------------ Child-Pugh
def _child_pugh(v: dict) -> Resultado:
    bil, alb, inr = v["bilirrubina"], v["albumina"], v["inr"]
    p_bil = 1 if bil < 2 else 2 if bil <= 3 else 3
    p_alb = 1 if alb > 3.5 else 2 if alb >= 2.8 else 3
    p_inr = 1 if inr < 1.7 else 2 if inr <= 2.3 else 3
    p_asc, p_enc = int(v["ascitis"]), int(v["encefalopatia"])
    total = p_bil + p_alb + p_inr + p_asc + p_enc
    clase, desc, nivel = ("A", "enfermedad compensada", "ok") if total <= 6 else ("B", "compromiso funcional significativo", "info") if total <= 9 else ("C", "enfermedad descompensada", "alerta")
    return Resultado(f"Child-Pugh clase {clase} ({total} puntos) · {desc}", nivel,
                     [("Bilirrubina", f"{p_bil} pt"), ("Albúmina", f"{p_alb} pt"), ("INR", f"{p_inr} pt"), ("Ascitis", f"{p_asc} pt"), ("Encefalopatía", f"{p_enc} pt")],
                     ["A: 5-6 puntos · B: 7-9 · C: 10-15."])


CHILD_PUGH = Instrumento("child_pugh", "Child-Pugh (cirrosis)", "Reserva funcional hepática.", (
    Campo("bilirrubina", "Bilirrubina total", "numero", minimo=0.1, maximo=60, unidad="mg/dL"),
    Campo("albumina", "Albúmina", "numero", minimo=0.5, maximo=7, unidad="g/dL"),
    Campo("inr", "INR", "numero", minimo=0.5, maximo=10),
    Campo("ascitis", "Ascitis", "opcion", _op((1, "Ausente"), (2, "Leve o controlada con diuréticos"), (3, "Moderada a severa o refractaria"))),
    Campo("encefalopatia", "Encefalopatía hepática", "opcion", _op((1, "Ausente"), (2, "Grado 1-2 o controlada con medicación"), (3, "Grado 3-4 o refractaria"))),
), _child_pugh)


# ------------------------------------------------------------------ DAS28-VSG
def _das28(v: dict) -> Resultado:
    das = 0.56 * math.sqrt(v["dolorosas"]) + 0.28 * math.sqrt(v["inflamadas"]) + 0.70 * math.log(v["vsg"]) + 0.014 * v["global"]
    cat, nivel = (("Remisión (< 2.6)", "ok") if das < 2.6 else ("Actividad baja (2.6 a 3.2)", "ok") if das <= 3.2 else
                  ("Actividad moderada (> 3.2 a 5.1)", "info") if das <= 5.1 else ("Actividad alta (> 5.1)", "alerta"))
    return Resultado(f"DAS28-VSG {_n(das, 2)} · {cat}", nivel, [("Articulaciones dolorosas", str(v["dolorosas"])), ("Articulaciones inflamadas", str(v["inflamadas"])),
                                                                  ("VSG", f"{v['vsg']:g} mm/h"), ("Salud global", f"{v['global']:g}/100")],
                     ["Versión con velocidad de sedimentación (no con PCR)."])


DAS28 = Instrumento("das28", "DAS28-VSG (artritis)", "Índice de actividad articular sobre 28 articulaciones.", (
    Campo("dolorosas", "Articulaciones dolorosas", "entero", minimo=0, maximo=28, ayuda="De 0 a 28"),
    Campo("inflamadas", "Articulaciones inflamadas", "entero", minimo=0, maximo=28, ayuda="De 0 a 28"),
    Campo("vsg", "VSG", "numero", minimo=1, maximo=150, unidad="mm/h"),
    Campo("global", "Salud global según el paciente", "numero", minimo=0, maximo=100, ayuda="Escala 0-100"),
), _das28)


# ------------------------------------------------------------------ Regla de los nueve (adulto) y Parkland
REGIONES_NUEVE = (("cabeza", "Cabeza y cuello", 9), ("tronco_a", "Tronco anterior", 18), ("tronco_p", "Tronco posterior", 18), ("msd", "Miembro superior derecho", 9),
                  ("msi", "Miembro superior izquierdo", 9), ("mid", "Miembro inferior derecho", 18), ("mii", "Miembro inferior izquierdo", 18), ("genital", "Genitales y periné", 1))


def _nueve(v: dict) -> Resultado:
    detalle, total = [], 0.0
    for clave, nombre, peso_region in REGIONES_NUEVE:
        pct = v[clave] or 0
        aporte = peso_region * pct / 100
        total += aporte
        if pct:
            detalle.append((nombre, f"{pct:g} % de {peso_region} % = {_n(aporte, 1)} %"))
    nivel = "alerta" if total >= 20 else "info"
    r = Resultado(f"Superficie corporal quemada ≈ {_n(total, 1)} %", nivel, detalle or [("Regiones", "sin superficie afectada")])
    r.notas.append("Regla de los nueve para ADULTOS. Cuente solo quemaduras de segundo grado o mayores. En niños los porcentajes cambian.")
    if v["peso"] and total > 0:
        ml = 4 * v["peso"] * total
        r.lineas += [("Parkland (24 h)", f"{ml:,.0f} mL de Ringer lactato"), ("Primeras 8 h desde la quemadura", f"{ml / 2:,.0f} mL ({ml / 2 / 8:,.0f} mL/h)"),
                     ("Siguientes 16 h", f"{ml / 2:,.0f} mL ({ml / 2 / 16:,.0f} mL/h)")]
        r.notas.append("Parkland: 4 mL × kg × % SCQ; es punto de partida, se ajusta a la diuresis. Suele reservarse a quemaduras ≥ 20 % en adultos.")
    return r


NUEVE = Instrumento("nueve", "Regla de los nueve (quemados)", "% de la región afectada por quemaduras de 2.º grado o mayor (adulto).", tuple(
    Campo(c, f"{n} (vale {p} %)", "numero", minimo=0, maximo=100, unidad="% afectado", requerido=False) for c, n, p in REGIONES_NUEVE
) + (Campo("peso", "Peso (para Parkland)", "numero", minimo=20, maximo=300, unidad="kg", requerido=False),), _nueve)


# ------------------------------------------------------------------ Superficie corporal
def _bsa(v: dict) -> Resultado:
    p, t = v["peso"], v["talla"]
    mosteller = math.sqrt(p * t / 3600)
    dubois = 0.007184 * p ** 0.425 * t ** 0.725
    return Resultado(f"Superficie corporal {_n(mosteller, 2)} m² (Mosteller)", "info", [("Mosteller", f"{_n(mosteller, 2)} m²"), ("DuBois", f"{_n(dubois, 2)} m²")],
                     ["Para dosis por m² use la fórmula que defina el protocolo del tratamiento y verifique contra su guía."])


BSA = Instrumento("bsa", "Superficie corporal", "Mosteller y DuBois.", (
    Campo("peso", "Peso", "numero", minimo=2, maximo=400, unidad="kg"), Campo("talla", "Talla", "numero", minimo=40, maximo=250, unidad="cm")), _bsa)


# ------------------------------------------------------------------ Calculadora gestacional
def _gestacional(v: dict) -> Resultado:
    fum, ref = v["fum"], v["referencia"] or date.today()
    dias = (ref - fum).days
    if dias < 0:
        raise ValueError("La fecha de referencia no puede ser anterior a la FUM")
    if dias > 301:
        raise ValueError("Más de 43 semanas desde la FUM: revise las fechas")
    sem, d = divmod(dias, 7)
    fpp = fum + timedelta(days=280)
    tri = "Primer trimestre" if sem < 14 else "Segundo trimestre" if sem < 28 else "Tercer trimestre"
    faltan = (fpp - ref).days
    rest = f"faltan {faltan} días" if faltan > 0 else "es hoy" if faltan == 0 else f"superada hace {-faltan} días"
    return Resultado(f"Edad gestacional {sem} semanas + {d} días · {tri}", "info",
                     [("FUM", fum.isoformat()), ("Fecha de referencia", ref.isoformat()), ("Fecha probable de parto (Naegele)", f"{fpp.isoformat()} ({rest})")],
                     ["Regla de Naegele: FUM + 280 días (ciclos de 28 días). Si el ultrasonido temprano difiere, el médico decide la fecha de referencia."])


GESTACIONAL = Instrumento("gestacional", "Calculadora gestacional", "Edad gestacional y fecha probable de parto por FUM.", (
    Campo("fum", "Fecha de última menstruación (FUM)", "fecha"),
    Campo("referencia", "Calcular al día", "fecha", requerido=False, ayuda="Si lo deja vacío se usa hoy")), _gestacional)


# ------------------------------------------------------------------ Harris-Benedict (revisada) e IMC
FACTORES = _op(("1.2", "Sedentario (poco o nada de ejercicio)"), ("1.375", "Ligero (1-3 días por semana)"), ("1.55", "Moderado (3-5 días)"),
               ("1.725", "Intenso (6-7 días)"), ("1.9", "Muy intenso (doble sesión o trabajo físico)"))


def _harris(v: dict) -> Resultado:
    p, t, e = v["peso"], v["talla"], v["edad"]
    tmb = (88.362 + 13.397 * p + 4.799 * t - 5.677 * e) if v["sexo"] == "M" else (447.593 + 9.247 * p + 3.098 * t - 4.330 * e)
    get = tmb * float(v["actividad"])
    imc = p / (t / 100) ** 2
    cat = "Bajo peso" if imc < 18.5 else "Normopeso" if imc < 25 else "Sobrepeso" if imc < 30 else "Obesidad"
    return Resultado(f"Gasto energético total ≈ {get:,.0f} kcal/día", "info", [("Tasa metabólica basal", f"{tmb:,.0f} kcal/día"), ("Factor de actividad", v["actividad"]),
                                                                              ("IMC", f"{_n(imc, 1)} kg/m² · {cat} (OMS)")],
                     ["Ecuación de Harris-Benedict revisada (Roza y Shizgal, 1984), para adultos. Es una estimación; ajuste según la condición clínica."])


HARRIS = Instrumento("harris", "Harris-Benedict e IMC", "Gasto energético estimado del adulto.", (
    Campo("sexo", "Sexo", "opcion", SEXO), Campo("edad", "Edad", "entero", minimo=18, maximo=120, unidad="años"),
    Campo("peso", "Peso", "numero", minimo=20, maximo=400, unidad="kg"), Campo("talla", "Talla", "numero", minimo=100, maximo=250, unidad="cm"),
    Campo("actividad", "Actividad física", "opcion", FACTORES)), _harris)


# ------------------------------------------------------------------ Función renal
def _renal(v: dict) -> Resultado:
    e, p, cr, f = v["edad"], v["peso"], v["creatinina"], v["sexo"] == "F"
    cg = (140 - e) * p / (72 * cr) * (0.85 if f else 1)
    k, a = (0.7, -0.241) if f else (0.9, -0.302)
    ckd = 142 * min(cr / k, 1) ** a * max(cr / k, 1) ** -1.200 * 0.9938 ** e * (1.012 if f else 1)
    g = "G1" if ckd >= 90 else "G2" if ckd >= 60 else "G3a" if ckd >= 45 else "G3b" if ckd >= 30 else "G4" if ckd >= 15 else "G5"
    return Resultado(f"Filtrado estimado {_n(ckd, 0)} mL/min/1.73 m² (CKD-EPI 2021) · {g}", "alerta" if ckd < 30 else "info",
                     [("CKD-EPI 2021", f"{_n(ckd, 1)} mL/min/1.73 m²"), ("Cockcroft-Gault", f"{_n(cg, 1)} mL/min")],
                     ["Cockcroft-Gault usa peso real: en obesidad o desnutrición valore el peso ajustado. Úselo para ajustar dosis según la ficha del fármaco.",
                      "La estadificación G1-G5 requiere persistencia por más de 3 meses y considerar albuminuria."])


RENAL = Instrumento("renal", "Depuración de creatinina", "CKD-EPI 2021 y Cockcroft-Gault.", (
    Campo("sexo", "Sexo", "opcion", SEXO), Campo("edad", "Edad", "entero", minimo=18, maximo=120, unidad="años"),
    Campo("peso", "Peso", "numero", minimo=20, maximo=300, unidad="kg"), Campo("creatinina", "Creatinina sérica", "numero", minimo=0.2, maximo=20, unidad="mg/dL")), _renal)


# ------------------------------------------------------------------ HbA1c → glucosa media estimada
def _hba1c(v: dict) -> Resultado:
    a = v["hba1c"]
    mg = 28.7 * a - 46.7
    cat = "Normal (< 5.7 %)" if a < 5.7 else "Rango de prediabetes (5.7-6.4 %)" if a < 6.5 else "Rango diabético (≥ 6.5 %)"
    return Resultado(f"Glucosa media estimada {_n(mg, 0)} mg/dL", "info" if a < 6.5 else "alerta", [("HbA1c", f"{a:g} %"), ("Glucosa media estimada", f"{_n(mg, 0)} mg/dL ({_n(mg / 18.016, 1)} mmol/L)"),
                                                                                                 ("Categoría ADA", cat)],
                     ["Fórmula ADAG: 28.7 × HbA1c − 46.7. El diagnóstico exige confirmación según criterios vigentes; la HbA1c no es fiable en anemias o hemoglobinopatías."])


HBA1C = Instrumento("hba1c", "HbA1c y glucosa media", "Conversión a glucosa media estimada.", (Campo("hba1c", "HbA1c", "numero", minimo=3, maximo=20, unidad="%"),), _hba1c)


# ------------------------------------------------------------------ Morse
def _morse(v: dict) -> Resultado:
    total = sum(int(v[c]) for c in ("caidas", "secundario", "ayuda", "iv", "marcha", "mental"))
    cat, nivel = ("Riesgo bajo (0-24)", "ok") if total < 25 else ("Riesgo moderado (25-44)", "info") if total < 45 else ("Riesgo alto (≥ 45)", "alerta")
    return Resultado(f"Morse {total} · {cat}", nivel, [("Total", str(total))], ["Reevalúe al cambiar la condición del paciente, tras una caída o un traslado."])


MORSE = Instrumento("morse", "Escala de Morse (caídas)", "Riesgo de caída hospitalaria.", (
    Campo("caidas", "Antecedente de caídas (esta internación o en 3 meses)", "opcion", _op((0, "No · 0"), (25, "Sí · 25"))),
    Campo("secundario", "Diagnóstico secundario", "opcion", _op((0, "No · 0"), (15, "Sí · 15"))),
    Campo("ayuda", "Ayuda para deambular", "opcion", _op((0, "Ninguna, reposo en cama o ayuda de enfermería · 0"), (15, "Muletas, bastón o andador · 15"), (30, "Se apoya en los muebles · 30"))),
    Campo("iv", "Terapia intravenosa o catéter heparinizado", "opcion", _op((0, "No · 0"), (20, "Sí · 20"))),
    Campo("marcha", "Marcha", "opcion", _op((0, "Normal, en reposo o inmóvil · 0"), (10, "Débil · 10"), (20, "Alterada · 20"))),
    Campo("mental", "Estado mental", "opcion", _op((0, "Consciente de sus limitaciones · 0"), (15, "Olvida sus limitaciones · 15")))), _morse)


# ------------------------------------------------------------------ EVA
def _eva(v: dict) -> Resultado:
    n = v["eva"]
    cat, nivel = ("Sin dolor", "ok") if n == 0 else ("Dolor leve (1-3)", "ok") if n <= 3 else ("Dolor moderado (4-6)", "info") if n <= 6 else ("Dolor severo (7-10)", "alerta")
    return Resultado(f"EVA {n}/10 · {cat}", nivel, [("Valor", f"{n}/10")], ["Reevalúe tras cada intervención analgésica y anote la hora."])


EVA = Instrumento("eva", "Escala visual análoga del dolor", "0 = sin dolor, 10 = el peor dolor imaginable.", (Campo("eva", "Dolor referido", "entero", minimo=0, maximo=10, unidad="/10"),), _eva)


# ------------------------------------------------------------------ RASS
_RASS = {4: ("Combativo", "Violento, peligro inmediato para el personal"), 3: ("Muy agitado", "Se tira de tubos o catéteres, agresivo"),
         2: ("Agitado", "Movimientos frecuentes sin propósito, lucha con el ventilador"), 1: ("Inquieto", "Ansioso, sin movimientos agresivos"),
         0: ("Alerta y tranquilo", ""), -1: ("Somnoliento", "No completamente alerta; despierta a la voz (> 10 s)"),
         -2: ("Sedación ligera", "Despierta brevemente a la voz (< 10 s)"), -3: ("Sedación moderada", "Movimiento a la voz, sin contacto visual"),
         -4: ("Sedación profunda", "Sin respuesta a la voz; se mueve al estímulo físico"), -5: ("Sin respuesta", "Sin respuesta a la voz ni al estímulo físico")}


def _rass(v: dict) -> Resultado:
    n = int(v["rass"])
    nombre, desc = _RASS[n]
    return Resultado(f"RASS {n:+d} · {nombre}" if n else f"RASS 0 · {nombre}", "alerta" if abs(n) >= 3 else "info", [("Descripción", desc or "Sin agitación ni sedación")],
                     ["El objetivo de sedación lo define la indicación médica; registre el valor en cada evaluación."])


RASS = Instrumento("rass", "RASS (sedación y agitación)", "Richmond Agitation-Sedation Scale.", (
    Campo("rass", "Nivel observado", "opcion", tuple((str(k), f"{k:+d} · {n}" if k else f"0 · {n}") for k, (n, _d) in _RASS.items())),), _rass)


# ------------------------------------------------------------------ FIM
_FIM_NIVELES = _op((7, "7 · Independencia completa"), (6, "6 · Independencia modificada"), (5, "5 · Supervisión"), (4, "4 · Asistencia mínima"),
                   (3, "3 · Asistencia moderada"), (2, "2 · Asistencia máxima"), (1, "1 · Asistencia total"))
_FIM_MOTORES = (("Autocuidado", ("Alimentación", "Aseo personal", "Baño", "Vestido de la parte superior", "Vestido de la parte inferior", "Uso del retrete")),
                ("Control de esfínteres", ("Control de la vejiga", "Control del intestino")),
                ("Transferencias", ("Cama, silla y silla de ruedas", "Retrete", "Bañera o ducha")), ("Locomoción", ("Marcha o silla de ruedas", "Escaleras")))
_FIM_COGN = ("Comprensión", "Expresión", "Interacción social", "Resolución de problemas", "Memoria")


def _fim(v: dict) -> Resultado:
    motor = sum(int(v[f"m{i}"]) for i in range(1, 14))
    cogn = sum(int(v[f"c{i}"]) for i in range(1, 6))
    total = motor + cogn
    return Resultado(f"FIM total {total}/126", "info", [("Motora (13 ítems)", f"{motor}/91"), ("Cognitiva (5 ítems)", f"{cogn}/35"), ("Independencia funcional", f"{_n(total / 126 * 100, 0)} %")],
                     ["Compare con la medición al ingreso y al alta para medir la ganancia funcional."])


_fim_campos, _i = [], 0
for _g, _items in _FIM_MOTORES:
    for _t in _items:
        _i += 1
        _fim_campos.append(Campo(f"m{_i}", _t, "opcion", _FIM_NIVELES, grupo=_g))
_fim_campos += [Campo(f"c{i}", t, "opcion", _FIM_NIVELES, grupo="Cognición social") for i, t in enumerate(_FIM_COGN, 1)]
FIM = Instrumento("fim", "FIM (independencia funcional)", "18 ítems, 1 a 7 cada uno (18 a 126).", tuple(_fim_campos), _fim)


INSTRUMENTOS = (GLASGOW, PHQ9, CHILD_PUGH, DAS28, NUEVE, BSA, GESTACIONAL, HARRIS, RENAL, HBA1C, MORSE, EVA, RASS, FIM)
POR_CLAVE = {i.clave: i for i in INSTRUMENTOS}

# Ámbito laboral (clave de omega_core.roles_profesionales) → instrumentos de su widget.
ROLES: dict[str, tuple[str, ...]] = {
    "neurologo": ("glasgow",), "neurocirujano": ("glasgow",), "medico_de_urgencias": ("glasgow",), "intensivista_uci": ("glasgow", "rass"),
    "enfermero_de_uci": ("rass", "glasgow"), "endocrinologo": ("hba1c",), "gastroenterologo": ("child_pugh",), "nefrologo": ("renal",),
    "oncologo_medico": ("bsa",), "reumatologo": ("das28",), "geriatra": ("morse",), "psiquiatra": ("phq9",), "psicologo_clinico": ("phq9",),
    "fisiatra": ("fim",), "medico_paliativo": ("eva",), "cirujano_plastico": ("nueve",), "gineco_obstetra": ("gestacional",), "nutricionista": ("harris",),
}


def de_rol(clave_rol: str) -> tuple[Instrumento, ...]:
    return tuple(POR_CLAVE[c] for c in ROLES.get(clave_rol, ()))
