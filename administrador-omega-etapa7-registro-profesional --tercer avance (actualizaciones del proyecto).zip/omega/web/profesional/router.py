"""Portal profesional: panel por plantilla de rol y las 5 fases de la atención.

Solo presenta: las reglas (triaje, Código Rojo, bypass auditado, cierre solo por el médico responsable, expediente congelado)
son las de `core_expediente.maquina`, y la bitácora es la misma que la de la API. Lo único propio de este portal es qué
acciones muestra y permite cada plantilla de rol (`roles.py`), que además se vuelve a comprobar en cada POST.
"""
from collections import Counter
from datetime import date
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from pydantic import ValidationError
from sqlalchemy.orm import Session

from core_expediente import maquina, service
from core_expediente.constantes import NIVELES_TRIAJE, TIPOS_ATENCION, TIPOS_EGRESO
from core_expediente.deps import Profesional, profesional_de
from core_expediente.models import Atencion
from core_expediente.router_atenciones import _auditar_eventos, _registrar
from core_expediente.router_atenciones import detalle as _detalle
from core_expediente.router_atenciones import listar as _listar
from core_expediente.schemas import AbrirAtencionIn, EgresoIn, TransicionIn, TriajeIn
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.routers import personas
from omega_core.security.ratelimit import ip_cliente
from web.comun.ingreso import instalar_ingreso
from web.comun.portales import CIUDADANO, PROFESIONAL
from web.comun.sesion import Guardias, Sesion, csrf_de, requiere_area
from web.comun.vista import Vista

from . import alta, instrumentos, registros
from .roles import (
    ABRIR, ASUMIR, AVANZAR, CERRAR, CODIGO_ROJO, DIAGNOSTICAR, NOMBRES_FASE, NOTAR, SIGNOS, TRIAJE, Plantilla, plantilla_de,
)

PORTAL = PROFESIONAL
vista = Vista(PORTAL, Path(__file__).parent)
guardias = Guardias(PORTAL)
area = requiere_area(PORTAL)  # guardia de las páginas internas del portal
csrf = csrf_de(PORTAL)
router = APIRouter(prefix=PORTAL.base, include_in_schema=False)  # las páginas no aparecen en /docs (que documenta la API)
instalar_ingreso(router, PORTAL, vista, guardias)

# ------------------------------------------------------------------ Registro del profesional (sin sesión)
def _pagina_registro(request: Request, db: Session, status: int = 200, valores: dict | None = None, errores: dict | None = None):
    return vista.render(request, "registro.html", status=status, valores=valores or {}, errores=errores or {}, hoy=date.today().isoformat(), departamentos=alta.DEPARTAMENTOS,
                        tipos=alta.TIPOS, ambitos=alta.ambitos(), instituciones=alta.instituciones(db))


@router.get("/registro")
def pagina_registro(request: Request, sesion: Sesion | None = Depends(guardias.opcional), db: Session = Depends(get_db)):
    if sesion:
        return RedirectResponse(f"{PORTAL.base}/panel", status_code=303)
    return _pagina_registro(request, db)


@router.post("/registro")
def registrar(request: Request, campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    valores = alta.valores_de(campos)
    modelo, errores = alta.construir(valores, campos.get("password", ""), campos.get("password2", ""))
    if modelo is None:
        return _pagina_registro(request, db, 422, valores, errores)
    try:
        personas.registrar(modelo, request, db)  # mismo servicio que POST /personas: límite de intentos, duplicados y bitácora
    except HTTPException as e:
        return _pagina_registro(request, db, e.status_code, valores, {"general": e.detail})
    return RedirectResponse(f"{CIUDADANO.url_ingreso()}?registrado=1&tipo=profesional", status_code=303)


SOLO_ESTUDIANTE = "Su cuenta es de estudiante en práctica: su trabajo clínico va como borrador con cofirma de su tutor, no desde este tablero."


def _ctx(sesion: Sesion, db: Session) -> tuple[Plantilla | None, Profesional | None, str | None]:
    """(plantilla del rol, profesional habilitado para operar, motivo por el que no puede operar)."""
    pl = plantilla_de(sesion.sujeto)
    if pl is None:
        return None, None, SOLO_ESTUDIANTE
    try:
        return pl, profesional_de(sesion.sujeto, db), None
    except HTTPException as e:
        return pl, None, str(e.detail)


def _exigir(request: Request, sesion: Sesion, pl: Plantilla | None, prof: Profesional | None, accion: str) -> None:
    """Cada POST vuelve a comprobar la plantilla: ocultar un botón no es seguridad."""
    if pl is None or prof is None or not pl.permite(accion):
        auditar("WEB_AREA_DENEGADA", actor_tipo=sesion.tipo, actor_id=sesion.fila.sujeto_id, resultado="FALLO", ip=ip_cliente(request),
                detalle={"portal": PORTAL.slug, "ruta": request.url.path, "accion": accion})
        raise HTTPException(403, "Su plantilla de trabajo no permite esta acción")


def _mensaje(e: ValidationError) -> str:
    err = e.errors()[0]
    campo = ".".join(str(x) for x in err["loc"] if x != "egreso")
    texto = str(err["msg"]).removeprefix("Value error, ")
    return f"{campo}: {texto}" if campo else texto


def _tablero(prof: Profesional, db: Session) -> dict:
    atenciones = _listar(estado="ABIERTA", fase=None, limite=50, prof=prof, db=db)  # ya viene ordenado por prioridad de triaje
    return {"atenciones": atenciones, "por_fase": Counter(a.fase for a in atenciones), "rojos": sum(1 for a in atenciones if a.codigo_rojo)}


def _comunes() -> dict:
    return {"nombres": NOMBRES_FASE, "tipos_atencion": TIPOS_ATENCION, "niveles": NIVELES_TRIAJE, "tipos_egreso": TIPOS_EGRESO}


def _pagina_panel(request: Request, sesion: Sesion, db: Session, status: int = 200, **extra):
    pl, prof, aviso = _ctx(sesion, db)
    ctx = {"pl": pl, "operativo": prof is not None, "aviso": aviso, "valores": {}, **_comunes(), **extra}
    if prof is not None:
        ctx.update(_tablero(prof, db))
    return vista.render(request, "panel.html", sesion, status=status, **ctx)


@router.get("/panel")
def panel(request: Request, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    return _pagina_panel(request, sesion, db)


@router.get("/cuenta")
def cuenta(request: Request, sesion: Sesion = Depends(area)):
    return vista.render(request, "cuenta.html", sesion, pl=plantilla_de(sesion.sujeto))


@router.get("/tablero")
def tablero(request: Request, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    """Fragmento del tablero; el panel lo vuelve a pedir cada pocos segundos."""
    pl, prof, _ = _ctx(sesion, db)
    if pl is None or prof is None:
        raise HTTPException(403, "Acceso denegado")
    return vista.render(request, "_tablero.html", sesion, pl=pl, **_tablero(prof, db), **_comunes())


# ------------------------------------------------------------------ Abrir atención
@router.post("/atenciones")
def abrir(request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    pl, prof, _ = _ctx(sesion, db)
    rojo = campos.get("codigo_rojo") == "on"
    _exigir(request, sesion, pl, prof, ABRIR)
    if rojo:
        _exigir(request, sesion, pl, prof, CODIGO_ROJO)
    error, status = None, 422
    try:
        if "expediente:escribir" not in prof.persona.permisos:
            raise HTTPException(403, "Sin permiso para registrar atenciones")
        datos = AbrirAtencionIn(dui=(campos.get("dui") or "").strip(), tipo_atencion=campos.get("tipo_atencion", ""),
                                area=pl.area_fija or (campos.get("area") or "").strip(), motivo_consulta=(campos.get("motivo_consulta") or "").strip(),
                                codigo_rojo=rojo, motivo_codigo_rojo=(campos.get("motivo_codigo_rojo") or "").strip() or None)
        at, _pac, eventos = maquina.abrir_atencion(db, prof, datos)
        db.commit()
    except ValidationError as e:
        error = _mensaje(e)
    except HTTPException as e:
        db.rollback()
        error, status = str(e.detail), e.status_code
    else:
        _auditar_eventos(prof.persona, at, eventos, request)
        return RedirectResponse(f"{PORTAL.base}/atenciones/{at.id}", status_code=303)
    return _pagina_panel(request, sesion, db, status=status, error_abrir=error, valores=campos)


# ------------------------------------------------------------------ Una atención
def _vista_atencion(sesion: Sesion, db: Session, atencion_id):
    pl, prof, _ = _ctx(sesion, db)
    if pl is None or prof is None:
        raise HTTPException(403, "Acceso denegado")
    return pl, prof, _detalle(atencion_id, prof, db)


def _fragmento_acciones(request, sesion, db, atencion_id, status=200, cambio=False, **extra):
    pl, prof, a = _vista_atencion(sesion, db, atencion_id)
    resp = vista.render(request, "_acciones.html", sesion, status=status, pl=pl, a=a, es_doctor=prof.es_doctor,
                        es_responsable=a.medico_responsable_id == prof.persona.id, **_comunes(), **extra)
    if cambio:
        resp.headers["HX-Trigger"] = "fase-cambio"  # el estado y las acciones se refrescan al instante, sin esperar el sondeo
    return resp


@router.get("/atenciones/{atencion_id}")
def atencion(atencion_id: str, request: Request, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    pl, prof, a = _vista_atencion(sesion, db, _uuid(atencion_id))
    return vista.render(request, "atencion.html", sesion, pl=pl, a=a, es_doctor=prof.es_doctor, es_responsable=a.medico_responsable_id == prof.persona.id,
                        **_comunes(), **_contexto_clinico(request, db, prof, a))


@router.get("/atenciones/{atencion_id}/estado")
def estado(atencion_id: str, request: Request, fase: int | None = None, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    """Barra de fases + línea de tiempo. Si otra persona movió la atención (fase distinta de la que ve esta pantalla), avisa para refrescar las acciones."""
    pl, _prof, a = _vista_atencion(sesion, db, _uuid(atencion_id))
    resp = vista.render(request, "_estado.html", sesion, pl=pl, a=a, **_comunes())
    if fase is not None and fase != a.fase:
        resp.headers["HX-Trigger"] = "fase-cambio"
    return resp


@router.get("/atenciones/{atencion_id}/acciones")
def acciones(atencion_id: str, request: Request, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    return _fragmento_acciones(request, sesion, db, _uuid(atencion_id))


def _uuid(valor: str):
    import uuid
    try:
        return uuid.UUID(valor)
    except ValueError:
        raise HTTPException(404, "Atención no encontrada")


def _ejecutar(request, sesion, db, atencion_id, accion, operacion, ok: str):
    """Corre una operación de la máquina; errores de regla (409, 403, 423…) se muestran en el fragmento con su código."""
    pl, prof, _ = _ctx(sesion, db)
    _exigir(request, sesion, pl, prof, accion)
    try:
        at, eventos = operacion(prof)
        db.commit()
    except ValidationError as e:
        db.rollback()
        return _fragmento_acciones(request, sesion, db, atencion_id, status=422, error=_mensaje(e))
    except HTTPException as e:
        db.rollback()
        return _fragmento_acciones(request, sesion, db, atencion_id, status=e.status_code, error=str(e.detail))
    _auditar_eventos(prof.persona, at, eventos, request)
    return _fragmento_acciones(request, sesion, db, atencion_id, cambio=True, ok=ok)


@router.post("/atenciones/{atencion_id}/transicion")
def transicion(atencion_id: str, request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    aid = _uuid(atencion_id)
    try:
        a_fase = int(campos.get("a_fase", ""))
    except ValueError:
        raise HTTPException(422, "Fase de destino inválida")

    def operacion(prof):
        egreso = None
        if a_fase == 5:
            egreso = EgresoIn(tipo_egreso=campos.get("tipo_egreso", ""), condicion_egreso=(campos.get("condicion_egreso") or "").strip(),
                              resumen_egreso=(campos.get("resumen_egreso") or "").strip(), plan_seguimiento=(campos.get("plan_seguimiento") or "").strip())
        datos = TransicionIn(a_fase=a_fase, identidad_verificada=True if campos.get("identidad_verificada") == "on" else None,
                             antecedentes_revisados=True if campos.get("antecedentes_revisados") == "on" else None,
                             motivo=(campos.get("motivo") or "").strip() or None, egreso=egreso)
        return maquina.transicionar(db, prof, aid, datos)

    return _ejecutar(request, sesion, db, aid, CERRAR if a_fase == 5 else AVANZAR, operacion, "Atención cerrada." if a_fase == 5 else "Fase actualizada.")


@router.post("/atenciones/{atencion_id}/triaje")
def triaje(atencion_id: str, request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    aid = _uuid(atencion_id)
    nivel = campos.get("nivel", "")

    def operacion(prof):
        datos = TriajeIn(nivel=nivel, discriminador=(campos.get("discriminador") or "").strip(), motivo=(campos.get("motivo") or "").strip() or None)
        return maquina.registrar_triaje(db, prof, aid, datos)

    return _ejecutar(request, sesion, db, aid, CODIGO_ROJO if nivel == "ROJO" else TRIAJE, operacion, "Triaje registrado.")


@router.post("/atenciones/{atencion_id}/asumir")
def asumir(atencion_id: str, request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    aid = _uuid(atencion_id)
    return _ejecutar(request, sesion, db, aid, ASUMIR, lambda prof: maquina.asumir(db, prof, aid), "Usted asumió la atención.")


# ------------------------------------------------------------------ Registro clínico: notas SOAP, diagnósticos y signos vitales
def _contexto_clinico(request: Request, db: Session, prof: Profesional, a, justificacion: str | None = None, corregir: str | None = None,
                      valores: dict | None = None, seccion_error: str | None = None) -> dict:
    """Contexto del fragmento «Registro clínico». Los errores de acceso (429, justificación corta) se muestran dentro del fragmento."""
    at = db.get(Atencion, a.id)
    aviso = None
    try:
        r = registros.leer(db, prof, at, justificacion, ip_cliente(request))
    except HTTPException as e:
        r, aviso = {"sin_acceso": True, "bloqueado": True}, str(e.detail)
    vals, corrige = registros.formularios(r, registros.uuid_o_none(corregir), valores, seccion_error)
    return {"r": r, "aviso_clinico": aviso, "justificacion": justificacion or "", "valores": vals, "corrige": corrige, "fases_registro": registros.FASES_REGISTRO,
            "tipos_dx": registros.TIPOS, "estatus_dx": registros.ESTATUS, "campo_error": seccion_error}


def _fragmento_clinico(request, sesion, db, atencion_id, status=200, justificacion=None, corregir=None, valores=None, seccion_error=None, **extra):
    pl, prof, a = _vista_atencion(sesion, db, atencion_id)
    ctx = _contexto_clinico(request, db, prof, a, justificacion, corregir, valores, seccion_error)
    return vista.render(request, "_clinico.html", sesion, status=status, pl=pl, a=a, es_doctor=prof.es_doctor,
                        es_responsable=a.medico_responsable_id == prof.persona.id, **ctx, **extra)


@router.get("/atenciones/{atencion_id}/clinico")
def clinico(atencion_id: str, request: Request, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    return _fragmento_clinico(request, sesion, db, _uuid(atencion_id))


@router.post("/atenciones/{atencion_id}/clinico/ver")
def clinico_ver(atencion_id: str, request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    """Abre el contenido de nivel 4 (con justificación, auditada) y/o precarga una versión para corregirla. No guarda nada."""
    return _fragmento_clinico(request, sesion, db, _uuid(atencion_id), justificacion=(campos.get("justificacion") or "").strip() or None,
                              corregir=campos.get("corregir"))


def _registrar_web(request, sesion, db, atencion_id, accion, seccion, armar, creador, solo_doctor, ok: str, campos: dict):
    """Un POST de registro: comprueba la plantilla, arma el esquema de la API y lo guarda con la misma función que la API."""
    aid = _uuid(atencion_id)
    pl, prof, _ = _ctx(sesion, db)
    _exigir(request, sesion, pl, prof, accion)
    try:
        datos = armar(campos)
        _registrar(db, prof, aid, request, seccion, datos, creador, solo_doctor, registros.FASES_REGISTRO[seccion])
    except ValidationError as e:
        db.rollback()
        return _fragmento_clinico(request, sesion, db, aid, status=422, error=registros.mensaje_error(e), valores=campos, seccion_error=seccion)
    except HTTPException as e:
        db.rollback()
        return _fragmento_clinico(request, sesion, db, aid, status=e.status_code, error=str(e.detail), valores=campos, seccion_error=seccion)
    return _fragmento_clinico(request, sesion, db, aid, ok=ok)


@router.post("/atenciones/{atencion_id}/notas")
def nota_soap(atencion_id: str, request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    return _registrar_web(request, sesion, db, atencion_id, NOTAR, "notas", registros.nota_desde, service.crear_nota, True,
                          "Corrección de la nota registrada." if campos.get("reemplaza_id") else "Nota SOAP registrada.", campos)


@router.post("/atenciones/{atencion_id}/diagnosticos")
def diagnostico(atencion_id: str, request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    return _registrar_web(request, sesion, db, atencion_id, DIAGNOSTICAR, "diagnosticos", registros.diagnostico_desde, service.crear_diagnostico, True,
                          "Corrección del diagnóstico registrada." if campos.get("reemplaza_id") else "Diagnóstico registrado.", campos)


@router.post("/atenciones/{atencion_id}/signos-vitales")
def signos_vitales(atencion_id: str, request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    return _registrar_web(request, sesion, db, atencion_id, SIGNOS, "signos_vitales", registros.signos_desde, service.crear_signos, False,
                          "Corrección de los signos registrada." if campos.get("reemplaza_id") else "Signos vitales registrados.", campos)


# ------------------------------------------------------------------ Instrumentos de los widgets (calculadoras y escalas, sin estado)
@router.post("/instrumentos/{clave}")
def instrumento(clave: str, request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf)):
    """Calcula con los valores del formulario. No lee ni guarda datos de pacientes; solo el instrumento del widget de SU rol."""
    pl = plantilla_de(sesion.sujeto)
    inst = instrumentos.POR_CLAVE.get(clave)
    if pl is None or inst is None or inst not in pl.instrumentos:
        auditar("WEB_AREA_DENEGADA", actor_tipo=sesion.tipo, actor_id=sesion.fila.sujeto_id, resultado="FALLO", ip=ip_cliente(request),
                detalle={"portal": PORTAL.slug, "ruta": request.url.path, "accion": "instrumento"})
        raise HTTPException(403, "Este instrumento no corresponde a su plantilla de trabajo")
    try:
        resultado = inst.calcular(instrumentos.validar(inst, campos))
    except ValueError as e:
        return vista.render(request, "_instrumento_resultado.html", sesion, status=422, error=str(e))
    return vista.render(request, "_instrumento_resultado.html", sesion, r=resultado)
