"""Registro web del profesional de salud (Doctor / Enfermera).

Igual que el registro de personas del portal ciudadano, esto solo convierte un formulario en el esquema de la API
(`PersonaRegistro` con su `profesional` anidado) y guarda con el mismo servicio (`omega_core.routers.personas.registrar`):
validación de DUI, correo, teléfono y contraseña, límite de intentos por IP, duplicados (DUI, correo, número de junta) y bitácora
(`PERSONA_REGISTRADA`) son los de la API. El perfil nace `verificado=false`: Omega confirma la JVPM/JVPE después, y hasta entonces
el profesional puede ingresar pero no operar en expedientes (`core_expediente.deps.profesional_de`).
"""
from collections import defaultdict

from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session

from omega_core.constantes import TIPOS_PROFESIONAL
from omega_core.models import Institucion
from omega_core.roles_profesionales import ROLES
from omega_core.schemas import PersonaRegistro

from .roles import LAYOUTS

DEPARTAMENTOS = ["Ahuachapán", "Santa Ana", "Sonsonate", "Chalatenango", "La Libertad", "San Salvador", "Cuscatlán", "La Paz", "Cabañas", "San Vicente", "Usulután", "San Miguel", "Morazán", "La Unión"]
CAMPOS_PERSONA = ("dui", "nombres", "apellidos", "fecha_nacimiento", "sexo", "correo", "telefono", "departamento", "municipio")
CAMPOS_PROFESIONAL = ("tipo", "rol_clave", "especialidad", "numero_junta", "institucion_id")
CAMPOS = CAMPOS_PERSONA + CAMPOS_PROFESIONAL
ETIQUETA_TIPO = {"DOCTOR": "Doctor / Doctora", "ENFERMERA": "Enfermero / Enfermera"}
TIPOS = [(t, ETIQUETA_TIPO[t]) for t in TIPOS_PROFESIONAL]

# Mensajes de la validación cruzada del esquema, dichos para quien rellena el formulario.
_MENSAJES = {
    "rol_clave no corresponde al tipo de profesional (enfermería ↔ roles de enfermería)": "El ámbito laboral no corresponde al tipo de profesional: enfermería solo admite ámbitos de enfermería y viceversa.",
    "rol_clave no es uno de los 65 ámbitos laborales": "Elija un ámbito laboral de la lista.",
}


def ambitos() -> list[tuple[str, list[tuple[str, str]]]]:
    """Los 65 ámbitos laborales agrupados por plantilla de trabajo, para el selector."""
    grupos: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for r in ROLES:
        grupos[LAYOUTS[r.layout].nombre].append((r.clave, r.nombre))
    return list(grupos.items())


def instituciones(db: Session) -> list[tuple[str, str]]:
    """Lugares de trabajo posibles: hospitales, clínicas, farmacias y laboratorios activos (la universidad no es lugar de trabajo clínico)."""
    filas = db.execute(select(Institucion.id, Institucion.nombre_legal, Institucion.tipo)
                       .where(Institucion.estado == "ACTIVA", Institucion.tipo != "UNIVERSIDAD").order_by(Institucion.nombre_legal))
    return [(str(i), f"{nombre} ({tipo.capitalize()})") for i, nombre, tipo in filas]


def valores_de(campos: dict) -> dict:
    return {k: campos.get(k, "").strip() for k in CAMPOS}


def construir(valores: dict, password: str, password2: str) -> tuple[PersonaRegistro | None, dict]:
    """(modelo, {}) si todo es válido; (None, errores por campo) si no. Las reglas son las de omega_core.schemas; aquí solo se muestran."""
    errores: dict[str, str] = {}
    if password != password2:
        errores["password2"] = "Las contraseñas no coinciden."
    if not valores["tipo"]:
        errores["tipo"] = "Indique si es doctor o enfermero."
    if not valores["rol_clave"]:
        errores["rol_clave"] = "Elija su ámbito laboral."
    if errores.keys() & {"tipo", "rol_clave"}:  # sin esto el esquema respondería con mensajes técnicos
        return None, errores | _validar_resto(valores, password)
    datos = {k: (valores[k] or None) for k in CAMPOS_PERSONA} | {"password": password}
    datos["profesional"] = {k: (valores[k] or None) for k in CAMPOS_PROFESIONAL}
    try:
        modelo = PersonaRegistro(**datos)
    except ValidationError as e:
        for err in e.errors():
            loc = [str(x) for x in err["loc"]]
            if loc[:1] == ["profesional"]:
                campo = loc[1] if len(loc) > 1 else "rol_clave"  # la validación cruzada tipo ↔ ámbito no trae campo propio
            else:
                campo = loc[0] if loc else "general"
            texto = str(err["msg"]).removeprefix("Value error, ")
            errores.setdefault(campo, _MENSAJES.get(texto, texto))
        return None, errores
    return (None, errores) if errores else (modelo, {})


def _validar_resto(valores: dict, password: str) -> dict:
    """Cuando faltan tipo o ámbito, igual se validan los datos personales para mostrar todos los errores de una vez."""
    try:
        PersonaRegistro(**({k: (valores[k] or None) for k in CAMPOS_PERSONA} | {"password": password}))
    except ValidationError as e:
        return {(str(err["loc"][0]) if err["loc"] else "general"): str(err["msg"]).removeprefix("Value error, ") for err in reversed(e.errors())}
    return {}
