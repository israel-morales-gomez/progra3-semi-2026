"""Registro clínico de una atención desde la web: notas SOAP, diagnósticos CIE-10 y signos vitales.

Solo presenta. Las reglas (fases 3-4 para nota y diagnóstico, solo médicos, un único principal vigente, nivel 4 automático,
versionado con `reemplaza_id`, corrector solo autor o médico responsable, expediente congelado) son las de
`core_expediente.service`, las mismas que usa la API; la bitácora también (`REGISTRO_CLINICO`, `ACCESO_EXPEDIENTE`).
Este módulo solo convierte formularios en los esquemas de la API y lee los registros de UNA atención.
"""
import uuid
from typing import Any

from pydantic import ValidationError
from sqlalchemy import exists, select
from sqlalchemy.orm import Session, aliased

from core_expediente import service
from core_expediente.constantes import ESTATUS_DIAGNOSTICO, NIVEL_ULTRA, TIPOS_DIAGNOSTICO
from core_expediente.deps import Profesional
from core_expediente.models import Atencion
from core_expediente.schemas import DiagnosticoIn, NotaSoapIn, SignosVitalesIn
from core_expediente.service import MODELOS, PLANOS
from omega_core.security.campos import descifrar_json

SECCIONES = ("signos_vitales", "notas", "diagnosticos")
FASES_REGISTRO = {"signos_vitales": (1, 2, 3, 4), "notas": (3, 4), "diagnosticos": (3, 4)}
ESTATUS = ESTATUS_DIAGNOSTICO
TIPOS = TIPOS_DIAGNOSTICO
CAMPOS_SIGNOS = ("ta_sistolica", "ta_diastolica", "fc", "fr", "temperatura", "spo2", "glucemia", "peso_kg", "talla_cm", "dolor_eva")


# ------------------------------------------------------------------ Formulario → esquema de la API
def _texto(campos: dict, nombre: str) -> str:
    return (campos.get(nombre) or "").strip()


def _version(campos: dict) -> dict:
    return {"reemplaza_id": _texto(campos, "reemplaza_id") or None, "motivo_correccion": _texto(campos, "motivo_correccion") or None}


def nota_desde(campos: dict) -> NotaSoapIn:
    return NotaSoapIn(subjetivo=_texto(campos, "subjetivo"), objetivo=_texto(campos, "objetivo"), analisis=_texto(campos, "analisis"),
                      plan=_texto(campos, "plan"), confidencial=campos.get("confidencial") == "on", **_version(campos))


def diagnostico_desde(campos: dict) -> DiagnosticoIn:
    return DiagnosticoIn(codigo_cie10=_texto(campos, "codigo_cie10"), descripcion=_texto(campos, "descripcion"),
                         observaciones=_texto(campos, "observaciones") or None, tipo=_texto(campos, "tipo"),
                         estatus=_texto(campos, "estatus") or "ACTIVA", principal=campos.get("principal") == "on",
                         confidencial=campos.get("confidencial") == "on", **_version(campos))


def signos_desde(campos: dict) -> SignosVitalesIn:
    medidas = {c: _texto(campos, c).replace(",", ".") for c in CAMPOS_SIGNOS if _texto(campos, c)}
    return SignosVitalesIn(**medidas, **_version(campos))


def mensaje_error(e: ValidationError) -> str:
    err = e.errors()[0]
    campo = ".".join(str(x) for x in err["loc"])
    texto = str(err["msg"]).removeprefix("Value error, ")
    return f"{campo}: {texto}" if campo else texto


# ------------------------------------------------------------------ Lectura de lo registrado en esta atención
def _vigentes(db: Session, seccion: str, at: Atencion, abrir4: bool, prof: Profesional):
    """Versiones vigentes de la sección en ESTA atención (el nivel 4 sale restringido salvo que se haya abierto con justificación)."""
    M = MODELOS[seccion]
    hijo = aliased(M)
    filas = db.scalars(select(M).where(M.atencion_id == at.id, ~exists().where(hijo.reemplaza_id == M.id)).order_by(M.creado_en.desc())).all()
    items, abiertos4 = [], 0
    for f in filas:
        n4 = f.nivel_sensibilidad >= NIVEL_ULTRA
        item: dict[str, Any] = {"id": str(f.id), "creado_en": f.creado_en, "n4": n4, "restringido": n4 and not abrir4,
                                "es_correccion": f.reemplaza_id is not None, "motivo_correccion": f.motivo_correccion, "datos": None,
                                "principal": getattr(f, "principal", False),
                                "puede_corregir": prof.persona.id in (f.registrado_por, at.medico_responsable_id)}
        if not item["restringido"]:
            datos = {c: getattr(f, c) for c in PLANOS[seccion]}
            if n4:
                datos.update(descifrar_json(f.contenido_cifrado))
                abiertos4 += 1
            item["datos"] = datos
        items.append(item)
    return items, abiertos4


def leer(db: Session, prof: Profesional, at: Atencion, justificacion: str | None, ip: str) -> dict:
    """Notas, diagnósticos y signos de la atención, con el mismo control de acceso que la API (atención abierta o consentimiento).

    Devuelve {"sin_acceso": True} cuando la vía de lectura ya no existe (p. ej. atención cerrada y sin consentimiento del paciente).
    """
    service._limitar_lecturas(prof.persona.id)  # 429 igual que la API
    acceso = service.resolver_acceso(db, prof.persona.id, prof.institucion_id, at.paciente_id)
    if acceso is None:
        return {"sin_acceso": True}
    just = service.validar_justificacion(justificacion)
    abrir4 = acceso.puede_nivel4 and bool(just)
    r: dict[str, Any] = {"sin_acceso": False, "puede_nivel4": acceso.puede_nivel4}
    abiertos = 0
    for s in SECCIONES:
        r[s], ab = _vigentes(db, s, at, abrir4, prof)
        abiertos += ab
    restringidos = sum(1 for s in SECCIONES for i in r[s] if i["restringido"])
    r["restringidos"] = restringidos
    r["tiene_nota"] = bool(r["notas"])
    r["tiene_principal"] = any(i["principal"] for i in r["diagnosticos"])
    service.auditar_lectura(prof.persona.id, at.paciente_id, acceso, "atencion_registros", sum(len(r[s]) for s in SECCIONES), restringidos,
                            abiertos, just, False, ip)
    return r


def _valores_de(item: dict) -> dict:
    return {k: ("" if v is None else v) for k, v in (item["datos"] or {}).items()}


def formularios(r: dict, corregir: str | None, valores: dict | None, seccion_error: str | None) -> tuple[dict, dict]:
    """(valores de cada formulario, id que cada uno corrige). Tras un error se conserva lo escrito; al corregir se precarga la versión vigente."""
    vals: dict[str, dict] = {s: {} for s in SECCIONES}
    corrige: dict[str, str | None] = {s: None for s in SECCIONES}
    if seccion_error in vals:
        vals[seccion_error] = valores or {}
        corrige[seccion_error] = (valores or {}).get("reemplaza_id") or None
    elif corregir and not r.get("sin_acceso"):
        for s in SECCIONES:
            for item in r[s]:
                if item["id"] == corregir and not item["restringido"] and item["puede_corregir"]:
                    vals[s], corrige[s] = _valores_de(item), corregir
    return vals, corrige


def uuid_o_none(valor: str | None) -> str | None:
    try:
        return str(uuid.UUID(valor)) if valor else None
    except ValueError:
        return None
