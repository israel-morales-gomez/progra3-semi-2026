"""Plantilla de trabajo de cada cuenta profesional: qué rol (de los 65) tiene y qué puede hacer según su layout.

Los datos de los roles (layout, widget, fases dominantes, qué envía y recibe) son los del documento y viven en
`omega_core.roles_profesionales`. Aquí solo se decide la presentación y los permisos de la plantilla. La máquina de
estados y sus reglas (triaje, Código Rojo, cierre solo por el médico responsable) siguen siendo las de `core_expediente`.
"""
from dataclasses import dataclass

from core_expediente.constantes import normalizar_texto
from omega_core.models import Persona
from omega_core.roles_profesionales import ALIAS_ESPECIALIDAD, POR_CLAVE, Rol

from . import instrumentos

# Acciones que una plantilla puede ejecutar sobre una atención.
ABRIR, TRIAJE, ASUMIR, AVANZAR, CERRAR, CODIGO_ROJO = "abrir", "triaje", "asumir", "avanzar", "cerrar", "codigo_rojo"
# Registro clínico: la nota SOAP y el diagnóstico los firma un médico (la API lo exige también); los signos vitales los toma también enfermería.
NOTAR, DIAGNOSTICAR, SIGNOS = "notar", "diagnosticar", "signos"
# El Código Rojo es un bypass de emergencia que puede surgir en cualquier área (p. ej. sufrimiento fetal en obstetricia): lo tienen todas las plantillas operativas.
OPERATIVO = frozenset({ABRIR, TRIAJE, ASUMIR, AVANZAR, CERRAR, CODIGO_ROJO, NOTAR, DIAGNOSTICAR, SIGNOS})
NOMBRES_FASE = {1: "Admisión", 2: "Preparación y Validación", 3: "Ejecución Táctica", 4: "Trazabilidad", 5: "Cierre"}
# Salud mental es nivel 4 (cifrado de campo): el área de estos roles no se deja a la libre escritura para que el contenido siempre se cifre.
AREA_FIJA = {"psiquiatra": "Psiquiatría", "psicologo_clinico": "Psicología"}


@dataclass(frozen=True)
class Layout:
    clave: str
    nombre: str
    acciones: frozenset
    tipo_atencion: str  # valor por defecto al abrir una atención
    foco: tuple[int, ...] = ()  # fases que la plantilla destaca en el tablero


LAYOUTS = {
    "clinico_general": Layout("clinico_general", "Clínico General", OPERATIVO, "AMBULATORIA"),
    "urgencias": Layout("urgencias", "Urgencias / Trauma", OPERATIVO, "URGENCIAS", (1, 2, 3)),
    "quirurgico": Layout("quirurgico", "Quirúrgico", OPERATIVO, "HOSPITALIZACION", (2, 3)),
    # Enfermería: ingesta y trazabilidad. El cierre sigue siendo del médico responsable (la máquina lo exige).
    "apoyo_enfermeria": Layout("apoyo_enfermeria", "Apoyo / Enfermería", frozenset({ABRIR, TRIAJE, AVANZAR, CODIGO_ROJO, SIGNOS}), "AMBULATORIA", (1, 4)),
    # Laboratorio/imagen y gerencia: consultan el tablero; sus datos entran por sus propios portales y por la auditoría.
    "apoyo_lis": Layout("apoyo_lis", "Apoyo y LIS", frozenset(), "AMBULATORIA", (3, 4)),
    "apoyo_gerencial": Layout("apoyo_gerencial", "Apoyo / Gerencial", frozenset(), "AMBULATORIA", (4, 5)),
}


@dataclass(frozen=True)
class Plantilla:
    rol: Rol
    layout: Layout
    acciones: frozenset
    inferido: bool  # el perfil no trae rol_clave: se dedujo de la especialidad o del tipo

    def permite(self, accion: str) -> bool:
        return accion in self.acciones

    @property
    def instrumentos(self) -> tuple:
        """Instrumentos funcionales del widget de este rol (calculadoras y escalas); vacío si su widget aún no los tiene."""
        return instrumentos.de_rol(self.rol.clave)

    @property
    def area_fija(self) -> str | None:
        return AREA_FIJA.get(self.rol.clave)

    @property
    def area_defecto(self) -> str:
        return self.area_fija or self.rol.nombre

    @property
    def archivo(self) -> str:
        return f"layouts/{self.layout.clave}.html"

    @property
    def foco(self) -> tuple[int, ...]:
        return tuple(sorted(set(self.layout.foco) | set(self.rol.fases)))


def _armar(rol: Rol, inferido: bool) -> Plantilla:
    layout = LAYOUTS[rol.layout]
    acciones = set(layout.acciones)
    if rol.layout_alt:  # los 2 roles híbridos del documento (39 y 60) suman las acciones de ambos layouts
        acciones |= LAYOUTS[rol.layout_alt].acciones
    return Plantilla(rol, layout, frozenset(acciones), inferido)


def plantilla_de(persona: Persona) -> Plantilla | None:
    """Plantilla de una persona con perfil profesional; None si solo es estudiante (su flujo es borrador y cofirma)."""
    pf = persona.profesional
    if pf is None or not pf.activo:
        return None
    if pf.rol_clave in POR_CLAVE:
        return _armar(POR_CLAVE[pf.rol_clave], False)
    clave = ALIAS_ESPECIALIDAD.get(normalizar_texto(pf.especialidad or ""))
    if clave:
        return _armar(POR_CLAVE[clave], True)
    return _armar(POR_CLAVE["enfermero_general" if pf.tipo == "ENFERMERA" else "medico_internista"], True)
