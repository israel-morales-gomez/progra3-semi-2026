"""Frontend (Etapa 7): siete portales separados sobre los servicios de omega_core. Sin lógica de negocio propia."""
