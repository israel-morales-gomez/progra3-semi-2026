"""Servicios del portal ciudadano: citas paso a paso, directorio de centros, asistente virtual, búsqueda de farmacias, estado vital y datos civiles.
No tiene reglas propias: presenta y llama a las mismas funciones de portal_civil que usa la API (router_citas, router_directorio, router_chatbot),
así que heredan sus validaciones, sus límites y su bitácora. La persona sale SIEMPRE de la sesión: ninguna ruta ni formulario recibe un DUI o un id de paciente.
El recorrido de citas vive en la URL (GET con parámetros): funciona sin JavaScript y cada paso se puede volver a abrir."""
import uuid
from datetime import date, datetime, time
from urllib.parse import parse_qsl, urlencode, urlsplit

from fastapi import Depends, HTTPException, Query, Request
from fastapi.responses import RedirectResponse
from pydantic import ValidationError
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from core_expediente import service as servicio_vital
from core_expediente.schemas import EstadoVitalOut
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.database import get_db
from omega_core.models import Institucion, Persona
from omega_core.security.ratelimit import ip_cliente
from portal_civil import router_chatbot, router_citas, router_directorio
from portal_civil.schemas_citas import CancelarIn, CitaIn, MensajeIn, ReprogramarIn
from web.comun.sesion import Sesion

from .router import PORTAL, POR_PAGINA, SV, _desbloqueo, area, csrf, router, vista

SECTORES = {"PUBLICO": "Público", "PRIVADO": "Privado"}
REDES = {"PUBLICA": "Red pública", "POLIZA_PRIVADA": "Póliza privada"}
RED_CENTRO = {"PUBLICA": "Red pública", "POLIZA_PRIVADA": "Póliza privada", "AMBAS": "Red pública y póliza privada"}
TIPOS_CENTRO = {"HOSPITAL": "Hospital", "CLINICA": "Clínica"}
AVISOS_CITA = {"reservada": "Su cita quedó reservada.", "cancelada": "La cita se canceló y el horario quedó libre.", "reprogramada": "Su cita se reprogramó."}


def _uuid(v) -> uuid.UUID | None:
    try:
        return uuid.UUID(str(v))
    except (ValueError, TypeError):
        return None


def _fecha(v) -> date | None:
    try:
        return date.fromisoformat(str(v))
    except (ValueError, TypeError):
        return None


def _hora(v) -> time | None:
    try:
        return time.fromisoformat(str(v)).replace(second=0, microsecond=0)
    except (ValueError, TypeError):
        return None


def _consulta(**kw) -> str:
    return urlencode({k: (v.isoformat() if hasattr(v, "isoformat") else v) for k, v in kw.items() if v not in (None, "")})


def _url(ruta: str, **kw) -> str:
    q = _consulta(**kw)
    return f"{PORTAL.base}{ruta}" + (f"?{q}" if q else "")


# ================================================================== Citas: recorrido Especialidad > Centro > Doctor > Fecha > Hora
def _recorrido(db: Session, persona: Persona, p: dict) -> dict:
    """Calcula en qué paso está el ciudadano según los parámetros de la URL y trae las opciones de ese paso de la API (nunca se calculan en la plantilla)."""
    sector = p.get("sector") if p.get("sector") in SECTORES else None
    red = p.get("red_seguros") if p.get("red_seguros") in REDES else None
    esp = (p.get("especialidad") or "").strip()[:120] or None
    inst, med, dia, hora = _uuid(p.get("institucion_id")), _uuid(p.get("medico_id")), _fecha(p.get("fecha")), _hora(p.get("hora"))
    ctx = {"sector": sector, "red_seguros": red, "sectores": SECTORES, "redes": REDES, "elegido": [], "opciones": [], "paso": "especialidad", "error": None,
           "confirmar": None, "titulo_paso": "", "vacio": ""}
    m = None
    if med:
        try:
            m = router_citas._medico_reservable(db, med)  # noqa: SLF001 (misma regla que la API: doctor verificado y activo)
        except HTTPException as e:
            ctx["error"], med, dia, hora = str(e.detail), None, None, None
    if m:
        esp, inst = m.especialidad, m.institucion_id
    nombre_centro = (m.centro if m else db.scalar(select(Institucion.nombre_legal).where(Institucion.id == inst))) if inst else None
    if inst and not nombre_centro:
        inst = None
    ctx["esp"], ctx["inst"] = esp, inst

    # lo ya elegido, cada uno con el enlace que vuelve a ese paso (descarta lo posterior)
    filtros = {"sector": sector, "red_seguros": red}
    if esp:
        ctx["elegido"].append({"rotulo": "Especialidad", "valor": esp, "url": _url("/citas", **filtros)})
    if inst and esp:
        ctx["elegido"].append({"rotulo": "Centro", "valor": nombre_centro, "url": _url("/citas", especialidad=esp, **filtros)})
    if m:
        ctx["elegido"].append({"rotulo": "Doctor", "valor": f"{m.nombres} {m.apellidos}", "url": _url("/citas", especialidad=esp, institucion_id=inst, **filtros)})
    if m and dia:
        ctx["elegido"].append({"rotulo": "Fecha", "valor": f"{dia:%d/%m/%Y}", "url": _url("/citas", medico_id=med)})

    if m and dia and hora:
        libres = router_citas.horas(medico_id=med, fecha=dia, persona=persona, db=db).horas
        if hora in libres:
            ctx.update(paso="confirmar", titulo_paso="Confirme su cita",
                       confirmar={"medico_id": str(med), "fecha": dia.isoformat(), "hora": f"{hora:%H:%M}", "doctor": f"{m.nombres} {m.apellidos}", "especialidad": m.especialidad,
                                  "centro": m.centro, "fecha_texto": f"{dia:%d/%m/%Y}", "hora_texto": f"{hora:%H:%M}"})
            ctx["elegido"].append({"rotulo": "Hora", "valor": f"{hora:%H:%M}", "url": _url("/citas", medico_id=med, fecha=dia)})
            return ctx
        ctx["error"], hora = "Ese horario ya no está libre. Elija otro.", None
    if m and dia:
        libres = router_citas.horas(medico_id=med, fecha=dia, persona=persona, db=db).horas
        ctx.update(paso="hora", titulo_paso="Elija la hora", vacio="Ya no quedan horarios libres ese día.",
                   opciones=[{"etiqueta": f"{h:%H:%M}", "detalle": "", "url": _url("/citas", medico_id=med, fecha=dia, hora=h)} for h in libres])
    elif m:
        fechas = router_citas.fechas(medico_id=med, persona=persona, db=db).fechas
        ctx.update(paso="fecha", titulo_paso="Elija la fecha", vacio="Este doctor no tiene horarios libres en los próximos días.",
                   opciones=[{"etiqueta": f"{d:%d/%m/%Y}", "detalle": "", "url": _url("/citas", medico_id=med, fecha=d)} for d in fechas])
    elif esp and inst:
        docs = router_citas.doctores(especialidad=esp, institucion_id=inst, sector=sector, red_seguros=red, persona=persona, db=db)
        ctx.update(paso="doctor", titulo_paso="Elija el doctor", vacio="No hay doctores disponibles con esos filtros.",
                   opciones=[{"etiqueta": d.nombre, "detalle": d.centro, "url": _url("/citas", medico_id=d.medico_id)} for d in docs])
    elif esp:
        centros = router_citas.centros(especialidad=esp, sector=sector, red_seguros=red, persona=persona, db=db)
        ctx.update(paso="centro", titulo_paso="Elija el centro médico", vacio="Ningún centro atiende esa especialidad con esos filtros.",
                   opciones=[{"etiqueta": c.nombre,
                              "detalle": " · ".join(x for x in (", ".join(y for y in (c.municipio, c.departamento) if y), SECTORES.get(c.sector or ""), REDES.get(c.red_seguros or ""),
                                                                 f"{c.medicos} {'doctor' if c.medicos == 1 else 'doctores'}") if x),
                              "url": _url("/citas", especialidad=esp, institucion_id=c.institucion_id, **filtros)} for c in centros])
    elif inst:  # llegó desde el directorio con el centro ya elegido: solo las especialidades de ese centro
        sub = router_citas._medicos_q(institucion_id=inst, sector=sector, red_seguros=red).subquery()  # noqa: SLF001
        filas = db.execute(select(sub.c.especialidad, func.count()).group_by(sub.c.especialidad).order_by(sub.c.especialidad)).all()
        ctx["elegido"].append({"rotulo": "Centro", "valor": nombre_centro, "url": _url("/citas", **filtros)})
        ctx.update(paso="especialidad", titulo_paso=f"Elija la especialidad en {nombre_centro}", vacio="Este centro no tiene doctores con horarios abiertos por ahora.",
                   opciones=[{"etiqueta": e, "detalle": f"{n} {'doctor' if n == 1 else 'doctores'}", "url": _url("/citas", especialidad=e, institucion_id=inst, **filtros)} for e, n in filas])
    else:
        esps = router_citas.especialidades(sector=sector, red_seguros=red, persona=persona, db=db)
        ctx.update(paso="especialidad", titulo_paso="Elija la especialidad", vacio="Por ahora no hay doctores con horarios abiertos.",
                   opciones=[{"etiqueta": e.especialidad, "detalle": f"{e.medicos} {'doctor' if e.medicos == 1 else 'doctores'}", "url": _url("/citas", especialidad=e.especialidad, **filtros)}
                             for e in esps])
    return ctx


def _pagina_citas(request: Request, sesion: Sesion, db: Session, p: dict, status: int = 200, error: str | None = None):
    ctx = _recorrido(db, sesion.sujeto, p)
    if error:
        ctx["error"] = error
    return vista.render(request, "citas.html", sesion, status=status, seccion="citas", **ctx)


@router.get("/citas")
def citas(request: Request, especialidad: str | None = None, institucion_id: str | None = None, medico_id: str | None = None, fecha: str | None = None, hora: str | None = None,
          sector: str | None = None, red_seguros: str | None = None, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    return _pagina_citas(request, sesion, db, dict(especialidad=especialidad, institucion_id=institucion_id, medico_id=medico_id, fecha=fecha, hora=hora, sector=sector, red_seguros=red_seguros))


@router.post("/citas/reservar")
def reservar_cita(request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    """Reserva para el titular de la sesión. Doble reserva (409), expediente congelado (423) y demás reglas son las de POST /citas."""
    p = {k: campos.get(k) for k in ("medico_id", "fecha", "hora")}
    try:
        datos = CitaIn(medico_id=p["medico_id"] or "", fecha=p["fecha"] or "", hora=p["hora"] or "", motivo=(campos.get("motivo") or "").strip() or None)
        router_citas.reservar(datos, request, sesion.sujeto, db)
    except ValidationError as e:
        motivo_mal = any(x["loc"] == ("motivo",) for x in e.errors())
        return _pagina_citas(request, sesion, db, p, 422, "El motivo debe tener entre 3 y 300 caracteres." if motivo_mal else "Revise los datos de la cita.")
    except HTTPException as e:
        volver = {"medico_id": p["medico_id"], "fecha": p["fecha"]} if e.status_code in (409, 422) else {}  # horario ocupado: vuelve al paso de horas
        return _pagina_citas(request, sesion, db, volver, e.status_code, str(e.detail))
    return RedirectResponse(_url("/citas/mis", aviso="reservada"), status_code=303)


# ------------------------------------------------------------------ Mis citas, cancelar y reprogramar
def _pagina_mis(request: Request, sesion: Sesion, db: Session, status: int = 200, error: str | None = None, aviso: str | None = None):
    ahora_sv = datetime.now(SV)
    items = router_citas.mis_citas(estado=None, persona=sesion.sujeto, db=db).items
    filas = [{"c": c, "editable": c.estado == "PROGRAMADA" and datetime.combine(c.fecha, c.hora, tzinfo=SV) > ahora_sv} for c in items]
    return vista.render(request, "citas_mis.html", sesion, status=status, seccion="citas", filas=filas, error=error, aviso=AVISOS_CITA.get(aviso or ""))


@router.get("/citas/mis")
def mis_citas(request: Request, aviso: str | None = None, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    return _pagina_mis(request, sesion, db, aviso=aviso)


@router.post("/citas/{cita_id}/cancelar")
def cancelar_cita(cita_id: uuid.UUID, request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    try:
        motivo = (campos.get("motivo") or "").strip()
        router_citas.cancelar(cita_id, request, CancelarIn(motivo=motivo) if motivo else None, sesion.sujeto, db)
    except ValidationError:
        return _pagina_mis(request, sesion, db, 422, "El motivo debe tener entre 3 y 300 caracteres.")
    except HTTPException as e:  # una cita ajena responde igual que una inexistente (404)
        return _pagina_mis(request, sesion, db, e.status_code, str(e.detail))
    return RedirectResponse(_url("/citas/mis", aviso="cancelada"), status_code=303)


def _cita_propia(db: Session, persona: Persona, cita_id: uuid.UUID):
    return next((c for c in router_citas.mis_citas(estado="PROGRAMADA", persona=persona, db=db).items if c.id == cita_id), None)


def _pagina_reprogramar(request: Request, sesion: Sesion, db: Session, cita, p: dict, status: int = 200, error: str | None = None):
    dia, hora = _fecha(p.get("fecha")), _hora(p.get("hora"))
    base = f"/citas/{cita.id}/reprogramar"
    ctx = {"cita": cita, "opciones": [], "paso": "fecha", "confirmar": None, "error": error, "vacio": "Este doctor no tiene horarios libres en los próximos días.",
           "titulo_paso": "Elija la nueva fecha"}
    if dia:
        libres = router_citas.horas(medico_id=cita.medico_id, fecha=dia, persona=sesion.sujeto, db=db).horas
        if hora and hora in libres:
            ctx.update(paso="confirmar", titulo_paso="Confirme el nuevo horario",
                       confirmar={"fecha": dia.isoformat(), "hora": f"{hora:%H:%M}", "fecha_texto": f"{dia:%d/%m/%Y}", "hora_texto": f"{hora:%H:%M}"})
        else:
            if hora and not error:
                ctx["error"] = "Ese horario ya no está libre. Elija otro."
            ctx.update(paso="hora", titulo_paso=f"Elija la hora del {dia:%d/%m/%Y}", vacio="Ya no quedan horarios libres ese día.",
                       opciones=[{"etiqueta": f"{h:%H:%M}", "detalle": "", "url": _url(base, fecha=dia, hora=h)} for h in libres])
    else:
        fechas = router_citas.fechas(medico_id=cita.medico_id, persona=sesion.sujeto, db=db).fechas
        ctx["opciones"] = [{"etiqueta": f"{d:%d/%m/%Y}", "detalle": "", "url": _url(base, fecha=d)} for d in fechas]
    return vista.render(request, "citas_reprogramar.html", sesion, status=status, seccion="citas", **ctx)


@router.get("/citas/{cita_id}/reprogramar")
def reprogramar_pagina(cita_id: uuid.UUID, request: Request, fecha: str | None = None, hora: str | None = None, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    cita = _cita_propia(db, sesion.sujeto, cita_id)
    if cita is None:
        return _pagina_mis(request, sesion, db, 404, "Cita no encontrada")
    return _pagina_reprogramar(request, sesion, db, cita, dict(fecha=fecha, hora=hora))


@router.post("/citas/{cita_id}/reprogramar")
def reprogramar_cita(cita_id: uuid.UUID, request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    cita = _cita_propia(db, sesion.sujeto, cita_id)
    if cita is None:
        return _pagina_mis(request, sesion, db, 404, "Cita no encontrada")
    p = {k: campos.get(k) for k in ("fecha", "hora")}
    try:
        datos = ReprogramarIn(fecha=p["fecha"] or "", hora=p["hora"] or "", motivo=(campos.get("motivo") or "").strip() or None)
        router_citas.reprogramar(cita_id, datos, request, sesion.sujeto, db)
    except ValidationError:
        return _pagina_reprogramar(request, sesion, db, cita, {"fecha": p["fecha"]}, 422, "Revise la fecha, la hora y el motivo (3 a 300 caracteres).")
    except HTTPException as e:
        return _pagina_reprogramar(request, sesion, db, cita, {"fecha": p["fecha"]}, e.status_code, str(e.detail))
    return RedirectResponse(_url("/citas/mis", aviso="reprogramada"), status_code=303)


# ================================================================== Directorio de clínicas y hospitales
@router.get("/directorio")
def directorio(request: Request, tipo: str | None = None, sector: str | None = None, red_seguros: str | None = None, departamento: str | None = None, municipio: str | None = None,
               q: str | None = None, pagina: int = Query(1, ge=1, le=10000), sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    filtros = {"tipo": tipo if tipo in TIPOS_CENTRO else None, "sector": sector if sector in SECTORES else None, "red_seguros": red_seguros if red_seguros in REDES else None,
               "departamento": (departamento or "").strip()[:80] or None, "municipio": (municipio or "").strip()[:80] or None, "q": (q or "").strip()[:80] or None}
    aviso_q = None
    if filtros["q"] and len(filtros["q"]) < 2:
        filtros["q"], aviso_q = None, "Escriba al menos 2 letras para buscar por nombre."
    out = router_directorio.listar(limite=POR_PAGINA + 1, offset=(pagina - 1) * POR_PAGINA, persona=sesion.sujeto, db=db, **filtros)
    items = out.items[:POR_PAGINA]
    return vista.render(request, "directorio.html", sesion, seccion="directorio", items=items, pagina=pagina, hay_siguiente=len(out.items) > POR_PAGINA, filtros=filtros, aviso_q=aviso_q,
                        sectores=SECTORES, redes=REDES, tipos=TIPOS_CENTRO, red_centro=RED_CENTRO, consulta=_consulta(**filtros), agendar=lambda i: _url("/citas", institucion_id=i))


# ================================================================== Asistente virtual (consultivo: no agenda, no diagnostica)
def _accion_web(a) -> dict | None:
    """Traduce la acción que sugiere el motor del chat (rutas de la API) a una página del portal. Lo que no tiene página se descarta."""
    partes = urlsplit(a.ruta)
    ruta, consulta = partes.path, dict(parse_qsl(partes.query))
    if ruta == "/citas/especialidades":
        destino = _url("/citas")
    elif ruta == "/citas":
        destino = _url("/citas/mis")
    elif ruta == "/farmacias/buscar":
        destino = _url("/farmacias", **{k: consulta.get(k) for k in ("medicamento", "departamento", "municipio")})
    elif ruta == "/portal/accesos":
        destino = _url("/accesos")
    elif ruta.startswith("/portal/mi-expediente/"):
        destino = _url("/expediente", seccion=ruta.rsplit("/", 1)[1])
    elif ruta == "/portal/perfil":
        destino = _url("/perfil")
    else:
        return None
    return {"etiqueta": a.etiqueta, "url": destino}


def _pagina_asistente(request: Request, sesion: Sesion, turnos: list, status: int = 200, error: str | None = None, texto: str = ""):
    return vista.render(request, "asistente.html", sesion, status=status, seccion="asistente", turnos=turnos, error=error, texto=texto)


@router.get("/asistente")
def asistente(request: Request, sesion: Sesion = Depends(area)):
    return _pagina_asistente(request, sesion, [])


@router.post("/asistente")
def preguntar(request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    """El texto del chat se guarda solo en la página: ni la bitácora ni la base de datos lo conservan (puede contener síntomas)."""
    texto = (campos.get("mensaje") or "").strip()
    try:
        body = MensajeIn(mensaje=texto)
    except ValidationError:
        return _pagina_asistente(request, sesion, [], 422, "Escriba su pregunta (hasta 500 caracteres).", texto[:500])
    r = router_chatbot.mensaje(body, request, sesion.sujeto, db)
    turno = {"pregunta": texto, "respuesta": r.respuesta, "intencion": r.intencion, "aviso": r.aviso, "acciones": [x for x in (_accion_web(a) for a in r.acciones) if x]}
    if request.headers.get("hx-request") and not request.headers.get("hx-boosted"):
        return vista.render(request, "_chat_turno.html", sesion, turno=turno)
    return _pagina_asistente(request, sesion, [turno])


# ================================================================== Búsqueda de medicamentos en farmacias
ORDENES = {"disponibilidad": "Mayor disponibilidad", "precio": "Menor precio"}


@router.get("/farmacias")
def farmacias(request: Request, medicamento: str | None = None, departamento: str | None = None, municipio: str | None = None, orden: str = "disponibilidad",
              sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    valores = {"medicamento": (medicamento or "").strip(), "departamento": (departamento or "").strip()[:80], "municipio": (municipio or "").strip()[:80],
               "orden": orden if orden in ORDENES else "disponibilidad"}
    resultado, error, status = None, None, 200
    if medicamento is not None:
        if not 3 <= len(valores["medicamento"]) <= 60:
            error, status = "Escriba entre 3 y 60 caracteres del medicamento.", 422
        else:
            resultado = router_directorio.buscar(medicamento=valores["medicamento"], departamento=valores["departamento"] or None, municipio=valores["municipio"] or None,
                                                 orden=valores["orden"], limite=50, persona=sesion.sujeto, db=db)
    return vista.render(request, "farmacias.html", sesion, status=status, seccion="farmacias", valores=valores, resultado=resultado, error=error, ordenes=ORDENES)


# ================================================================== Estado vital y datos civiles (panel)
def tarjeta_vital(estado: EstadoVitalOut, causa_visible: bool) -> dict:
    """Qué muestra la tarjeta «Estado vital». La causa oficial de muerte se trata como dato protegido: solo con el desbloqueo vigente de nivel 4."""
    if estado.estado == "VIVO":
        return {"vivo": True}
    return {"vivo": False, "fallecido_en": estado.fallecido_en.astimezone(SV) if estado.fallecido_en else None, "entidad": estado.entidad_certificadora,
            "causa_visible": causa_visible, "causa": estado.causa_oficial if causa_visible else None, "cie10": estado.causa_cie10 if causa_visible else None}


def tarjeta_estado_vital(request: Request, sesion: Sesion, db: Session) -> dict:
    """Lee el estado vital del titular con el servicio del expediente y deja constancia en la bitácora (sin guardar la causa de muerte)."""
    persona = sesion.sujeto
    estado = servicio_vital.estado_vital(db, persona.id)
    visible = estado.estado == "FALLECIDO" and _desbloqueo(db, sesion) is not None
    auditar("PORTAL_LECTURA_PROPIA", actor_tipo="persona", actor_id=persona.id, recurso="expediente", recurso_id=persona.id, ip=ip_cliente(request),
            detalle={"seccion": "estado_vital", "devueltos": 1, "restringidos": 0, "nivel4_abierto": visible})
    return tarjeta_vital(estado, visible)


def datos_civiles(p: Persona) -> dict:
    """Datos civiles de solo lectura del titular (lo que falte se muestra como «Sin información»)."""
    c = p.civil
    return {"nombre": f"{p.nombres} {p.apellidos}", "dui": p.dui, "nit": p.nit, "tipo_sangre": c.tipo_sangre if c else None, "direccion": p.direccion,
            "ubicacion": ", ".join(x for x in (p.municipio, p.departamento) if x) or None, "telefono": p.telefono, "correo": p.correo,
            "emergencia_nombre": c.contacto_emergencia_nombre if c else None, "emergencia_telefono": c.contacto_emergencia_telefono if c else None}
