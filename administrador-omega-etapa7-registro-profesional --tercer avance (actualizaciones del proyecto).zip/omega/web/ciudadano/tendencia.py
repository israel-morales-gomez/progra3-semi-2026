"""Gráfico de tendencia en SVG propio (sin librerías ni estilos en línea: los colores salen de clases de portal.css). Solo presentación."""
from datetime import timezone
from zoneinfo import ZoneInfo

from markupsafe import Markup

SV = ZoneInfo("America/El_Salvador")
W, H, MI, MD, MS, MB = 320, 130, 44, 10, 12, 26  # ancho, alto y márgenes izquierdo, derecho, superior, inferior


def _n(v: float) -> str:
    return f"{v:.2f}".rstrip("0").rstrip(".")


def _dia(f) -> str:
    return (f if f.tzinfo else f.replace(tzinfo=timezone.utc)).astimezone(SV).strftime("%d/%m/%y")


def tendencia_svg(puntos: list[dict], unidad: str | None = None) -> Markup:
    """Línea con los valores numéricos de una prueba a lo largo del tiempo, banda del rango de referencia y puntos críticos con aro de alerta. Con un solo valor dibuja el punto."""
    nums = [p for p in puntos if p.get("valor") is not None]
    if not nums:
        return Markup("")
    ref = next(((p["ref_min"], p["ref_max"]) for p in reversed(nums) if p.get("ref_min") is not None or p.get("ref_max") is not None), (None, None))
    ys = [p["valor"] for p in nums] + [r for r in ref if r is not None]
    lo, hi = min(ys), max(ys)
    pad = (hi - lo) * 0.15 or abs(hi) * 0.1 or 1
    lo, hi = lo - pad, hi + pad
    t0, t1 = nums[0]["fecha"].timestamp(), nums[-1]["fecha"].timestamp()
    x = lambda f: MI + ((W - MI - MD) / 2 if t1 == t0 else (f.timestamp() - t0) / (t1 - t0) * (W - MI - MD))
    y = lambda v: MS + (hi - v) / (hi - lo) * (H - MS - MB)
    o = [f'<svg class="tendencia" viewBox="0 0 {W} {H}" role="img" aria-label="Tendencia de {len(nums)} {"valor" if len(nums) == 1 else "valores"}{" en " + str(unidad) if unidad else ""}">']
    if ref[0] is not None and ref[1] is not None:
        o.append(f'<rect class="tend-ref" x="{MI}" y="{_n(y(ref[1]))}" width="{W - MI - MD}" height="{_n(y(ref[0]) - y(ref[1]))}"><title>Rango de referencia {_n(ref[0])} – {_n(ref[1])}</title></rect>')
    else:
        for r in ref:
            if r is not None:
                o.append(f'<line class="tend-limite" x1="{MI}" x2="{W - MD}" y1="{_n(y(r))}" y2="{_n(y(r))}"/>')
    o.append(f'<line class="tend-eje" x1="{MI}" x2="{MI}" y1="{MS}" y2="{H - MB}"/><line class="tend-eje" x1="{MI}" x2="{W - MD}" y1="{H - MB}" y2="{H - MB}"/>')
    o.append(f'<text class="tend-txt" x="{MI - 4}" y="{MS + 4}" text-anchor="end">{_n(hi)}</text><text class="tend-txt" x="{MI - 4}" y="{H - MB}" text-anchor="end">{_n(lo)}</text>')
    o.append(f'<text class="tend-txt" x="{MI}" y="{H - 8}" text-anchor="start">{_dia(nums[0]["fecha"])}</text>')
    if len(nums) > 1:
        o.append(f'<text class="tend-txt" x="{W - MD}" y="{H - 8}" text-anchor="end">{_dia(nums[-1]["fecha"])}</text>')
        o.append('<polyline class="tend-linea" points="' + " ".join(f"{_n(x(p['fecha']))},{_n(y(p['valor']))}" for p in nums) + '"/>')
    for p in nums:
        cx, cy = _n(x(p["fecha"])), _n(y(p["valor"]))
        if p.get("critico"):
            o.append(f'<circle class="tend-alerta" cx="{cx}" cy="{cy}" r="8"/>')
        o.append(f'<circle class="tend-punto{" critico" if p.get("critico") else ""}" cx="{cx}" cy="{cy}" r="4"><title>{_dia(p["fecha"])}: {_n(p["valor"])}{" " + str(unidad) if unidad else ""}{" (crítico)" if p.get("critico") else ""}</title></circle>')
    o.append("</svg>")
    return Markup("".join(o))
