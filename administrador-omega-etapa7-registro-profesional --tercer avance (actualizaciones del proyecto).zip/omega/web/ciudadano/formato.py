"""Formato legible para las pantallas del portal: fechas en español y hora de El Salvador (UTC-6, sin horario de verano). Solo presentación."""
from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo

SV = ZoneInfo("America/El_Salvador")
MESES = ("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre")
BANDERAS = {"NORMAL": "Normal", "BAJO": "Bajo", "ALTO": "Alto", "ANORMAL": "Anormal", "CRITICO_BAJO": "Crítico (bajo)", "CRITICO_ALTO": "Crítico (alto)", "CRITICO": "Crítico"}
ESTADOS_RECETA = {"EMITIDA": "Emitida", "DESPACHADA": "Despachada", "VENCIDA": "Vencida", "ANULADA": "Anulada"}


def _como_valor(v):
    if isinstance(v, str):
        try:
            return datetime.fromisoformat(v) if "T" in v or " " in v else date.fromisoformat(v)
        except ValueError:
            return None
    return v if isinstance(v, (date, datetime)) else None


def fecha(v) -> str:
    """20 de octubre de 2026. Un instante con hora se convierte antes a la hora de El Salvador para no correr el día."""
    d = _como_valor(v)
    if d is None:
        return "—"
    if isinstance(d, datetime):
        d = (d if d.tzinfo else d.replace(tzinfo=timezone.utc)).astimezone(SV)
    return f"{d.day} de {MESES[d.month - 1]} de {d.year}"


def fecha_hora(v) -> str:
    """20 de octubre de 2026, 3:45 p. m. (hora de El Salvador)."""
    d = _como_valor(v)
    if not isinstance(d, datetime):
        return fecha(v)
    d = (d if d.tzinfo else d.replace(tzinfo=timezone.utc)).astimezone(SV)
    return f"{fecha(d)}, {d.hour % 12 or 12}:{d.minute:02d} {'a. m.' if d.hour < 12 else 'p. m.'}"


def numero(v) -> str:
    if v is None:
        return "—"
    return f"{float(v):.2f}".rstrip("0").rstrip(".")


def bandera(v) -> str:
    return BANDERAS.get(v or "", v or "—")


def estado_receta(v) -> str:
    return ESTADOS_RECETA.get(v or "", v or "—")


def cuando(v) -> str:
    """DD/MM/AAAA - HH:MM en hora de El Salvador. Una fecha sin hora (p. ej. próxima dosis de una vacuna) sale como DD/MM/AAAA - sin hora."""
    d = _como_valor(v)
    if isinstance(d, datetime):
        d = (d if d.tzinfo else d.replace(tzinfo=timezone.utc)).astimezone(SV)
        return f"{d:%d/%m/%Y - %H:%M}"
    return f"{d:%d/%m/%Y} - sin hora" if d else "—"


def instalar_filtros(env) -> None:
    from .tendencia import tendencia_svg
    env.filters.update(fecha=fecha, fecha_hora=fecha_hora, numero=numero, bandera=bandera, estado_receta=estado_receta, cuando=cuando)
    env.globals["tendencia_svg"] = tendencia_svg
