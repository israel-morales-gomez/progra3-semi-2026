"""Portal ciudadano: ingreso, salida, inicio, perfil y cuenta. No tiene reglas propias: valida con los esquemas de omega_core / portal_civil y
guarda llamando a las mismas funciones que la API (portal_civil.router_perfil), así que heredan sus reglas y su bitácora de auditoría."""
import uuid
from datetime import date, datetime
from pathlib import Path
from typing import Literal
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import RedirectResponse
from pydantic import ValidationError
from sqlalchemy.orm import Session

from omega_core.constantes import TIPOS_SANGRE
from omega_core.database import get_db
from omega_core.routers import personas
from omega_core.security.ratelimit import ip_cliente
from omega_core.schemas import PersonaRegistro
from portal_civil import router_expediente as servicio_expediente
from portal_civil import router_perfil as servicio_perfil
from portal_civil import service_autocompras, service_historial
from portal_civil.schemas_autocompras import AutocompraIn
from portal_civil.schemas import DesbloquearIn, EstadoPerfilIn, PerfilCiudadanoIn
from web.comun.ingreso import instalar_ingreso
from web.comun.portales import CIUDADANO
from web.comun.sesion import Guardias, Sesion, requiere_area, csrf_de
from web.comun.vista import Vista

from .formato import instalar_filtros

PORTAL = CIUDADANO
vista = Vista(PORTAL, Path(__file__).parent)
instalar_filtros(vista.plantillas.env)  # fecha, fecha_hora, numero, bandera, estado_receta
guardias = Guardias(PORTAL)
area = requiere_area(PORTAL)  # guardia de las páginas internas del portal
router = APIRouter(prefix=PORTAL.base, include_in_schema=False)  # las páginas no aparecen en /docs (que documenta la API)
instalar_ingreso(router, PORTAL, vista, guardias)

# ------------------------------------------------------------------ Registro de personas
DEPARTAMENTOS = ["Ahuachapán", "Santa Ana", "Sonsonate", "Chalatenango", "La Libertad", "San Salvador", "Cuscatlán", "La Paz", "Cabañas", "San Vicente", "Usulután", "San Miguel", "Morazán", "La Unión"]
CAMPOS_REGISTRO = ("dui", "nombres", "apellidos", "fecha_nacimiento", "sexo", "correo", "telefono", "departamento", "municipio")
csrf = csrf_de(PORTAL)


@router.get("/registro")
def pagina_registro(request: Request, sesion: Sesion | None = Depends(guardias.opcional)):
    if sesion:
        return RedirectResponse(f"{PORTAL.base}/panel", status_code=303)
    return vista.render(request, "registro.html", valores={}, errores={}, hoy=date.today().isoformat(), departamentos=DEPARTAMENTOS)


@router.post("/registro")
def registrar(request: Request, campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    valores = {k: campos.get(k, "").strip() for k in CAMPOS_REGISTRO}
    ctx = dict(valores=valores, hoy=date.today().isoformat(), departamentos=DEPARTAMENTOS)
    if campos.get("password", "") != campos.get("password2", ""):
        return vista.render(request, "registro.html", status=422, errores={"password2": "Las contraseñas no coinciden."}, **ctx)
    datos = {k: (v or None) for k, v in valores.items()} | {"password": campos.get("password", "")}
    try:
        modelo = PersonaRegistro(**datos)
    except ValidationError as e:  # las reglas de validación son las de omega_core.schemas; aquí solo se muestran
        errores = {}
        for err in e.errors():
            campo = str(err["loc"][0]) if err["loc"] else "general"
            errores.setdefault(campo, str(err["msg"]).removeprefix("Value error, "))
        return vista.render(request, "registro.html", status=422, errores=errores, **ctx)
    try:
        personas.registrar(modelo, request, db)  # mismo servicio que POST /personas: límite de intentos, duplicados y bitácora
    except HTTPException as e:
        return vista.render(request, "registro.html", status=e.status_code, errores={"general": e.detail}, **ctx)
    return RedirectResponse(f"{PORTAL.base}/ingresar?registrado=1", status_code=303)



# ------------------------------------------------------------------ Inicio, perfil y perfiles de estudiante / profesional
CAMPOS_CONTACTO = ("correo", "telefono", "departamento", "municipio", "direccion")
CAMPOS_SALUD = ("tipo_sangre", "contacto_emergencia_nombre", "contacto_emergencia_telefono")  # datos civiles: viven en perfil_civil
CAMPOS_PERFIL = CAMPOS_CONTACTO + CAMPOS_SALUD
OBLIGATORIOS = {"correo": "El correo", "telefono": "El teléfono"}  # el servicio no admite dejarlos vacíos
SV = ZoneInfo("America/El_Salvador")
PERFILES = {
    "estudiante": ("Estudiante en práctica", "Deja de operar como estudiante en práctica."),
    "profesional": ("Profesional de salud", "Deja de leer y escribir en expedientes y de emitir recetas y órdenes."),
}
AVISOS = {"guardado": "Sus datos se guardaron.", "sin_cambios": "No hay cambios que guardar."}


def _saludo() -> str:
    hora = datetime.now(SV).hour
    return "Buenos días" if hora < 12 else "Buenas tardes" if hora < 19 else "Buenas noches"


def _iniciales(persona) -> str:
    return ((persona.nombres[:1] + persona.apellidos[:1]) or "?").upper()


def _resumen(sesion: Sesion) -> dict:
    """Lo que muestran inicio y perfil: el mismo resumen que entrega la API (GET /portal/perfil)."""
    return {"perfil": servicio_perfil.ver(sesion.sujeto), "iniciales": _iniciales(sesion.sujeto)}


def _mensaje(e: ValidationError) -> dict:
    errores = {}
    for err in e.errors():
        campo = str(err["loc"][0]) if err["loc"] else "general"
        ctx = err.get("ctx") or {}
        if err["type"] == "string_too_short":
            texto = f"Escriba al menos {ctx.get('min_length')} caracteres."
        elif err["type"] == "string_too_long":
            texto = f"Use como máximo {ctx.get('max_length')} caracteres."
        elif err["type"] == "literal_error":
            texto = "Elija un valor de la lista."
        else:
            texto = str(err["msg"]).removeprefix("Value error, ")
        errores.setdefault(campo, texto)
    return errores


@router.get("/panel")
def panel(request: Request, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    return vista.render(request, "panel.html", sesion, seccion="inicio", saludo=_saludo(), vital=tarjeta_estado_vital(request, sesion, db), civiles=datos_civiles(sesion.sujeto),
                        **_resumen(sesion))


# ------------------------------------------------------------------ Mi expediente (solo lectura)
PESTANAS = {"resumen": "Resumen", "atenciones": "Atenciones", "diagnosticos": "Diagnósticos", "recetas": "Recetas", "medicamentos": "Medicamentos", "resultados": "Resultados", "laboratorio": "Laboratorio", "imagen": "Imagen", "vacunas": "Vacunas", "seguimiento": "Seguimiento"}
POR_PAGINA = 10
SEGUIMIENTO_TIPOS = {"CITA": "Citas", "CONTROL": "Controles", "VACUNA": "Vacunas pendientes", "TRATAMIENTO": "Tratamientos continuos"}
Pagina = Query(1, ge=1, le=10000)


def _desbloqueo(db: Session, sesion: Sesion):
    """Desbloqueo de nivel 4 vigente de ESTA sesión web, o None. Si venció o fue revocado se limpia de la sesión (vuelve a quedar bloqueado)."""
    fila = sesion.fila
    if not fila.n4_desbloqueo_id:
        return None
    d = servicio_expediente.desbloqueo_vigente(db, sesion.sujeto, fila.n4_desbloqueo_id)
    if d is None:
        fila.n4_desbloqueo_id = None
        db.commit()
    return d


def _leer_pestana(request: Request, sesion: Sesion, db: Session, pestana: str, pagina: int) -> tuple[dict, int]:
    """Lee UNA página de UNA sección del expediente del titular de la sesión, llamando a los servicios de portal_civil (los mismos de /portal/mi-expediente).
    El sujeto es siempre sesion.sujeto: ninguna ruta ni parámetro admite un DUI o un id. Los datos de nivel 4 salen como `restringido` salvo que esta sesión tenga un
    desbloqueo 2FA vigente (se abre en /ciudadano/nivel4, dura unos minutos y se pierde al cerrar sesión); el navegador nunca recibe el token. Cada lectura la audita el servicio."""
    d4 = _desbloqueo(db, sesion)
    ctx = dict(seccion="expediente", pestanas=PESTANAS, pestana=pestana, pagina=pagina, por_pagina=POR_PAGINA, items=[], restringidos=0, hay_siguiente=False, error=None,
               n4_abierto=d4 is not None, n4_expira=d4.expira_en if d4 else None)
    desplazamiento = (pagina - 1) * POR_PAGINA
    try:
        if pestana == "resumen":  # una sola página, sin paginación
            ctx["pagina"] = 1
            ctx["resumen"] = servicio_expediente.mi_resumen(request, d4 is not None, sesion.sujeto, db)
            ctx["restringidos"] = ctx["resumen"]["restringidos"]
        elif pestana == "atenciones":
            ctx["items"] = servicio_expediente.mis_atenciones(request, d4 is not None, POR_PAGINA, desplazamiento, sesion.sujeto, db)
            ctx["restringidos"] = sum(1 for i in ctx["items"] if i["restringido"] or (i.get("diagnostico") or {}).get("restringido"))
        elif pestana in ("laboratorio", "imagen", "seguimiento"):  # se leen completas (máx. 200 resultados) y se cortan aquí en páginas
            leer = {"laboratorio": servicio_expediente.mi_laboratorio, "imagen": servicio_expediente.mis_imagenes, "seguimiento": servicio_expediente.mi_seguimiento}[pestana]
            todos, ctx["restringidos"] = leer(request, d4 is not None, sesion.sujeto, db)
            ctx["items"] = todos[desplazamiento:desplazamiento + POR_PAGINA]
            ctx["hay_siguiente_corte"] = len(todos) > desplazamiento + POR_PAGINA
            if pestana == "seguimiento":
                presentes = {f["tipo"] for f in todos}
                ctx["sin_datos"] = [n for t, n in SEGUIMIENTO_TIPOS.items() if t not in presentes]
        elif pestana == "medicamentos":  # historial farmacológico multicanal: recetas + administraciones + autocompras, con alertas de interacciones
            lectura = service_historial.leer(request, sesion.sujeto, db, POR_PAGINA, desplazamiento)
            ctx["items"], ctx["alertas"], ctx["hay_siguiente_corte"] = lectura["items"], lectura["alertas"], lectura["hay_siguiente"]
            ctx["hoy"] = datetime.now(ZoneInfo("America/El_Salvador")).date()
        elif pestana == "recetas":
            ctx["items"] = servicio_expediente.mis_recetas(request, limite=POR_PAGINA, offset=desplazamiento, persona=sesion.sujeto, db=db).items
        else:
            salida = servicio_expediente.leer_propia(pestana, request, False, POR_PAGINA, desplazamiento, d4 is not None, sesion.sujeto, db)
            ctx["items"], ctx["restringidos"] = salida.items, salida.restringidos
    except HTTPException as e:
        return ctx | {"error": str(e.detail)}, e.status_code
    ctx["hay_siguiente"] = ctx.get("hay_siguiente_corte", False) if pestana in ("laboratorio", "imagen", "seguimiento", "medicamentos") else pestana != "resumen" and len(ctx["items"]) == POR_PAGINA  # página llena: puede haber más (si la siguiente viene vacía, se avisa)
    return ctx, 200


@router.get("/expediente")
def expediente(request: Request, seccion: str = "diagnosticos", pagina: int = Pagina, aviso: str | None = None, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    """Página completa (también es el respaldo sin JavaScript de las pestañas). `seccion` solo elige la pestaña; cualquier otro valor cae en diagnósticos."""
    ctx, status = _leer_pestana(request, sesion, db, seccion if seccion in PESTANAS else "diagnosticos", pagina)
    return vista.render(request, "expediente.html", sesion, status=status, aviso_med=AVISOS_MED.get(aviso or ""), **ctx)


@router.get("/expediente/{pestana}")
def expediente_pestana(pestana: str, request: Request, pagina: int = Pagina, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    """Fragmento HTMX de una pestaña. Sin HTMX redirige a la página completa. Una pestaña que no existe es 404 (aquí nunca va un id)."""
    if pestana not in PESTANAS:
        raise HTTPException(404, "Sección no encontrada")
    if not request.headers.get("hx-request") or request.headers.get("hx-boosted"):
        return RedirectResponse(f"{PORTAL.base}/expediente?seccion={pestana}&pagina={pagina}", status_code=303)
    ctx, status = _leer_pestana(request, sesion, db, pestana, pagina)
    return vista.render(request, "_expediente.html", sesion, status=status, **ctx)


# ------------------------------------------------------------------ Medicamentos: declarar una autocompra
AVISOS_MED = {"autocompra": "Su autocompra quedó registrada como «Declarada por el paciente»."}
CAMPOS_AUTOCOMPRA = ("medicamento", "dosis", "fecha_compra", "farmacia")


@router.post("/medicamentos/autocompra")
def declarar_autocompra(request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    """Declara una autocompra del titular de la sesión (la persona nunca viene del formulario). Validación y bitácora son las de POST /portal/autocompras."""
    valores = {k: (campos.get(k) or "").strip() for k in CAMPOS_AUTOCOMPRA}
    errores: dict = {}
    status = 422
    try:
        datos = AutocompraIn(**valores)
        service_autocompras.registrar(db, sesion.sujeto, datos, ip_cliente(request))
        return RedirectResponse(f"{PORTAL.base}/expediente?seccion=medicamentos&aviso=autocompra", status_code=303)
    except ValidationError as e:
        errores = _mensaje(e)
        if any(x["loc"] == ("fecha_compra",) and (x["type"] == "missing" or x["type"].startswith("date")) for x in e.errors()):
            errores["fecha_compra"] = "Indique una fecha de compra válida."
    except HTTPException as e:
        status, errores = e.status_code, {"general": str(e.detail)}
    ctx, st = _leer_pestana(request, sesion, db, "medicamentos", 1)
    return vista.render(request, "expediente.html", sesion, status=status if st == 200 else st, valores_med=valores, errores_med=errores, **ctx)


# ------------------------------------------------------------------ Datos protegidos (nivel 4) con 2FA
def _pestana_valida(valor: str | None) -> str:
    return valor if valor in PESTANAS else "diagnosticos"


def _pagina_nivel4(request: Request, sesion: Sesion, db: Session, status: int = 200, error: str | None = None, desafio_id: str | None = None, volver: str = "diagnosticos"):
    d4 = _desbloqueo(db, sesion)
    return vista.render(request, "nivel4.html", sesion, status=status, seccion="expediente", error=error, desafio_id=desafio_id, volver=volver, pestanas=PESTANAS,
                        n4_abierto=d4 is not None, n4_expira=d4.expira_en if d4 else None, minutos=servicio_expediente.DESBLOQUEO_MIN)


@router.get("/nivel4")
def pagina_nivel4(request: Request, volver: str = "diagnosticos", sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    return _pagina_nivel4(request, sesion, db, volver=_pestana_valida(volver))


@router.post("/nivel4/codigo")
def pedir_codigo(request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    """Pide el código 2FA con el mismo servicio de la API (máximo 5 solicitudes cada 10 minutos; el código sale al teléfono registrado)."""
    volver = _pestana_valida(campos.get("volver"))
    try:
        r = servicio_expediente.pedir_desafio(request, sesion.sujeto, db)
    except HTTPException as e:
        return _pagina_nivel4(request, sesion, db, e.status_code, str(e.detail), volver=volver)
    return _pagina_nivel4(request, sesion, db, desafio_id=str(r.desafio_id), volver=volver)


@router.post("/nivel4/verificar")
def verificar_codigo(request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    """Verifica el código con el mismo servicio de la API (desafío vigente, 5 intentos, bloqueo por cuenta, bitácora). Si es correcto, el desbloqueo queda ligado a ESTA sesión:
    el token nunca se envía al navegador."""
    volver, desafio = _pestana_valida(campos.get("volver")), campos.get("desafio_id", "")
    try:
        did = uuid.UUID(desafio)
    except ValueError:
        return _pagina_nivel4(request, sesion, db, 401, "Código inválido o vencido", volver=volver)  # sin desafío válido no hay segundo paso: se pide uno nuevo
    try:
        datos = DesbloquearIn(desafio_id=did, codigo=campos.get("codigo", "").strip())
    except ValidationError:  # no es de 6 dígitos: no gasta un intento ni el desafío
        return _pagina_nivel4(request, sesion, db, 422, "Escriba el código de 6 dígitos.", desafio, volver)
    try:
        _, d = servicio_expediente.abrir_desbloqueo(datos, request, sesion.sujeto, db)
    except HTTPException as e:
        return _pagina_nivel4(request, sesion, db, e.status_code, str(e.detail), desafio if e.status_code == 401 else None, volver)
    sesion.fila.n4_desbloqueo_id = d.id
    db.commit()
    return RedirectResponse(f"{PORTAL.base}/expediente?seccion={volver}", status_code=303)


@router.post("/nivel4/bloquear")
def bloquear_nivel4(request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    """Vuelve a ocultar el nivel 4 ahora mismo: revoca los desbloqueos de la persona (mismo servicio que la API) y limpia el de la sesión."""
    servicio_expediente.bloquear(request, sesion.sujeto, db)
    sesion.fila.n4_desbloqueo_id = None
    db.commit()
    return RedirectResponse(f"{PORTAL.base}/expediente?seccion={_pestana_valida(campos.get('volver'))}", status_code=303)


# ------------------------------------------------------------------ Quién consultó mi expediente
MOTIVOS = {"ATENCION_ACTIVA": "Atención médica en curso", "CONSENTIMIENTO": "Con su consentimiento"}


def _motivo(a) -> str:
    """Motivo de la consulta, sin datos clínicos: profesionales → su vía de acceso; farmacias y laboratorios → lo que consultaron."""
    return MOTIVOS.get(a.via or "", "Consulta de su expediente") if a.tipo == "PROFESIONAL" else a.que_consulto.capitalize()


@router.get("/accesos")
def accesos(request: Request, pagina: int = Pagina, sesion: Sesion = Depends(area), db: Session = Depends(get_db)):
    """Quién consultó mi expediente, tomado de la bitácora con el mismo servicio de la API (GET /portal/accesos): siempre MI expediente, sin parámetros de persona.
    Solo se pasa a la plantilla quién, institución, fecha y motivo: ni sección, ni IP, ni justificaciones, ni datos clínicos."""
    try:
        r = servicio_expediente.accesos(request, limite=POR_PAGINA, offset=(pagina - 1) * POR_PAGINA, persona=sesion.sujeto, db=db)
    except HTTPException as e:
        return vista.render(request, "accesos.html", sesion, status=e.status_code, seccion="accesos", items=[], pagina=pagina, hay_siguiente=False, error=str(e.detail))
    filas = [{"fecha": a.fecha, "quien": a.accedio, "institucion": a.establecimiento or a.accedio, "motivo": _motivo(a)} for a in r.items]
    return vista.render(request, "accesos.html", sesion, seccion="accesos", items=filas, pagina=pagina, hay_siguiente=len(filas) == POR_PAGINA, error=None)


def _actual(persona, campo: str) -> str:
    """Valor guardado de un campo del perfil: los datos civiles (sangre, contacto de emergencia) viven en perfil_civil, el resto en persona."""
    origen = persona.civil if campo in CAMPOS_SALUD else persona
    return (getattr(origen, campo, None) if origen else None) or ""


def _completitud(persona) -> tuple[int, int]:
    """«Perfil completo»: cuántos de los datos editables están llenos. Solo informativo, se calcula en el servidor."""
    return sum(1 for k in CAMPOS_PERFIL if _actual(persona, k)), len(CAMPOS_PERFIL)


def _pagina_perfil(request: Request, sesion: Sesion, status: int = 200, valores: dict | None = None, errores: dict | None = None, aviso: str | None = None, **extra):
    p = sesion.sujeto
    actuales = {k: _actual(p, k) for k in CAMPOS_PERFIL}
    llenos, total = _completitud(p)
    return vista.render(request, "perfil.html", sesion, status=status, seccion="perfil", valores=valores or actuales, errores=errores or {}, aviso=aviso,
                        departamentos=DEPARTAMENTOS, perfiles_info=PERFILES, tipos_sangre=TIPOS_SANGRE, nit=p.nit, llenos=llenos, total=total, **_resumen(sesion), **extra)


@router.get("/perfil")
def perfil(request: Request, aviso: str | None = None, sesion: Sesion = Depends(area)):
    return _pagina_perfil(request, sesion, aviso=AVISOS.get(aviso or ""))


@router.post("/perfil")
def guardar_perfil(request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    persona = sesion.sujeto
    valores = {k: (campos.get(k) or "").strip() for k in CAMPOS_PERFIL}  # solo estos campos: DUI, nombres y fecha de nacimiento nunca se leen del formulario
    errores = {k: f"{etiqueta} no puede quedar vacío." for k, etiqueta in OBLIGATORIOS.items() if not valores[k]}
    if errores:
        return _pagina_perfil(request, sesion, 422, valores, errores)
    candidatos = {k: v for k, v in valores.items() if v and v != _actual(persona, k)}  # un campo opcional en blanco no se envía: el servicio no borra datos
    try:
        validado = PerfilCiudadanoIn(**candidatos).model_dump(exclude_unset=True) if candidatos else {}  # mismas validaciones que PATCH /portal/perfil
        cambios = {k: v for k, v in validado.items() if str(v).lower() != _actual(persona, k).lower()}
        if not cambios:
            return RedirectResponse(f"{PORTAL.base}/perfil?aviso=sin_cambios", status_code=303)
        servicio_perfil.actualizar(PerfilCiudadanoIn(**cambios), request, persona, db)  # guarda y deja constancia en la bitácora (PORTAL_PERFIL_ACTUALIZADO)
    except ValidationError as e:
        return _pagina_perfil(request, sesion, 422, valores, _mensaje(e))
    except HTTPException as e:
        return _pagina_perfil(request, sesion, e.status_code, valores, {"general": str(e.detail)})
    return RedirectResponse(f"{PORTAL.base}/perfil?aviso=guardado", status_code=303)


@router.post("/perfil/{nombre}/estado")
def cambiar_perfil(nombre: Literal["estudiante", "profesional"], request: Request, sesion: Sesion = Depends(area), campos: dict = Depends(csrf), db: Session = Depends(get_db)):
    """Activa o desactiva SU perfil: la persona sale de la sesión, nunca de la URL ni del formulario. Las reglas (existe el perfil, conserva su verificación) y la bitácora son del servicio."""
    quiere = campos.get("activo") == "1"
    aviso, error, status = None, None, 200
    try:
        servicio_perfil.cambiar_estado(nombre, EstadoPerfilIn(activo=quiere), request, sesion.sujeto, db)  # registra PORTAL_PERFIL_ESTADO
        aviso = f"Perfil de {PERFILES[nombre][0].lower()} {'activado' if quiere else 'desactivado'}."
    except HTTPException as e:
        error, status = str(e.detail), e.status_code
    if request.headers.get("hx-request") and not request.headers.get("hx-boosted"):  # el interruptor pide solo el bloque de perfiles
        return vista.render(request, "_perfiles.html", sesion, status=status, aviso_perfiles=aviso, error=error, perfiles_info=PERFILES, **_resumen(sesion))
    if error:
        return _pagina_perfil(request, sesion, status, error_perfiles=error)
    return RedirectResponse(f"{PORTAL.base}/perfil", status_code=303)


@router.get("/cuenta")
def cuenta(request: Request, sesion: Sesion = Depends(area)):
    return vista.render(request, "cuenta.html", sesion)


# ------------------------------------------------------------------ Citas, directorio, asistente, farmacias y estado vital (módulo aparte; comparte este router)
from .servicios import datos_civiles, tarjeta_estado_vital  # noqa: E402,F401  (al final: servicios.py importa de este módulo)
