import uuid
from datetime import datetime

from sqlalchemy import Boolean, CheckConstraint, DateTime, Index, String, Uuid
from sqlalchemy.orm import Mapped, mapped_column

from omega_core.models.base import Base, ahora


class SesionWeb(Base):
    """Sesión del navegador de UN portal. La cookie lleva un valor aleatorio; aquí solo se guarda su SHA-256 (nunca el JWT)."""

    __tablename__ = "sesion_web"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    portal: Mapped[str] = mapped_column(String(20))  # una sesión solo vale en el portal que la abrió
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    sujeto_tipo: Mapped[str] = mapped_column(String(12))
    sujeto_id: Mapped[uuid.UUID] = mapped_column(Uuid)
    refresh_jti: Mapped[uuid.UUID | None] = mapped_column(Uuid)  # refresh token del login, para revocarlo al cerrar sesión
    creada_en: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    ultimo_uso: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    expira_en: Mapped[datetime] = mapped_column(DateTime(timezone=True))  # vencimiento absoluto
    revocada: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    ip: Mapped[str | None] = mapped_column(String(45))
    n4_desbloqueo_id: Mapped[uuid.UUID | None] = mapped_column(Uuid)  # desbloqueo 2FA de nivel 4 ligado a ESTA sesión (solo portal ciudadano); el token nunca sale del servidor
    __table_args__ = (
        CheckConstraint("sujeto_tipo IN ('persona', 'institucion', 'omega')", name="tipo_valido"),
        CheckConstraint("portal IN ('ciudadano', 'profesional', 'institucion', 'farmacia', 'laboratorio', 'universidad', 'omega')", name="portal_valido"),
        Index("ix_sesion_web_sujeto", "portal", "sujeto_tipo", "sujeto_id"),
    )
