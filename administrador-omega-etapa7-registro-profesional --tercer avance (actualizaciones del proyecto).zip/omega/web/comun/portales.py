"""Definición de los siete portales y de qué cuentas admite cada uno. Solo lee datos de omega_core; no decide permisos de negocio."""
from dataclasses import dataclass
from datetime import timedelta
from typing import Callable

from omega_core.config import settings
from omega_core.models import Institucion, Persona

SEGURA = settings.produccion or settings.hsts_activo  # con HTTPS: cookie Secure y prefijo __Secure-


@dataclass(frozen=True)
class Portal:
    slug: str
    nombre: str  # se muestra en la cabecera
    descripcion: str
    sujeto: str  # persona | institucion | omega: tipo de cuenta que inicia sesión aquí
    admite: Callable[[Persona | Institucion], bool]
    etiqueta_cuenta: str
    ingreso_en: str | None = None  # si se define, este portal NO tiene login propio: usa el de otro (ej. profesional → /ciudadano/ingresar)
    tipo_ingreso: str | None = None  # opción preseleccionada en ese login compartido
    ruta: str | None = None  # prefijo propio si no es /<slug> (Omega: ruta secreta)
    inactividad_min: int = 30  # expiración PROPIA del portal: minutos sin actividad
    absoluta_min: int = 480  # y vigencia máxima de la sesión

    @property
    def inactividad(self) -> timedelta:
        return timedelta(minutes=self.inactividad_min)

    @property
    def absoluta(self) -> timedelta:
        return timedelta(minutes=self.absoluta_min)

    @property
    def base(self) -> str:
        return self.ruta or f"/{self.slug}"

    @property
    def css(self) -> str:
        return f"{self.base}/static/portal.css" if self.ruta else f"/static/{self.slug}/portal.css"

    @property
    def carpeta_estatica(self) -> str:
        return f"{self.base}/static" if self.ruta else f"/static/{self.slug}"

    def url_ingreso(self, siguiente: str | None = None) -> str:
        url = self.ingreso_en or f"{self.base}/ingresar"
        extra = ([f"tipo={self.tipo_ingreso}"] if self.tipo_ingreso else []) + ([f"siguiente={siguiente}"] if siguiente else [])
        return url + ("?" + "&".join(extra) if extra else "")

    @property
    def cookie_sesion(self) -> str:
        return ("__Secure-" if SEGURA else "") + f"omega_{self.slug}"

    @property
    def cookie_csrf(self) -> str:
        return self.cookie_sesion + "_csrf"


def _persona(p) -> bool:
    return isinstance(p, Persona) and p.activo and not p.es_omega


def _profesional(p) -> bool:
    return _persona(p) and ((p.profesional is not None and p.profesional.activo) or (p.estudiante is not None and p.estudiante.activo))


def _solo_profesional(p) -> bool:
    return _persona(p) and p.profesional is not None and p.profesional.activo


def _solo_estudiante(p) -> bool:
    return _persona(p) and p.estudiante is not None and p.estudiante.activo


def _tipo(*tipos: str):
    return lambda i: isinstance(i, Institucion) and i.estado == "ACTIVA" and i.tipo in tipos


CIUDADANO = Portal("ciudadano", "Ciudadano", "Ciudadanos, profesionales de salud y estudiantes en práctica ingresan aquí.", "persona", _persona, "Persona")
PROFESIONAL = Portal("profesional", "Profesional", "Personal de salud y estudiantes en práctica.", "persona", _profesional, "Profesional de salud", ingreso_en="/ciudadano/ingresar", tipo_ingreso="profesional")
INSTITUCION = Portal("institucion", "Hospitales y clínicas", "Gestión institucional de hospitales y clínicas.", "institucion", _tipo("HOSPITAL", "CLINICA"), "Hospital o clínica")
FARMACIA = Portal("farmacia", "Farmacia", "Dispensación de recetas.", "institucion", _tipo("FARMACIA"), "Farmacia")
LABORATORIO = Portal("laboratorio", "Laboratorio", "Órdenes y resultados de laboratorio.", "institucion", _tipo("LABORATORIO"), "Laboratorio")
UNIVERSIDAD = Portal("universidad", "Universidad", "Prácticas y cofirma académica.", "institucion", _tipo("UNIVERSIDAD"), "Universidad")
OMEGA = Portal("omega", "Administrador Omega", "Administración nacional del sistema.", "omega", lambda p: isinstance(p, Persona) and p.activo and p.es_omega, "Administrador Omega",
              ruta=settings.omega_ruta_web, inactividad_min=settings.omega_token_minutos, absoluta_min=settings.omega_token_minutos * 3)

PUBLICOS = (CIUDADANO, PROFESIONAL, INSTITUCION, FARMACIA, LABORATORIO, UNIVERSIDAD)  # los que muestra el índice
PORTALES = PUBLICOS + (OMEGA,)  # todos los que se montan; Omega NUNCA aparece en el índice público

# Login único de personas: la opción elegida decide a qué portal se entra y qué perfil activo se exige.
PERFILES_ACCESO = {"ciudadano": (CIUDADANO, _persona, "ciudadano"), "profesional": (PROFESIONAL, _solo_profesional, "profesional de salud"), "estudiante": (PROFESIONAL, _solo_estudiante, "estudiante en práctica")}
