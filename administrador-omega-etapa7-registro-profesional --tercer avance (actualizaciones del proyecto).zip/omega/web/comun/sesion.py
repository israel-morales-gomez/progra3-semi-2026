"""Sesión web por portal: cookie opaca HttpOnly + SameSite=Strict con Path limitado al portal, sesión en base de datos y CSRF
por token firmado ligado a la cookie. El JWT nunca llega al navegador."""
import hashlib
import hmac
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse

from fastapi import Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from omega_core.auditoria.servicio import registrar as auditar
from omega_core.config import settings
from omega_core.database import get_db
from omega_core.deps import ip_permitida_omega
from omega_core.models import Institucion, Persona
from omega_core.security.ratelimit import ip_cliente
from omega_core.security.tokens import decodificar, obtener_refresh

from .models import SesionWeb
from .portales import SEGURA, Portal

def _hash(valor: str) -> str:
    return hashlib.sha256(valor.encode()).hexdigest()


def _ahora() -> datetime:
    return datetime.now(timezone.utc)


def poner_cookie(resp, portal: Portal, nombre: str, valor: str) -> None:
    # sin max_age: cookie de sesión del navegador; el vencimiento real lo decide el servidor. Path = solo la ruta de este portal.
    resp.set_cookie(nombre, valor, httponly=True, samesite="strict", secure=SEGURA, path=portal.base)


def borrar_cookie(resp, portal: Portal) -> None:
    resp.delete_cookie(portal.cookie_sesion, path=portal.base, httponly=True, samesite="strict", secure=SEGURA)


# ------------------------------------------------------------------ CSRF
def _base_csrf(request: Request, portal: Portal) -> str | None:
    return request.cookies.get(portal.cookie_sesion) or request.cookies.get(portal.cookie_csrf)


def firmar_csrf(portal: Portal, base: str) -> str:
    return hmac.new(settings.jwt_secret.encode(), f"csrf:{portal.slug}:{base}".encode(), hashlib.sha256).hexdigest()


def token_csrf(request: Request, portal: Portal) -> tuple[str, str | None]:
    """(token para formularios y HTMX, cookie CSRF nueva que hay que fijar en la respuesta o None)."""
    base, nueva = _base_csrf(request, portal), None
    if base is None:
        base = nueva = secrets.token_urlsafe(32)
    return firmar_csrf(portal, base), nueva


def _rechazar_csrf(request: Request, portal: Portal, motivo: str):
    auditar("WEB_CSRF_RECHAZADO", actor_tipo="anonimo", resultado="FALLO", ip=ip_cliente(request), detalle={"portal": portal.slug, "motivo": motivo, "ruta": request.url.path, "metodo": request.method})
    raise HTTPException(403, "Solicitud rechazada (token de seguridad inválido). Recargue la página e inténtelo de nuevo.")


def csrf_de(portal: Portal):
    async def formulario_csrf(request: Request) -> dict:
        """Dependencia de TODA petición web que cambia algo: exige el token (campo `csrf_token` o cabecera `X-CSRF-Token` de HTMX) y devuelve los campos del formulario."""
        origen = request.headers.get("origin")
        if origen and urlparse(origen).netloc != request.headers.get("host"):
            _rechazar_csrf(request, portal, "ORIGEN_DISTINTO")
        ctype = request.headers.get("content-type", "")
        campos = {k: v for k, v in (await request.form()).items() if isinstance(v, str)} if ctype.startswith(("application/x-www-form-urlencoded", "multipart/form-data")) else {}
        base = _base_csrf(request, portal)
        esperado = firmar_csrf(portal, base) if base else None
        enviados = [request.headers.get("x-csrf-token") or "", campos.get("csrf_token") or ""]  # basta que uno sea válido
        if esperado is None or not any(hmac.compare_digest(e, esperado) for e in enviados):
            _rechazar_csrf(request, portal, "TOKEN_AUSENTE_O_INVALIDO")
        return campos

    return formulario_csrf


# ------------------------------------------------------------------ Sesiones
class AccesoDenegado(Exception):
    """El login fue válido pero la cuenta no es de este portal."""


def cargar_sujeto(db: Session, tipo: str, sujeto_id: uuid.UUID) -> Persona | Institucion | None:
    return db.get(Institucion if tipo == "institucion" else Persona, sujeto_id)


def crear_sesion(db: Session, request: Request, portal: Portal, tokens: dict, admite=None) -> str:  # noqa: C901
    """Convierte un login ya validado por omega_core en una sesión de servidor SOLO si la cuenta pertenece al portal.
    Devuelve el valor de la cookie. El caller hace commit. Si la cuenta no es de este portal, revoca el refresh token emitido."""
    acceso = decodificar(tokens["access_token"], "access")
    tipo, sub = acceso["typ"], uuid.UUID(acceso["sub"])
    jti = uuid.UUID(decodificar(tokens["refresh_token"], "refresh")["jti"]) if tokens.get("refresh_token") else None
    sujeto = cargar_sujeto(db, tipo, sub)
    if tipo != portal.sujeto or sujeto is None or not (admite or portal.admite)(sujeto):
        if jti is not None:
            rt = obtener_refresh(db, jti)
            if rt is not None:
                rt.revocado = True
        auditar("WEB_ACCESO_DENEGADO", actor_tipo=tipo, actor_id=sub, resultado="FALLO", ip=ip_cliente(request), detalle={"portal": portal.slug})
        db.commit()
        raise AccesoDenegado()
    return abrir_sesion(db, request, portal, tipo, sub, jti)


def abrir_sesion(db: Session, request: Request, portal: Portal, tipo: str, sujeto_id: uuid.UUID, jti: uuid.UUID | None = None) -> str:
    """Fábrica de sesión de UN portal: valor opaco aleatorio (solo se guarda su hash) y vencimiento absoluto propio del portal. El caller hace commit."""
    valor = secrets.token_urlsafe(48)
    ahora = _ahora()
    db.execute(delete(SesionWeb).where(SesionWeb.expira_en < ahora - timedelta(days=1)))  # limpieza oportunista
    db.add(SesionWeb(portal=portal.slug, token_hash=_hash(valor), sujeto_tipo=tipo, sujeto_id=sujeto_id, refresh_jti=jti, expira_en=ahora + portal.absoluta, ip=ip_cliente(request)))
    return valor


class Sesion:
    """Sesión vigente + el sujeto (Persona o Institución) ya cargado y comprobado en esta petición."""

    def __init__(self, fila: SesionWeb, sujeto: Persona | Institucion):
        self.fila, self.sujeto, self.tipo = fila, sujeto, fila.sujeto_tipo

    @property
    def nombre(self) -> str:
        s = self.sujeto
        return s.nombre_legal if self.tipo == "institucion" else ("Administrador Omega" if self.tipo == "omega" else f"{s.nombres} {s.apellidos}")


class RedirigirALogin(Exception):
    def __init__(self, destino: str, portal: Portal):
        self.destino, self.portal = destino, portal


def siguiente_valido(portal: Portal, ruta: str | None) -> str:
    """Solo rutas internas DE ESTE PORTAL (evita open redirect y saltos entre portales); si no es válida, cadena vacía."""
    if ruta and ruta.startswith(portal.base + "/") and "//" not in ruta and "\\" not in ruta and "\n" not in ruta and "\r" not in ruta:
        return ruta
    return ""


def destino_seguro(portal: Portal, ruta: str | None) -> str:
    return siguiente_valido(portal, ruta) or f"{portal.base}/panel"


class Guardias:
    """Guardia de área de un portal: solo deja pasar sesiones abiertas EN este portal y con cuenta admitida por él."""

    def __init__(self, portal: Portal):
        self.portal = portal

        def opcional(request: Request, db: Session = Depends(get_db)) -> Sesion | None:
            valor = request.cookies.get(portal.cookie_sesion)
            if not valor:
                return None
            fila = db.scalar(select(SesionWeb).where(SesionWeb.token_hash == _hash(valor), SesionWeb.portal == portal.slug))
            ahora = _ahora()
            if fila is None or fila.revocada or fila.expira_en <= ahora or ahora - fila.ultimo_uso > portal.inactividad:
                return None
            sujeto = cargar_sujeto(db, fila.sujeto_tipo, fila.sujeto_id)
            if sujeto is None or fila.sujeto_tipo != portal.sujeto or not portal.admite(sujeto):
                return None  # cuenta desactivada, suspendida o que dejó de cumplir el perfil del portal
            if portal.sujeto == "omega" and not ip_permitida_omega(ip_cliente(request)):
                return None  # la IP de Omega se revalida en cada petición, como en la API
            if ahora - fila.ultimo_uso > timedelta(seconds=60):  # no se escribe en cada petición
                fila.ultimo_uso = ahora
                db.commit()
            return Sesion(fila, sujeto)

        def requiere(request: Request, sesion: Sesion | None = Depends(opcional)) -> Sesion:
            if sesion is None:
                siguiente = request.url.path + (f"?{request.url.query}" if request.url.query else "")
                raise RedirigirALogin(portal.url_ingreso(siguiente if request.method == "GET" and siguiente != f"{portal.base}/panel" else None), portal)
            return sesion

        self.opcional, self.requiere = opcional, requiere


def requiere_area(portal: Portal, permitido=None):
    """Guardia de un área de `portal`. Sin sesión válida de ESE portal → redirige al login propio (HTMX: 401 + HX-Redirect).
    Con sesión pero sin el permiso que pide `permitido(sesion)` → 403 (queda en bitácora). Se usa como Depends(requiere_area(PORTAL))."""
    g = Guardias(portal)

    def area(request: Request, sesion: Sesion = Depends(g.requiere)) -> Sesion:
        if permitido is not None and not permitido(sesion):
            auditar("WEB_AREA_DENEGADA", actor_tipo=sesion.tipo, actor_id=sesion.fila.sujeto_id, resultado="FALLO", ip=ip_cliente(request), detalle={"portal": portal.slug, "ruta": request.url.path})
            raise HTTPException(403, "Acceso denegado")
        return sesion

    return area


def manejar_redireccion(request: Request, exc: RedirigirALogin):
    resp = RedirectResponse(exc.destino, status_code=303)
    if request.headers.get("hx-request"):  # una petición HTMX no debe seguir la redirección dentro del fragmento
        resp = RedirectResponse(exc.destino, status_code=401)
        resp.headers["HX-Redirect"] = exc.destino
    borrar_cookie(resp, exc.portal)
    return resp


def cerrar_sesion(db: Session, request: Request, sesion: Sesion) -> None:
    sesion.fila.revocada = True
    if sesion.fila.n4_desbloqueo_id:  # el desbloqueo de nivel 4 se pierde con la sesión
        from portal_civil.router_expediente import revocar_desbloqueo
        revocar_desbloqueo(db, sesion.fila.n4_desbloqueo_id)
        sesion.fila.n4_desbloqueo_id = None
    if sesion.fila.refresh_jti:
        rt = obtener_refresh(db, sesion.fila.refresh_jti)
        if rt is not None:
            rt.revocado = True
    db.commit()
    auditar("WEB_SESION_CERRADA", actor_tipo=sesion.tipo, actor_id=sesion.fila.sujeto_id, recurso="sesion_web", recurso_id=sesion.fila.id, ip=ip_cliente(request), detalle={"portal": sesion.fila.portal})
