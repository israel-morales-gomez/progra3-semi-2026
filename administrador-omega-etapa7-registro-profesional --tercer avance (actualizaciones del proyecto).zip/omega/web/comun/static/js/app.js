// Componentes Alpine (build CSP: sin eval ni expresiones inline). Todo el JS propio vive aquí.
document.addEventListener("alpine:init", () => {
  Alpine.data("navegacion", () => ({
    abierto: false,
    alternar() { this.abierto = !this.abierto; },
    get expandido() { return this.abierto ? "true" : "false"; },
    get claseMenu() { return this.abierto ? "abierto" : ""; },
  }));
  // Formulario de perfil: el botón Guardar solo se habilita cuando algo cambió respecto a lo que se cargó.
  Alpine.data("formularioPerfil", () => ({
    inicial: "",
    cambiado: false,
    serializar() { return Array.from(new FormData(this.$root).entries()).filter((par) => par[0] !== "csrf_token").map((par) => par.join("=")).join("&"); },
    init() { this.inicial = this.serializar(); this.cambiado = this.$root.dataset.sucio === "1"; },
    revisar() { this.cambiado = this.serializar() !== this.inicial; },
    get sinCambios() { return !this.cambiado; },
    get textoEstado() { return this.cambiado ? "Tiene cambios sin guardar" : "Sin cambios"; },
  }));
  // Aviso de confirmación: se cierra solo a los pocos segundos o con la ×.
  Alpine.data("aviso", () => ({
    visible: true,
    cerrar() { this.visible = false; },
    init() { setTimeout(() => { this.visible = false; }, 6000); },
  }));
  Alpine.data("clave", () => ({
    visible: false,
    alternar() { this.visible = !this.visible; },
    get tipo() { return this.visible ? "text" : "password"; },
    get etiqueta() { return this.visible ? "Ocultar" : "Mostrar"; },
  }));
});
