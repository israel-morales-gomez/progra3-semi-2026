"""Rutas de ingreso y salida compartidas por los portales. No contienen reglas de negocio: llaman a las mismas funciones de omega_core
(login, 2FA, TOTP de Omega) y muestran su resultado, así que heredan límites de intentos, bloqueos, anti-repetición y bitácora."""
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from pydantic import ValidationError
from sqlalchemy.orm import Session

from omega_core.database import get_db
from omega_core.routers import auth, omega
from omega_core.schemas import LoginInstitucion, LoginOmega, LoginPersona, Verificar2FA
from omega_core.security.ratelimit import ip_cliente
from omega_core.auditoria.servicio import registrar as auditar
from omega_core.security.tokens import decodificar

from . import sesion as ses
from .portales import PERFILES_ACCESO, Portal
from .sesion import AccesoDenegado, Guardias, Sesion, csrf_de, destino_seguro, siguiente_valido
from .vista import Vista

SIN_ACCESO = "Esta cuenta no tiene acceso a este portal."


def iniciar_sesion(db: Session, request: Request, portal: Portal, tokens: dict, siguiente: str | None, admite=None) -> RedirectResponse:
    """El login ya fue validado por omega_core: aquí solo se abre la sesión web (cookie nueva = sin fijación de sesión)."""
    valor = ses.crear_sesion(db, request, portal, tokens, admite)
    db.commit()
    a = decodificar(tokens["access_token"], "access")
    auditar("WEB_SESION_INICIADA", actor_tipo=a["typ"], actor_id=a["sub"], ip=ip_cliente(request), detalle={"portal": portal.slug})
    resp = RedirectResponse(destino_seguro(portal, siguiente), status_code=303)
    ses.poner_cookie(resp, portal, portal.cookie_sesion, valor)
    return resp


def instalar_ingreso(router: APIRouter, portal: Portal, vista: Vista, g: Guardias) -> None:
    csrf = csrf_de(portal)
    base = portal.base
    compartido = portal.ingreso_en is not None  # sin login propio (profesional): entra por el login único de personas
    login_persona = portal.sujeto == "persona" and not compartido  # el login único: ciudadano · profesional · estudiante

    def _siguiente(s):  # el login único admite destinos de cualquiera de los dos portales de personas
        return siguiente_valido(portal, s) or (siguiente_valido(PERFILES_ACCESO["profesional"][0], s) if login_persona else "")

    def _tipo_inicial(tipo, s):
        return tipo if tipo in PERFILES_ACCESO else ("profesional" if (s or "").startswith("/profesional/") else "ciudadano")
    plantilla = {"persona": "ingresar_persona.html", "institucion": "ingresar_institucion.html", "omega": "ingresar_omega.html"}[portal.sujeto]  # profesional no la usa (redirige)

    @router.get("")
    def inicio(sesion: Sesion | None = Depends(g.opcional)):
        return RedirectResponse(f"{base}/panel" if sesion else portal.url_ingreso(), status_code=303)

    @router.get("/ingresar")
    def pagina(request: Request, siguiente: str | None = None, registrado: int = 0, salio: int = 0, tipo: str | None = None, sesion: Sesion | None = Depends(g.opcional)):
        if sesion:
            return RedirectResponse(f"{base}/panel", status_code=303)
        if compartido:  # profesional: no hay formulario aquí, se va al login único conservando la opción y el destino
            return RedirectResponse(portal.url_ingreso(siguiente_valido(portal, siguiente) or None), status_code=303)
        s = _siguiente(siguiente)
        return vista.render(request, plantilla, siguiente=s, tipo=_tipo_inicial(tipo, s), registrado=bool(registrado), salio=bool(salio))

    def _error(request, status, mensaje, **ctx):
        return vista.render(request, plantilla, status=status, error=mensaje, **ctx)

    def _abrir_persona(db, request, tokens, siguiente, tipo, dui):
        """Login único de personas: el tipo elegido decide el portal. Si es profesional o estudiante y el perfil activo se confirma, el proceso termina en su panel."""
        destino, admite, etiqueta = PERFILES_ACCESO[tipo]
        try:
            return iniciar_sesion(db, request, destino, tokens, siguiente, admite)
        except AccesoDenegado:
            msg = SIN_ACCESO if tipo == "ciudadano" else f"Esta cuenta no está registrada como {etiqueta}. Elija «Ciudadano» o verifique su perfil."
            return _error(request, 403, msg, tipo=tipo, dui=dui, siguiente=_siguiente(siguiente))

    def _abrir(db, request, tokens, siguiente, **ctx):
        try:
            return iniciar_sesion(db, request, portal, tokens, siguiente)
        except AccesoDenegado:
            return _error(request, 403, SIN_ACCESO, **ctx)

    if login_persona:

        @router.post("/ingresar")
        def entrar(request: Request, campos: dict = Depends(csrf), db: Session = Depends(get_db)):
            siguiente, dui = campos.get("siguiente"), campos.get("dui", "")[:20]
            tipo = campos.get("tipo") or "ciudadano"
            ctx = dict(dui=dui, siguiente=_siguiente(siguiente), tipo=_tipo_inicial(tipo, siguiente))
            if tipo not in PERFILES_ACCESO:
                return _error(request, 422, "Seleccione si ingresa como ciudadano, profesional o estudiante.", **ctx)
            try:
                r = auth.login_persona(LoginPersona(dui=campos.get("dui", ""), password=campos.get("password", "")), request, db)
            except ValidationError:
                return _error(request, 401, "Credenciales inválidas", **ctx)
            except HTTPException as e:
                return _error(request, e.status_code, e.detail, **ctx)
            return _abrir_persona(db, request, r.tokens.model_dump(), siguiente, tipo, dui)

    elif portal.sujeto == "institucion":

        @router.post("/ingresar")
        def entrar(request: Request, campos: dict = Depends(csrf), db: Session = Depends(get_db)):
            ident = campos.get("identificador", "")[:40]
            try:
                r = auth.login_institucion(LoginInstitucion(identificador=campos.get("identificador", ""), password=campos.get("password", "")), request, db)
            except ValidationError:
                return _error(request, 401, "Credenciales inválidas", identificador=ident)
            except HTTPException as e:
                return _error(request, e.status_code, e.detail, identificador=ident)
            if r.requiere_2fa:
                return vista.render(request, "ingresar_2fa.html", desafio_id=str(r.desafio_id))
            return _abrir(db, request, r.tokens.model_dump(), None, identificador=ident)

        @router.post("/ingresar/2fa")
        def verificar_codigo(request: Request, campos: dict = Depends(csrf), db: Session = Depends(get_db)):
            desafio = campos.get("desafio_id", "")
            try:
                r = auth.verificar_2fa(Verificar2FA(desafio_id=desafio, codigo=campos.get("codigo", "").strip()), request, db)
            except ValidationError:
                return vista.render(request, "ingresar_2fa.html", status=401, error="Código inválido o vencido", desafio_id=desafio)
            except HTTPException as e:
                return vista.render(request, "ingresar_2fa.html", status=e.status_code, error=e.detail, desafio_id=desafio)
            try:
                return iniciar_sesion(db, request, portal, r.tokens.model_dump(), None)
            except AccesoDenegado:
                return _error(request, 403, SIN_ACCESO)

    elif portal.sujeto == "omega":  # contraseña + TOTP

        @router.post("/ingresar")
        def entrar(request: Request, campos: dict = Depends(csrf), db: Session = Depends(get_db)):
            dui = campos.get("dui", "")[:20]
            try:
                t = omega.login_omega(LoginOmega(dui=campos.get("dui", ""), password=campos.get("password", ""), totp=campos.get("totp", "").strip()), request, db)
            except ValidationError:
                return _error(request, 401, "Credenciales inválidas", dui=dui)
            except HTTPException as e:
                return _error(request, e.status_code, e.detail, dui=dui)
            return _abrir(db, request, t.model_dump(), None, dui=dui)

    @router.post("/salir")
    def salir(request: Request, sesion: Sesion = Depends(g.requiere), _: dict = Depends(csrf), db: Session = Depends(get_db)):
        ses.cerrar_sesion(db, request, sesion)
        resp = RedirectResponse(portal.url_ingreso() + ("&" if "?" in portal.url_ingreso() else "?") + "salio=1", status_code=303)
        ses.borrar_cookie(resp, portal)
        return resp
