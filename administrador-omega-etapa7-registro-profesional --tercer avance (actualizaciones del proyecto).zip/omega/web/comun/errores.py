"""Páginas de error 403, 404, 405 y 500 para navegadores (Accept: text/html). Mensajes fijos: nunca muestran rutas, trazas, SQL ni detalles internos.
Quien no pide HTML (API, pruebas, curl) recibe el JSON de siempre."""
from fastapi import FastAPI, Request
from fastapi.exception_handlers import http_exception_handler
from fastapi.responses import JSONResponse, Response
from fastapi.templating import Jinja2Templates
from starlette.exceptions import HTTPException as StarletteHTTPException

from pathlib import Path

PLANTILLAS = Jinja2Templates(directory=str(Path(__file__).parent / "templates"))
TEXTOS = {
    403: ("Acceso denegado", "No tiene permiso para ver esta página o la solicitud venció. Recargue la página e inténtelo de nuevo."),
    404: ("Página no encontrada", "La página que busca no existe o ya no está disponible."),
    405: ("Acción no disponible", "Esta acción no está permitida en esta dirección."),
    500: ("Error del sistema", "Ocurrió un problema de nuestro lado. Inténtelo de nuevo en unos minutos."),
}
_RUTAS_DOCS = ("/docs", "/redoc", "/openapi.json")


def _quiere_html(request: Request) -> bool:
    return "text/html" in request.headers.get("accept", "") and not request.url.path.startswith(_RUTAS_DOCS)


def pagina_error(request: Request, codigo: int) -> Response:
    from omega_core.app import CSP_HTML  # import tardío: omega_core.app instala este módulo

    titulo, mensaje = TEXTOS[codigo]
    resp = PLANTILLAS.TemplateResponse(request, "error.html", {"codigo": codigo, "titulo": titulo, "mensaje": mensaje}, status_code=codigo)
    resp.headers.update({"Content-Security-Policy": CSP_HTML, "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer"})
    return resp  # las cabeceras van aquí también porque un 500 no pasa por el middleware de cabeceras


def instalar_errores(app: FastAPI) -> None:
    async def http_error(request: Request, exc: StarletteHTTPException):
        if exc.status_code in TEXTOS and _quiere_html(request):
            return pagina_error(request, exc.status_code)
        return await http_exception_handler(request, exc)

    async def error_interno(request: Request, exc: Exception):  # la traza la registra el servidor; el cliente no ve nada interno
        if _quiere_html(request):
            return pagina_error(request, 500)
        return JSONResponse({"detail": "Error interno"}, status_code=500)

    app.add_exception_handler(StarletteHTTPException, http_error)
    app.add_exception_handler(Exception, error_interno)
