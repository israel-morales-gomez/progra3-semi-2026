"""Plantillas de un portal: busca primero en la carpeta del portal y después en comun. Inyecta el token CSRF, el portal y la sesión."""
from pathlib import Path

from fastapi import Request
from fastapi.templating import Jinja2Templates

from . import sesion as ses
from .portales import Portal

COMUN = Path(__file__).parent


class Vista:
    def __init__(self, portal: Portal, carpeta: Path):
        self.portal = portal
        self.plantillas = Jinja2Templates(directory=[str(carpeta / "templates"), str(COMUN / "templates")])

    def render(self, request: Request, nombre: str, sesion: "ses.Sesion | None" = None, status: int = 200, **ctx):
        token, cookie_nueva = ses.token_csrf(request, self.portal)
        resp = self.plantillas.TemplateResponse(request, nombre, {"portal": self.portal, "csrf_token": token, "sesion": sesion, **ctx}, status_code=status)
        if cookie_nueva:
            ses.poner_cookie(resp, self.portal, self.portal.cookie_csrf, cookie_nueva)
        return resp
