from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .portales import PORTALES, PUBLICOS
from .errores import instalar_errores
from .sesion import RedirigirALogin, manejar_redireccion

RAIZ = Path(__file__).resolve().parent.parent


def instalar_frontend(app: FastAPI) -> None:
    """Monta los estáticos (htmx, Alpine y CSS propios), los siete portales (Omega en su ruta secreta) y el manejo de 'sin sesión → login de ESE portal'."""
    from web.ciudadano.router import router as ciudadano
    from web.farmacia.router import router as farmacia
    from web.institucion.router import router as institucion
    from web.laboratorio.router import router as laboratorio
    from web.omega.router import router as omega
    from web.profesional.router import router as profesional
    from web.universidad.router import router as universidad

    for p in PORTALES:  # CSS propio de cada portal (se monta antes que /static). Omega: bajo su ruta secreta, no en /static/omega
        app.mount(p.carpeta_estatica, StaticFiles(directory=str(RAIZ / p.slug / "static")), name=f"static_{p.slug}")
    app.mount("/static", StaticFiles(directory=str(RAIZ / "comun" / "static")), name="static")
    app.add_exception_handler(RedirigirALogin, manejar_redireccion)
    instalar_errores(app)
    entrada = Jinja2Templates(directory=str(RAIZ / "comun" / "templates"))

    @app.get("/", include_in_schema=False)
    def raiz(request: Request):  # índice neutro, sin sesión: no pertenece a ningún portal
        return entrada.TemplateResponse(request, "entrada.html", {"portales": PUBLICOS})

    @app.get("/favicon.ico", include_in_schema=False)
    def favicon():
        return Response(status_code=204)

    for r in (ciudadano, profesional, institucion, farmacia, laboratorio, universidad, omega):
        app.include_router(r)
