"""Piezas compartidas por los portales: sesión, CSRF, vista, rutas de ingreso y guardias de área."""
