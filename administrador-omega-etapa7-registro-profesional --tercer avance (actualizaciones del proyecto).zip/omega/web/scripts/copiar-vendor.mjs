// Copia htmx y Alpine (build compatible con CSP, sin eval) desde node_modules a comun/static/vendor.
// Uso:  cd web && npm install && npm run vendor
import { copyFileSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";

mkdirSync("comun/static/vendor", { recursive: true });
const archivos = [
  ["node_modules/htmx.org/dist/htmx.min.js", "comun/static/vendor/htmx.min.js"],
  ["node_modules/@alpinejs/csp/dist/cdn.min.js", "comun/static/vendor/alpine.csp.min.js"],
];
const lineas = [];
for (const [origen, destino] of archivos) {
  copyFileSync(origen, destino);
  const hash = createHash("sha256").update(readFileSync(destino)).digest("hex");
  lineas.push(`${hash}  ${destino.replace("comun/static/", "")}`);
}
writeFileSync("comun/static/vendor/SHA256SUMS", lineas.join("\n") + "\n");
console.log(lineas.join("\n"));
